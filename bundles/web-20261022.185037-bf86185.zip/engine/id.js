// Who this phone is and which modules it may open (DISTRIBUTION-PLAN.md, id/README.md), like the PC's hub/api/id.mjs.
// Shivam, 21 Oct 2026: a phone opens nothing without an invite code, phones that had the app need one too, and the
// owner-only modules (Insights, Oracle TM) only come with the owner customer's codes.
// The phone joins with a code: it makes its own key pair (WebCrypto P-256; the private key is kept in IndexedDB and
// can't be read out) and gets a signed pass (24 hours) listing its modules, renewed with that key every 6 hours and
// whenever the app comes back; offline it keeps working 7 days past its end. The pass is checked here with shivo-id's
// public key (the same as hub/id-key.json).
import * as store from './store.js';
import { plugin } from './native.js';

export const ID_API = 'https://shivo-id.ishivamparmar.workers.dev';
const PASS_KEY = { kty: 'EC', crv: 'P-256', x: 'fDqQze_0UkWTaFU0x3cLeyVh8SAwK1Xr2TZsLAaro5I', y: 'DM847YuriqmGL7zpLKGKJgAVXBPfTRrGUWJ-okLI1rY' };
const GRACE = 7 * 86400e3, RENEW = 6 * 3600e3;
// the phone app's screens -> shivo-id's modules (Tasks are Labs AI's; Cloud is "files")
export const MODULE_OF = { ai: 'ai', cloud: 'ai', tasks: 'ai', chat: 'chat', beam: 'files', tv: 'tv', camera: 'camera', phone: 'phone', insights: 'insights', oracle: 'oracle' };

const ECDSA = { name: 'ECDSA', namedCurve: 'P-256' }, SIGN = { name: 'ECDSA', hash: 'SHA-256' };
const enc = (s) => new TextEncoder().encode(s);
const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), (c) => c.charCodeAt(0));

// the private key, in IndexedDB (a CryptoKey that can't be exported)
const db = () => new Promise((ok, no) => { const r = indexedDB.open('shivo-id', 1); r.onupgradeneeded = () => r.result.createObjectStore('keys'); r.onsuccess = () => ok(r.result); r.onerror = () => no(r.error); });
async function keyGet() { const d = await db(); return new Promise((ok) => { const r = d.transaction('keys').objectStore('keys').get('device'); r.onsuccess = () => ok(r.result || null); r.onerror = () => ok(null); }); }
async function keyPut(k) { const d = await db(); return new Promise((ok, no) => { const t = d.transaction('keys', 'readwrite'); t.objectStore('keys').put(k, 'device'); t.oncomplete = () => ok(); t.onerror = () => no(t.error); }); }

let pub = null;
async function readPass(p) {
  try {
    const [data, sig] = String(p).split('.');
    pub ||= await crypto.subtle.importKey('jwk', PASS_KEY, ECDSA, false, ['verify']);
    if (!(await crypto.subtle.verify(SIGN, pub, unb64u(sig), enc(data)))) return null;
    return JSON.parse(new TextDecoder().decode(unb64u(data)));
  } catch { return null; }
}

let cur = null;   // {device, customer, modules: Set, exp}
export const state = () => cur;
// may this phone open that screen? (a screen id from app.js MODULES)
export const may = (screen) => !!cur && cur.modules.has(MODULE_OF[screen] || screen);

async function load() {
  const s = store.get('sl.id', null);
  const b = s?.pass && (await readPass(s.pass));
  cur = b && b.device === s.device && Date.now() <= b.exp + GRACE ? { device: s.device, customer: b.name, modules: new Set(b.modules), exp: b.exp } : null;
  return cur;
}

async function post(path, body) {
  let r;
  try { r = await fetch(ID_API + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); }
  catch { throw new Error("Can't reach Shivo Labs. Check the internet."); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error || `Shivo Labs answered ${r.status}`); e.status = r.status; e.removed = !!j.removed; throw e; }
  return j;
}

// the code from the invite: joins this phone; returns {customer, modules}
export async function enrol(code) {
  if (!crypto?.subtle) throw new Error("This phone can't make its key. Update the app from the download page.");
  // the private half can't be exported, kept in IndexedDB; where a WebView can't keep a key there, an exportable one
  // goes into the app's own storage instead (still only on this phone)
  let kp = await crypto.subtle.generateKey(ECDSA, false, ['sign', 'verify']), inDb = true;
  try { await keyPut(kp.privateKey); } catch { inDb = false; kp = await crypto.subtle.generateKey(ECDSA, true, ['sign', 'verify']); }
  const key = await crypto.subtle.exportKey('jwk', kp.publicKey);
  let name = 'Phone';
  try { const i = await plugin('Device')?.getInfo(); name = [i?.manufacturer, i?.model].filter(Boolean).join(' ') || name; } catch {}
  const r = await post('/enrol', { code: String(code).replace(/[^a-z0-9]/gi, ''), kind: 'phone', name, key: { kty: key.kty, crv: key.crv, x: key.x, y: key.y }, version: '' });
  if (inDb) store.del('sl.idkey'); else store.set('sl.idkey', await crypto.subtle.exportKey('jwk', kp.privateKey));
  store.set('sl.id', { device: r.device, pass: r.pass });
  await load();
  return { customer: r.customer, modules: r.modules };
}

// a new pass with this phone's key; returns true when what the phone may open changed
export async function renew() {
  const s = store.get('sl.id', null); if (!s?.device) return false;
  const before = [...(cur?.modules || [])].sort().join();
  try {
    const jwk = store.get('sl.idkey', null);
    const k = jwk ? await crypto.subtle.importKey('jwk', jwk, ECDSA, false, ['sign']) : await keyGet().catch(() => null);
    if (!k) throw new Error('no key');
    let ts = Date.now();
    try { const j = await (await fetch(ID_API + '/now', { cache: 'no-store' })).json(); if (j.now) ts = j.now; } catch {}   // its clock, not the phone's
    const sig = b64u(await crypto.subtle.sign(SIGN, k, enc(`${s.device}.${ts}`)));
    const r = await post('/pass', { device: s.device, ts, sig, version: '' });
    store.set('sl.id', { ...s, pass: r.pass });
  } catch (e) {
    if (e.removed) store.set('sl.id', { device: s.device, pass: null });   // removed by the owner: no modules from now on
  }
  await load();
  return before !== [...(cur?.modules || [])].sort().join();
}

let last = 0;
// at start: the pass as it is (no waiting for the internet); a renew follows in the background. onChange when the
// modules change (the owner changed them, or removed this phone).
export async function start(onChange) {
  await load();
  const go = async () => { if (Date.now() - last < 60e3) return; last = Date.now(); if (await renew()) onChange?.(cur); };
  go();
  setInterval(go, RENEW);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && Date.now() - last > 15 * 60e3) go(); });
  return cur;
}
