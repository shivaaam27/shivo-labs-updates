// Shivo Labs Cloud on the phone (files/PLAN.md): joining the PC's account, browsing, opening and adding files. All of
// it is encrypted and decrypted here, on the phone (files/FORMAT.md), as on the PC and in the Files app's location
// (ShivoFiles extension). Joining happens on the home Wi-Fi only, through the PC's sending engine, with a key exchange
// nobody in between can read (files/FORMAT.md, "Joining a phone").
import { plugin } from './native.js';
import * as beam from './beam.js';

const KEY = 'sl.cloud';
const enc = new TextEncoder(), dec = new TextDecoder();
const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = (s) => { const t = String(s).replace(/-/g, '+').replace(/_/g, '/'); return Uint8Array.from(atob(t + '='.repeat((4 - (t.length % 4)) % 4)), (c) => c.charCodeAt(0)); };

export const creds = () => { try { return JSON.parse(localStorage.getItem(KEY)) || null; } catch { return null; } };
const store = (c) => { try { localStorage.setItem(KEY, JSON.stringify(c)); } catch {} };

// hand the details to the Files app's Shivo Cloud location (once per app start, and after joining)
let shared = false;
export async function share(force = false) {
  const c = creds(), N = plugin('ShivoNative');
  if (!c || !N?.cloudShare || (shared && !force)) return null;
  try { const i = await N.info(); if (!i.cloudFiles) return null; } catch { return null; }
  shared = true;
  return N.cloudShare({ api: c.api, token: c.token, master: c.master, account: c.account });
}

// join the PC's Shivo Cloud: ECDH P-256 with the hub, through Beam on the home Wi-Fi
export async function join() {
  const lan = await beam.lanForJoin();   // throws when the PC isn't on this Wi-Fi
  const pair = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
  const pub = b64u(await crypto.subtle.exportKey('raw', pair.publicKey));
  const r = await fetch(`${lan.base}/files/join?k=${encodeURIComponent(lan.key)}&bid=${encodeURIComponent(lan.bid)}`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, cache: 'no-store',
    body: JSON.stringify({ pub, name: lan.name || 'iPhone', kind: beam.deviceKind() }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `The PC answered ${r.status}`);
  const hub = await crypto.subtle.importKey('raw', unb64u(j.pub), { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const secret = await crypto.subtle.deriveBits({ name: 'ECDH', public: hub }, pair.privateKey, 256);
  const hk = await crypto.subtle.importKey('raw', secret, 'HKDF', false, ['deriveKey']);
  const key = await crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: enc.encode('shivo-files-join'), info: enc.encode('v1') },
    hk, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
  const box = unb64u(j.box);
  const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: box.slice(0, 12), additionalData: enc.encode('shivo-join') }, key, box.slice(12));
  const c = JSON.parse(dec.decode(plain));
  if (!c.token || !c.master || !c.api) throw new Error("The PC's answer was incomplete");
  store(c);
  const s = await share(true);
  return { ...c, files: s };
}

export function forget() { try { localStorage.removeItem(KEY); } catch {} shared = false; }

async function call(path, { method = 'GET', body, raw } = {}) {
  const c = creds(); if (!c) throw new Error('Not connected');
  const r = await fetch(c.api + path, { method, cache: 'no-store', body: raw ?? (body ? JSON.stringify(body) : undefined),
    headers: { authorization: 'Bearer ' + c.token, ...(body ? { 'content-type': 'application/json' } : {}) } });
  if (r.status === 401) { forget(); throw new Error("This phone was removed from Shivo Labs Cloud. Connect again on the PC's Wi-Fi."); }
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || `Shivo Labs Cloud answered ${r.status}`);
  return r;
}
const api = async (path, opts) => (await call(path, opts)).json();
// names are encrypted on the server: read them with the master key
async function names(items) {
  const k = await crypto.subtle.importKey('raw', unb64u(creds().master), 'AES-GCM', false, ['decrypt']);
  return Promise.all(items.map(async (it) => {
    let name = '?';
    try {
      const box = unb64u(String(it.name).slice(3));
      name = dec.decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: box.slice(0, 12), additionalData: enc.encode('shivo-name') }, k, box.slice(12)));
    } catch {}
    return { ...it, name };
  }));
}
export const status = () => api('/v1/me');
// folders first, then the newest
const order = (a, b) => (a.kind === b.kind ? (b.mtime || 0) - (a.mtime || 0) || a.name.localeCompare(b.name) : a.kind === 'folder' ? -1 : 1);
export async function list(parent = '') { return (await names((await api('/v1/items?parent=' + encodeURIComponent(parent))).items)).sort(order); }
export const top = () => list('');
// everything (for search): the whole account, read once a minute at most
let every = null;
export async function all() {
  if (every && Date.now() - every.at < 60000) return every.items;
  const out = new Map();
  for (let since = 0, more = true; more; ) { const j = await api('/v1/changes?since=' + since); for (const it of j.items) out.set(it.id, it); since = j.seq; more = j.more; }
  const items = await names([...out.values()].filter((it) => !it.deleted));
  every = { at: Date.now(), items };
  return items;
}
export async function search(q) {
  const items = await all(), byId = new Map(items.map((it) => [it.id, it])), t = q.trim().toLowerCase();
  const where = (it) => { const p = []; for (let at = byId.get(it.parent); at && p.length < 20; at = byId.get(at.parent)) p.unshift(at.name); return p.join(' › '); };
  return items.filter((it) => it.name.toLowerCase().includes(t)).sort(order).slice(0, 200).map((it) => ({ ...it, where: where(it) }));
}

// ---------- the format (files/FORMAT.md), the same as the PC's
const cat = (...a) => { const o = new Uint8Array(a.reduce((n, x) => n + x.length, 0)); let i = 0; for (const x of a) { o.set(x, i); i += x.length; } return o; };
const u32 = (n) => { const b = new Uint8Array(4); new DataView(b.buffer).setUint32(0, n); return b; };
const aes = (raw, use) => crypto.subtle.importKey('raw', raw, 'AES-GCM', false, [use]);
const CHUNK = 1048576;
async function seal(raw, plain, aad) { const n = crypto.getRandomValues(new Uint8Array(12)); return cat(n, new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: n, additionalData: enc.encode(aad) }, await aes(raw, 'encrypt'), plain))); }
async function open(raw, box, aad) { return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: box.slice(0, 12), additionalData: enc.encode(aad) }, await aes(raw, 'decrypt'), box.slice(12))); }
const master = () => unb64u(creds().master);
async function decryptSC1(key, box) {
  const k = await aes(key, 'decrypt');
  if (box.length < 16 || box[0] !== 0x53 || box[1] !== 0x43 || box[2] !== 0x31) throw new Error('Not a Shivo Labs Cloud file');
  const header = box.slice(0, 16), size = new DataView(header.buffer).getUint32(4), prefix = header.slice(8, 16), out = [];
  for (let at = 16, i = 0; ; i++) {
    const end = Math.min(at + size + 16, box.length), last = end === box.length;
    out.push(new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: cat(prefix, u32(i)), additionalData: cat(header, u32(i), new Uint8Array([last ? 1 : 0])) }, k, box.slice(at, end))));
    at = end; if (last) return out;
  }
}
async function encryptSC1(key, plain) {
  const k = await aes(key, 'encrypt'), prefix = crypto.getRandomValues(new Uint8Array(8)), header = cat(new Uint8Array([0x53, 0x43, 0x31, 0]), u32(CHUNK), prefix), out = [header];
  const n = Math.max(1, Math.ceil(plain.length / CHUNK));
  for (let i = 0; i < n; i++) out.push(new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: cat(prefix, u32(i)), additionalData: cat(header, u32(i), new Uint8Array([i === n - 1 ? 1 : 0])) }, k, plain.subarray(i * CHUNK, (i + 1) * CHUNK))));
  return cat(...out);
}

// a file's plain bytes (pieces, ready for a Blob)
export async function read(item) {
  const it = await api('/v1/item/' + item.id);
  const key = await open(master(), unb64u(String(it.key).slice(3)), 'shivo-key');
  return decryptSC1(key, new Uint8Array(await (await call('/v1/file/' + item.id)).arrayBuffer()));
}
// a file from the phone into a folder (onPart: 0..1)
export async function add(parent, file, onPart) {
  const plain = new Uint8Array(await file.arrayBuffer()), fileKey = crypto.getRandomValues(new Uint8Array(32));
  const box = await encryptSC1(fileKey, plain);
  const start = await api('/v1/uploads', { method: 'POST', body: { parent, name: 'n1.' + b64u(await seal(master(), enc.encode(file.name), 'shivo-name')),
    key: 'k1.' + b64u(await seal(master(), fileKey, 'shivo-key')), size: plain.length, stored: box.length } });
  const q = `?upload=${encodeURIComponent(start.upload)}&object=${encodeURIComponent(start.object)}`, parts = [];
  try {
    for (let i = 0, n = 1; ; i += start.part, n++) {
      parts.push(await api(`/v1/uploads/${start.item}/${n}${q}`, { method: 'PUT', raw: box.subarray(i, i + start.part) }));
      onPart?.(Math.min(1, (i + start.part) / box.length));
      if (i + start.part >= box.length) break;
    }
    every = null;
    return api(`/v1/uploads/${start.item}/done`, { method: 'POST', body: { upload: start.upload, object: start.object, parts } });
  } catch (e) { call(`/v1/uploads/${start.item}${q}`, { method: 'DELETE' }).catch(() => {}); throw e; }
}
// the top folder with this name (the PC's Beam folder), or ''
export async function folderNamed(name) { return (await top()).find((it) => it.kind === 'folder' && it.name === name)?.id || ''; }
