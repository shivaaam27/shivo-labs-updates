// Beam inside the phone app: send photos and files to the PC, and receive what the PC sends.
// Talks straight to Beam on the PC over the shared Wi-Fi (beam.local:8765). Nothing goes online.
// The first time, Beam on the PC asks its owner to accept this phone (like AirDrop).
// Received photos and videos go into Photos; other files go into the Files app
// (On My iPhone > Shivo Labs > Beam).
import { plugin } from './native.js';

export const SHARE_URL = 'https://shivamparmar.vercel.app/beam';
let host = 'beam.local';
export const setHost = (h) => { host = String(h || 'beam.local').trim().replace(/^https?:\/\//, '').replace(/[:/].*$/, '') || 'beam.local'; };
const base = () => `http://${host}:8765`;

async function call(path, opts = {}, ms = 8000) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await fetch(base() + path, { ...opts, signal: ctl.signal, cache: 'no-store' });
    if (r.status === 403) throw new Error('Not accepted on the PC yet. Click Accept on the PC, then try again.');
    if (r.status === 401) throw new Error('The PC did not accept this phone. Try again and click Accept on the PC.');
    return r;
  } catch (e) {
    if (e.name === 'AbortError' || e instanceof TypeError) throw new Error("Can't reach Beam. Check Beam is open on the PC and both are on the same Wi-Fi.");
    throw e;
  } finally { clearTimeout(t); }
}

// Is Beam there? Returns the PC's name. The first call may wait while the owner clicks Accept.
export async function ping() {
  const r = await call('/ping', {}, 75000);
  if (!r.ok) throw new Error('Beam answered ' + r.status);
  return (await r.json()).pc || 'PC';
}

export async function waiting() {
  const r = await call('/outbox', {}, 75000);
  return r.ok ? r.json() : [];
}

// Send files (from an <input type=file>) one by one; onStep(done, total, name) for progress.
export async function send(files, onStep) {
  let n = 0;
  for (const f of files) {
    onStep?.(n, files.length, f.name);
    const fd = new FormData(); fd.append('file', f, f.name);
    const r = await call('/upload', { method: 'POST', body: fd }, 10 * 60000);
    if (!r.ok) throw new Error((await r.text()) || 'Upload failed');
    n++;
  }
  return n;
}

// Save everything waiting on the PC: photos and videos to Photos, the rest to Files.
export async function receiveAll(onStep) {
  const FS = plugin('Filesystem'), M = plugin('Media');
  if (!FS) throw new Error('Saving files only works in the installed app.');
  const items = await waiting(); let done = 0, photos = 0;
  for (const it of items) {
    onStep?.(done, items.length, it.name);
    const url = base() + '/file/' + encodeURIComponent(it.name);
    if (it.kind === 'media' && M) {
      // Download into the app first, then hand the local file to Photos.
      const rel = 'beam-tmp/' + it.name;
      await FS.downloadFile({ url, path: rel, directory: 'CACHE', recursive: true });
      const { uri } = await FS.getUri({ path: rel, directory: 'CACHE' });
      await (/\.(mov|mp4|m4v|avi|mkv|webm|3gp)$/i.test(it.name) ? M.saveVideo({ path: uri }) : M.savePhoto({ path: uri }));
      FS.deleteFile({ path: rel, directory: 'CACHE' }).catch(() => {});
      photos++;
    } else {
      await FS.downloadFile({ url, path: 'Beam/' + it.name, directory: 'DOCUMENTS', recursive: true });
    }
    await call('/done?name=' + encodeURIComponent(it.name), { method: 'POST' });
    done++;
  }
  return { done, photos };
}
