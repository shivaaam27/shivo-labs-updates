// Real Liquid Glass on iPhone (iOS 26+): the tab bar and the round buttons are drawn by our native
// add-on (native/shivo-native) as floating glass views over the page, so they truly bend and reflect
// what's behind them. The page keeps the web versions in place (invisible) for layout, measures them,
// and tells the add-on where to draw. Older iPhones and the preview keep the web versions.
import { plugin } from './native.js';

const N = () => plugin('ShivoNative');
let on = false, hidden = 0;

export async function startGlass({ tabs, buttons, onTab, onButton, onHold }) {
  const P = N(); if (!P) return false;
  try { if (!(await P.info()).glass) return false; } catch { return false; }
  on = true;
  document.documentElement.classList.add('nglass');
  await P.addListener('tab', (e) => onTab(e.id));
  await P.addListener('button', (e) => onButton(e.id));
  if (onHold) await P.addListener('hold', onHold);
  const sync = () => syncGlass({ tabs, buttons });
  addEventListener('resize', () => setTimeout(sync, 60));
  sync();
  glassPark(false);   // the app is in: show what the start parked
  return true;
}

// The glass floats above the whole page, the logo screen included, and stays on the screen while the page restarts
// (an update). Park it at the start of every launch and while an update restarts; startGlass shows it once the app is in.
export function glassPark(park = true) {
  const P = N(); if (!P) return;
  P.setVisible({ tabs: !park && !hidden, buttons: !park && !hidden }).catch(() => {});
}

const box = (el) => { const r = el?.getBoundingClientRect(); return r && r.width ? { x: r.left, y: r.top, w: r.width, h: r.height } : null; };

// tabs(): { el, items, selected }; buttons(): [{ id, symbol }] for elements that are on screen now
export function syncGlass({ tabs, buttons }) {
  if (!on) return;
  const P = N(), t = tabs();
  // the web bar is measured to place the glass over it: while it is still moving (scaling back after the search box, or
  // sliding up) its box is the wrong size, and the glass kept that size ("the bar becomes small"). Measured when it has settled.
  const moving = t.el ? [t.el, t.el.parentElement].flatMap((e) => e?.getAnimations?.() || []).filter((x) => x.playState === 'running') : [];
  if (moving.length) {
    Promise.allSettled(moving.map((x) => x.finished)).then(() => syncGlass({ tabs, buttons }));
  } else P.setTabs({ frame: box(t.el), items: t.items, selected: t.selected }).catch(() => {});
  P.setButtons({ buttons: buttons().map((b) => ({ ...b, frame: box(document.getElementById(b.id)) })).filter((b) => b.frame) }).catch(() => {});
}

// the app's Light / Dark choice, for the glass and the system sheets (ShivoNative.setTheme; older builds don't have it)
export function glassTheme(theme) { try { N()?.setTheme?.({ theme })?.catch?.(() => {}); } catch {} }

export const selectGlassTab = (id) => on && N().selectTab({ id }).catch(() => {});

// Sheets, the side panel and menus slide over the glass: hide it while any of them is open.
export function glassCover(cover) {
  if (!on) return;
  hidden = Math.max(0, hidden + (cover ? 1 : -1));
  N().setVisible({ tabs: !hidden, buttons: !hidden }).catch(() => {});
}

export const haptic = (style = 'light') => N()?.haptic({ style }).catch(() => {});
export const openURL = async (url) => { const P = N(); if (P) return (await P.openURL({ url })).opened; location.href = url; return true; };
