// Shivo Labs Camera (design v3: phone/docs/design/camera.html). One screen, two engines:
//   web    the camera as a web page gets it (today's builds): looks developed live on the phone's graphics chip,
//          exposure and white balance applied to the picture (digital), photos from the video stream (about 12 MP).
//   native the ShivoCamera add-on (newer builds): the real camera through AVFoundation: focus, exposure, ISO,
//          shutter, white balance, lenses, RAW, 48 MP. Its picture is drawn behind this page.
// The screen asks the engine what it can do (caps) and shows the rest as "after the update".
import { LOOKS, lookById } from './looks.js';
import { makeRenderer } from './develop.js';
import { webEngine } from './engine-web.js';
import { nativeEngine } from './engine-native.js';

const ASPECTS = [['3:2', 3 / 2], ['4:3', 4 / 3], ['1:1', 1], ['16:9', 16 / 9], ['FULL', 0]];   // height : width, portrait
const DEF = { look: 'softchrome', amount: 1, grain: 1, ev: 0, k: 0, tint: 0, aspect: '4:3', flash: 'off', timer: 0, grid: true, level: false,
  hist: false, peak: false, zebra: false, fc: false, mirror: true, loc: false, sound: true, stab: true, live: false,
  facing: 'back', mm: 26, depth: false, ap: 2.8, fmt: 'JPEG', mp: 12, mode: 'PHOTO', looks: true, pro: false, iso: 0, ss: 0, mf: -1 };
const SV = {
  x: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
  flashOff: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/><path d="M4 4l16 16"/>', flashAuto: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/>',
  flashOn: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z" fill="currentColor"/>',
  timer: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9.5V13l2.5 1.5M9.5 2.5h5"/>',
  more: '<circle cx="6" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="18" cy="12" r="1.4" fill="currentColor"/>',
  ap: '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5 15.5 12M20.5 12l-8 3.4M12 20.5 8.5 12M3.5 12l8-3.4"/>',
  pro: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
  flip: '<path d="M3.5 8.5A1.5 1.5 0 0 1 5 7h2.2l1.4-2h6.8l1.4 2H19a1.5 1.5 0 0 1 1.5 1.5v9A1.5 1.5 0 0 1 19 19H5a1.5 1.5 0 0 1-1.5-1.5z"/><path d="M8.6 12.2a3.5 3.5 0 0 1 6.2-1.7M15.4 13.8a3.5 3.5 0 0 1-6.2 1.7"/><path d="M15 8.6v2.2h-2.2M9 17.4v-2.2h2.2"/>',
  sun: '<circle cx="12" cy="12" r="3.4"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"/>',
  grid: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M9.3 4v16M14.7 4v16M4 9.3h16M4 14.7h16"/>', level: '<path d="M3 12h4M17 12h4M8.5 12.4l7-.8"/>',
  hist: '<path d="M4 19h16"/><path d="M5 19c2-1 2.5-9 4.5-9s2 6 3.5 6 1.8-11 3.5-11 1.5 10 3.5 14"/>', peak: '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>',
  zebra: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 12 12 4M4 18 18 4M9 20l11-11M15 20l5-5"/>', fc: '<circle cx="8" cy="9" r="2.4"/><circle cx="15.5" cy="8" r="2.4"/><circle cx="16" cy="15.5" r="2.4"/><circle cx="8.5" cy="16" r="2.4"/>',
  mirror: '<path d="M12 3v18"/><path d="M8 7 4 12l4 5zM16 7l4 5-4 5z"/>', loc: '<path d="M12 21s-6.5-6.2-6.5-11a6.5 6.5 0 0 1 13 0c0 4.8-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
  sound: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6"/>', stab: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M3 9V5a2 2 0 0 1 2-2h4M21 15v4a2 2 0 0 1-2 2h-4"/>',
  live: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="6.5" stroke-dasharray="2 2.2"/><circle cx="12" cy="12" r="9.5"/>', reset: '<path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v4h4"/>',
  cam: '<path d="M4 8.5h3l1.8-2.5h6.4L17 8.5h3v10.5H4z"/><circle cx="12" cy="13.5" r="3.6"/>', share: '<path d="M12 3v12M7.5 7.5 12 3l4.5 4.5"/><path d="M5 12v8h14v-8"/>',
  photos: '<rect x="3.5" y="5" width="17" height="14" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="m20 16-4.5-4.5L7 19"/>',
};
const ic = (n, w = 18) => `<svg viewBox="0 0 24 24" style="width:${w}px;height:${w}px">${SV[n]}</svg>`;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const LATER = 'Comes with the camera update (one install with X Tools)';

// dials: values to pick from, how to show them, and "automatic"
const ISO = [0, 32, 50, 64, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400];
const SS = [0, 1 / 8000, 1 / 4000, 1 / 2000, 1 / 1000, 1 / 500, 1 / 250, 1 / 125, 1 / 60, 1 / 30, 1 / 15, 1 / 8, 1 / 4, 1 / 2, 1];
const WB = [0, 2500, 2800, 3200, 3600, 4000, 4500, 5000, 5600, 6200, 7000, 8000, 9000, 10000];
const MF = [-1, 0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1];
const EVS = [-3, -2.7, -2.3, -2, -1.7, -1.3, -1, -0.7, -0.3, 0, 0.3, 0.7, 1, 1.3, 1.7, 2, 2.3, 2.7, 3];
const APS = [1.4, 1.8, 2, 2.8, 4, 5.6, 8, 11, 16];
const fmtSS = (s) => (!s ? 'AUTO' : s >= 1 ? s + '"' : '1/' + Math.round(1 / s));
const DIALS = {
  ev: { list: EVS, get: (st) => st.ev, set: (st, v) => (st.ev = v), fmt: (v) => (v > 0 ? '+' : v < 0 ? '−' : '±') + (Math.abs(v) < 0.05 ? '0' : Math.abs(v).toFixed(1)), auto: (v) => !v },
  iso: { list: ISO, get: (st) => st.iso, set: (st, v) => (st.iso = v), fmt: (v) => (v ? String(v) : 'AUTO'), auto: (v) => !v, cap: 'iso' },
  ss: { list: SS, get: (st) => st.ss, set: (st, v) => (st.ss = v), fmt: fmtSS, auto: (v) => !v, cap: 'shutter' },
  wb: { list: WB, get: (st) => st.k, set: (st, v) => (st.k = v), fmt: (v) => (v ? v + 'K' : 'AUTO'), auto: (v) => !v },
  mf: { list: MF, get: (st) => st.mf, set: (st, v) => (st.mf = v), fmt: (v) => (v < 0 ? 'AF' : v === 0 ? 'NEAR' : v === 1 ? 'FAR' : Math.round(v * 100) + '%'), auto: (v) => v < 0, cap: 'focus' },
  ap: { list: APS, get: (st) => st.ap, set: (st, v) => (st.ap = v), fmt: (v) => 'ƒ' + v, auto: () => false, cap: 'depth' },
};

// opts: { toast, haptic, plugin, openURL }
export function mountCamera(root, { toast, haptic = () => {}, plugin = () => null, openURL } = {}) {
  let st = { ...DEF }; try { Object.assign(st, JSON.parse(localStorage.getItem('sl.cam2') || '{}')); } catch {}
  const save = () => { try { localStorage.setItem('sl.cam2', JSON.stringify(st)); } catch {} };
  const C = { on: false, busy: false, shots: [], tilt: 0, turn: 0, motion: false, dial: '', frame: { top: 0, h: 0 } };

  root.innerHTML = `<div class="cm${st.looks ? '' : ' nolooks'}${st.pro ? ' pro' : ''}" id="cm">
    <video id="cmVid" playsinline muted autoplay></video>
    <canvas id="cmGL"></canvas>
    <div class="cm-veil t" id="cmVt"></div><div class="cm-veil b" id="cmVb"></div>
    <div class="cm-frame" id="cmFrame"><canvas id="cmFG"></canvas><div class="cm-grid"><i></i><i></i><i></i><i></i></div><div class="cm-level" id="cmLevel" hidden><b></b><i></i><b></b></div></div>
    <div class="cm-touch" id="cmTouch"></div>
    <div class="cm-fbox" id="cmFbox"><div class="sq"></div><div class="sun">${ic('sun')}</div><span class="ev" id="cmFev"></span></div>
    <div class="cm-lock" id="cmLock">AE/AF LOCK</div>
    <div class="cm-hist cm-glass" id="cmHist" hidden><canvas width="216" height="92"></canvas></div>
    <div class="cm-count" id="cmCount"></div>

    <header class="cm-top">
      <button class="cm-rb cm-glass" id="cmClose" aria-label="Close">${ic('x')}</button>
      <div class="cm-pill cm-glass">
        <button id="cmFlash" class="cm-rot" aria-label="Flash"></button>
        <button id="cmTimer" class="cm-rot" aria-label="Timer"></button>
        <button id="cmAspect" class="cm-rot"></button>
        <button id="cmMore" class="cm-rot" aria-label="Photo controls">${ic('more')}</button>
      </div>
      <button class="cm-fmt cm-glass cm-rot" id="cmFmt"><i></i><span id="cmFmtT"></span><small id="cmFmtS"></small></button>
    </header>
    <div class="cm-menu cm-glass" id="cmMenu"></div>

    <div class="cm-lens cm-glass" id="cmLens"></div>
    <div class="cm-dial" id="cmDial"><span class="val" id="cmDialV"></span><div class="ticks" id="cmTicks"></div></div>
    <div class="cm-read cm-glass" id="cmRead">${['ev:EV', 'iso:ISO', 'ss:SHUTTER', 'wb:WB', 'mf:FOCUS', 'ap:DEPTH'].map((x) => { const [k, n] = x.split(':'); return `<button data-r="${k}"><small>${n}</small><span></span></button>`; }).join('')}</div>
    <div class="cm-line" id="cmLine"></div>
    <div class="cm-dock"></div>
    <button class="cm-grab" id="cmGrab" aria-label="Show or hide looks"></button>
    <div class="cm-modes" id="cmModes">${['VIDEO', 'PHOTO', 'STACK', 'NIGHT'].map((m) => `<button data-m="${m}">${m}</button>`).join('')}</div>
    <div class="cm-looks" id="cmLooks">${LOOKS.map((l) => `<button class="cm-look" data-look="${l.id}"><span class="cm-sw" style="background:linear-gradient(135deg,${l.sw[0]} 0 50%,${l.sw[1]} 50%)"></span><span>${esc(l.name.split(' ')[0])}</span></button>`).join('')}</div>
    <div class="cm-row">
      <button class="cm-thumb cm-rot" id="cmThumb" aria-label="Photos taken"></button>
      <button class="cm-shutter" id="cmShot" aria-label="Take photo"><b></b></button>
      <button class="cm-rb cm-glass cm-flip cm-rot" id="cmFlip" aria-label="Front or back camera">${ic('flip', 22)}</button>
    </div>
    <div class="cm-scrim" id="cmScrim"></div>
    <div class="cm-sheet cm-glass" id="cmSheet"></div>
    <div class="cm-blink" id="cmBlink"></div>
    <div class="cm-ff" id="cmFF"></div>
    <div class="cm-viewer" id="cmViewer" hidden></div>
    <div class="cm-gate" id="cmGate" hidden></div>
  </div>`;
  const $ = (s) => root.querySelector(s), $$ = (s) => [...root.querySelectorAll(s)];
  const cm = $('#cm'), vid = $('#cmVid'), glc = $('#cmGL');

  /* ---------- the engine: native when this build has the camera add-on, else the web camera ---------- */
  let E = null;
  const ctx = { vid, glc, makeRenderer, view: () => view(), onFrame: () => onFrame(), onHist: (h) => drawHist(h), plugin };
  async function pickEngine() {
    if (E) return E;
    const N = await nativeEngine(ctx).catch(() => null);
    E = N || webEngine(ctx);
    cm.classList.toggle('native', E.kind === 'native');
    return E;
  }
  const caps = () => E?.caps?.() || {};
  const view = () => ({ look: lookById(st.look), amount: st.amount, grain: st.grain, ev: st.ev, k: st.k || 5600, tint: st.tint,
    mirror: st.facing === 'front' && st.mirror, zoom: E?.digitalZoom?.(st.mm) || 1, zebra: st.zebra, false: st.fc, peak: st.peak });

  /* ---------- layout: controls keep their places; the frame (chosen aspect) moves under them ---------- */
  function layout() {
    const R = cm.getBoundingClientRect(); if (!R.width) return;
    const top0 = $('.cm-top').getBoundingClientRect().bottom - R.top + 10;
    const lowTop = $('#cmModes').getBoundingClientRect().top - R.top - 6;   // where the controls start
    const lensTop = lowTop - 46;
    const a = (ASPECTS.find((x) => x[0] === st.aspect) || ASPECTS[1])[1];
    let top, h;
    if (!a) { top = 0; h = R.height; } else { h = Math.round(R.width * a); const room = lensTop - 8 - top0; top = top0 + Math.max(0, Math.round((room - h) / 2)); }
    C.frame = { top, h, W: R.width, H: R.height };
    $('#cmVt').style.height = top + 'px'; $('#cmVb').style.height = Math.max(0, R.height - top - h) + 'px';
    for (const el of [$('#cmFrame'), $('#cmTouch')]) { el.style.top = top + 'px'; el.style.height = h + 'px'; }
    const lt = Math.min(top + h - 46, lensTop);
    $('#cmLens').style.top = lt + 'px';
    $('#cmRead').style.top = (lt - 52) + 'px'; $('#cmDial').style.top = (lt - 52 - 46) + 'px';
    $('#cmLine').style.top = (lt - (st.pro ? 84 : 30)) + 'px';
    $('#cmFrame').style.setProperty('--under', Math.max(0, top + h - lowTop) + 'px');
    $('#cmLock').style.top = Math.max(top + 12, top0) + 'px'; $('#cmHist').style.top = Math.max(top + 12, top0) + 'px';
    E?.layout?.(C.frame);
  }
  new ResizeObserver(() => layout()).observe(cm);
  cm.addEventListener('transitionend', (e) => { if (e.target === $('#cmModes') && e.propertyName === 'bottom') layout(); });

  const line = (t) => { const e = $('#cmLine'); e.textContent = t; e.classList.add('show'); clearTimeout(line.t); line.t = setTimeout(() => e.classList.remove('show'), 1500); };

  /* ---------- start and stop ---------- */
  async function start() {
    C.on = true; await pickEngine(); layout();
    if (!E.available()) return gate('none');
    if (E.kind === 'web' && !localStorage.getItem('sl.cam.asked')) return gate('ask');
    try {
      await E.start({ facing: st.facing, mm: st.mm, mp: st.mp });
      if (!C.on) return E.stop();
      $('#cmGate').hidden = true;
      if (!lensList().some((l) => l.mm === st.mm)) st.mm = (lensList().find((l) => l.zoom === 1) || lensList()[0]).mm;
      await applyAll(); paintAll(); layout();
    } catch (e) {
      console.error(e);
      if (e.name === 'NotAllowedError' || e.name === 'SecurityError' || /denied|not allowed/i.test(e.message || '')) gate('denied');
      else gate('error', e.message);
    }
  }
  function stop() { C.on = false; E?.stop(); closeSheet(); }
  // after a restart, the camera gets every setting again
  async function applyAll() {
    const c = caps();
    await E.setLens?.(st.mm);
    if (c.iso || c.shutter) await E.setExposure?.({ iso: st.iso, ss: st.ss, ev: st.ev });
    if (c.wb) await E.setWB?.({ k: st.k, tint: st.tint });
    if (c.focus) await E.setFocus?.({ pos: st.mf });
    E.setLook?.(view());
  }

  /* ---------- live view helpers (web engine calls these each frame) ---------- */
  function onFrame() {}
  function drawHist(H) {
    if (!st.hist || !H) return;
    const cv = $('#cmHist canvas'), x = cv.getContext('2d'), W = cv.width, Ht = cv.height, B = H[0].length;
    const max = Math.max(...H.map((a) => Math.max(...Array.from(a).slice(1, B - 1)))) || 1;
    x.clearRect(0, 0, W, Ht); x.globalCompositeOperation = 'lighter';
    [['rgba(232,84,70,.55)', 0], ['rgba(110,200,120,.55)', 1], ['rgba(80,130,235,.6)', 2]].forEach(([col, c]) => {
      x.beginPath(); x.moveTo(0, Ht);
      for (let i = 0; i < B; i++) x.lineTo(i / (B - 1) * W, Ht - Math.min(1, H[c][i] / max) * (Ht - 4));
      x.lineTo(W, Ht); x.closePath(); x.fillStyle = col; x.fill();
    });
    x.globalCompositeOperation = 'source-over'; x.beginPath();
    for (let i = 0; i < B; i++) x.lineTo(i / (B - 1) * W, Ht - Math.min(1, H[3][i] / max) * (Ht - 4));
    x.strokeStyle = 'rgba(255,255,255,.85)'; x.lineWidth = 2; x.stroke();
  }

  /* ---------- top: flash, timer, frame, more; the format menu ---------- */
  function paintTop() {
    const c = caps();
    $('#cmFlash').innerHTML = ic(st.flash === 'on' ? 'flashOn' : st.flash === 'auto' ? 'flashAuto' : 'flashOff'); $('#cmFlash').classList.toggle('lit', st.flash === 'on');
    $('#cmTimer').innerHTML = st.timer ? `<span style="font:600 12px var(--display)">${st.timer}s</span>` : ic('timer'); $('#cmTimer').classList.toggle('lit', !!st.timer);
    $('#cmAspect').textContent = st.aspect;
    const raw = st.fmt.startsWith('RAW') && c.raw;
    $('#cmFmtT').textContent = raw ? 'RAW' : (c.formats || ['JPEG']).includes(st.fmt) ? st.fmt.replace('RAW+', 'RAW') : 'JPEG';
    $('#cmFmtS').textContent = (E?.mpFor?.(st) || st.mp) + (st.fmt === 'RAW+' && raw ? '+' : '');
    $('#cmShot').classList.toggle('raw', raw);
  }
  $('#cmFlash').onclick = () => { const c = caps(); const opts = c.flash ? ['off', 'auto', 'on'] : ['off', 'on']; st.flash = opts[(opts.indexOf(st.flash) + 1) % opts.length]; haptic('selection'); save(); paintTop(); line('Flash ' + st.flash + (c.flash ? '' : ' (torch)')); };
  $('#cmTimer').onclick = () => { st.timer = st.timer === 0 ? 3 : st.timer === 3 ? 10 : 0; haptic('selection'); save(); paintTop(); line(st.timer ? `Timer ${st.timer} s` : 'Timer off'); };
  $('#cmAspect').onclick = () => { const i = ASPECTS.findIndex((a) => a[0] === st.aspect); st.aspect = ASPECTS[(i + 1) % ASPECTS.length][0]; haptic('selection'); save(); paintTop(); layout(); };
  $('#cmMore').onclick = (e) => { e.stopPropagation(); openSheet(); };
  $('#cmClose').onclick = () => root.dispatchEvent(new CustomEvent('camera-close', { bubbles: true }));
  $('#cmFmt').onclick = (e) => { e.stopPropagation(); paintMenu(); $('#cmMenu').classList.toggle('on'); };
  cm.addEventListener('click', (e) => { if (!e.target.closest('#cmMenu,#cmFmt')) $('#cmMenu').classList.remove('on'); });
  function paintMenu() {
    const c = caps(), F = ['RAW+', 'RAW', 'HEIF', 'JPEG'], M = [12, 24, 48];
    const okF = (f) => (f.startsWith('RAW') ? c.raw : (c.formats || ['JPEG']).includes(f));
    const okM = (m) => (c.mp || [12]).includes(m);
    $('#cmMenu').innerHTML = `<h4>FORMAT</h4><div class="cm-seg" data-k="fmt">${F.map((f) => `<button data-v="${f}" class="${st.fmt === f ? 'on' : ''}${okF(f) ? '' : ' off'}">${f === 'RAW+' ? 'RAW+HEIF' : f}</button>`).join('')}</div>
      <h4>RESOLUTION</h4><div class="cm-seg" data-k="mp">${M.map((m) => `<button data-v="${m}" class="${+st.mp === m ? 'on' : ''}${okM(m) ? '' : ' off'}">${m} MP</button>`).join('')}</div>
      <p>${({ 'RAW+': 'The sensor\'s RAW file plus a developed copy with your look.', RAW: 'Only the sensor\'s RAW file, to develop later.', HEIF: 'Developed with your look; small files.', JPEG: 'Developed with your look; works everywhere.' })[st.fmt]}${E?.kind === 'web' ? ' RAW, HEIF and more megapixels come with the camera update.' : ''}</p>`;
    $$('#cmMenu .cm-seg').forEach((s) => s.querySelectorAll('button').forEach((b) => (b.onclick = (e) => {
      e.stopPropagation(); const k = s.dataset.k, v = k === 'mp' ? +b.dataset.v : b.dataset.v;
      if (b.classList.contains('off')) return line(E?.kind === 'web' ? LATER : 'This iPhone can\'t do that');
      st[k] = v; save(); haptic('selection'); paintMenu(); paintTop(); if (k === 'mp') E.setResolution?.(v);
    })));
  }

  /* ---------- lens ring: real focal lengths (mm) ---------- */
  const lensList = () => E?.lenses?.(st.facing) || [{ mm: 26, kind: 'optical' }];
  function paintLens() {
    const L = lensList(), c = caps();
    $('#cmLens').innerHTML = `<button class="pb ${st.pro ? 'on' : ''}" id="cmPro" aria-label="Pro controls">${ic('pro', 16)}</button><i class="sep"></i>` +
      L.map((l) => `<button class="lz ${l.mm === st.mm ? 'on' : ''}" data-mm="${l.mm}">${l.mm === st.mm ? l.mm + 'mm' : l.mm}</button>`).join('');
    $('#cmPro').onclick = () => { st.pro = !st.pro; save(); haptic('selection'); cm.classList.toggle('pro', st.pro); if (!st.pro) closeDial(); paintLens(); layout(); line(st.pro ? 'Pro controls' : 'Pro controls hidden'); };
    $$('#cmLens .lz').forEach((b) => (b.onclick = async () => {
      const mm = +b.dataset.mm; if (mm === st.mm) return;
      st.mm = mm; save(); haptic('selection'); paintLens(); paintTop();
      const l = L.find((x) => x.mm === mm);
      line(`${mm} mm · ${l?.zoom ? l.zoom + '×' : ''}${l?.kind === 'crop' ? ' · from the main camera' : ''}`);
      await E.setLens?.(mm); E.setLook?.(view());
    }));

  }

  /* ---------- readouts and the dial ---------- */
  function paintRead() {
    const c = caps();
    $$('#cmRead button').forEach((b) => {
      const k = b.dataset.r, D = DIALS[k], v = D.get(st), ok = !D.cap || c[D.cap];
      b.querySelector('span').textContent = !ok ? '—' : k === 'ap' && !st.depth ? 'OFF' : D.fmt(v);
      b.classList.toggle('auto', ok && (k === 'ap' ? st.depth : D.auto(v))); b.classList.toggle('off', !ok); b.classList.toggle('on', C.dial === k);
    });
  }
  function openDial(k) { C.dial = k; $('#cmDial').classList.add('show'); $('#cmLens').classList.add('away'); paintRead(); showDial(); }
  function closeDial() { C.dial = ''; $('#cmDial').classList.remove('show'); $('#cmLens').classList.remove('away'); paintRead(); }
  function showDial() {
    const D = DIALS[C.dial]; if (!D) return;
    const i = Math.max(0, D.list.indexOf(D.get(st)));
    $('#cmTicks').style.transform = `translateX(${-i * 50 + (D.list.length * 25)}px)`;
    $('#cmDialV').textContent = D.fmt(D.get(st));
  }
  $$('#cmRead button').forEach((b) => {
    b.onclick = () => {
      const k = b.dataset.r, D = DIALS[k];
      if (D.cap && !caps()[D.cap]) return line(E?.kind === 'web' ? LATER : 'This iPhone can\'t set that by hand');
      if (k === 'ap' && !st.depth) { st.depth = true; save(); E.setDepth?.({ on: true, ap: st.ap }); line('Depth on · tap what stays sharp · double-tap DEPTH to turn off'); }
      if (C.dial === k) closeDial(); else openDial(k);
      haptic('selection');
    };
    let tap = 0;
    b.addEventListener('pointerup', () => { const n = Date.now(); if (n - tap < 320) toAuto(b.dataset.r); tap = n; });
  });
  async function toAuto(k) {
    const D = DIALS[k];
    if (k === 'ap') { st.depth = false; save(); closeDial(); E.setDepth?.({ on: false, ap: st.ap }); paintRead(); return line('Depth off'); }
    D.set(st, D.list[k === 'ev' ? EVS.indexOf(0) : 0]); if (k === 'wb') st.tint = 0;
    save(); paintRead(); showDial(); await applyDial(k); line('Automatic'); haptic('light');
  }
  async function applyDial(k) {
    if (k === 'ev' || k === 'iso' || k === 'ss') await E.setExposure?.({ iso: st.iso, ss: st.ss, ev: st.ev });
    else if (k === 'wb') await E.setWB?.({ k: st.k, tint: st.tint });
    else if (k === 'mf') await E.setFocus?.({ pos: st.mf });
    else if (k === 'ap') E.setDepth?.({ on: st.depth, ap: st.ap });
    E.setLook?.(view()); paintLens();
  }
  (() => {   // drag the dial sideways
    const d = $('#cmDial'); let x0 = null, i0 = 0, last = -1, busy = false;
    d.addEventListener('pointerdown', (e) => { const D = DIALS[C.dial]; if (!D) return; x0 = e.clientX; i0 = Math.max(0, D.list.indexOf(D.get(st))); d.setPointerCapture(e.pointerId); });
    d.addEventListener('pointermove', async (e) => {
      if (x0 == null) return; const D = DIALS[C.dial];
      const i = clamp(i0 - Math.round((e.clientX - x0) / 50), 0, D.list.length - 1);
      if (i === last) return; last = i; D.set(st, D.list[i]); haptic('selection'); paintRead(); showDial();
      if (!busy) { busy = true; await applyDial(C.dial).catch(() => {}); busy = false; }
    });
    const end = () => { if (x0 == null) return; x0 = null; last = -1; save(); applyDial(C.dial); };
    d.addEventListener('pointerup', end); d.addEventListener('pointercancel', end);
  })();

  /* ---------- tap the picture: focus there; then drag up or down anywhere to brighten or darken; hold to lock ---------- */
  (() => {
    const t = $('#cmTouch'), fb = $('#cmFbox'); let hideT = 0, holdT = 0, ev0 = 0, y0 = 0, x0 = 0, dragging = false, locked = false, active = false, fresh = false;
    const show = () => { fb.classList.add('in'); clearTimeout(hideT); hideT = setTimeout(() => { if (!locked) { fb.classList.remove('in'); active = false; } }, 3000); };
    const paintSun = () => { fb.style.setProperty('--sy', -st.ev * 14 + 'px'); $('#cmFev').textContent = st.ev ? (st.ev > 0 ? '+' : '') + st.ev.toFixed(1) : ''; };
    const place = (x, y) => {
      fb.style.left = x + 'px'; fb.style.top = y + 'px';
      const f = C.frame; E.focusAt?.({ x: x / f.W, y: y / f.H, depth: st.depth });   // the point, as a share of the screen
      haptic('light');
    };
    t.addEventListener('pointerdown', (e) => {
      if (!E?.running?.()) return;
      const r = cm.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      y0 = e.clientY; x0 = e.clientX; ev0 = st.ev; dragging = false; fresh = !active;
      t.setPointerCapture(e.pointerId);
      if (fresh) {
        if (locked) { locked = false; $('#cmLock').classList.remove('on'); E.lock?.(false); }
        place(x, y); active = true; paintSun(); show();
        holdT = setTimeout(() => { locked = true; $('#cmLock').classList.add('on'); fb.classList.add('in'); clearTimeout(hideT); E.lock?.(true); haptic('medium'); }, 650);
      } else show();
    });
    t.addEventListener('pointermove', (e) => {
      if (y0 == null) return;
      if (Math.abs(e.clientY - y0) > 6) { dragging = true; clearTimeout(holdT); }
      if (!dragging) return;
      const v = Math.round(clamp(ev0 + (y0 - e.clientY) / 40, -3, 3) * 10) / 10;
      if (v !== st.ev) { st.ev = v; paintSun(); paintRead(); E.setExposure?.({ iso: st.iso, ss: st.ss, ev: st.ev }); E.setLook?.(view()); }
      show();
    });
    t.addEventListener('pointerup', (e) => {
      clearTimeout(holdT);
      if (!dragging && !fresh && active && !locked) {   // a tap somewhere else while the box shows: move the focus there
        const r = cm.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
        if (Math.hypot(x - parseFloat(fb.style.left), y - parseFloat(fb.style.top)) > 40) { place(x, y); fb.classList.remove('in'); void fb.offsetWidth; show(); }
      }
      if (dragging) save();
      y0 = null;
    });
  })();

  /* ---------- modes ---------- */
  function paintModes() { $$('#cmModes button').forEach((b) => b.classList.toggle('on', b.dataset.m === st.mode)); $('#cmShot').classList.toggle('stack', st.mode === 'STACK' || st.mode === 'NIGHT'); }
  $$('#cmModes button').forEach((b) => (b.onclick = () => {
    const m = b.dataset.m, c = caps();
    if (m !== 'PHOTO' && !(c.modes || []).includes(m)) return line(E?.kind === 'web' ? LATER : m === 'VIDEO' ? 'Video is coming next' : 'Comes with the next camera build');
    st.mode = m; save(); haptic('selection'); paintModes();
    line({ VIDEO: 'Video', PHOTO: 'Photo', STACK: 'Stack · several RAW frames merged', NIGHT: 'Night · a longer stack, hold still' }[m]);
  }));

  /* ---------- looks: swipe the strip; swipe the lower area down to hide it, up to show it, up again for controls ---------- */
  const looksEl = $('#cmLooks');
  function centerLook(smooth) {
    const b = looksEl.querySelector(`[data-look="${st.look}"]`); if (!b) return;
    $$('.cm-look').forEach((x) => x.classList.toggle('on', x === b));
    looksEl.scrollTo({ left: b.offsetLeft + b.offsetWidth / 2 - looksEl.clientWidth / 2, behavior: smooth ? 'smooth' : 'auto' });
  }
  function setLook(id) { if (st.look !== id) { haptic('selection'); line(lookById(id).name); } st.look = id; save(); centerLook(true); E?.setLook?.(view()); if ($('#cmSheet').classList.contains('on')) paintSheet(); }
  $$('.cm-look').forEach((b) => (b.onclick = () => setLook(b.dataset.look)));
  let lT = 0;
  looksEl.addEventListener('scroll', () => {
    clearTimeout(lT); lT = setTimeout(() => {
      const mid = looksEl.scrollLeft + looksEl.clientWidth / 2; let best = null, bd = 1e9;
      $$('.cm-look').forEach((b) => { const d = Math.abs(b.offsetLeft + b.offsetWidth / 2 - mid); if (d < bd) { bd = d; best = b; } });
      if (best && best.dataset.look !== st.look) setLook(best.dataset.look);
    }, 120);
  }, { passive: true });
  const looksOn = (on) => { st.looks = on; save(); cm.classList.toggle('nolooks', !on); line(on ? 'Looks' : 'Looks hidden · swipe up to show'); if (on) setTimeout(() => centerLook(false), 50); };
  $('#cmGrab').onclick = () => looksOn(!st.looks);
  (() => {   // swipes on the lower section
    let y0 = null, x0 = 0;
    cm.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.cm-read,.cm-dial,.cm-lens,.cm-top,.cm-menu,.cm-viewer,.cm-gate,.cm-touch')) return;
      const r = cm.getBoundingClientRect(), y = e.clientY - r.top;
      const sheet = $('#cmSheet').classList.contains('on');
      if (sheet ? e.target.closest('.cm-sheet') && !e.target.closest('input') : y > $('#cmModes').getBoundingClientRect().top - r.top - 10) { y0 = e.clientY; x0 = e.clientX; }
    });
    cm.addEventListener('pointerup', (e) => {
      if (y0 == null) return; const dy = e.clientY - y0, dx = e.clientX - x0; y0 = null;
      if (Math.abs(dy) < 36 || Math.abs(dx) > Math.abs(dy)) return;
      const sheet = $('#cmSheet').classList.contains('on');
      if (dy < 0) { if (!st.looks) looksOn(true); else openSheet(); } else if (sheet) closeSheet(); else if (st.looks) looksOn(false);
    });
  })();

  /* ---------- photo controls: the sheet ---------- */
  const TOOLS = [['grid', 'Grid'], ['level', 'Level'], ['hist', 'Histogram'], ['peak', 'Peaking'], ['zebra', 'Zebra'], ['fc', 'False colour'],
    ['mirror', 'Mirror selfie'], ['loc', 'Location'], ['sound', 'Shutter sound'], ['stab', 'Stabilise'], ['live', 'Live photo'], ['reset', 'Reset']];
  function paintSheet() {
    const c = caps(), ok = (k) => !['loc', 'sound', 'stab', 'live'].includes(k) || (c.tools || []).includes(k);
    $('#cmSheet').innerHTML = `<div class="gr"></div>
      <h4>LOOK · ${esc(lookById(st.look).name.toUpperCase())}</h4>
      <div class="cm-slider"><span>Strength</span><input type="range" min="0" max="100" value="${Math.round(st.amount * 100)}" id="cmAmt"><b>${Math.round(st.amount * 100)}%</b></div>
      <div class="cm-slider"><span>Grain</span><input type="range" min="0" max="200" value="${Math.round(st.grain * 100)}" id="cmGr"><b>${Math.round(st.grain * 100)}%</b></div>
      <h4>PHOTO CONTROLS</h4>
      <div class="cm-tools">${TOOLS.map(([k, n]) => `<button class="cm-tool ${k !== 'reset' && st[k] && ok(k) ? 'on' : ''}${ok(k) ? '' : ' off'}" data-k="${k}">${ic(k, 20)}<b>${n}</b><small>${k === 'reset' ? 'All' : !ok(k) ? 'After update' : st[k] ? 'On' : 'Off'}</small></button>`).join('')}</div>
      ${E?.kind === 'web' ? `<p class="cm-note">This camera is the web version: brightness and colour are applied to the picture. Real focus, ISO, shutter, RAW, 48 MP and depth come with the camera update.</p>` : ''}`;
    const amt = $('#cmAmt'), gr = $('#cmGr');
    amt.oninput = () => { st.amount = amt.value / 100; amt.nextElementSibling.textContent = amt.value + '%'; E.setLook?.(view()); };
    gr.oninput = () => { st.grain = gr.value / 100; gr.nextElementSibling.textContent = gr.value + '%'; E.setLook?.(view()); };
    amt.onchange = gr.onchange = save;
    $$('#cmSheet .cm-tool').forEach((b) => (b.onclick = async () => {
      const k = b.dataset.k; if (b.classList.contains('off')) return line(LATER);
      haptic('selection');
      if (k === 'reset') { const keep = { facing: st.facing, look: st.look, looks: st.looks }; st = { ...DEF, ...keep }; await applyAll(); line('Back to the start'); }
      else if (k === 'level' && !st.level && !(await askMotion())) return;
      else st[k] = !st[k];
      save(); paintAll(); paintSheet(); E.setTools?.(st);
    }));
  }
  function openSheet() { paintSheet(); $('#cmSheet').classList.add('on'); $('#cmScrim').classList.add('on'); closeDial(); haptic('light'); }
  function closeSheet() { $('#cmSheet').classList.remove('on'); $('#cmScrim').classList.remove('on'); }
  $('#cmScrim').onclick = closeSheet;

  /* ---------- the level, and turning photos when the phone is held sideways ---------- */
  function onMotion(e) {
    const g = e.accelerationIncludingGravity; if (!g || g.x == null) return;
    const ax = g.x, ay = g.y, flat = Math.abs(g.z) > 8.6;
    const turn = flat ? C.turn : Math.abs(ax) > Math.abs(ay) * 1.2 ? (ax > 0 ? -90 : 90) : Math.abs(ay) > Math.abs(ax) * 1.2 ? 0 : C.turn;
    if (turn !== C.turn) { C.turn = turn; cm.style.setProperty('--turn', turn + 'deg'); }
    let a = Math.atan2(ax, -ay) * 180 / Math.PI; if (turn === 90) a -= 90; else if (turn === -90) a += 90;
    C.tilt = a; if (!st.level) return;
    const lv = $('#cmLevel'), ok = Math.abs(a) < 1;
    lv.style.setProperty('--tilt', (ok ? 0 : -a) + 'deg');
    if (ok && !lv.classList.contains('ok')) haptic('selection');
    lv.classList.toggle('ok', ok);
  }
  async function askMotion() {
    try {
      const D = window.DeviceMotionEvent;
      if (D?.requestPermission && (await D.requestPermission()) !== 'granted') throw new Error('no');
      if (!C.motion) { addEventListener('devicemotion', onMotion); C.motion = true; }
      localStorage.setItem('sl.cam.motion', '1'); return true;
    } catch { toast?.('Allow Motion for the level and turning photos'); return false; }
  }
  if (localStorage.getItem('sl.cam.motion')) cm.addEventListener('pointerdown', () => { if (!C.motion) askMotion(); }, { once: true });
  if (window.DeviceMotionEvent && !window.DeviceMotionEvent.requestPermission) { addEventListener('devicemotion', onMotion); C.motion = true; }

  /* ---------- take the photo ---------- */
  $('#cmShot').onclick = shoot;
  async function shoot() {
    if (!E?.running?.() || C.busy) return;
    C.busy = true; $('#cmShot').classList.add('busy');
    try {
      if (st.timer) for (let s = st.timer; s > 0; s--) { count(s); haptic('light'); await sleep(1000); }
      count('');
      const a = (ASPECTS.find((x) => x[0] === st.aspect) || ASPECTS[1])[1] || C.frame.H / C.frame.W;
      const shot = await E.shoot({ ...st, aspect: a, turn: C.turn, view: view(), onCapture: () => { blink(); haptic('medium'); },
        flashFront: async (on) => { $('#cmFF').classList.toggle('on', on); if (on) await sleep(320); } });
      if (!shot) return;
      shot.look = lookById(st.look).name; C.shots.unshift(shot); paintThumb();
      if (shot.error) toast?.(shot.error);
    } catch (e) { console.error(e); toast?.('Photo not taken: ' + (e.message || e)); }
    finally { C.busy = false; $('#cmShot').classList.remove('busy'); count(''); $('#cmFF').classList.remove('on'); }
  }
  function count(n) { const c = $('#cmCount'); c.textContent = n; c.classList.toggle('on', n !== ''); }
  function blink() { const b = $('#cmBlink'); b.classList.remove('on'); void b.offsetWidth; b.classList.add('on'); }

  /* ---------- photos taken: the corner thumbnail and the viewer ---------- */
  function paintThumb() { const t = $('#cmThumb'), s = C.shots[0]; t.innerHTML = s ? `<img src="${s.url}" alt="">` : ''; if (s) { t.classList.remove('pop'); void t.offsetWidth; t.classList.add('pop'); } }
  $('#cmThumb').onclick = () => { if (C.shots.length) openViewer(); else (openURL ? openURL('photos-redirect://') : null)?.catch?.(() => {}); };
  function openViewer() {
    const v = $('#cmViewer');
    v.innerHTML = `<div class="cv-top"><button class="cm-rb cm-glass" id="cvClose" aria-label="Close">${ic('x')}</button><span id="cvN"></span><span class="cv-sp"></span></div>
      <div class="cv-strip" id="cvStrip">${C.shots.map((s) => `<figure><img src="${s.url}" alt=""><figcaption>${esc(s.look || '')} · ${(s.w * s.h / 1e6).toFixed(1)} MP${s.raw ? ' · RAW' : ''}</figcaption></figure>`).join('')}</div>
      <div class="cv-bar"><button class="cv-btn" id="cvShare">${ic('share', 22)}<span>Share</span></button><span class="cv-saved" id="cvSaved"></span><button class="cv-btn" id="cvPhotos">${ic('photos', 22)}<span>Photos</span></button></div>`;
    v.hidden = false; requestAnimationFrame(() => v.classList.add('in'));
    const strip = $('#cvStrip'), at = () => Math.round(strip.scrollLeft / strip.clientWidth);
    const paint = () => { const s = C.shots[at()]; $('#cvN').textContent = `${at() + 1} of ${C.shots.length}`; $('#cvSaved').textContent = s?.saved ? 'Saved to Photos' : 'Not saved'; };
    strip.addEventListener('scroll', paint, { passive: true }); paint();
    $('#cvClose').onclick = () => { v.classList.remove('in'); setTimeout(() => (v.hidden = true), 300); };
    $('#cvPhotos').onclick = () => (openURL ? openURL('photos-redirect://') : null)?.catch?.(() => {});
    $('#cvShare').onclick = async () => { const s = C.shots[at()]; if (!s) return; try { const SH = plugin('Share'); if (SH && s.uri) await SH.share({ files: [s.uri] }); else toast?.('Sharing isn\'t available here'); } catch {} };
  }

  /* ---------- flip between back and front ---------- */
  $('#cmFlip').onclick = async () => {
    st.facing = st.facing === 'front' ? 'back' : 'front'; st.mm = 26; save(); haptic('light');
    const f = $('#cmFlip'); f.classList.toggle('spin'); cm.classList.add('swap'); setTimeout(() => cm.classList.remove('swap'), 420);
    await E?.stop(); start();
  };

  /* ---------- asking for the camera, and when it is off ---------- */
  function gate(kind, detail) {
    const g = $('#cmGate'); g.hidden = false;
    const T = {
      ask: ['Shivo Labs Camera', 'Film looks, live in the viewfinder. Photos go straight to your Photos.', 'Allow camera', 'iPhone will ask you once.'],
      denied: ['Camera is off', 'Shivo Labs isn\'t allowed to use the camera. Turn on Camera for Shivo Labs in Settings, then come back.', 'Open Settings', ''],
      none: ['No camera here', 'This device has no camera Shivo Labs can use.', '', ''],
      error: ['The camera didn\'t start', detail || 'Something else may be using it. Close other camera apps and try again.', 'Try again', ''],
    }[kind];
    g.innerHTML = `<button class="cm-rb cm-glass cg-x" id="cgX" aria-label="Close">${ic('x')}</button><div class="cg-in"><span class="cg-ic">${ic('cam', 44)}</span><h2>${T[0]}</h2><p>${esc(T[1])}</p>
      ${T[2] ? `<button class="cg-go" id="cgGo">${T[2]}</button>` : ''}${kind === 'denied' ? '<button class="cg-alt" id="cgAgain">Try again</button>' : ''}<small>${T[3]}</small></div>`;
    const go = $('#cgGo');
    if (go) go.onclick = () => { if (kind === 'denied') return (openURL ? openURL('app-settings:') : Promise.reject()).catch(() => toast?.('Open Settings, then Shivo Labs, then Camera')); localStorage.setItem('sl.cam.asked', '1'); start(); };
    $('#cgX').onclick = () => $('#cmClose').click();
    const again = $('#cgAgain'); if (again) again.onclick = start;
  }

  function paintAll() {
    cm.dataset.grid = st.grid ? '1' : ''; $('#cmLevel').hidden = !st.level; $('#cmHist').hidden = !st.hist;
    paintTop(); paintLens(); paintRead(); paintModes(); centerLook(false); E?.setTools?.(st); E?.setLook?.(view());
  }
  paintAll(); paintThumb();

  // the camera stops when the app goes to the background and comes back with it
  document.addEventListener('visibilitychange', () => { if (!C.on) return; if (document.hidden) E?.stop(); else start(); });

  return { start, stop, get on() { return C.on; } };
}
