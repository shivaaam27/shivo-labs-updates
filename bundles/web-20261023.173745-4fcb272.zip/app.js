/* Shivo Labs: your AI on your phone. Standalone: your own Claude and Gemini keys live on this phone,
   chats call the models directly, and long tasks run as hosted agents on Anthropic's servers. */
import * as store from './engine/store.js';
import { MODELS, checkKey, runChat, costOf, messagesStream } from './engine/claude.js';
import { PHONE_TOOLS, WRITE_TOOLS, execPhoneTool, contextLine, phoneTools } from './engine/tools.js';
import { paired as tvPaired } from './engine/tvctl.js';
import { signedIn as chatSignedIn } from './engine/chatctl.js';
import { hasPc } from './engine/pcctl.js';
import { listGeminiModels, defaultGeminiChain, makeGeminiLimits, runGeminiChat, freeLimits, prettyGemini } from './engine/gemini.js';
import * as ag from './engine/agents.js';
import { plugin } from './engine/native.js';
import { appReady, checkForUpdate, myVersion } from './engine/ota.js';
import { updateApp, wantsApp } from './engine/apkupdate.js';
import * as pass from './engine/id.js';
import * as beam from './engine/beam.js';
import * as cloud from './engine/cloud.js';
import * as live from './engine/live.js';
import { mountChat } from './chat/chat.js';
import { mountCamera } from './camera/camera.js';
import { mountTv } from './tv/tv.js';
import { mountInsights } from './insights/insights.js';
import { startGlass, syncGlass, selectGlassTab, glassCover, glassPark, glassTheme, openURL, haptic } from './engine/glass.js';
import qrcode from './kit/qrcode.mjs';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));
const qs = new URLSearchParams(location.search);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const FAST = qs.has('fast');
glassPark();   // nothing of the native bar over the logo screen while the app starts

/* ---------- icons, mark, markdown ---------- */
const IC = {
  chev: 'm9 6 6 6-6 6', check: 'm5 12.5 4.5 4.5L19 7.5', x: 'M6 6l12 12M18 6 6 18',
  spark: 'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z', doc: 'M7 3h7l5 5v13H7zM14 3v5h5',
  img: 'M4 5h16v14H4zM4 15l5-5 4 4 3-3 4 4',
};
const ic = (n, cls = '') => `<svg class="${cls}" viewBox="0 0 24 24"><path d="${IC[n]}"/></svg>`;
const TILES = [[18, 64, 't'], [64, 18, 't'], [18, 41, 't'], [41, 18, 't'], [41, 41, 't'], [18, 18, 'lit']];
const mark = (cls = '') => `<svg class="mk ${cls}" viewBox="0 0 100 100"><g transform="rotate(15 50 50)">${TILES.map(([x, y, c], i) => `<rect class="${c}" style="--i:${i}" x="${x}" y="${y}" width="18" height="18" rx="4.5"/>`).join('')}</g></svg>`;
const light = () => document.documentElement.dataset.theme === 'light';
const loader = (k, n = 18) => fabraLoader(k, n, light());

function md(src) {
  let s = String(src || '');
  const blocks = [];
  s = s.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, l, c) => { blocks.push(`<pre><code>${esc(c.replace(/\n$/, ''))}</code></pre>`); return `\u0000${blocks.length - 1}\u0000`; });
  const inline = (t) => esc(t)
    .replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<i>$2</i>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  const out = [];
  for (const para of s.split(/\n{2,}/)) {
    const p = para.trim(); if (!p) continue;
    if (/^\u0000\d+\u0000$/.test(p)) { out.push(p); continue; }
    const lines = p.split('\n');
    if (lines.every((l) => /^\s*[-*] /.test(l))) { out.push('<ul>' + lines.map((l) => '<li>' + inline(l.replace(/^\s*[-*] /, '')) + '</li>').join('') + '</ul>'); continue; }
    if (lines.every((l) => /^\s*\d+[.)] /.test(l))) { out.push('<ol>' + lines.map((l) => '<li>' + inline(l.replace(/^\s*\d+[.)] /, '')) + '</li>').join('') + '</ol>'); continue; }
    const h = /^(#{1,4}) (.+)$/.exec(p);
    if (h && lines.length === 1) { out.push(`<h4>${inline(h[2])}</h4>`); continue; }
    out.push('<p>' + lines.map(inline).join('<br>') + '</p>');
  }
  return out.join('').replace(/\u0000(\d+)\u0000/g, (_, i) => blocks[+i]);
}

/* ---------- state ---------- */
const DEF = { theme: 'auto', askPhone: true, mode: 'auto', model: 'sonnet', effort: 'medium', workspace: 'chat', abil: { cal: true, rem: true } };
const S = { keys: {}, st: { ...DEF }, chats: [], cur: null, run: null, gm: { models: [], chain: [] }, online: navigator.onLine !== false, app: 'home', log: [], limits: null };
const saveSettings = () => store.set('sl.settings', S.st);
const saveKeys = () => store.set('sl.keys', S.keys);
const saveChat = (c) => { if (!c) return; store.set('chat.' + c.id, c); store.set('sl.index', S.chats.map((x) => x.id)); paintAiRow(); };
let saveT = 0; const saveSoon = (c) => { clearTimeout(saveT); saveT = setTimeout(() => saveChat(c), 400); };
const hasClaude = () => !!S.keys.claude, hasGemini = () => !!S.keys.gemini;
const isG = (m = S.st.model) => String(m).startsWith('g:');
const canUse = () => S.online && (isG() ? hasGemini() : hasClaude());
const monthKey = () => new Date().toISOString().slice(0, 7);
const monthSpend = () => store.get('sl.spend', {})[monthKey()] || 0;
function addSpend(d) { if (!d) return; const sp = store.get('sl.spend', {}); sp[monthKey()] = (sp[monthKey()] || 0) + d; store.set('sl.spend', sp); paintPill(); }
const money = (n) => '$' + (n < 0.01 && n > 0 ? '0.01' : n.toFixed(2));
function paintPill() { $('#pcName').textContent = !S.online ? 'Offline' : monthSpend() > 0 ? money(monthSpend()) + ' this month' : 'Settings'; $('#pcPill').classList.toggle('off', !S.online); }
const modelName = (m) => (isG(m) ? prettyGemini(m.slice(2)) : MODELS[m]?.name || m);

/* ---------- theme ---------- */
const mq = matchMedia('(prefers-color-scheme: dark)');
function applyTheme() {
  const t = S.st.theme === 'auto' ? (mq.matches ? 'dark' : 'light') : S.st.theme;
  document.documentElement.dataset.theme = t;
  $('meta[name=theme-color]').content = t === 'dark' ? '#141517' : '#F5F5F2';
  plugin('StatusBar')?.setStyle?.({ style: t === 'dark' ? 'DARK' : 'LIGHT' })?.catch?.(() => {});
  glassTheme(S.st.theme);   // the native glass follows the app's choice, not only the phone's
}
mq.addEventListener?.('change', applyTheme);

/* ---------- sheets and toasts ---------- */
let sheetUp = false, drawerUp = false, pendingBack = null;
function openSheet(title, html, after, backArg) {
  if (!sheetUp) { sheetUp = true; glassCover(true); }
  // a page inside Settings says where "back" goes (subSheet sets it just before)
  const back = backArg || pendingBack; pendingBack = null;
  const bk = $('#shBack'); bk.hidden = !back;
  if (back) { bk.innerHTML = `${ic('chev')} ${esc(back[0])}`; bk.onclick = () => swapSheet(back[1]); }
  $('#shTitle').textContent = title; $('#shBody').innerHTML = html;
  $('#scrim').classList.remove('out'); $('#scrim').hidden = false; $('#sheet').hidden = false; void $('#sheet').offsetHeight; $('#sheet').classList.add('up');
  after && after($('#shBody'));
}
function closeSheet() {
  if (sheetUp) { sheetUp = false; glassCover(false); }
  $('#sheet').classList.remove('up'); $('#scrim').classList.add('out');
  // hidden only after the slide down (.55s in app.css) has finished, or it is cut off
  setTimeout(() => { if (!$('#sheet').classList.contains('up') && !$('#drawer').classList.contains('in')) { $('#sheet').hidden = true; $('#scrim').hidden = true; } }, 600);
}
const swapSheet = (fn) => { closeSheet(); setTimeout(fn, 440); };
const toSettings = ['Settings', () => $('#pcPill').click()];
const subSheet = (fn) => swapSheet(() => { pendingBack = toSettings; fn(); });   // a page inside Settings: it gets "‹ Settings"
$('#scrim').onclick = closeSheet;
// "Your PC" in the Files app: say why it couldn't be added (shown once per app start)
beam.onFilesNote((why) => toast('Files app: ' + why));
function toast(t, act) {   // act: ['Undo', fn] adds a button and keeps the message a little longer
  let el = $('#toast'); if (!el) { el = document.createElement('div'); el.id = 'toast'; $('#device').append(el); }
  el.textContent = t; el.classList.toggle('act', !!act);
  if (act) { const b = document.createElement('button'); b.textContent = act[0]; b.onclick = () => { el.classList.remove('on'); act[1](); }; el.append(b); }
  el.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('on'), act ? 6500 : 2800);
}
function pickSheet(title, items, current, onPick) {
  openSheet(title, items.map(([id, name, sub, off]) => `<button class="row ${id === current ? 'sel' : ''} ${off ? 'dis' : ''}" data-id="${id}"><span class="t"><b>${esc(name)}</b><small>${esc(sub || '')}</small></span>${ic('check', 'tick')}</button>`).join(''),
    (b) => $$('.row', b).forEach((r) => (r.onclick = () => { onPick(r.dataset.id); closeSheet(); })));
}

/* ---------- Ask the TV (tv/family.js): one short answer from Claude with the key on this phone, web search allowed ---------- */
async function tvAi({ system, text, image, web = true, maxTokens = 1200 }) {
  if (!hasClaude()) throw new Error('Add a Claude key in Settings.');
  const content = image ? [{ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: image } }, { type: 'text', text }] : text;
  let messages = [{ role: 'user', content }];
  for (let i = 0; i < 4; i++) {
    const r = await messagesStream({ key: S.keys.claude, model: MODELS.sonnet.id, system, messages, maxTokens, effort: 'low',
      tools: web ? [{ type: 'web_search_20250305', name: 'web_search', max_uses: 3 }] : [] });
    if (r.stop_reason === 'pause_turn') { messages = [...messages, { role: 'assistant', content: r.content }]; continue; }
    return r.content.filter((b) => b.type === 'text').map((b) => b.text).join('').trim();
  }
  throw new Error('Claude took too long. Try again.');
}

/* ---------- boot ---------- */
async function boot() {
  await store.initStore();
  S.st = { ...DEF, ...store.get('sl.settings', {}) }; S.st.abil = { ...DEF.abil, ...(S.st.abil || {}) };
  S.keys = store.get('sl.keys', {});
  S.gm = store.get('sl.gm', { models: [], chain: [] });
  S.log = store.get('sl.log', []);
  S.chats = store.get('sl.index', []).map((id) => store.get('chat.' + id)).filter(Boolean);
  S.limits = makeGeminiLimits(store);
  if (qs.has('reset')) { S.keys = {}; saveKeys(); }
  applyTheme();
  $('#splashMark').innerHTML = mark('play'); $('#loginMark').innerHTML = mark('play loop'); $('#topMark').innerHTML = mark('play');
  $('#welcomeMark').innerHTML = mark('play loop');
  paintWelcome();
  if (!hasClaude() && !hasGemini() && !store.get('sl.imported', false)) {
    try {   // a build made on the owner's PC carries the keys in keys.json; they move into phone storage once
      const r = await fetch('keys.json', { cache: 'no-store' });
      if (r.ok) { const j = await r.json(); if (j.claude || j.gemini) { S.keys = { claude: j.claude || '', gemini: j.gemini || '' }; saveKeys(); store.set('sl.imported', true); if (j.gemini) refreshGemini(); } }
    } catch {}
  }
  if (!S.keys.claude && !S.keys.gemini) S.keys = {};
  if (!store.get('sl.shelf', '')) {   // a build made on the owner's PC carries the private shelf link ("Your PC"); kept once
    try { const r = await fetch('shelf.json', { cache: 'no-store' }); if (r.ok) { const j = await r.json(); if (j.url) store.set('sl.shelf', j.url); } } catch {}
  }
  normalizeModel();
  await sleepMs(FAST ? 250 : 1700);
  $('#splash').classList.add('out');
  // Shivam, 21 Oct 2026: nothing opens without an invite code (engine/id.js); with one, the welcome the first time,
  // after that straight in (keys are asked when Labs AI is opened)
  if (!(await pass.start(passChanged))) showGate(); else goIn();
  if (hasGemini() && !S.gm.chain.length) refreshGemini();
  appReady(); otaCheck(); followAsk(); setTimeout(() => appCheck(), 8000);
}
// Over-the-air updates: check on opening and whenever the app comes back to the front.
// an update restarts the page: bring the logo screen back and park the native bar first, so only the logo is on screen
const otaCheck = () => checkForUpdate({
  isIdle: () => !S.run,
  onApplied: () => { glassPark(); $('#splash').classList.remove('out'); },
  onAbort: () => { $('#splash').classList.add('out'); glassPark(false); toast("Couldn't switch to the new version"); },
});
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { otaCheck(); if (wantsApp()) appCheck(true); } });
// The Android app itself (engine/apkupdate.js): a newer version is offered at most once a day; Android then asks
// "Update?". force: the person just allowed installs and came back, so carry on without asking again.
async function appCheck(force) {
  if (S.run) return;
  const ask = force ? undefined : async (v) => {
    const k = store.get('sl.apkAsk', {}); if (k.v === v && Date.now() - k.at < 86400e3) return false;
    store.set('sl.apkAsk', { v, at: Date.now() });
    const D = plugin('Dialog'); if (!D) return false;
    return (await D.confirm({ title: 'Update Shivo Labs', message: `Version ${v} is ready.`, okButtonTitle: 'Install', cancelButtonTitle: 'Later' })).value;
  };
  const r = await updateApp({ ask }).catch(() => null);
  if (r && !/ is ready\.$/.test(r)) toast(r);
}

/* ---------- first run: welcome ---------- */
$('#welcomeGo').onclick = () => { store.set('sl.welcomed', true); $('#welcome').hidden = true; enterApp(); };
function goIn() {
  paintWelcome();
  if (hasClaude() || hasGemini() || store.get('sl.explore', false) || store.get('sl.welcomed', false)) enterApp(); else { $('#welcome').hidden = false; }
}
function paintWelcome() {
  $('#welcomeMods').innerHTML = shown().map((m, i) => `<span class="wl-mod" style="--i:${i}">${modIcon(m)}${m.name}</span>`).join('');
}
// the modules this phone shows: the ones its pass has (Insights also needs the PC link that carries its numbers)
const shown = () => MODULES.filter((m) => pass.may(m.id) && (m.id !== 'insights' || store.get('sl.shelf', '')));

/* ---------- the invite code (engine/id.js): shown until this phone has a pass ---------- */
function showGate() {
  $('#gateMark').innerHTML = mark('play loop');
  $('#welcome').hidden = true; $('#shell').hidden = true; $('#gate').hidden = false;
  const input = $('#gateCode'), msg = (t, bad) => { $('#gateMsg').textContent = t; $('#gateMsg').classList.toggle('bad', !!bad); };
  input.oninput = () => { const c = input.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10); input.value = c.length > 5 ? `${c.slice(0, 5)}-${c.slice(5)}` : c; msg(''); };
  const go = async () => {
    const code = input.value.replace(/[^A-Z0-9]/gi, '');
    if (code.length < 10) return msg('The code has 10 letters and numbers', true);
    $('#gateGo').disabled = true; msg('Checking…');
    try {
      const r = await pass.enrol(code);
      haptic('success');
      $('#gate').hidden = true; $('#gateGo').disabled = false; input.value = ''; msg('');
      toast(`Welcome, ${r.customer}`);
      if ($('#shell').classList.contains('on')) { $('#shell').hidden = false; renderHome(); } else goIn();
    } catch (e) {
      $('#gateGo').disabled = false;
      msg(e.status === 404 ? 'That code is wrong or has expired' : e.message, true);
    }
  };
  $('#gateGo').onclick = go;
  input.onkeydown = (e) => { if (e.key === 'Enter') go(); };
  // the owner's code as a QR (Owner page): scanned here instead of typed
  $('#gateScan').onclick = async () => {
    const t = await scanQr('Scan the invite code');
    const c = /^shivolabs:\/\/code\/([A-Z0-9-]{10,14})\/?$/i.exec(t || '')?.[1] || (/^[A-Z0-9]{5}-?[A-Z0-9]{5}$/i.test(t || '') ? t : null);
    if (c) { const k = c.toUpperCase().replace(/[^A-Z0-9]/g, ''); input.value = `${k.slice(0, 5)}-${k.slice(5)}`; go(); }
    else if (t) msg('That QR is not an invite code', true);
  };
  // or a phone that is already joined scans this phone's QR and adds it (UNIFY-PLAN.md): checked every 3 seconds
  clearTimeout(showGate.timer);
  const showQr = async () => {
    if ($('#gate').hidden) return;
    let j = null; try { j = await pass.joinStart(); } catch {}
    if (!j) { $('#gateQr').hidden = true; showGate.timer = setTimeout(showQr, 30000); return; }
    const q = qrcode(0, 'M'); q.addData(j.link); q.make();
    $('#gateQrImg').innerHTML = q.createSvgTag({ cellSize: 4, margin: 1, scalable: true });
    $('#gateCheck').textContent = j.check; $('#gateQr').hidden = false;
    const wait = async () => {
      if ($('#gate').hidden) return;
      let r = null; try { r = await pass.joinWait(); } catch {}
      if (r?.customer) {
        haptic('success'); $('#gate').hidden = true; toast(`Welcome, ${r.customer}`);
        if ($('#shell').classList.contains('on')) { $('#shell').hidden = false; renderHome(); } else goIn();
        return;
      }
      showGate.timer = setTimeout(r?.expired ? showQr : wait, r?.expired ? 0 : 3000);
    };
    showGate.timer = setTimeout(wait, 3000);
  };
  showQr();
}

/* ---------- the Owner page on the owner's phone (UNIFY-PLAN.md): every customer, their modules, invite codes and
   devices, as on the owner's PC (hub/www/modules/owner.js). Each change is signed with this phone's key (engine/id.js);
   devices get it at their next pass. ---------- */
const MOD_NAMES = { ai: 'Shivo Labs AI', chat: 'Chat', mirror: 'Mirror', files: 'Shivo Labs Cloud', xtools: 'X Tools', tv: 'TV',
  camera: 'Camera', phone: 'Phone', insights: 'Insights', oracle: 'Oracle TM' };
const modName = (m) => MOD_NAMES[m] || m;
const prettyCode = (c) => `${c.slice(0, 5)}-${c.slice(5)}`;
const dayTxt = (t) => (t ? new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) : '');
// a device that checked in within 20 minutes (engine/id.js sends one every 15 while it runs) is online
const onlineNow = (d) => !d.removed && d.last_seen && Date.now() - d.last_seen < 20 * 60e3;
const devLine = (d) => [d.info?.os || d.kind.toUpperCase(), onlineNow(d) ? 'online' : `seen ${agoTxt(d.last_seen)}`, d.version, d.removed && 'removed'].filter(Boolean).map(esc).join(' · ');
const agoTxt = (t) => { if (!t) return 'never'; const m = (Date.now() - t) / 60000; return m < 2 ? 'just now' : m < 90 ? `${Math.round(m)} min ago` : m < 2880 ? `${Math.round(m / 60)} h ago` : dayTxt(t); };
let ownerSt = null;
async function ownerLoad() { ownerSt = await pass.owner('state'); return ownerSt; }
async function ownerSheet() {
  openSheet('Owner', '<p class="sh-p">Loading…</p>');
  try { await ownerLoad(); } catch (e) { $('#shBody').innerHTML = `<p class="sh-p">${esc(e.message)}</p>`; return; }
  const list = ownerSt.customers.slice().reverse();
  $('#shBody').innerHTML = `<div class="sgroup"><button class="row" id="ownNew"><span class="s-ic">${ic('x', 'own-plus')}</span><span class="t"><b>New customer</b><small>A shop, a family or a company.</small></span>${ic('chev')}</button></div>
    <div class="sh-sub">CUSTOMERS</div><div class="sgroup">${list.map((c) => {
      const n = c.devices.filter((d) => !d.removed).length;
      return `<button class="row${c.paused ? ' gone' : ''}" data-c="${c.id}"><span class="t"><b>${esc(c.name)}</b><small>${c.owner ? 'Owner · every module' : esc(c.modules.map(modName).join(' · ') || 'No modules')}${c.paused ? ' · paused' : ''}</small></span><span class="own-n">${n}</span>${ic('chev')}</button>`;
    }).join('') || '<p class="sh-p own-none">No customers yet.</p>'}</div>`;
  $('#ownNew').onclick = () => subSheet(() => ownerNewSheet());
  $$('[data-c]', $('#shBody')).forEach((r) => (r.onclick = () => swapSheet(() => customerSheet(r.dataset.c))));
}
const modChips = (all, sel) => `<div class="own-chips">${all.map((m) => `<label class="own-chip"><input type="checkbox" value="${m}" ${sel.includes(m) ? 'checked' : ''}><span>${esc(modName(m))}</span></label>`).join('')}</div>`;
const pickedMods = (box) => $$('.own-chip input:checked', box).map((i) => i.value);
function ownerNewSheet() {
  openSheet('New customer', `<input class="field" id="ownName" maxlength="80" placeholder="Name" autocorrect="off">
    <div class="sh-sub">MODULES</div>${modChips(ownerSt.modules, [])}
    <button class="btn pri" id="ownAdd" style="margin-top:12px">Add customer</button>`, (b) => {
    $('#ownAdd', b).onclick = async () => {
      const name = $('#ownName', b).value.trim(), modules = pickedMods(b);
      if (!name) return toast('Type a name');
      if (!modules.length) return toast('Pick at least one module');
      $('#ownAdd', b).disabled = true;
      try { const r = await pass.owner('customer', { name, modules }); haptic('success'); await ownerLoad(); swapSheet(() => customerSheet(r.id)); }
      catch (e) { $('#ownAdd', b).disabled = false; toast(e.message); }
    };
  });
}
async function shareCode(code) {
  const text = `Shivo Labs: download it from ${pass.ID_API} and type this code: ${prettyCode(code)}`;
  const S2 = plugin('Share');
  try { if (S2) await S2.share({ title: 'Shivo Labs', text }); else if (navigator.share) await navigator.share({ text }); else { await navigator.clipboard.writeText(text); toast('Copied, with the download link'); } } catch {}
}
function customerSheet(id, qrFor) {
  const c = ownerSt?.customers.find((x) => x.id === id);
  if (!c) return ownerSheet();
  openSheet(c.name, `<button class="own-back" id="ownBack">${ic('chev')} Customers</button>
    ${c.owner ? '<p class="sh-p">Your own devices: every module, and Insights and Oracle TM.</p>' : `<div class="sh-sub">MODULES</div>${modChips(ownerSt.modules, c.modules)}
    <div class="sgroup"><div class="row"><span class="t"><b>Paused</b><small>Its devices lose their modules at their next pass.</small></span><div class="seg" id="ownPause"><button data-p="0" class="${c.paused ? '' : 'on'}">On</button><button data-p="1" class="${c.paused ? 'on' : ''}">Paused</button></div></div>
    <div class="row"><span class="t"><b>Paid until</b><small>Empty when it isn't paid by date.</small></span><input class="field own-date" id="ownPaid" type="date" value="${c.paidUntil ? new Date(c.paidUntil).toISOString().slice(0, 10) : ''}"></div></div>
    <button class="btn sm" id="ownSave" style="margin-top:10px">Save</button>`}
    <div class="sh-sub">INVITE CODES</div><div class="sgroup">${c.codes.map((k) => `<div class="row"><span class="t"><b class="own-code">${prettyCode(k.code)}</b><small>${esc(k.label || 'No label')} · ${k.uses - k.used} of ${k.uses} left · until ${dayTxt(k.expires)}</small></span>
      <span class="own-acts"><button data-qr="${k.code}">QR</button><button data-share="${k.code}">Send</button><button data-revoke="${k.code}">Cancel</button></span></div>
      <div class="own-qr" data-qr-for="${k.code}" hidden></div>`).join('') || '<p class="sh-p own-none">No open codes.</p>'}</div>
    <div class="own-line"><input class="field" id="ownLabel" maxlength="60" placeholder="For (e.g. Till PC)"><input class="field xs" id="ownUses" type="number" min="1" max="100" value="1" aria-label="Uses"></div>
    <button class="btn sm pri" id="ownCode">Make a code</button>
    <div class="sh-sub">DEVICES</div><div class="sgroup">${c.devices.map((d) => `<div class="row${d.removed ? ' gone' : ''}"><span class="t"><b>${onlineNow(d) ? '<i class="own-on"></i>' : ''}${esc(d.name)}</b><small>${devLine(d)}</small>${d.info?.update && !d.info.update.ok ? `<small class="own-bad">${esc(d.info.update.msg)}</small>` : ''}</span>
      <span class="own-acts"><button data-dev="${d.id}" data-removed="${d.removed ? 1 : 0}">${d.removed ? 'Allow' : 'Remove'}</button></span></div>`).join('') || '<p class="sh-p own-none">No devices yet. Send a code.</p>'}</div>
    ${c.paused && !c.owner ? '<button class="btn sm own-del" id="ownDel">Delete this customer</button>' : ''}`, (b) => {
    const again = async (msg) => { try { await ownerLoad(); } catch {} if (msg) toast(msg); customerSheet(id); };
    const act = async (btn, what, body, msg) => { btn.disabled = true; try { await pass.owner(what, body); haptic('light'); await again(msg); } catch (e) { btn.disabled = false; toast(e.message); } };
    const showQr = (code) => {
      const box = $(`[data-qr-for="${code}"]`, b);
      if (!box) return;
      if (!box.hidden) { box.hidden = true; return; }
      const q = qrcode(0, 'M'); q.addData(`shivolabs://code/${code}`); q.make();
      box.innerHTML = `<div>${q.createSvgTag({ cellSize: 4, margin: 1, scalable: true })}</div><small>Scan with the new phone's camera. That phone then adds their other devices.</small>`;
      box.hidden = false;
    };
    $('#ownBack', b).onclick = () => subSheet(() => ownerSheet());
    $$('#ownPause button', b).forEach((x) => (x.onclick = () => $$('#ownPause button', b).forEach((y) => y.classList.toggle('on', y === x))));
    $('#ownSave', b) && ($('#ownSave', b).onclick = () => {
      const modules = pickedMods(b);
      if (!modules.length) return toast('Pick at least one module');
      act($('#ownSave', b), 'customer', { id, modules, paused: $('#ownPause .on', b)?.dataset.p === '1', paidUntil: $('#ownPaid', b).value ? Date.parse($('#ownPaid', b).value + 'T23:59:59') : 0 }, 'Saved. Devices change at their next pass');
    });
    $('#ownCode', b).onclick = async () => {
      const btn = $('#ownCode', b); btn.disabled = true;
      try {
        const r = await pass.owner('code', { customer: id, uses: +$('#ownUses', b).value || 1, label: $('#ownLabel', b).value.trim() });
        haptic('success'); await ownerLoad(); customerSheet(id, r.code);
      } catch (e) { btn.disabled = false; toast(e.message); }
    };
    $$('[data-qr]', b).forEach((x) => (x.onclick = () => showQr(x.dataset.qr)));
    $$('[data-share]', b).forEach((x) => (x.onclick = () => shareCode(x.dataset.share)));
    $$('[data-revoke]', b).forEach((x) => (x.onclick = () => act(x, 'code/revoke', { code: x.dataset.revoke }, 'Code cancelled')));
    $$('[data-dev]', b).forEach((x) => (x.onclick = () => act(x, 'device', { id: x.dataset.dev, removed: x.dataset.removed !== '1' })));
    // deleted for good, with its codes and devices: only a paused customer, and a second tap to be sure
    $('#ownDel', b) && ($('#ownDel', b).onclick = async () => {
      const x = $('#ownDel', b);
      if (!x.dataset.sure) { x.dataset.sure = 1; x.textContent = `Tap again to delete ${c.name}`; return; }
      x.disabled = true;
      try { await pass.owner('customer/delete', { id }); haptic('success'); toast(`${c.name} deleted`); swapSheet(() => ownerSheet()); }
      catch (e) { x.disabled = false; toast(e.message); }
    });
    if (qrFor) showQr(qrFor);
  });
}

/* ---------- adding a device by QR (UNIFY-PLAN.md): a new PC, phone or TV shows a QR; this phone scans and adds it ---------- */
// the camera's QR scanner (Capacitor's barcode scanner); null when cancelled or not available
async function scanQr(hint) {
  const B = plugin('CapacitorBarcodeScanner');
  if (!B) { toast("This app can't scan yet. Open the QR with the Camera app instead."); return null; }
  try { const r = await B.scanBarcode({ hint: 0, scanInstructions: hint, scanButton: false }); return r?.ScanResult || null; } catch { return null; }
}
const KIND = { pc: 'PC', phone: 'Phone', tv: 'TV' };
// Settings > Add a device: this phone's QR for a new phone to scan (a code for one use, 10 minutes; a PC has no camera,
// so a new PC shows its own QR instead), and the scanner for a new PC's, phone's or TV's QR
async function addDevice(join) {
  if (!pass.state()) return toast('Join this phone first, then add the others');
  if (join) return approveDevice(join);
  openSheet('Add a device', `<div class="own-qr inv-qr"><div id="invImg"></div><small id="invTxt">Making a QR…</small></div>
    <button class="btn pri" id="invScan">Scan a new device</button>`, (b) => {
    const show = async () => {
      if (!$('#invImg', b)?.isConnected || !$('#sheet').classList.contains('up')) return;   // only while it's on screen
      try {
        const r = await pass.invite();
        const q = qrcode(0, 'M'); q.addData(r.link); q.make();
        $('#invImg', b).innerHTML = q.createSvgTag({ cellSize: 4, margin: 1, scalable: true });
        $('#invTxt', b).textContent = 'A new phone: scan this with its camera. It works once, for 10 minutes.';
        clearTimeout(addDevice.t); addDevice.t = setTimeout(show, Math.max(r.expires - Date.now() - 30e3, 30e3));   // a fresh one before it runs out
      } catch (e) { $('#invTxt', b).textContent = e.message; }
    };
    show();
    $('#invScan', b).onclick = async () => {
      const t = await scanQr('Scan the QR on the new PC, phone or TV');
      if (!t) return;
      const j = pass.joinIdOf(t);
      if (!j) return toast('That QR is not a Shivo Labs device');
      swapSheet(() => approveDevice(j));
    };
  });
}
async function approveDevice(join) {
  let d; try { d = await pass.lookJoin(join); } catch (e) { return toast(e.message); }
  if (d.done) return toast('That device was added already');
  openSheet('Add a device', `
    <div class="add-dev"><b>${esc(d.name)}</b><small>${esc(KIND[d.kind] || d.kind)} · its screen shows <span class="mono">${esc(d.check)}</span></small></div>
    <p class="sh-p">It joins ${esc(pass.state().customer)} with the same modules as this phone.</p>
    <button class="btn pri" id="addGo" style="margin-top:12px">Add</button>`, (b) => {
    $('#addGo', b).onclick = async () => {
      $('#addGo', b).disabled = true;
      try { const r = await pass.approveJoin(join); haptic('success'); closeSheet(); toast(`${r.name} added`); }
      catch (e) { $('#addGo', b).disabled = false; toast(e.message); }
    };
  });
}
// the owner changed this phone's modules, or removed it
function passChanged(cur) {
  if (!cur) { switchApp('home'); return showGate(); }
  renderHome(); paintWelcome();
  if (S.app !== 'home' && !pass.may(S.app)) switchApp('home');
  paintNav(); syncGlass(GL);
}

/* ---------- keys: asked when Labs AI is opened without one ---------- */
const keysUp = () => !$('#login').hidden;
function askKeys() { if (keysUp()) return; $('#login').hidden = false; glassCover(true); setTimeout(() => kc.focus?.(), 600); }
function closeKeys() { if (!keysUp()) return; $('#login').hidden = true; glassCover(false); }
// after keys are added (or "Look around first"): into the app if needed, then into Labs AI
const intoAi = () => { closeKeys(); if ($('#shell').hidden) enterApp(); switchApp('ai'); };
const kc = $('#claudeKey'), kg = $('#geminiKey');
const syncGo = () => { $('#goBtn').disabled = kc.value.trim().length < 12 && kg.value.trim().length < 12; };
kc.oninput = kg.oninput = () => { $('#codeHint').className = 'hint'; syncGo(); };
$('#goBtn').onclick = async () => {
  const c = kc.value.trim(), g = kg.value.trim(), hint = $('#codeHint'), btn = $('#goBtn');
  btn.disabled = true; hint.className = 'hint'; hint.textContent = 'Checking your keys…';
  if (c) { const r = await checkKey(c); if (!r.ok) { hint.className = 'hint err'; hint.textContent = r.error; syncGo(); return; } }
  let models = [];
  if (g) { try { models = await listGeminiModels(g); } catch (e) { hint.className = 'hint err'; hint.textContent = e.message; syncGo(); return; } }
  S.keys = { claude: c, gemini: g }; saveKeys();
  if (g) { S.gm = { models, chain: defaultGeminiChain(models) }; store.set('sl.gm', S.gm); }
  normalizeModel(); hint.textContent = 'You are in.';
  await sleepMs(500); paintChips(); updateSend(); intoAi();
};
// Setup: "Get a key" opens the provider's page; the paste buttons fill a field from the clipboard.
$$('.lg-get').forEach((b) => (b.onclick = () => openURL(b.dataset.url).catch(() => window.open(b.dataset.url, '_blank'))));
$$('.lg-paste').forEach((b) => (b.onclick = async () => {
  try { const t = (await navigator.clipboard.readText()).trim(); if (!t) return toast('Nothing to paste'); const f = $('#' + b.dataset.for); f.value = t; f.dispatchEvent(new Event('input')); haptic('light'); }
  catch { toast('Tap and hold the box, then Paste'); }
}));
// Look around without keys; keys can be added later in Settings.
$('#exploreBtn').onclick = () => { store.set('sl.explore', true); intoAi(); };
$('#loginClose').onclick = closeKeys;

/* ---------- shell ---------- */
function enterApp() {
  $('#login').hidden = true; $('#shell').hidden = false;
  requestAnimationFrame(() => $('#shell').classList.add('on'));
  paintNav();   // the floating bar, with what this phone's pass has
  $('#offLoader').innerHTML = loader('wait', 18);
  paintPill(); paintChips(); renderMsgs(); updateSend(); renderTasks(); renderHome();
  $('#offline').hidden = S.online;
  const last = S.chats.find((c) => c.session?.status === 'running'); if (last) resumeTask(last);
  live.setLook(S.st.liveLook);
  if (S.st.autoBeam !== false) bmTimer = setTimeout(bmPoll, 600);
  setTimeout(() => MODULES.filter((m) => m.web).forEach((m) => plugin('ShivoNative')?.preloadWeb?.({ url: m.web, css: m.css || '' }).catch(() => {})), 2500);
  if (!enterApp.glass) { enterApp.glass = true; setTimeout(() => startGlass({ ...GL, onTab: (id) => (id !== S.app && openModule(id)), onButton: (id) => (id === 'homeBtn' || id === 'homeBtnT') ? (!SW.el && switchApp('home')) : $('#' + id)?.click(), onHold: onNativeHold }), 450); }
}
const ORDER = ['home', 'ai', 'chat', 'beam', 'tv', 'insights', 'camera'];
// the floating bar (UNIFY-PLAN.md phase 2, Shivam 23 Oct): Chat, TV, Cloud, Camera (what this phone's pass has), and
// Search at the right. It shows on Home and on those screens, not inside a conversation or the full-screen camera.
const NAV = [
  { id: 'chat', label: 'Chat', symbol: 'bubble.left.and.bubble.right', icon: '<path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v8a2.5 2.5 0 0 1-2.5 2.5H10l-4.5 3.5V17A2.5 2.5 0 0 1 4 14.5z"/>' },
  { id: 'tv', label: 'TV', symbol: 'tv', icon: '<rect x="3" y="5" width="18" height="12" rx="2.5"/><path d="M8 21h8M12 17v4"/>' },
  { id: 'beam', label: 'Cloud', symbol: 'icloud', icon: '<path d="M7 18a4.5 4.5 0 0 1-.8-8.93A6 6 0 0 1 17.6 8.5 4 4 0 0 1 17 18z"/>' },
  { id: 'camera', label: 'Camera', symbol: 'camera', icon: '<path d="M4 8.5h3l1.8-2.5h6.4L17 8.5h3v10.5H4z"/><circle cx="12" cy="13.5" r="3.6"/>' },
];
const navItems = () => NAV.filter((n) => pass.may(n.id));
const navShown = () => ['home', 'chat', 'tv', 'beam'].includes(S.app) && !(S.app === 'chat' && $('#chApp')?.classList.contains('open')) && navItems().length > 0;
function paintNav() {
  const bar = $('#tabs'), lens = $('.lens', bar);
  bar.innerHTML = navItems().map((n) => `<button data-go="${n.id}" class="${n.id === S.app ? 'on' : ''}"><span class="ico"><svg viewBox="0 0 24 24">${n.icon}</svg></span><span class="lbl">${n.label}</span></button>`).join('');
  if (lens) bar.prepend(lens);
  $$('button', bar).forEach((b) => (b.onclick = () => (b.dataset.go === S.app ? null : openModule(b.dataset.go))));
  document.body.classList.toggle('nav', navShown());
  document.body.classList.toggle('deep', S.app === 'chat' && !!$('#chApp')?.classList.contains('open'));   // a conversation has its own header
  window.__syncLens?.();
}
// what the native glass draws (iOS 26): the bar, the search button, and the round buttons of each screen
const GL = {
  tabs: () => (navShown() && !document.body.classList.contains('searching')
    ? { el: $('#tabs'), selected: navItems().some((n) => n.id === S.app) ? S.app : '', items: navItems().map(({ id, label, symbol }) => ({ id, label, symbol })) }
    : { el: null, selected: '', items: [] }),
  buttons: () => [
    ...(navShown() && !document.body.classList.contains('searching') ? [{ id: 'searchBtn', symbol: 'magnifyingglass' }] : []),
    ...(S.app === 'ai' ? [{ id: 'menuBtn', symbol: 'clock.arrow.circlepath' }, { id: 'newBtn', symbol: 'square.and.pencil' }, { id: 'homeBtn', symbol: 'chevron.left' }]
      : S.app === 'home' ? [{ id: 'homeSet', symbol: 'gearshape' }] : S.app === 'camera' ? [] : [{ id: 'homeBtnT', symbol: 'square.grid.2x2' }]),
  ],
};
const taskBadgeEl = () => $('#taskBadge') || { hidden: true };
function ensureChat() {
  if (switchApp.chat) return;
  window.shivoMark = mark;
  switchApp.chat = mountChat($('#chatBody'), { toast, haptic, cover: glassCover, getPass: async () => pass.passFor('chat'), ai: pass.may('ai') ? { info: aiInfo, open: () => openAiThread() } : null });
}
function switchApp(to) {
  if (to === S.app) return;
  // Back from the Labs AI thread goes to where it was opened (Chat, where it is pinned), not always Home
  if (to === 'home' && S.app === 'ai' && S.aiFrom && S.aiFrom !== 'home') to = S.aiFrom;
  if (to !== 'home' && !pass.may(to)) return;   // links and notifications too: only what this phone's pass has
  // Labs AI needs a Claude or Gemini key: ask for one first (other modules don't)
  if (to === 'ai' && !hasClaude() && !hasGemini() && !store.get('sl.explore', false)) return askKeys();
  endSearch();   // any change of screen puts the search box away
  keyboardSync();   // and drops a keyboard lift that is no longer true
  const from = S.app; S.app = to; document.body.dataset.app = to;
  if (to === 'ai') S.aiFrom = from;
  paintNav(); selectGlassTab(to); syncGlass(GL); setTimeout(() => syncGlass(GL), 560);
  const vf = $('#v-' + from), vt = $('#v-' + to);
  vf.classList.remove('on'); vf.classList.toggle('left', ORDER.indexOf(to) > ORDER.indexOf(from)); vt.classList.remove('left'); vt.classList.add('on');
  const tag = $('#tag'); tag.classList.add('swap');
  setTimeout(() => { tag.textContent = { home: 'HOME', ai: 'AI', tasks: 'TASKS', chat: 'CHAT', beam: 'CLOUD', tv: 'TV', insights: 'INSIGHTS', phone: 'PHONE', camera: 'CAMERA' }[to]; tag.classList.remove('swap'); }, 160);
  const m = $('#topMark .mk'); m.classList.remove('play', 'sweep'); void m.getBoundingClientRect(); m.classList.add('sweep');
  if (to === 'tasks') renderTasks(); if (to === 'beam') renderBeam(true); if (to === 'chat') ensureChat(); if (from === 'camera') switchApp.cam?.stop();
  if (from === 'tv') switchApp.tv?.stop();
  if (from === 'insights') switchApp.ins?.stop();
  if (to === 'insights') { if (!switchApp.ins) switchApp.ins = mountInsights($('#insightsBody'), { load: loadInsights, toast, haptic }); switchApp.ins.start(); }
  if (to === 'tv') { if (!switchApp.tv) switchApp.tv = mountTv($('#tvBody'), { toast, haptic, ai: tvAi }); switchApp.tv.start(); }
  if (to === 'camera') { if (!switchApp.cam) { switchApp.cam = mountCamera($('#camBody'), { toast, haptic, plugin, openURL }); $('#camBody').addEventListener('camera-close', () => switchApp('home')); } switchApp.cam.start(); }
  if (to === 'home' && !switchApp.keepHome) renderHome(); switchApp.keepHome = false;
  markScrolled();
}
const scroller = () => ({ home: $('#homeBody'), ai: $('#msgs'), tasks: $('#tasksBody'), beam: $('#beamBody'), tv: $('#tvBody'), insights: $('#insightsBody') }[S.app]);
const markScrolled = () => $('.top').classList.toggle('scrolled', (scroller()?.scrollTop || 0) > 4);
// glass buttons that sit inside scrolling content (the home gear) follow it while scrolling
let glassRaf = 0;
$('#homeBody').addEventListener('scroll', () => { if (!glassRaf) glassRaf = requestAnimationFrame(() => { glassRaf = 0; syncGlass(GL); }); }, { passive: true });
['#homeBody', '#msgs', '#tasksBody', '#beamBody', '#tvBody', '#insightsBody'].forEach((s) => $(s).addEventListener('scroll', markScrolled, { passive: true }));

function setOnline(v) {
  S.online = v; $('#offline').hidden = v; paintPill(); syncPlaceholder(); updateSend();
  if (v) { const c = S.chats.find((x) => x.session?.status === 'running'); if (c && !S.run) resumeTask(c); }
}
addEventListener('online', () => setOnline(true)); addEventListener('offline', () => setOnline(false));
document.addEventListener('visibilitychange', async () => {
  if (document.visibilityState !== 'visible' || $('#shell').hidden) return;
  const live = S.run?.chat?.session?.status === 'running' ? S.run : null;
  if (live) {   // iOS may have cut the live stream while we were away: drop it and re-attach
    live.detached = true; live.ctl.abort();
    for (let i = 0; i < 40 && S.run; i++) await sleepMs(50);
    S.run = null;
    resumeTask(live.chat, true); return;
  }
  const c = S.chats.find((x) => x.session?.status === 'running');
  if (c) resumeTask(c, true);
});

/* ---------- models ---------- */
function normalizeModel() {
  if (isG() && !hasGemini()) S.st.model = hasClaude() ? 'sonnet' : S.st.model;
  else if (!isG() && !hasClaude() && hasGemini()) S.st.model = 'g:' + (S.gm.chain[0] || 'gemini-3.5-flash-lite');
  if (S.st.workspace === 'cloud' && !hasClaude()) S.st.workspace = 'chat';
  saveSettings();
}
async function refreshGemini() {
  try { const models = await listGeminiModels(S.keys.gemini); S.gm = { models, chain: defaultGeminiChain(models) }; store.set('sl.gm', S.gm); normalizeModel(); paintChips(); } catch {}
}
function chainFor(m) { const start = String(m).slice(2); return [start, ...S.gm.chain.filter((x) => x !== start)]; }

function paintChips() {
  $('#chatTitle').textContent = modelName(S.st.model).replace('Gemini ', '');
  $('#modelTxt').textContent = S.fell ? modelName('g:' + S.fell).replace('Gemini ', '') : modelName(S.st.model).replace('Gemini ', '');
  $('#modelChip').classList.toggle('fell', !!S.fell);
  $('#folderTxt').textContent = S.st.workspace === 'cloud' ? 'Cloud task' : 'Chat';
  $('#modeTxt').textContent = { ask: 'Ask', auto: 'Auto', plan: 'Plan' }[S.st.mode];
  $('#modeChip').hidden = S.st.workspace !== 'cloud';
  syncPlaceholder();
}
function syncPlaceholder() { $('#box').placeholder = !S.online ? "You're offline" : !canUse() ? 'Add a key in Settings to start' : S.st.workspace === 'cloud' ? 'Describe a task…' : 'Ask Labs AI…'; }

$('#modelChip').onclick = () => {
  const row = (id, n, sub, off) => `<button class="row ${id === S.st.model ? 'sel' : ''} ${off ? 'dis' : ''}" data-id="${id}"><span class="t"><b>${esc(n)}</b><small>${esc(sub)}</small></span>${ic('check', 'tick')}</button>`;
  const claude = hasClaude() ? Object.entries(MODELS).map(([k, m]) => row(k, m.name, m.note)).join('')
    : `<button class="row" id="addClaude"><span class="t"><b>Add your Claude key</b><small>From the Claude Console. Kept on this phone only.</small></span>${ic('chev')}</button>`;
  const gem = hasGemini() ? (S.gm.chain.length ? S.gm.chain.map((m) => {
    const L = freeLimits(m), used = S.limits.usedToday(m), out = S.limits.isOut(m);
    return row('g:' + m, prettyGemini(m), out ? (S.limits.whyOut(m) === 'gone' ? 'Not available to your key' : S.limits.whyOut(m) === 'busy' ? 'Overloaded at Google, retrying soon' : 'Used up today') : `Free: ${used} of ${L.rpd} used today`);
  }).join('') : '<p class="sh-p">Loading your Gemini models…</p>')
    : `<button class="row" id="addGem"><span class="t"><b>Add a Gemini key</b><small>Free from Google. Works anywhere.</small></span>${ic('chev')}</button>`;
  openSheet('Model', `<div class="sh-sub" style="margin-top:0">CLAUDE · YOUR KEY</div>${claude}
    <div class="sh-sub">GEMINI · YOUR FREE KEY</div>${gem}
    <p class="sh-p" style="margin-top:10px">If a Gemini model runs out of free requests, the next one takes over by itself and you get a notice.</p>`, (b) => {
    $$('.row[data-id]', b).forEach((r) => (r.onclick = () => { S.st.model = r.dataset.id; S.fell = null; if (isG() && S.st.workspace === 'cloud') { S.st.workspace = 'chat'; toast('Gemini works in Chat. Cloud tasks use Claude.'); } saveSettings(); paintChips(); updateSend(); closeSheet(); }));
    $('#addClaude', b) && ($('#addClaude', b).onclick = () => swapSheet(() => keySheet('claude')));
    $('#addGem', b) && ($('#addGem', b).onclick = () => swapSheet(() => keySheet('gemini')));
  });
};
$('#folderChip').onclick = () => pickSheet('How should it work?', [
  ['chat', 'Chat', 'Quick answers. Can search the web and use your calendar.'],
  ['cloud', 'Cloud task', hasClaude() ? 'A cloud workspace that builds, fixes and writes things. Keeps going when you lock your phone.' : 'Needs your Claude key', !hasClaude()],
], S.st.workspace, (id) => { S.st.workspace = id; if (id === 'cloud' && isG()) S.st.model = 'sonnet'; saveSettings(); paintChips(); updateSend(); });
$('#modeChip').onclick = () => pickSheet('How much can it do on its own?', [
  ['auto', 'Auto', 'Does the work without stopping to ask'], ['ask', 'Ask', 'Asks before it runs commands or changes files'], ['plan', 'Plan', 'Only looks and proposes a plan'],
], S.st.mode, (id) => { S.st.mode = id; saveSettings(); paintChips(); });

/* ---------- chats ---------- */
const msgsEl = $('#msgs'), box = $('#box');
const scrollDown = () => { msgsEl.scrollTop = msgsEl.scrollHeight; };
const newChat = () => ({ id: 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), title: 'New chat', at: Date.now(), history: [], ui: [], session: null, kind: 'chat' });
function syncWorkspace() { const w = S.cur?.session ? 'cloud' : 'chat'; if (S.cur && S.st.workspace !== w) { S.st.workspace = w; saveSettings(); paintChips(); updateSend(); } }
// ---- the Labs AI thread lives in Chat (pinned row at the top; chat/chat.js `ai`). Its newest conversation is "the" thread; the side panel
// (clock button) is its History; "New chat" starts a fresh topic. The row's line is the last words of the newest conversation.
const recentThread = (maxAge) => { const c = S.chats.filter((x) => !x.session).sort((a, b) => b.at - a.at)[0]; return c && Date.now() - c.at < maxAge ? c : null; };
function aiInfo() {
  const c = S.chats.filter((x) => !x.session).sort((a, b) => b.at - a.at)[0];
  if (!c) return { sub: 'Ask anything. Reminders, calendar, files, the web.', at: 0 };
  const last = [...(c.ui || [])].reverse().find((m) => m.t);
  return { sub: last ? (last.r === 'u' ? 'You: ' : '') + String(last.t).replace(/\s+/g, ' ').slice(0, 90) : c.title, at: c.at };
}
function openAiThread() {
  if (!S.cur || S.cur.session) { S.cur = recentThread(Infinity); if (S.st.workspace === 'cloud') { S.st.workspace = 'chat'; saveSettings(); } paintChips(); renderMsgs(); }
  switchApp('ai');
}
const paintAiRow = () => $('#chatBody')?._paintAi?.();
function renderChats() { paintAiRow(); $('#chatTitle').textContent = modelName(S.st.model).replace('Gemini ', ''); document.body.classList.toggle('fresh', !S.cur || !S.cur.ui.length); }
function assistantEl(a) {
  const el = document.createElement('div'); el.className = 'm a';
  for (const n of a.notes || []) addNote(el, n);
  if (a.steps?.length) el.insertAdjacentHTML('beforeend', `<div class="steps collapsed"><button class="sg"><span class="ico">${ic('check')}</span><span class="lbl">${esc(a.sum || a.steps.length + ' steps')}</span>${ic('chev', 'chev')}</button><div class="sl"><div>${a.steps.map((s) => `<div class="st done"><i class="s"></i><span>${s.html}</span></div>`).join('')}</div></div></div>`);
  if (a.t) el.insertAdjacentHTML('beforeend', `<div class="txt">${md(a.t)}</div>`);
  if (a.files?.length) addFiles(el, a.files, S.cur);
  $$('.steps .sg', el).forEach((b) => (b.onclick = () => b.parentElement.classList.toggle('collapsed')));
  return el;
}
function renderMsgs() {
  renderChats();
  const c = S.cur;
  if (!c || !c.ui.length) {
    const sugg = S.st.workspace === 'cloud'
      ? [['Coffee stall website', 'Build me a one-page website for a coffee stall'], ['Summarise my notes', 'Turn my notes into a clean one-page summary'], ['Budget tracker', 'Make a simple budget tracker page']]
      : [['My week ahead', 'What is on my calendar this week?'], ['Remind me at 9', 'Remind me to call the electrician tomorrow at 9'], ['Explain mortgages', 'Explain how mortgages work in simple terms']];
    const hr = new Date().getHours(), hi = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
    msgsEl.innerHTML = `<div class="empty"><div class="mkw hero">${mark('play')}</div>
      <h1>${hi}. <span>${S.st.workspace === 'cloud' ? 'What should I build in the cloud?' : 'What are we doing today?'}</span></h1>
      <div class="sugg">${sugg.map(([l, q]) => `<button data-q="${esc(q)}">${ic('spark')}<span>${esc(l)}</span></button>`).join('')}</div></div>`;
    $$('.sugg button', msgsEl).forEach((b) => (b.onclick = () => send(b.dataset.q)));
    return;
  }
  msgsEl.innerHTML = '';
  for (const m of c.ui) {
    if (m.r === 'u') { const el = document.createElement('div'); el.className = 'm u'; el.innerHTML = `${attStrip(m.att || [])}<div>${esc(m.t)}</div>`; msgsEl.append(el); }
    else msgsEl.append(assistantEl(m));
  }
  scrollDown();
}
$('#modelTitle').onclick = () => modelMenu();
$('#menuBtn').onclick = () => openDrawer();
/* ---------- attachments: photos, camera, PDFs and text files (the + in the message box) ---------- */
const ATT = [];   // waiting to be sent: { name, kind: 'image'|'pdf'|'text', mime, data, text, thumb }
const readAs = (f, how) => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = () => no(r.error); r[how](f); });
// Photos are shrunk to at most 1600 px (plenty for the models, and keeps chats small on the phone).
async function shrink(f) {
  const url = URL.createObjectURL(f);
  try {
    const img = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = url; });
    const k = Math.min(1, 1600 / Math.max(img.naturalWidth, img.naturalHeight));
    const cv = document.createElement('canvas'); cv.width = Math.round(img.naturalWidth * k); cv.height = Math.round(img.naturalHeight * k);
    cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
    const full = cv.toDataURL('image/jpeg', 0.85);
    const t = document.createElement('canvas'), tk = 120 / Math.max(cv.width, cv.height); t.width = Math.round(cv.width * tk); t.height = Math.round(cv.height * tk);
    t.getContext('2d').drawImage(cv, 0, 0, t.width, t.height);
    return { mime: 'image/jpeg', data: full.split(',')[1], thumb: t.toDataURL('image/jpeg', 0.7) };
  } finally { URL.revokeObjectURL(url); }
}
async function addAttachments(list) {
  for (const f of list) {
    if (ATT.length >= 6) { toast('Up to 6 at a time'); break; }
    try {
      if (f.type.startsWith('image/')) ATT.push({ name: f.name || 'Photo', kind: 'image', ...(await shrink(f)) });
      else if (f.type === 'application/pdf' || /\.pdf$/i.test(f.name)) {
        if (f.size > 20e6) { toast(`${f.name} is over 20 MB`); continue; }
        ATT.push({ name: f.name, kind: 'pdf', mime: 'application/pdf', data: (await readAs(f, 'readAsDataURL')).split(',')[1] });
      } else if (f.type.startsWith('text/') || /\.(txt|md|csv)$/i.test(f.name)) ATT.push({ name: f.name, kind: 'text', text: (await readAs(f, 'readAsText')).slice(0, 200000) });
      else toast(`${f.name}: only photos, PDFs and text files for now`);
    } catch { toast(`Couldn't read ${f.name}`); }
  }
  paintAtt(); updateSend();
}
const fileIcon = '<svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13H7zM14 3v5h5"/></svg>';
function attStrip(list) {
  if (!list?.length) return '';
  return `<div class="att-strip">${list.map((f) => f.thumb ? `<img src="${f.thumb}" alt="">` : `<span class="att-doc">${fileIcon}<i>${esc(f.name)}</i></span>`).join('')}</div>`;
}
function paintAtt() {
  const el = $('#att'); if (!el) return;
  el.hidden = !ATT.length;
  const x = '<svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7 7 17"/></svg>';
  el.innerHTML = ATT.map((f, i) => f.thumb
    ? `<span class="att-tile"><img src="${f.thumb}" alt=""><button data-i="${i}" aria-label="Remove">${x}</button></span>`
    : `<span class="att-tile doc">${fileIcon}<i>${esc(f.name)}</i><button data-i="${i}" aria-label="Remove">${x}</button></span>`).join('');
  $$('button', el).forEach((b) => (b.onclick = () => { ATT.splice(+b.dataset.i, 1); paintAtt(); updateSend(); }));
}
// The user's message as content blocks: attachments first, then the words.
function userContent(text) {
  const files = S.pending || []; S.pending = null;
  if (!files.length) return text;
  return [...files.map((f) => f.kind === 'image' ? { type: 'image', source: { type: 'base64', media_type: f.mime, data: f.data } }
    : f.kind === 'pdf' ? { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: f.data } }
    : { type: 'text', text: `File "${f.name}":\n${f.text}` }), { type: 'text', text }];
}
$('#plusBtn').onclick = () => openSheet('Add', `
  <div class="add-tiles">
    <button data-p="pickPhotos"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-8 8"/></svg>Photos</button>
    <button data-p="pickCamera"><svg viewBox="0 0 24 24"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>Camera</button>
    <button data-p="pickFiles"><svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13H7zM14 3v5h5"/></svg>Files</button>
  </div>
  <p class="sh-p">Photos, PDFs and text files. ${S.st.workspace === 'cloud' ? 'Switch to Chat to send them.' : 'They go with your next message.'}</p>`, (b) => {
  $$('.add-tiles button', b).forEach((x) => (x.onclick = () => { closeSheet(); $('#' + x.dataset.p).click(); }));
});
['pickPhotos', 'pickCamera', 'pickFiles'].forEach((id) => ($('#' + id).onchange = (e) => { addAttachments([...e.target.files]); e.target.value = ''; }));

/* ---------- model menu: drops down from the title (like Gemini's) ---------- */
const EFFORT = [['low', 'Low', 'Quick and efficient'], ['medium', 'Medium', 'Balanced depth'], ['high', 'High', 'Extra thorough']];
function modelMenu() {
  if ($('#mmenu')) return closeModelMenu();
  const cur = S.st.model, eff = S.st.effort || 'medium';
  const item = (id, n, sub) => `<button class="mm-i ${id === cur ? 'on' : ''}" data-m="${id}">${ic('check', 'mm-tick')}<span><b>${esc(n)}</b><small>${esc(sub)}</small></span></button>`;
  const claude = hasClaude() ? Object.entries(MODELS).map(([k, m]) => item(k, m.name, m.note)).join('') : '';
  const gem = hasGemini() ? S.gm.chain.slice(0, 4).map((m) => item('g:' + m, prettyGemini(m).replace('Gemini ', ''), S.limits.isOut(m) ? 'Used up today' : 'Free with your key')).join('') : '';
  const none = !claude && !gem ? `<button class="mm-i" data-keys="1"><span><b>Add a key</b><small>Claude or Gemini, in Settings</small></span></button>` : '';
  const el = document.createElement('div'); el.id = 'mmenu'; el.className = 'mmenu';
  el.innerHTML = `${claude}${claude && gem ? '<hr>' : ''}${gem}${none}<hr><div class="mm-lbl">THINKING</div><div class="mm-eff">${EFFORT.map(([k, n]) => `<button class="${k === eff ? 'on' : ''}" data-e="${k}">${n}</button>`).join('')}</div>`;
  $('#device').append(el); glassCover(true);
  const shade = document.createElement('div'); shade.id = 'mshade'; shade.onclick = closeModelMenu; $('#device').append(shade);
  requestAnimationFrame(() => el.classList.add('in'));
  $$('[data-m]', el).forEach((b) => (b.onclick = () => { S.st.model = b.dataset.m; S.fell = null; if (isG() && S.st.workspace === 'cloud') { S.st.workspace = 'chat'; toast('Gemini works in Chat. Cloud tasks use Claude.'); } saveSettings(); paintChips(); updateSend(); closeModelMenu(); }));
  $$('[data-e]', el).forEach((b) => (b.onclick = () => { S.st.effort = b.dataset.e; saveSettings(); closeModelMenu(); }));
  $('[data-keys]', el) && ($('[data-keys]', el).onclick = () => { closeModelMenu(); $('#pcPill').click(); });
}
function closeModelMenu() {
  const el = $('#mmenu'); $('#mshade')?.remove(); if (!el) return; el.id = ''; glassCover(false);
  el.classList.remove('in'); setTimeout(() => el.remove(), 250);
}

/* ---------- Insights (insights/insights.js): the website's visitors, through the shelf (no key on the phone).
   The last answer per range is kept, so the screen opens at once and still shows something offline. */
async function loadInsights(range) {
  const shelf = store.get('sl.shelf', ''), kept = 'sl.insights.' + range;
  if (!shelf) return { error: 'setup' };
  try {
    const r = await fetch(`${shelf}/insights?range=${encodeURIComponent(range)}`, { cache: 'no-store' });
    const j = await r.json();
    if (!r.ok || j.error) throw new Error(j.error || `answered ${r.status}`);
    store.set(kept, j); return j;
  } catch (e) {
    const old = store.get(kept, null);
    const net = e instanceof TypeError || navigator.onLine === false;   // no connection (fetch's own error), not the cloud's answer
    return old ? { ...old, stale: e.message } : { error: 'offline', message: net ? 'Check the internet connection and try again.' : e.message };
  }
}

/* ---------- home: the app's modules as cards. New apps are added to MODULES. ---------- */
const MODULES = [
  { id: 'ai', name: 'Labs AI', sub: 'Chat, photos, voice', icon: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16v4M17 18h4"/>' },
  { id: 'cloud', name: 'Tasks', sub: 'AI tasks that keep running', icon: '<path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18z"/>' },
  { id: 'chat', name: 'Chat', sub: 'Messages with your team', icon: '<path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v8a2.5 2.5 0 0 1-2.5 2.5H10l-4.5 3.5V17A2.5 2.5 0 0 1 4 14.5z"/><path d="M8.5 9h7M8.5 12.5h4.5"/>' },
  { id: 'beam', name: 'Shivo Labs Cloud', sub: 'Send and keep files', icon: '<path d="M7 18a4.5 4.5 0 0 1-.8-8.93A6 6 0 0 1 17.6 8.5 4 4 0 0 1 17 18z"/><path d="M12 11v5m0-5-2 2m2-2 2 2"/>' },
  { id: 'tv', name: 'TV', sub: 'Your Shivo Labs TV', icon: '<rect x="3" y="5" width="18" height="12" rx="2.5"/><path d="M8 21h8M12 17v4"/>' },
  { id: 'insights', name: 'Insights', sub: 'Website visitors, live', icon: '<path d="M4 19h16"/><path d="M7 15v-4M12 15V6M17 15v-7"/>' },
  { id: 'camera', name: 'Camera', sub: 'Film looks, full size', icon: '<path d="M4 8.5h3l1.8-2.5h6.4L17 8.5h3v10.5H4z"/><circle cx="12" cy="13.5" r="3.6"/>' },
  { id: 'browser', name: 'Browser', sub: 'Private, no ads', free: true, icon: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.4 2.6 3.6 5.4 3.6 8.5s-1.2 5.9-3.6 8.5c-2.4-2.6-3.6-5.4-3.6-8.5s1.2-5.9 3.6-8.5z"/>' },
  // web apps open full screen in the app (native), keeping their own login
  { id: 'oracle', name: 'Oracle TM', sub: 'Task management system', web: 'https://oracleconsultancy.vercel.app',
    // small adjustments for how it sits inside Shivo Labs (sent to the in-app browser, so they update over the air)
    css: `html body::before{background:color-mix(in srgb,#F3F3F1 42%,transparent)!important;-webkit-backdrop-filter:saturate(160%) blur(10px)!important;backdrop-filter:saturate(160%) blur(10px)!important}
      html.dark body::before{background:color-mix(in srgb,#121315 42%,transparent)!important}
      .st-sheet{max-height:calc(100dvh - 72px - var(--app-sat,0px))!important}`,
    icon: '<path d="M10 6h10M10 12h10M10 18h10"/><path d="m3.5 6 1.5 1.5L7.5 5M3.5 12l1.5 1.5L7.5 11M3.5 18l1.5 1.5L7.5 17"/>' },
];
const modIcon = (m) => `<svg viewBox="0 0 24 24">${m.icon}</svg>`;
function openModule(id) {
  if (id === 'browser') return openBrowser();
  if (!pass.may(id)) return toast("That isn't part of your Shivo Labs.");
  const web = MODULES.find((m) => m.id === id)?.web;
  // in the app (native); if this install can't yet, open it in Safari rather than doing nothing
  if (web) { const N = plugin('ShivoNative'); haptic('light'); return (N ? N.openWeb({ url: web, css: MODULES.find((m) => m.id === id).css || '' }) : Promise.reject(new Error('no add-on'))).catch(() => openURL(web).catch(() => window.open(web, '_blank'))); }
  if (id === 'cloud') {
    if (!hasClaude()) { toast('Cloud tasks need your Claude key. Add it in Settings.'); return $('#pcPill').click(); }
    if (!S.run) { S.st.workspace = 'cloud'; if (isG()) S.st.model = 'sonnet'; saveSettings(); S.cur = null; paintChips(); renderMsgs(); updateSend(); }
    id = 'ai';
  } else if (id === 'ai' && S.st.workspace === 'cloud' && !S.run && !S.cur) { S.st.workspace = 'chat'; saveSettings(); paintChips(); renderMsgs(); updateSend(); }
  switchApp(id);
}
function renderHome() {
  const root = $('#homeBody'); if (!root) return;
  const hr = new Date().getHours(), hi = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
  const running = S.chats.filter((c) => c.session?.status === 'running').length;
  const recent = [...S.chats].sort((a, b) => b.at - a.at).slice(0, 4);
  // UNIFY-PLAN.md phase 2: the bar holds Chat, TV, Cloud and Camera, and Search asks Labs AI; the rest sits in one row
  // Labs AI is no tile any more: it is pinned in Chat, and Search asks it (Shivam, 23 Oct 2026)
  const more = homeApps().filter((m) => !NAV.some((n) => n.id === m.id) && m.id !== 'ai');
  // Home is drawn again only when what it shows has changed, and then keeps its scroll and does not replay its
  // entrance (every visit used to rebuild it: the logo and the icons jumped each time)
  const sig = JSON.stringify([hi, running, more.map((m) => m.id), recent.map((c) => [c.id, c.title, c.session ? 1 : 0, ago(c.at)])]);
  if (renderHome.sig === sig && root.firstChild) return;
  const first = !renderHome.sig, keep = root.scrollTop; renderHome.sig = sig;
  if (!first) root.classList.add('seen');
  root.innerHTML = `
    <header class="home-top"><div class="home-brand"><div class="mkw">${mark(first ? 'play loop' : 'loop')}</div><div class="word">SHIVO<span>LABS</span></div></div>
      <button class="gbtn" id="homeSet" aria-label="Settings"><svg viewBox="0 0 24 24"><path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg></button></header>
    <h1 class="home-hi">${hi}.<span>Search or ask anything below.</span></h1>
    <button class="home-ask" id="homeAsk"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/></svg><span>Search or ask anything</span></button>
    ${more.length ? `<div class="home-more">${more.map((m, i) => `<button class="hm" data-mod="${m.id}" style="--i:${i}"><span class="mod-ic">${m.id === 'ai' ? mark('loop') : modIcon(m)}</span><span>${m.id === 'cloud' ? 'Tasks' : m.name}</span>${m.id === 'cloud' && running ? `<i class="ai2-n">${running}</i>` : ''}</button>`).join('')}</div>` : ''}
    ${recent.length ? `<h4 class="home-h">Continue</h4>${recent.map((c) => `<button class="home-row" data-chat="${c.id}"><span class="mod-ic sm">${modIcon(MODULES[c.session ? 1 : 0])}</span><span>${esc(c.title)}</span><small>${ago(c.at)}</small></button>`).join('')}` : ''}`;
  $$('[data-mod]', root).forEach((b) => (b.onclick = () => openModule(b.dataset.mod)));
  $$('[data-chat]', root).forEach((b) => (b.onclick = () => { if (S.run) return toast('Wait for the current reply, or stop it first'); S.cur = S.chats.find((c) => c.id === b.dataset.chat); syncWorkspace(); S.fell = null; paintChips(); renderMsgs(); switchApp('ai'); }));
  $('#homeSet', root).onclick = () => $('#pcPill').click();
  $('#homeAsk', root).onclick = () => startSearch();
  root.scrollTop = keep;
}
// the apps Home lists in its row, and Search lists under "Apps": the same ones (Tasks only with a Claude key)
const homeApps = () => MODULES.filter((m) => (m.free || pass.may(m.id)) && (m.id !== 'cloud' || hasClaude()));

/* ---------- Shivo Browser (UNIFY-PLAN.md phase 2, iPhone first): our own browser (native, ShivoBrowser.swift) with
   tabs, private tabs, ad and tracker blocking and Reader view. "Ask about this page" comes back here as a new Labs AI
   chat with the page attached; "Save to Cloud" as a PDF for the Cloud's Saved folder. Older builds open Safari. ---------- */
const webTarget = (q) => {
  q = String(q || '').trim();
  if (/^https?:\/\//i.test(q)) return q;
  if (!/\s/.test(q) && /\.[a-z]{2,}(\/|$)/i.test(q)) return 'https://' + q;
  return 'https://duckduckgo.com/?q=' + encodeURIComponent(q);   // a private search engine by default (Shivam, 23 Oct 2026)
};
// ---- the browser's start page (step 1 of phone/docs/BROWSER-PLAN.md): written here so it can change over the air, shown by the native
// browser for every new tab. A search box, the doors to Shivam's own things (what this phone's pass has), and, filled in by the browser,
// the bookmarks and recent pages. Links "shivo://door/<screen>" open one of the app's screens; "shivo://search?q=" searches.
function startPageHtml() {
  const icon = (id) => (MODULES.find((m) => m.id === id) || {}).icon || '';
  const globe = '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.4 2.6 3.6 5.4 3.6 8.5s-1.2 5.9-3.6 8.5c-2.4-2.6-3.6-5.4-3.6-8.5s1.2-5.9 3.6-8.5z"/>';
  const tiles = [
    pass.may('oracle') && { label: 'Oracle TM', href: 'https://oracleconsultancy.vercel.app', icon: icon('oracle') },
    pass.may('insights') && store.get('sl.shelf', '') && { label: 'Insights', href: 'shivo://door/insights', icon: icon('insights') },
    pass.isOwner() && { label: 'shivolabs.com', href: 'https://shivolabs.com', icon: globe },
    pass.may('beam') && { label: 'Cloud', href: 'shivo://door/beam', icon: icon('beam') },
  ].filter(Boolean);
  const T = tiles.map((t) => `<a class="tile" href="${esc(t.href)}"><i><svg viewBox="0 0 24 24">${t.icon}</svg></i>${esc(t.label)}</a>`).join('');
  return `<!doctype html><html data-theme="${light() ? 'light' : 'dark'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>Shivo Labs</title><style>
:root{--bg:#F5F5F2;--text:#141517;--muted:#6B6E73;--soft:rgba(20,21,23,.06);--line:rgba(20,21,23,.09);--sage:#4F7A5A}
html[data-theme=dark]{--bg:#141517;--text:#ECEDE9;--muted:#9A9CA1;--soft:rgba(255,255,255,.07);--line:rgba(255,255,255,.1)}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;background:var(--bg);color:var(--text)}
body{font:16px/1.4 -apple-system,system-ui,sans-serif;padding:max(34px,env(safe-area-inset-top)) 20px 140px;-webkit-user-select:none;user-select:none}
.mk{width:38px;height:38px;display:block}.mk rect{fill:var(--text)}.mk .lit{fill:var(--sage)}
h1{font:600 30px/1.15 ui-rounded,-apple-system,sans-serif;letter-spacing:-.02em;margin:20px 2px 4px}
.sub{margin:0 2px 20px;color:var(--muted);font-size:17px}
form{display:flex;align-items:center;gap:10px;padding:0 16px;border-radius:20px;background:var(--soft);border:.5px solid var(--line)}
form svg{width:20px;height:20px;flex:none;color:var(--muted);fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round}
input{flex:1;min-width:0;border:0;outline:0;background:none;color:var(--text);font-size:17px;padding:15px 0;-webkit-appearance:none;user-select:text;-webkit-user-select:text}
input::placeholder{color:var(--muted)}
.tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:18px 6px;margin-top:24px}
.tile{display:grid;justify-items:center;gap:8px;color:var(--muted);font-size:12px;text-align:center;text-decoration:none}
.tile i{width:58px;height:58px;border-radius:19px;background:var(--soft);display:grid;place-items:center;color:var(--text);border:.5px solid var(--line)}
.tile svg{width:25px;height:25px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
.tile:active i{transform:scale(.94)}
h3{font:600 14px ui-rounded,-apple-system,sans-serif;color:var(--muted);margin:32px 4px 6px}
.row{display:block;padding:11px 4px;text-decoration:none;color:var(--text);border-top:1px solid var(--line)}
.row b{display:block;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.row small{display:block;color:var(--muted);font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.row:active{opacity:.6}
.note{color:var(--muted);font-size:15px;line-height:1.5;margin:6px 4px}
</style></head><body>
${mark('')}
<h1>Browse.</h1><p class="sub">Search the web, or open one of yours.</p>
<form id="f" autocomplete="off"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/></svg><input id="q" type="search" placeholder="Search or type a link" enterkeyhint="go" autocapitalize="off" autocorrect="off" spellcheck="false"></form>
${T ? `<div class="tiles">${T}</div>` : ''}
<div id="more"></div>
<script>
document.getElementById('f').onsubmit=function(e){e.preventDefault();var q=document.getElementById('q').value.trim();if(q)location.href='shivo://search?q='+encodeURIComponent(q);};
function esc(s){return String(s||'').replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function rows(l){return l.map(function(v){var h=String(v.url).replace(/^https?:\\/\\//,'').replace(/^www\\./,'');return '<a class="row" href="'+esc(v.url)+'"><b>'+esc(v.title||h)+'</b><small>'+esc(h)+'</small></a>'}).join('')}
window.shivoFill=function(d){var m=document.getElementById('more'),h='';
 if(d.private){h='<h3>Private tab</h3><p class="note">Nothing you do here is remembered: no history, no cookies kept. Closing the tab clears it.</p>'}
 else{if(d.marks&&d.marks.length)h+='<h3>Bookmarks</h3>'+rows(d.marks.slice(0,6));if(d.recent&&d.recent.length)h+='<h3>Recent</h3>'+rows(d.recent.slice(0,6));}
 m.innerHTML=h;};
</script></body></html>`;
}
// the conversations the browser can send a page to (Chat has to be set up; the list is read once Chat has synced)
async function chatSnapshot() {
  if (!pass.may('chat')) return [];
  ensureChat();
  const root = $('#chatBody');
  for (let i = 0; i < 12 && !root._share?.ready(); i++) await sleepMs(125);
  return root._share?.ready() ? root._share.list() : [];
}
// a message from the app shown on the browser's own screen (the app is behind it), and in the app too
function bToast(t) {
  toast(t);
  try { plugin('ShivoNative')?.browserToast?.({ text: t })?.catch?.(() => {}); } catch {}
  try { plugin('ShivoBrowser')?.toast?.({ text: t })?.catch?.(() => {}); } catch {}
}
const noteName = (t) => String(t || 'Page').replace(/[\\/?%*|"<>:]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80) || 'Page';
function noteMd(e) {
  const stamp = new Date().toLocaleString([], { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  const body = String(e.text || '').trim();
  return `# ${e.title || e.url}\n\n${e.url}\n\nSaved ${stamp}${e.selection ? ' · a clip' : ''}\n${body ? `\n---\n\n${body}\n` : ''}`;
}
let browserOk = null;
async function openBrowser(url, priv = false) {
  const N = plugin('ShivoNative'), A = plugin('ShivoBrowser');   // iPhone (ShivoBrowser.swift) / Android (ShivoBrowserPlugin.java)
  if (browserOk === null) { try { browserOk = !!(await N?.info())?.browser; } catch { browserOk = false; } }
  haptic('light');
  const extra = browserOk || A ? { start: startPageHtml(), chats: await chatSnapshot().catch(() => []) } : {};
  if (browserOk) return N.browse({ ...(url ? { url } : {}), private: priv, ...extra }).catch((e) => toast(e.message || "Couldn't open the browser"));
  if (A) return A.open({ ...(url ? { url } : {}), private: priv, ...extra }).catch((e) => toast(e.message || "Couldn't open the browser"));
  if (url) return (plugin('ShivoNative') ? openURL(url) : androidOpen(url)).catch(() => window.open(url, '_blank'));
  toast('The browser comes with the next app update');
}
for (const N of [plugin('ShivoNative'), plugin('ShivoBrowser')]) {
  if (!N?.addListener) continue;
  N.addListener('browserAsk', (e) => {
    if (!pass.may('ai')) return toast("Labs AI isn't part of your Shivo Labs");
    if (S.run) return toast('Wait for the current reply, or stop it first');
    let host = ''; try { host = new URL(e.url).host.replace(/^www\./, ''); } catch {}
    S.cur = null; if (S.st.workspace === 'cloud') { S.st.workspace = 'chat'; saveSettings(); }
    paintChips(); renderMsgs();
    ATT.push({ name: (e.title || host || 'Web page').slice(0, 60), kind: 'text', text: `${e.url}\n\n${String(e.text || '').slice(0, 60000)}` });
    paintAtt();
    if (S.app !== 'ai') switchApp('ai');
    if (!hasClaude() && !hasGemini()) return askKeys();
    setTimeout(() => { box.focus(); toast('The page is attached. Ask your question.'); }, 350);
  });
  // Save: the page as a PDF and a link go into Cloud's Saved folder, a text clip into its Notes folder (notes are files in Cloud)
  N.addListener('browserSave', async (e) => {
    if (!cloud.creds()) return bToast('Connect Shivo Labs Cloud first (the Cloud tab)');
    try {
      const kind = e.kind || (e.data ? 'pdf' : 'link');
      if (kind === 'pdf') {
        const bytes = Uint8Array.from(atob(e.data), (c) => c.charCodeAt(0));
        const file = new File([bytes], e.name || 'Page.pdf', { type: e.type || 'application/pdf' });
        await cloud.add(await cloud.folder('Saved'), file);
        haptic('success'); bToast(`Saved to Cloud › Saved: ${file.name}`);
      } else {
        const name = noteName(e.title || e.url) + '.md', folder = kind === 'note' ? 'Notes' : 'Saved';
        await cloud.add(await cloud.folder(folder), new File([noteMd(e)], name, { type: 'text/markdown' }));
        haptic('success'); bToast(kind === 'note' ? `Saved as a note: ${name}` : `Link saved to Cloud › Saved`);
      }
    } catch (err) { bToast(err.message || "Couldn't save it"); }
  });
  // Send to Chat: the page's title and link go into the chosen conversation
  N.addListener('browserShare', async (e) => {
    const root = $('#chatBody');
    if (!root?._share?.ready()) return bToast('Set up Chat first (the Chat tab)');
    try { await root._share.send(e.chat, `${e.title ? e.title + '\n' : ''}${e.url}`); haptic('success'); bToast(`Sent to ${e.name || 'the chat'}`); }
    catch (err) { bToast(err.message || "Couldn't send it"); }
  });
  // a door on the start page: the browser closes and the screen opens
  N.addListener('browserDoor', (e) => { if (e.id) openModule(e.id); });
}
// links in Labs AI's answers open in the browser too
$('#msgs').addEventListener('click', (e) => {
  const a = e.target.closest?.('a[href^="http"]'); if (!a) return;
  e.preventDefault(); openBrowser(a.href);
});

/* ---------- Search (UNIFY-PLAN.md phase 2; Shivam, 23 Oct): no page of its own. The round search button in the floating
   bar stretches into a typing box over the bar (the other buttons fade away) and rides on top of the keyboard. Enter
   asks Labs AI, which answers with the web and its tools (calendar, reminders, Shortcuts, the TV, Cloud...) and asks
   before changing anything; a web address opens in the Shivo Browser. ---------- */
const SR = { q: '' };
const searching = () => document.body.classList.contains('searching');
function startSearch() {
  const sq = $('#sq');
  if (searching()) return sq.focus();
  document.body.classList.add('searching');
  haptic('light'); syncGlass(GL);
  sq.focus(); setTimeout(() => sq.focus(), 60);   // at once (inside the tap) so the keyboard opens with the box, and again once it has stretched
}
function endSearch() {
  if (!searching()) return;
  document.body.classList.remove('searching');
  $('#sq').value = ''; SR.q = '';
  $('#sq').blur();
  keyboardSync(); setTimeout(keyboardSync, 400);   // the lift for the keyboard is dropped for sure, not only when a focus event arrives
  syncGlass(GL); setTimeout(() => syncGlass(GL), 600);   // again once the bar has stretched back (it is placed from the web bar's box)
}
$('#searchBtn').onclick = startSearch;
$('#sclose').onclick = endSearch;
$('#sq').oninput = (e) => { SR.q = e.target.value.trim(); };
$('#sq').onkeydown = (e) => { if (e.key === 'Escape') endSearch(); };
$('#sbox').onsubmit = (e) => { e.preventDefault(); searchGo(SR.q); };
// a tap on the page behind, or the keyboard put away with nothing typed: the bar goes back to what it was
$('#views').addEventListener('pointerdown', () => { if (searching() && !SR.q) endSearch(); });
$('#sq').addEventListener('blur', () => setTimeout(() => { if (searching() && !SR.q && document.activeElement !== $('#sq')) endSearch(); }, 160));
// the keyboard: on iPhone the page keeps its size and the keyboard covers its bottom, so the bar is lifted by the
// keyboard's height (--kb); Android resizes the page itself and nothing is added
// (Since the app's own iPhone add-on makes the page as tall as the keyboard leaves free, this finds nothing to lift: it is only
// the fallback for an older add-on. It applies ONLY while a text field has the focus, and is cleared when it loses it: before, a
// height measured mid-animation stayed after the keyboard went away and left the bar floating with a gap under it.)
const vv = window.visualViewport;
function keyboardSync() {
  const a = document.activeElement, typing = !!a && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable);
  const kb = vv && typing ? Math.round(innerHeight - vv.height - vv.offsetTop) : 0, up = kb > 100;
  document.documentElement.style.setProperty('--kb', (up ? kb : 0) + 'px');
  if (up !== document.body.classList.contains('kb')) setTimeout(() => syncGlass(GL), 600);   // the bar moves with the keyboard
  document.body.classList.toggle('kb', up);
}
vv?.addEventListener('resize', keyboardSync); vv?.addEventListener('scroll', keyboardSync);
document.addEventListener('focusin', () => setTimeout(keyboardSync, 350));
document.addEventListener('focusout', () => setTimeout(keyboardSync, 350));   // 350 ms: after the keyboard has gone
document.addEventListener('visibilitychange', () => setTimeout(keyboardSync, 200));
function searchGo(q) {
  q = String(q || '').trim(); if (!q) return;
  if (/^[^\s]+\.[a-z]{2,}(\/\S*)?$/i.test(q) || /^https?:\/\//i.test(q)) { endSearch(); return openBrowser(webTarget(q)); }
  if (!pass.may('ai')) { endSearch(); return toast("Labs AI isn't part of your Shivo Labs"); }
  if (!hasClaude() && !hasGemini()) { endSearch(); toast('Add a Claude or Gemini key in Settings to ask'); return $('#pcPill').click(); }
  if (S.run) return toast('Wait for the current reply, or stop it first');
  // the question goes into the Labs AI thread (the newest conversation if it is from the last 6 hours, else a fresh one); the answer
  // appears there, in the thread pinned in Chat, with its tools and its History one tap away
  S.cur = recentThread(6 * 3600e3); if (S.st.workspace === 'cloud') { S.st.workspace = 'chat'; saveSettings(); }
  paintChips(); renderMsgs();
  switchApp('ai');   // closes the search box too
  setTimeout(() => send(q), 120);
}

// team Chat opening or closing a conversation shows or hides the bar
new MutationObserver(() => { if (S.app === 'chat') { paintNav(); syncGlass(GL); } }).observe($('#chatBody'), { subtree: true, attributes: true, attributeFilter: ['class'] });

/* ---------- hold the home button and slide: pick another module ---------- */
const SW = { el: null, pick: null, x0: 0, y0: 0, moved: false };
function switcherOpen(fromEl, x, y) {
  if (SW.el) return;
  const el = document.createElement('div'); el.id = 'switcher';
  const list = [{ id: 'home', name: 'Home', sub: 'All apps', icon: '<path d="M4 11 12 4l8 7v9h-5v-6H9v6H4z"/>' }, ...MODULES].filter((m) => m.id !== S.app);
  el.innerHTML = `<div class="sw-list">${list.map((m, i) => `<div class="sw-card" data-mod="${m.id}" style="--i:${i}"><span class="mod-ic">${modIcon(m)}</span><span><b>${m.name}</b><small>${m.sub}</small></span></div>`).join('')}</div><p class="sw-hint">Slide onto an app and let go, or tap one</p>`;
  $('#device').append(el); glassCover(true);
  const r = fromEl?.getBoundingClientRect(); if (r) el.style.setProperty('--top', r.bottom + 18 + 'px');
  requestAnimationFrame(() => el.classList.add('in'));
  Object.assign(SW, { el, pick: null, moved: false, x0: x ?? (r ? r.left + r.width / 2 : 0), y0: y ?? (r ? r.top + r.height / 2 : 0) });
  el.onclick = (e) => { const c = e.target.closest('.sw-card'); switcherEnd(c ? c.dataset.mod : null, true); };
}
function switcherMove(x, y) {
  if (!SW.el) return;
  // nothing lights up until the finger has really moved (a held finger shouldn't pick anything)
  if (!SW.moved && Math.hypot(x - SW.x0, y - SW.y0) < 16) return;
  SW.moved = true;
  const hit = document.elementFromPoint(x, y)?.closest?.('.sw-card');
  $$('.sw-card', SW.el).forEach((c) => c.classList.toggle('hot', c === hit));
  const id = hit?.dataset.mod || null;
  if (id && id !== SW.pick) haptic('selection');
  SW.pick = id;
}
// released: go to the picked app; held without moving: stay open to tap; slid off: close
function switcherRelease() { if (!SW.el) return; if (SW.pick) switcherEnd(SW.pick); else if (SW.moved) switcherEnd(null); }
function switcherEnd(id) {
  const el = SW.el; if (!el) return; SW.el = null;
  el.classList.remove('in'); setTimeout(() => el.remove(), 300); glassCover(false);
  if (id) { haptic('success'); id === 'home' ? switchApp('home') : openModule(id); }
}
// the web version of the gesture (preview, older iPhones): hold 0.35 s, slide, let go
function holdable(btn) {
  let t = null, held = false;
  btn.addEventListener('touchstart', (e) => e.preventDefault(), { passive: false });   // no iOS text selection / callout
  btn.addEventListener('pointerdown', (e) => { held = false; const x = e.clientX, y = e.clientY; t = setTimeout(() => { held = true; haptic('medium'); switcherOpen(btn, x, y); }, 350); });
  addEventListener('pointermove', (e) => { if (held) switcherMove(e.clientX, e.clientY); });
  addEventListener('pointerup', (e) => {
    clearTimeout(t);
    if (held) { held = false; switcherMove(e.clientX, e.clientY); switcherRelease(); return; }
    if (e.target.closest && e.target.closest('#' + btn.id) && !SW.el) switchApp('home');
  });
  btn.addEventListener('click', (e) => { e.preventDefault(); e.stopImmediatePropagation(); });   // handled on pointerup
}
holdable($('#homeBtn')); holdable($('#homeBtnT'));
// the native version: the glass button reports the hold and finger position
function onNativeHold(e) {
  if (e.state === 'began') switcherOpen(document.getElementById(e.id), e.x, e.y);
  else if (e.state === 'moved') switcherMove(e.x, e.y);
  else if (e.state === 'ended') { switcherMove(e.x, e.y); switcherRelease(); }
  else if (SW.moved) switcherEnd(null);
}

/* ---------- swipe from the left edge to go back, like iPhone apps ---------- */
// A finger that starts at the left edge and moves right drags the screen along and goes back on letting go:
// from Team Chat's Details to the conversation, from a conversation to the chat list, from any module to Home (which shows underneath).
(() => {
  const EDGE = 24, views = $('#views');
  let g = null;
  const blocked = () => S.app === 'home' || SW.el || !$('#sheet').hidden || !$('#drawer').hidden || ($('#chVeil') && !$('#chVeil').hidden);
  const style = (el, s) => el && Object.assign(el.style, s);
  views.addEventListener('touchstart', (e) => {
    g = null;
    const t = e.touches[0]; if (e.touches.length > 1 || t.clientX > EDGE || blocked()) return;
    // Team Chat's Details page (full screen on a phone) goes back to the conversation; a conversation to the list
    const info = S.app === 'chat' && $('#chInfo') && !$('#chInfo').hidden && getComputedStyle($('#chInfo')).position === 'fixed';
    const conv = S.app === 'chat' && $('#chApp')?.classList.contains('open') && $('#chBack') && getComputedStyle($('#chBack')).display !== 'none';
    g = info ? { x0: t.clientX, y0: t.clientY, el: $('#chInfo'), under: null, done: () => $('#chInfoX').click() }
      : conv ? { x0: t.clientX, y0: t.clientY, el: $('.ch-main', $('#chApp')), under: $('.ch-side', $('#chApp')), done: () => $('#chBack').click() }
      : { x0: t.clientX, y0: t.clientY, el: $('#v-' + S.app), under: $('#v-home'), home: true, top: $('.top'), done: () => { switchApp.keepHome = true; switchApp('home'); } };
    if (!g.el) g = null;
  }, { passive: true });
  views.addEventListener('touchmove', (e) => {
    if (!g) return;
    const t = e.touches[0], dx = t.clientX - g.x0, dy = t.clientY - g.y0;
    if (!g.on) {
      if (Math.abs(dy) > 10 && Math.abs(dy) > dx) { g = null; return; }   // scrolling up or down: not ours
      if (dx < 10) return;
      g.on = true; g.w = views.clientWidth; g.t = performance.now(); g.v = 0; g.last = dx;
      document.activeElement?.blur?.(); glassCover(true);
      style(g.el, { transition: 'none', boxShadow: '-12px 0 30px -18px rgba(0,0,0,.35)', background: g.under ? 'var(--bg)' : '' });
      // Home has no top bar: it shows where it will end up (up under the bar), and the bar leaves with the screen
      if (g.home) renderHome();   // fresh now, while it slides in; not again (with its rise-in) when it arrives
      const th = g.top ? g.top.offsetHeight : 0; if (!th) g.top = null;
      style(g.under, { transition: 'none', visibility: 'visible', top: -th + 'px' });
      if (th) views.style.overflow = 'visible';   // Home reaches up under the bar
      style(g.top, { transition: 'none', position: 'relative', zIndex: '2', background: 'var(--bg)', boxShadow: '-12px 0 30px -18px rgba(0,0,0,.35)' });
    }
    e.preventDefault();
    const x = Math.max(0, dx), now = performance.now();
    g.v = (x - g.last) / Math.max(1, now - g.t); g.last = x; g.t = now;
    style(g.el, { transform: `translateX(${x}px)` }); style(g.top, { transform: `translateX(${x}px)` });
    style(g.under, { transform: `translateX(${-0.3 * (g.w - x)}px)`, opacity: String(Math.min(1, x / g.w + 0.35)) });
  }, { passive: false });
  const end = (e) => {
    if (!g?.on) { g = null; return; }
    // the finger lifts over what slid in: that must not count as a tap (it opened the search box and the keyboard)
    if (e?.cancelable) e.preventDefault();
    const { el, under, top, w, done } = g, go = g.last > w * 0.35 || (g.v > 0.45 && g.last > 30); g = null;
    const tr = 'transform .26s cubic-bezier(.2,.8,.2,1), opacity .26s';
    style(el, { transition: tr, transform: go ? `translateX(${w}px)` : 'translateX(0)' }); style(top, { transition: tr, transform: go ? `translateX(${w}px)` : 'translateX(0)' });
    style(under, { transition: tr, transform: go ? 'none' : `translateX(${-0.3 * w}px)`, opacity: go ? '1' : '0.35' });
    if (go) haptic('light');
    setTimeout(() => {
      style(el, { transition: 'none' }); style(under, { transition: 'none' }); style(top, { transition: 'none' });
      glassCover(false);
      if (go) done();
      // in the same frame as the switch, so nothing is painted in between (that was the jump)
      style(el, { transform: '', boxShadow: '', background: '' }); style(under, { transform: '', opacity: '', visibility: '', top: '' });
      style(top, { transform: '', position: '', zIndex: '', background: '', boxShadow: '' }); views.style.overflow = '';
      requestAnimationFrame(() => {
        requestAnimationFrame(() => { style(el, { transition: '' }); style(under, { transition: '' }); style(top, { transition: '' }); });
      });
    }, 270);
  };
  views.addEventListener('touchend', end); views.addEventListener('touchcancel', end);
})();

/* ---------- drawer: chat history and Cloud tasks (like Gemini's side menu) ---------- */
const LAB = { running: ['Running', 'run'], done: ['Done', ''], stopped: ['Stopped', ''], budget: ['Paused at cap', 'bad'], error: ['Error', 'bad'] };
function openDrawer() {
  const dr = $('#drawer'), sc = $('#scrim');
  if (!drawerUp) { drawerUp = true; glassCover(true); }
  const paint = (q = '') => {
    const f = (c) => !q || (c.title + ' ' + (c.ui.at(-1)?.t || '')).toLowerCase().includes(q);
    const all = [...S.chats].filter(f).sort((a, b) => (b.pin ? 1 : 0) - (a.pin ? 1 : 0) || b.at - a.at);
    const cloud = all.filter((c) => c.session), chats = all.filter((c) => !c.session);
    const row = (c) => `<button class="dr-row ${S.cur === c ? 'sel' : ''}" data-id="${c.id}"><span>${esc(c.title)}</span>${c.session ? `<i class="st-pill ${LAB[c.session.status]?.[1] || ''}">${LAB[c.session.status]?.[0] || 'Done'}</i>` : ''}</button>`;
    $('#drawerBody').innerHTML = `
      <div class="dr-top"><b>History</b><button class="gbtn" id="drClose" aria-label="Close"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
      <button class="dr-act" id="drNew"><svg viewBox="0 0 24 24"><path d="M12 20h8M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg><span>New chat</span></button>
      <button class="dr-act" id="drCloud"><svg viewBox="0 0 24 24"><path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18z"/></svg><span>New cloud task<small>Keeps working when your phone is locked</small></span></button>
      <label class="dr-search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6"/><path d="m20 20-4-4"/></svg><input id="drQ" placeholder="Search chats" value="${esc(q)}" autocapitalize="off"></label>
      ${cloud.length ? `<h4>Cloud</h4>${cloud.map(row).join('')}` : ''}
      <h4>Recent</h4>${chats.map(row).join('') || '<p class="emptyt">No chats yet.</p>'}
      ${S.chats.length ? '<button class="dr-row danger" id="drDel"><span>Delete all chats on this phone</span></button>' : ''}`;
    const b = $('#drawerBody');
    $('#drClose', b).onclick = closeDrawer;
    $('#drNew', b).onclick = () => { closeDrawer(); if (S.run) return; S.st.workspace = 'chat'; saveSettings(); S.cur = null; S.fell = null; paintChips(); renderMsgs(); switchApp('ai'); };
    $('#drCloud', b).onclick = () => { closeDrawer(); if (S.run) return; if (!hasClaude()) return toast('Cloud tasks need your Claude key. Add it in Settings.'); S.st.workspace = 'cloud'; if (isG()) S.st.model = 'sonnet'; saveSettings(); S.cur = null; paintChips(); renderMsgs(); updateSend(); switchApp('ai'); box.focus(); };
    $('#drQ', b).oninput = (e) => { const v = e.target.value, pos = e.target.selectionStart; paint(v.toLowerCase()); const i = $('#drQ'); i.focus(); i.value = v; i.setSelectionRange(pos, pos); };
    $$('.dr-row[data-id]', b).forEach((r) => (r.onclick = () => { if (S.run) return toast('Wait for the current reply, or stop it first'); S.cur = S.chats.find((c) => c.id === r.dataset.id); syncWorkspace(); S.fell = null; paintChips(); renderMsgs(); closeDrawer(); switchApp('ai'); }));
    $('#drDel', b) && ($('#drDel', b).onclick = () => { if (S.run) return toast('Stop the current reply first'); if (!confirm('Delete every chat on this phone? Files made by tasks stay in your Claude account.')) return; S.chats.forEach((c) => store.del('chat.' + c.id)); S.chats = []; S.cur = null; store.set('sl.index', []); renderMsgs(); renderTasks(); paint(); });
  };
  paint();
  sc.classList.remove('out'); sc.hidden = false; dr.hidden = false; void dr.offsetHeight; dr.classList.add('in');
  sc.onclick = closeDrawer;
}
function closeDrawer() {
  if (drawerUp) { drawerUp = false; glassCover(false); }
  const dr = $('#drawer'); dr.classList.remove('in'); $('#scrim').classList.add('out'); $('#scrim').onclick = closeSheet;
  setTimeout(() => { if (!dr.classList.contains('in')) { dr.hidden = true; if ($('#sheet').hidden) $('#scrim').hidden = true; } }, 380);
}
// swipe the drawer closed to the left
(() => {
  let x0 = null; const dr = $('#drawer');
  dr.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true });
  dr.addEventListener('touchmove', (e) => { if (x0 == null) return; dr.style.transform = `translateX(${Math.min(0, e.touches[0].clientX - x0)}px)`; }, { passive: true });
  dr.addEventListener('touchend', (e) => { if (x0 == null) return; const dx = e.changedTouches[0].clientX - x0; x0 = null; dr.style.transform = ''; if (dx < -70) closeDrawer(); });
})();

/* ---------- sheets: drag the handle (or the top of the sheet) down to close ---------- */
(() => {
  const sh = $('#sheet'); let y0 = null, dy = 0;
  sh.addEventListener('touchstart', (e) => {
    if (sh.scrollTop > 0) return;
    if (e.target.closest('input,textarea,.seg')) return;
    y0 = e.touches[0].clientY; dy = 0; sh.style.transition = 'none';
  }, { passive: true });
  sh.addEventListener('touchmove', (e) => { if (y0 == null) return; dy = Math.max(0, e.touches[0].clientY - y0); sh.style.transform = `translateY(${dy}px)`; }, { passive: true });
  sh.addEventListener('touchend', () => { if (y0 == null) return; y0 = null; sh.style.transition = ''; sh.style.transform = ''; if (dy > 90) closeSheet(); });
})();

/* ---------- tab bar: press and slide along it; a glass lens follows your finger and stretches ---------- */
(() => {
  const bar = $('#tabs'); const lens = document.createElement('i'); lens.className = 'lens'; bar.prepend(lens);
  const btns = () => $$('button', bar);
  const place = (el, s = 1) => { const r = el.getBoundingClientRect(), b = bar.getBoundingClientRect(); lens.style.width = r.width + 'px'; lens.style.transform = `translateX(${r.left - b.left}px) scale(${s})`; };
  const sync = () => { const on = $('button.on', bar); if (on) place(on); };
  new ResizeObserver(sync).observe(bar); setTimeout(sync, 60);
  let drag = false, lastX = 0;
  const at = (x) => btns().find((b) => { const r = b.getBoundingClientRect(); return x >= r.left && x <= r.right; });
  bar.addEventListener('pointerdown', (e) => { drag = true; lastX = e.clientX; bar.classList.add('drag'); const b = at(e.clientX); if (b) place(b, 1.12); });
  bar.addEventListener('pointermove', (e) => {
    if (!drag) return; const v = e.clientX - lastX; lastX = e.clientX;
    const br = bar.getBoundingClientRect(), w = lens.offsetWidth, x = Math.max(4, Math.min(br.width - w - 4, e.clientX - br.left - w / 2));
    lens.style.transform = `translateX(${x}px) scale(${1.12 + Math.min(.18, Math.abs(v) / 50)}, ${1.12 - Math.min(.08, Math.abs(v) / 120)})`;
  });
  const end = (e) => { if (!drag) return; drag = false; bar.classList.remove('drag'); const b = at(e.clientX); if (b && b.dataset.go !== S.app) b.click(); setTimeout(sync, 0); };
  bar.addEventListener('pointerup', end);
  bar.addEventListener('pointercancel', () => { drag = false; bar.classList.remove('drag'); sync(); });
  window.__syncLens = sync;
})();
const oldChatsSheet = () => {
  const list = [...S.chats].sort((a, b) => (b.pin ? 1 : 0) - (a.pin ? 1 : 0) || b.at - a.at);
  const row = (c) => `<button class="row ${S.cur === c ? 'sel' : ''}" data-id="${c.id}"><span class="t"><b>${esc(c.title)}</b><small>${c.kind === 'task' ? 'Cloud task · ' : ''}${esc(c.ui.at(-1)?.t?.slice(0, 60) || 'No messages yet')}</small></span>${c.session?.status === 'running' ? '<i class="live-dot"></i>' : ''}</button>`;
  openSheet('Chats', (list.map(row).join('') || '<p class="sh-p">No chats yet.</p>') + (list.length ? '<button class="row danger" id="delAll"><span class="t"><b>Delete all chats on this phone</b></span></button>' : ''), (b) => {
    $$('.row[data-id]', b).forEach((r) => (r.onclick = () => { if (S.run) return toast('Wait for the current reply, or stop it first'); S.cur = S.chats.find((c) => c.id === r.dataset.id); syncWorkspace(); S.fell = null; paintChips(); renderMsgs(); closeSheet(); switchApp('ai'); }));
    $('#delAll', b) && ($('#delAll', b).onclick = () => { if (S.run) return toast('Stop the current reply first'); if (!confirm('Delete every chat on this phone? Files made by tasks stay in your Claude account.')) return; S.chats.forEach((c) => store.del('chat.' + c.id)); S.chats = []; S.cur = null; store.set('sl.index', []); renderMsgs(); renderTasks(); closeSheet(); });
  });
};
$('#newBtn').onclick = () => { if (S.run) return; S.cur = null; S.fell = null; paintChips(); renderMsgs(); box.focus(); };

/* ---------- composer ---------- */
function grow() { box.style.height = 'auto'; box.style.height = Math.min(box.scrollHeight, 120) + 'px'; }
function updateSend() {
  syncPlaceholder();
  const b = $('#sendBtn'); b.classList.toggle('stop', !!S.run);
  b.innerHTML = S.run ? '<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="3"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M12 19V5m0 0-6 6m6-6 6 6"/></svg>';
  b.disabled = S.run ? false : (!box.value.trim() && !ATT.length) || !canUse();
}
box.addEventListener('input', () => { grow(); updateSend(); });
box.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !('ontouchstart' in window)) { e.preventDefault(); $('#sendBtn').click(); } });
$('#sendBtn').onclick = () => (S.run ? stopRun() : send(box.value));
let rec = null;
// Voice: the iPhone's own speech recognition, through our add-on (the web view has none).
let nativeRec = null;
async function nativeMic(P) {
  const mic = $('#micBtn');
  if (nativeRec) { P.stopListening().catch(() => {}); return; }
  nativeRec = [];
  const base = box.value;
  const subs = [await P.addListener('speech', (d) => { box.value = (base ? base + ' ' : '') + (d.text || ''); grow(); updateSend(); }),
    await P.addListener('speechEnd', () => { mic.classList.remove('rec'); nativeRec?.forEach((x) => x.remove()); nativeRec = null; })];
  nativeRec = subs; mic.classList.add('rec'); haptic('light');
  try { await P.listen({ lang: navigator.language || 'en-US' }); }
  catch (e) { mic.classList.remove('rec'); subs.forEach((x) => x.remove()); nativeRec = null; toast(e.message || 'Voice did not start'); }
}
$('#micBtn').onclick = () => {
  const P = plugin('ShivoNative'); if (P) return nativeMic(P);
  const SR = globalThis.SpeechRecognition || globalThis.webkitSpeechRecognition;
  if (!SR) return toast('Voice needs the newest app version. For now, use the microphone key on your keyboard.');
  if (rec) { rec.stop(); return; }
  rec = new SR(); rec.interimResults = true; rec.lang = navigator.language || 'en-US';
  const base = box.value; $('#micBtn').classList.add('rec');
  rec.onresult = (e) => { box.value = (base ? base + ' ' : '') + [...e.results].map((r) => r[0].transcript).join(' '); grow(); updateSend(); };
  rec.onend = rec.onerror = () => { rec = null; $('#micBtn').classList.remove('rec'); };
  try { rec.start(); } catch { rec = null; $('#micBtn').classList.remove('rec'); }
};

/* ---------- live pieces of a reply ---------- */
function addNote(parent, text) {
  const n = document.createElement('div'); n.className = 'note';
  n.innerHTML = '<svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.6-5.9M20 4v5h-5"/></svg><span></span>'; $('span', n).textContent = text; parent.append(n); return n;
}
// a note sits above the steps of the reply it belongs to
function noteBefore(msg, sb, text) { const n = addNote(document.createDocumentFragment(), text); msg.insertBefore(n, sb.el); return n; }
function stepsBox() {
  const el = document.createElement('div'); el.className = 'steps working';
  el.innerHTML = `<button class="sg"><span class="ico"></span><span class="lbl"></span>${ic('chev', 'chev')}</button><div class="sl"><div></div></div>`;
  const o = { el, rows: $('.sl>div', el), byId: new Map(), list: [], n: 0,
    kind(k, label) { $('.ico', el).innerHTML = loader(k, 20); $('.lbl', el).textContent = label; },
    add(id, html) { $$('.st', el).forEach((x) => x.classList.add('done')); const r = document.createElement('div'); r.className = 'st'; r.innerHTML = `<i class="s"></i><span>${html}</span>`; o.rows.append(r); o.byId.set(id, r); o.list.push({ html }); o.n++; return r; },
    update(id, html) { const r = o.byId.get(id); if (r) { $('span', r).innerHTML = html; const i = [...o.rows.children].indexOf(r); if (o.list[i]) o.list[i].html = html; } },
    finish(stopped) {
      el.classList.remove('working'); $$('.st', el).forEach((r) => r.classList.add('done'));
      o.summary = o.n ? (stopped ? 'Stopped · ' : '') + o.n + (o.n === 1 ? ' step' : ' steps') : (stopped ? 'Stopped' : 'Thought about it');
      $('.ico', el).innerHTML = ic('check'); $('.lbl', el).textContent = o.summary; setTimeout(() => el.classList.add('collapsed'), 350);
    } };
  $('.sg', el).onclick = () => el.classList.toggle('collapsed');
  return o;
}
async function permCard(msg, title, detail, signal) {
  const p = document.createElement('div'); p.className = 'perm';
  p.innerHTML = `<div class="ph">${loader('wait', 18)}<span></span></div><pre></pre><div class="pb"><button class="btn" data-a="deny">Deny</button><button class="btn pri" data-a="allow">Allow</button></div>`;
  $('.ph span', p).textContent = title; $('pre', p).textContent = detail; msg.append(p); scrollDown();
  const ans = await new Promise((res) => { signal?.addEventListener('abort', () => res('stop'), { once: true }); $$('button', p).forEach((b) => (b.onclick = () => res(b.dataset.a))); });
  if (ans === 'stop') { p.remove(); return 'stop'; }
  p.classList.add('done'); $('.ph', p).innerHTML = '<span></span>'; $('.ph span', p).textContent = (ans === 'allow' ? 'Allowed: ' : 'Denied: ') + detail.split('\n').join(' · ');
  return ans;
}
function addFiles(el, files, chat) {
  const wrap = document.createElement('div'); wrap.className = 'files';
  for (const f of files) {
    const b = document.createElement('button'); b.className = 'art';
    const ext = (f.name.split('.').pop() || 'file').slice(0, 4).toUpperCase();
    b.innerHTML = `<span class="ext">${esc(ext)}</span><span><b>${esc(f.name)}</b><small>${f.size ? Math.max(1, Math.round(f.size / 1024)) + ' KB · ' : ''}Tap to open</small></span>`;
    b.onclick = () => openFile(f, chat);
    wrap.append(b);
  }
  el.append(wrap);
}
async function openFile(f, chat) {
  openSheet(f.name, `<div class="sh-p">Loading…</div>`);
  try {
    const r = await ag.downloadOutput(S.keys.claude, f.id); const blob = await r.blob(); const ext = (f.name.split('.').pop() || '').toLowerCase();
    const body = $('#shBody'); body.innerHTML = '';
    if (['html', 'htm'].includes(ext)) {
      const fr = document.createElement('iframe'); fr.className = 'preview'; fr.setAttribute('sandbox', 'allow-scripts'); fr.srcdoc = await blob.text(); body.append(fr);
    } else if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].includes(ext) || blob.type.startsWith('image/')) {
      const im = document.createElement('img'); im.className = 'preview-img'; im.src = URL.createObjectURL(blob); body.append(im);
    } else {
      const pre = document.createElement('pre'); pre.className = 'preview-txt'; pre.textContent = (await blob.text()).slice(0, 60000); body.append(pre);
    }
    const act = document.createElement('div'); act.className = 'sh-act';
    if (navigator.canShare?.({ files: [new File([blob], f.name)] })) {
      const s = document.createElement('button'); s.className = 'btn pri'; s.textContent = 'Share or save';
      s.onclick = () => navigator.share({ files: [new File([blob], f.name, { type: blob.type })] }).catch(() => {}); act.append(s);
    }
    const t = document.createElement('button'); t.className = 'btn'; t.textContent = 'Copy text';
    t.onclick = async () => { try { await navigator.clipboard.writeText(await blob.text()); toast('Copied'); } catch { toast("Couldn't copy"); } }; act.append(t);
    body.append(act);
  } catch (e) { $('#shBody').innerHTML = `<p class="sh-p">${esc(e.message || "Couldn't open this file.")}</p>`; }
}

/* ---------- phone tools ---------- */
// opening other apps: the iPhone add-on; on Android (no add-on) links go through Android itself (Capacitor hands tel:,
// sms:, mailto: and the like to the right app; web links open in an in-app browser tab, never in place of this app)
const androidOpen = async (url) => {
  if (/^https?:/i.test(url)) { const B = plugin('Browser'); if (B) { await B.open({ url }); return true; } window.open(url, '_blank'); return true; }
  if (/^shortcuts:/i.test(url)) return false;
  location.href = url; return true;
};
const phoneEnv = () => ({ calendar: plugin('CapacitorCalendar'), abil: S.st.abil, openURL: plugin('ShivoNative') ? openURL : /Android/i.test(navigator.userAgent) ? androidOpen : null });
const toolTitle = { list_calendar_events: 'Check your calendar', add_calendar_event: 'Add to your calendar', add_reminder: 'Add a reminder', run_shortcut: 'Run a shortcut', open_app: 'Open an app',
  tv_status: 'Look at the TV', tv_control: 'Control the TV', tv_message: 'Show a message on the TV', cloud_find: 'Look in your Cloud',
  chat_overview: 'Look at Chat', chat_read: 'Read a chat', chat_search: 'Search Chat', chat_send: 'Send a Chat message',
  pc_status: 'Look at your PC', pc_renew_apps: 'Renew your iPhone apps', pc_find_files: 'Look on your PC', pc_copy_to_cloud: 'Copy a file from your PC',
  find_contact: 'Look in your contacts', flashlight: 'Flashlight' };
function toolDetail(name, i = {}) {
  const when = (s) => { const d = new Date(s); return Number.isNaN(+d) ? s : d.toLocaleString([], { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); };
  if (name === 'add_calendar_event') return `${i.title || 'Event'}\n${i.start ? when(i.start) : ''}${i.end ? ' to ' + new Date(i.end).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : ''}${i.location ? '\n' + i.location : ''}`.trim();
  if (name === 'add_reminder') return `${i.title || 'Reminder'}${i.due ? '\n' + when(i.due) : ''}`;
  if (name === 'run_shortcut') return `Run the shortcut "${i.name}"${i.input ? '\nwith: ' + i.input : ''}`;
  if (name === 'chat_send') return `To ${i.to || ''}:\n${i.text || ''}`;
  if (name === 'pc_renew_apps') return 'Your PC renews this iPhone\'s apps. Shivo Labs closes for a moment.';
  if (name === 'pc_copy_to_cloud') return `${i.name || String(i.id || '').split('/').pop()}\ninto Cloud › From PC`;
  if (name === 'tv_control') return `${({ play: 'Play', pause: 'Pause', next: 'Next', previous: 'Previous', volume_up: 'Volume up', volume_down: 'Volume down', mute: 'Mute', home: 'Home screen', open_app: 'Open' })[i.action] || i.action}${i.app ? ' ' + i.app : ''}${i.times > 1 ? ` (${i.times} steps)` : ''}\non ${tvPaired()?.name || 'the TV'}`;
  if (name === 'tv_message') return `${i.title ? i.title + '\n' : ''}${i.text || ''}\non ${tvPaired()?.name || 'the TV'}`;
  if (name === 'open_app') return `${({ call: 'Call', sms: 'Text', whatsapp: 'WhatsApp', email: 'Email', maps: 'Maps', url: 'Open' })[i.kind] || 'Open'} ${i.to || i.query || ''}${i.text ? '\n' + i.text : ''}`;
  return 'Look at the next few days';
}
// one place that asks first (when asked to), runs the tool, and writes the log
async function runPhoneTool(msg, name, input, signal) {
  if (WRITE_TOOLS.has(name) && S.st.askPhone) {
    const a = await permCard(msg, 'Allow this on your phone?', `${toolTitle[name]}\n${toolDetail(name, input)}`, signal);
    if (a === 'stop') throw new DOMException('Stopped', 'AbortError');
    if (a !== 'allow') return { error: 'The user declined this.' };
  }
  const out = await execPhoneTool(name, input, phoneEnv());
  if (!out.error && WRITE_TOOLS.has(name)) { S.log.unshift({ t: `${toolTitle[name]}: ${(input.title || '').slice(0, 60)}`, w: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) }); store.set('sl.log', S.log.slice(0, 30)); }
  return out;
}

/* ---------- one turn ---------- */
const chatSystem = (web) => `You are Shivo Labs AI, an assistant on the user's phone. They may be away from any computer, so answer directly and briefly, in plain language.${web ? ' You can search the web.' : ''} You can read and add to their calendar and reminders, run their iPhone Shortcuts by name, and open apps ready to call, text, WhatsApp, email or show a map${tvPaired() ? `; you can see and control their TV (${tvPaired().name || 'Shivo Labs TV'}): what is playing, play and pause, volume, open apps, show a message` : ''}${cloud.creds() ? '; you can find files in their Shivo Labs Cloud by name' : ''}${chatSignedIn() ? '; you can read, search and send their team Chat messages' : ''}${hasPc() ? '; you can see whether their PC is on, find files in the folders it shares with the phone, copy one into their Cloud, and ask it to renew this iPhone\'s apps' : ''}; you can look up their contacts and turn the flashlight on or off; changes ask the user first. Never say you did something unless a tool confirmed it. ${contextLine()}`;
const stepLabel = { chat_overview: 'Looked at Chat', chat_read: 'Read a chat', chat_search: 'Searched Chat', chat_send: 'Sent a Chat message',
  pc_status: 'Looked at your PC', pc_renew_apps: 'Asked your PC to renew', pc_find_files: 'Looked on your PC', pc_copy_to_cloud: 'Copied it to your Cloud',
  find_contact: 'Looked in your contacts', flashlight: 'Flashlight', tv_status: 'Looked at the TV', tv_control: 'Controlled the TV', tv_message: 'Showed it on the TV', cloud_find: 'Looked in your Cloud', bash: 'Ran a command', write: 'Wrote a file', edit: 'Edited a file', read: 'Read a file', glob: 'Looked for files', grep: 'Searched files', web_search: 'Searched the web', web_fetch: 'Read a page', list_calendar_events: 'Checked your calendar', add_calendar_event: 'Added to your calendar', add_reminder: 'Added a reminder' };
const stepKind = { bash: 'run', write: 'write', edit: 'edit', read: 'read', glob: 'search', grep: 'search', web_search: 'web', web_fetch: 'web' };
const stepDetail = (n, i = {}) => i.command ? String(i.command).split('\n')[0].slice(0, 70) : i.file_path || i.path || i.pattern || i.query || i.url || i.title || '';

function failText(e) { return e.message || 'Something went wrong. Try again.'; }
async function send(text) {
  text = String(text || '').trim();
  const files = ATT.splice(0); paintAtt();
  if ((!text && !files.length) || S.run || !canUse()) { ATT.push(...files); paintAtt(); return; }
  if (files.length && S.st.workspace === 'cloud') { ATT.push(...files); paintAtt(); return toast('Attachments work in Chat for now, not in cloud tasks.'); }
  if (!text) text = files.length > 1 ? 'Have a look at these.' : 'Have a look at this.';
  S.pending = files;
  box.value = ''; grow();
  let c = S.cur; if (!c) { c = newChat(); S.chats.unshift(c); S.cur = c; }
  if (!c.ui.length) { c.title = text.length > 34 ? text.slice(0, 32).trim() + '…' : text; msgsEl.innerHTML = ''; }
  renderChats();
  const u = document.createElement('div'); u.className = 'm u'; u.innerHTML = `${attStrip(files)}<div>${esc(text)}</div>`; msgsEl.append(u);
  c.ui.push({ r: 'u', t: text, att: files.map((f) => ({ name: f.name, kind: f.kind, thumb: f.thumb })) }); c.at = Date.now();
  const a = { r: 'a', t: '', steps: [], notes: [], files: [] }; c.ui.push(a);
  const msg = document.createElement('div'); msg.className = 'm a'; msgsEl.append(msg);
  const run = (S.run = { ctl: new AbortController(), chat: c }); updateSend();
  const sb = stepsBox(); msg.append(sb.el); sb.kind('think', 'Thinking…'); scrollDown();
  let txt = null, acc = '', brk = false;
  const stream = (t, whole) => {
    if (!txt) { txt = document.createElement('div'); txt.className = 'txt caret'; msg.append(txt); }
    acc += ((whole || brk) && acc ? '\n\n' : '') + t; brk = false; a.t = acc; txt.innerHTML = md(acc); scrollDown(); saveSoon(c);
  };
  const step = (id, kind, label, detail) => {
    brk = true;
    const html = `${esc(label)}${detail ? ` <code>${esc(detail)}</code>` : ''}`;
    if (sb.byId.has(id)) sb.update(id, html); else sb.add(id, html);
    sb.kind(kind, label); scrollDown();
  };
  const task = S.st.workspace === 'cloud' && hasClaude();
  try {
    if (task) await runTaskTurn({ c, a, msg, sb, run, text, stream, step });
    else if (isG()) await runGeminiTurn({ c, a, msg, sb, run, text, stream, step });
    else await runClaudeTurn({ c, a, msg, sb, run, text, stream, step });
    finishTurn(c, a, sb, false);
  } catch (e) {
    if (run.detached) { sb.finish(false); a.steps = sb.list; a.sum = sb.summary; }
    else if (run.ctl.signal.aborted || e.name === 'AbortError') { finishTurn(c, a, sb, true); }
    else { sb.finish(false); const er = document.createElement('div'); er.className = 'note err'; er.innerHTML = '<span></span>'; $('span', er).textContent = failText(e); msg.append(er); a.t = (a.t ? a.t + '\n\n' : '') + '⚠️ ' + failText(e); a.steps = sb.list; a.sum = sb.summary; }
  } finally {
    if (txt) txt.classList.remove('caret');
    if (S.run === run) S.run = null;
    trimAttachments(c); saveChat(c); updateSend(); renderTasks(); paintPill();
  }
}
function trimAttachments(c) {
  const users = c.history.filter((m) => m.role === 'user' && Array.isArray(m.content));
  for (const m of users.slice(0, -1)) m.content = m.content.map((b) => (b.type === 'image' || b.type === 'document') && b.source?.data ? { type: 'text', text: `[an earlier ${b.type === 'image' ? 'photo' : 'PDF'} the user attached]` } : b);
}
function finishTurn(c, a, sb, stopped) { sb.finish(stopped); a.steps = sb.list; a.sum = sb.summary; if (!a.t && !stopped && !a.files?.length) a.t = '(No text came back.)'; }
function stopRun() {
  const r = S.run; if (!r) return;
  r.ctl.abort();
  const c = r.chat;
  if (c.session?.id && hasClaude()) ag.interrupt(S.keys.claude, c.session.id).catch(() => {});
}

// ---- keeping a long conversation cheap: the whole history goes with every question, so when it passes ~28 messages the older part is
// folded into one short summary (the conversation on screen is untouched). A turn is never cut in the middle (a tool's request and its
// answer stay together). Without a Claude key (Gemini only) the oldest turns are simply left out of what is sent.
const HIST_MAX = 28, HIST_KEEP_TURNS = 4;
const isTurnStart = (m) => m.role === 'user' && !(Array.isArray(m.content) && m.content.some((b) => b.type === 'tool_result'));
const plainOf = (m) => (Array.isArray(m.content) ? m.content : [{ type: 'text', text: String(m.content ?? '') }])
  .map((b) => (b.type === 'text' ? b.text : b.type === 'tool_use' ? `[used ${b.name}]` : b.type === 'image' ? '[a photo]' : b.type === 'document' ? '[a PDF]' : '')).filter(Boolean).join(' ');
async function foldHistory(c) {
  const H = c.history;
  if (H.length <= HIST_MAX) return;
  const starts = H.map((m, i) => (isTurnStart(m) ? i : -1)).filter((i) => i >= 0);
  if (starts.length <= HIST_KEEP_TURNS + 1) return;
  const cut = starts[starts.length - HIST_KEEP_TURNS], old = H.slice(0, cut), keep = H.slice(cut);
  let summary = '';
  if (hasClaude()) {
    try {
      const text = old.map((m) => `${m.role === 'user' ? 'User' : 'Assistant'}: ${plainOf(m)}`).filter((l) => l.length > 12).join('\n').slice(-30000);
      const r = await messagesStream({ key: S.keys.claude, model: MODELS.haiku.id, maxTokens: 400, effort: 'low',
        system: 'You compress a conversation for later reference. Write a short plain summary (under 180 words): what the user wants, facts and preferences they gave, decisions made, anything still open. No preamble.',
        messages: [{ role: 'user', content: text }] });
      summary = r.content.filter((b) => b.type === 'text').map((b) => b.text).join('').trim();
      addSpend(costOf(MODELS.haiku.id, r.usage));
    } catch { return; }   // nothing is lost: it is tried again with the next question
    if (!summary) return;
  }
  c.history = summary ? [{ role: 'user', content: `Earlier in this conversation (summary): ${summary}` }, { role: 'assistant', content: [{ type: 'text', text: 'Understood.' }] }, ...keep] : keep;
}

async function runClaudeTurn({ c, a, msg, sb, run, text, stream, step }) {
  const model = MODELS[S.st.model]?.id || MODELS.sonnet.id;
  await foldHistory(c);
  c.history.push({ role: 'user', content: userContent(text) });
  const tn = new Map();
  await runChat({ key: S.keys.claude, model, system: chatSystem(true), history: c.history, phoneTools: phoneTools(), signal: run.ctl.signal, effort: S.st.effort || 'medium',
    execTool: (n, i) => runPhoneTool(msg, n, i, run.ctl.signal),
    onText: (t) => stream(t), onThinking: () => sb.kind('think', 'Thinking…'),
    onStep: (s) => { if (s.kind === 'web') step(s.id, 'web', s.label, s.detail); else { tn.set(s.id, s.label); step(s.id, 'wait', toolTitle[s.label] || s.label, ''); } },
    onStepDone: (id, out) => { const n = tn.get(id); step(id, 'read', out?.error ? `Couldn't: ${(toolTitle[n] || n).toLowerCase()}` : (stepLabel[n] || n), ''); },
    onUsage: (u) => addSpend(costOf(model, u)) });
}
async function runGeminiTurn({ c, a, msg, sb, run, text, stream, step }) {
  await foldHistory(c);
  c.history.push({ role: 'user', content: userContent(text) });
  const tn = new Map();
  S.fell = null;
  const chain = chainFor(S.st.model);
  const res = await runGeminiChat({ key: S.keys.gemini, limits: S.limits, chain, system: chatSystem(false), history: c.history, phoneTools: phoneTools(), signal: run.ctl.signal, effort: S.st.effort || 'medium',
    execTool: (n, i) => runPhoneTool(msg, n, i, run.ctl.signal),
    onText: (t) => stream(t), onThought: () => sb.kind('think', 'Thinking…'),
    onStep: (s) => { tn.set(s.id, s.label); step(s.id, 'wait', toolTitle[s.label] || s.label, ''); },
    onStepDone: (id, out) => { const n = tn.get(id); step(id, 'read', out?.error ? `Couldn't: ${(toolTitle[n] || n).toLowerCase()}` : (stepLabel[n] || n), ''); },
    onNotice: ({ from, to, why }) => {
      const t = `Switched to ${prettyGemini(to)}: ${prettyGemini(from)} ${({ busy: 'is overloaded at Google right now', gone: "isn't available to your key any more", big: "can't take a chat this big on the free tier" })[why] || 'has used its free requests for today'}`;
      a.notes.push(t); noteBefore(msg, sb, t); S.fell = to; paintChips(); toast(t);
    },
    onWait: (m, sec, kind) => sb.kind('wait', kind === 'check' ? `Gemini refused this; waiting ${sec}s to see why…` : `Pacing for Gemini's per-minute limit (${sec}s)…`) });
  if (res?.used && res.used !== chain[0]) { S.fell = res.used; paintChips(); }
}

/* ---------- cloud tasks ---------- */
const TASK_PREFIX = (mode) => (mode === 'plan' ? 'PLAN ONLY: look at what is needed and write a short step-by-step plan. Do not create or change anything.\n\n' : '');
async function runTaskTurn({ c, a, msg, sb, run, text, stream, step }) {
  const key = S.keys.claude, modelKey = isG() ? 'sonnet' : S.st.model, modelId = MODELS[modelKey].id;
  const ask = S.st.mode === 'ask';
  c.kind = 'task';
  const noteT = `Running in the cloud. You can lock your phone, it keeps working.`; if (!c.session) { a.notes.push(noteT); noteBefore(msg, sb, noteT); }
  sb.kind('think', 'Getting a cloud workspace ready…');
  if (!c.session) {
    const envId = await ag.ensureEnvironment(key, store);
    const agent = await ag.ensureAgent(key, modelId, ask, store, PHONE_TOOLS);
    const id = await ag.createSession(key, { agent, environmentId: envId, title: c.title });   // no spending cap (Shivam, 23 Oct 2026: it was removed; the budget sent with it may have been what made tasks fail)
    c.session = { id, seen: [], model: modelId, cost: 0, status: 'running' };
  }
  c.session.status = 'running'; saveChat(c); renderTasks();
  const seen = new Set(c.session.seen); run.seen = seen;
  await attach({ c, a, msg, sb, run, seen, stream, step, message: TASK_PREFIX(S.st.mode) + `[${contextLine()}]\n\n` + text });
}
// Follow the session; used for a new turn and for coming back after the phone was locked.
async function attach({ c, a, msg, sb, run, seen, stream, step, message }) {
  const key = S.keys.claude;
  const handlers = {
    onText: (t) => { stream(t, true); sb.kind('write', 'Writing…'); },
    onStep: (s) => { const k = stepKind[s.name] || (s.phone ? 'wait' : 'run'); step(s.id, k, stepLabel[s.name] || s.name, stepDetail(s.name, s.input)); },
    onStepResult: (id, r) => { if (!r.ok) { const row = sb.byId.get(id); if (row) row.classList.add('bad'); } },
    confirm: async (name, input) => { const ans = await permCard(msg, 'Allow this in the cloud?', `${stepLabel[name] || name}\n${stepDetail(name, input)}`, run.ctl.signal); return ans === 'allow'; },
    execCustom: (name, input) => runPhoneTool(msg, name, input, run.ctl.signal),
    onUsage: (u) => { const cost = ag.sessionCost(c.session.model, u); const d = cost - (c.session.cost || 0); if (d > 0) { c.session.cost = cost; addSpend(d); } },
    onStatus: (s) => { if (s === 'waiting') sb.kind('wait', 'Waiting for you…'); },
  };
  // keep the seen-set saved as events arrive, so a locked phone can pick up exactly where it left off
  const tick = setInterval(() => { c.session.seen = [...seen]; saveChat(c); }, 1500);
  let res;
  try { res = await ag.followSession({ key, sessionId: c.session.id, message, seen, handlers, signal: run.ctl.signal }); }
  finally { clearInterval(tick); c.session.seen = [...seen]; }
  c.session.status = res.status === 'stopped' ? (run.detached ? 'running' : 'stopped') : res.status === 'error' ? 'error' : res.status === 'budget' ? 'budget' : 'done';
  if (res.status === 'error') throw new Error(res.error || 'The task hit an error.');
  if (res.status === 'budget') { const t = 'This task paused because its budget ran out.'; a.notes.push(t); noteBefore(msg, sb, t); }
  if (res.status !== 'stopped') await loadOutputs(c, a, msg);
}
async function loadOutputs(c, a, msg) {
  let files = [];
  for (let i = 0; i < 6 && !files.length; i++) { try { files = await ag.listOutputs(S.keys.claude, c.session.id); } catch {} if (!files.length) await sleepMs(FAST ? 100 : 2000); }
  const known = new Set((c.files || []).map((f) => f.id)); const fresh = files.filter((f) => !known.has(f.id));
  c.files = [...(c.files || []), ...fresh];
  if (fresh.length) { a.files = fresh; addFiles(msg, fresh, c); scrollDown(); }
}
async function resumeTask(c, fromVisibility) {
  if (S.run || !c.session?.id || !hasClaude() || !S.online) return;
  // rebuild the screen from what we saved, then continue with whatever happened while away
  if (S.cur !== c) { S.cur = c; paintChips(); }
  renderMsgs();
  let a = c.ui.at(-1); if (!a || a.r !== 'a') { a = { r: 'a', t: '', steps: [], notes: [], files: [] }; c.ui.push(a); }
  const msg = document.createElement('div'); msg.className = 'm a'; msgsEl.append(msg);
  const run = (S.run = { ctl: new AbortController(), chat: c }); updateSend();
  const sb = stepsBox(); msg.append(sb.el); sb.kind('think', 'Catching up with your task…');
  let txt = null, acc = a.t || '';
  const stream = (t, whole) => { if (!txt) { txt = document.createElement('div'); txt.className = 'txt caret'; msg.append(txt); } acc += (whole && acc ? '\n\n' : '') + t; a.t = acc; txt.innerHTML = md(acc); scrollDown(); saveSoon(c); };
  const step = (id, kind, label, detail) => { const html = `${esc(label)}${detail ? ` <code>${esc(detail)}</code>` : ''}`; if (sb.byId.has(id)) sb.update(id, html); else sb.add(id, html); sb.kind(kind, label); };
  try {
    const seen = new Set(c.session.seen); run.seen = seen;
    await attach({ c, a, msg, sb, run, seen, stream, step });
    a.steps = [...(a.steps || []), ...sb.list]; sb.finish(false); a.sum = (a.steps.length) + ' steps';
  } catch (e) { if (!(run.ctl.signal.aborted || e.name === 'AbortError')) toast(failText(e)); sb.finish(true); }
  finally { if (txt) txt.classList.remove('caret'); if (S.run === run) S.run = null; saveChat(c); updateSend(); renderTasks(); }
}

/* ---------- tasks tab ---------- */
const ago = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'Just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' d ago'; };
function renderTasks() {
  const tasks = S.chats.filter((c) => c.session).sort((a, b) => b.at - a.at);
  const running = tasks.filter((c) => c.session.status === 'running').length;
  taskBadgeEl().hidden = !running; $('#menuBtn')?.classList.toggle('busy', !!running);
  const lab = { running: ['Running', 'run'], done: ['Done', ''], stopped: ['Stopped', ''], budget: ['Paused at cap', 'bad'], error: ['Error', 'bad'] };
  $('#tasksBody').innerHTML = `<h1 class="mod-h">Tasks</h1>` + (tasks.length ? `<section class="card"><div class="head"><h2>Cloud <span>tasks</span></h2></div>${tasks.map((c) => {
    const [t, k] = lab[c.session.status] || ['Done', ''];
    return `<button class="trow" data-id="${c.id}"><span class="tt"><b>${esc(c.title)}</b><small>${ago(c.at)} · ${money(c.session.cost || 0)}${c.files?.length ? ' · ' + c.files.length + ' file' + (c.files.length > 1 ? 's' : '') : ''}</small></span><span class="st-pill ${k}">${t}</span></button>`;
  }).join('')}</section><p class="foot">Tasks run on Anthropic's servers, so they keep going when your phone is locked.</p>`
    : `<section class="card"><div class="head"><h2>Cloud <span>tasks</span></h2></div><p class="emptyt">Nothing yet. In Chat, choose <b>Cloud task</b> and describe what you want built, fixed or written.</p></section>`);
  $$('.trow', $('#tasksBody')).forEach((b) => (b.onclick = () => { if (S.run) return toast('Wait for the current reply, or stop it first'); S.cur = S.chats.find((c) => c.id === b.dataset.id); syncWorkspace(); renderMsgs(); switchApp('ai'); }));
}

/* ---------- phone tab ---------- */
async function accessState() {
  const cal = plugin('CapacitorCalendar'); if (!cal) return null;
  try { const r = await cal.checkAllPermissions(); return r?.result || null; } catch { return null; }
}
// Phone access (was the Phone screen, now a page of Settings): what Labs AI may do on this phone, the iPhone's permission, and a log
function phoneSheet() {
  const native = !!plugin('CapacitorCalendar');
  const sw = (on) => `<i class="sw ${on ? 'on' : ''}"></i>`;
  const I = {
    cal: '<rect x="4" y="5" width="16" height="15" rx="2.5"/><path d="M4 10h16M9 3v4M15 3v4"/>',
    bell: '<path d="M12 3a5 5 0 0 0-5 5v3l-1.5 3h13L17 11V8a5 5 0 0 0-5-5zM10 18a2 2 0 0 0 4 0"/>',
    shield: '<path d="M12 3.5 19 6v5.5c0 4.2-3 7.6-7 9-4-1.4-7-4.8-7-9V6z"/><path d="m9 12 2 2 4-4"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  };
  const si = (d) => `<span class="s-ic"><svg viewBox="0 0 24 24">${d}</svg></span>`;
  openSheet('Phone access', `<p class="sh-p">What Labs AI may do on this phone. Only what you send to a model leaves the phone.</p>
    <div class="sgroup">
      <button class="row" data-ab="cal">${si(I.cal)}<span class="t"><b>Calendar</b><small>Read your events and add new ones</small></span>${sw(S.st.abil.cal)}</button>
      <button class="row" data-ab="rem">${si(I.bell)}<span class="t"><b>Reminders</b><small>Add reminders to the Reminders app</small></span>${sw(S.st.abil.rem)}</button>
      <button class="row" id="askRow">${si(I.shield)}<span class="t"><b>Ask me before each change</b><small>Recommended. You see what it will do and tap Allow.</small></span>${sw(S.st.askPhone)}</button></div>
    <div class="sgroup"><button class="row ${native ? '' : 'dis'}" id="askAccess">${si(I.lock)}<span class="t"><b>Allow calendar and reminders</b><small>${native ? 'iPhone asks once. You can change it any time in iPhone Settings.' : 'Only works inside the installed phone app.'}</small></span>${ic('chev')}</button></div>
    <div class="sh-sub">RECENT ACTIONS</div><div class="sgroup">${S.log.length ? S.log.slice(0, 12).map((l) => `<div class="row" style="pointer-events:none"><span class="t"><b>${esc(l.t)}</b><small>${esc(l.w)}</small></span></div>`).join('') : '<p class="sh-p own-none">Nothing yet.</p>'}</div>
    <p class="foot">Everything it does on this phone is listed here.</p>`, (r) => {
    $$('[data-ab]', r).forEach((x) => (x.onclick = () => { const k = x.dataset.ab; S.st.abil[k] = !S.st.abil[k]; saveSettings(); $('.sw', x).classList.toggle('on', S.st.abil[k]); }));
    $('#askRow', r).onclick = (e) => { S.st.askPhone = !S.st.askPhone; saveSettings(); $('.sw', e.currentTarget).classList.toggle('on', S.st.askPhone); };
    $('#askAccess', r).onclick = async () => {
      const cal = plugin('CapacitorCalendar'); if (!cal) return;
      try { const a = await cal.requestFullCalendarAccess(); const rm = await cal.requestFullRemindersAccess(); toast(a.result === 'granted' && rm.result === 'granted' ? 'Calendar and reminders allowed' : a.result === 'granted' ? 'Calendar allowed. Reminders were not.' : 'Not allowed. You can change it in iPhone Settings.'); }
      catch (e) { toast(e.message || "Couldn't ask for access"); }
    };
  });
}

/* ---------- Shivo Labs Cloud: sending between this phone and the PC (Beam's engine), and the files kept in the cloud ---------- */
// The screen is built once and only the parts that changed are updated, so the cards don't pop in
// again (and the QR, address box and file picker aren't rebuilt) each time a file is saved.
const BM = { pc: '', items: [], busy: '', err: '', since: 0 };
const bmBytes = (b) => b >= 1e9 ? (b / 1e9).toFixed(1) + ' GB' : b >= 1e6 ? Math.round(b / 1e6) + ' MB' : Math.max(1, Math.round(b / 1e3)) + ' KB';
const bmBig = (size) => size >= 5e6 ? ` (${bmBytes(size)})` : '';   // only worth a mention when it takes a moment
const bmSet = (el, html) => { if (el.dataset.h !== html) { el.dataset.h = html; el.innerHTML = html; } };
// Cloud's settings (the phone's name on the PC, the PC's address, Shivo Labs for another PC, the live card test)
function beamSettings() {
  const ic1 = '<svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="8" rx="4"/><path d="M7 12h6"/></svg>';
  openSheet('Cloud settings', `
    <div class="sh-sub" style="margin-top:0">THIS PHONE</div><div class="sgroup">
      <div class="row col"><span class="t"><b>Name on your PC</b><small>So your PC can tell your devices apart.</small></span>
        <input class="field" id="bmName" maxlength="40" placeholder="e.g. Sara's iPhone" value="${esc(beam.deviceName())}" autocorrect="off" spellcheck="false"></div></div>
    <div class="sh-sub">YOUR PC</div><div class="sgroup">
      <div class="row col"><span class="t"><b>PC address</b><small>Leave as beam.local unless your PC shows a different one.</small></span>
        <input class="field" id="bmHost" value="${esc(S.st.beamHost || 'beam.local')}" autocapitalize="off" autocorrect="off" spellcheck="false"></div></div>
    <p class="sh-p" style="margin:12px 4px 0">Files from your PC save by themselves while Shivo Labs is open: photos to Photos, the rest to Files. Near the PC they go straight across the Wi-Fi; away from home through Shivo Labs (up to 100 MB each, PC on). With the PC off, what you send waits in Shivo Labs Cloud.</p>
    <div class="sh-sub">SHIVO LABS FOR ANOTHER PC</div><div class="sgroup">
      <div class="row col"><span class="t"><b>Scan this, or send the link</b></span><div class="bm-qr" id="bmQr"></div><button class="btn sm" id="bmShare">Send the link</button></div></div>
    ${cloud.creds() ? `<div class="sh-sub">TRASH</div><div class="sgroup">
      <button class="row" id="bmTrash"><span class="s-ic"><svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-12M9 7V4h6v3"/></svg></span><span class="t"><b>Trash</b><small>Deleted files stay 30 days. Bring them back here.</small></span>${ic('chev')}</button></div>` : ''}
    <div class="sh-sub">CHECK</div><div class="sgroup">
      <button class="row" id="bmLive"><span class="s-ic">${ic1}</span><span class="t"><b>Test the live card</b><small>Shows a card on the Lock Screen to see that it works.</small></span></button></div>
    <p class="hint" id="bmLiveOut" hidden></p>`, (root) => {
    $('#bmTrash', root) && ($('#bmTrash', root).onclick = () => swapSheet(() => trashSheet()));
    const q = qrcode(0, 'M'); q.addData(beam.SHARE_URL); q.make(); $('#bmQr', root).innerHTML = q.createSvgTag({ cellSize: 5, margin: 2, scalable: true });
    $('#bmShare', root).onclick = async () => {
      const S2 = plugin('Share');
      try { if (S2) await S2.share({ title: 'Shivo Labs', text: 'Send and keep files between your iPhone and PC:', url: beam.SHARE_URL }); else if (navigator.share) await navigator.share({ url: beam.SHARE_URL }); else { await navigator.clipboard.writeText(beam.SHARE_URL); toast('Link copied'); } } catch {}
    };
    $('#bmHost', root).onchange = (e) => { S.st.beamHost = e.target.value.trim() || 'beam.local'; saveSettings(); BM.pc = ''; renderBeam(true); };
    $('#bmLive', root).onclick = async () => {
      const o = $('#bmLiveOut', root); o.hidden = false; o.textContent = 'Checking…';
      const lines = await live.test();
      if (live.lastError) lines.push('Last Beam card: ' + live.lastError);
      o.innerHTML = lines.map(esc).join('<br>');
    };
    $('#bmName', root).onchange = (e) => { beam.setDeviceName(e.target.value); e.target.value = beam.deviceName(); toast(e.target.value ? 'Your PC will show it as ' + e.target.value : 'Name cleared'); renderBeam(true); };
  });
}
function buildBeam(root) {
  // UNIFY-PLAN.md phase 2 (minimal Cloud): the PC in one line, two buttons, then your files; settings in a sheet
  root.innerHTML = `
    <header class="cz-top"><h1 class="cz-h">Cloud</h1>
      <button class="gbtn" id="czSet" aria-label="Cloud settings"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg></button></header>
    <div class="cz-pc"><i class="cz-dot" id="czDot"></i><span id="bmTitle"></span><button class="cz-link" id="bmRetry">Check</button></div>
    <p class="cz-note" id="bmErr" hidden></p>
    <p class="cz-note" id="bmBusy" hidden><span class="bm-ld" id="bmLd"></span> <span id="bmBusyTxt"></span></p>
    <div class="cz-acts">
      <label class="btn bm-send" id="bmSendLbl">Send to PC<input type="file" id="bmPick" multiple hidden></label>
      <label class="btn" id="ccAddLbl" hidden>Add to Cloud<input type="file" id="ccPick" multiple hidden></label>
    </div>
    <button class="btn" id="bmGet" hidden disabled>Nothing waiting on the PC</button>
    <p class="hint" id="bmHint" hidden></p>
    <p class="cz-note" id="ccState">Your files, available with the PC off. Encrypted on your devices.</p>
    <div id="ccTools" hidden>
      <label class="cz-search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/></svg><input id="ccQ" type="search" placeholder="Search your files" enterkeyhint="search" autocorrect="off" autocapitalize="off" spellcheck="false"></label>
      <nav class="cf-crumbs" id="ccCrumbs"></nav>
    </div>
    <div id="ccList"></div>
    <button class="btn" id="ccMore" hidden>Show more</button>
    <button class="btn pri" id="ccJoin">Connect</button>`;
  $('#czSet', root).onclick = () => beamSettings();
  $('#bmRetry', root).onclick = () => renderBeam(true);
  $('#bmTitle', root).onclick = () => { root.dataset.why = root.dataset.why === '1' ? '' : '1'; paintBeam(); };
  $('#ccJoin', root).onclick = async () => {
    const b = $('#ccJoin', root); b.disabled = true; b.textContent = 'Connecting…';
    try {
      const r = await cloud.join();
      toast(r.files && !r.files.files ? 'Connected. Files app: ' + (r.files.error || 'not added') : 'Connected to Shivo Labs Cloud'); haptic('success');
    } catch (e) {
      // away from the PC's Wi-Fi: join with the pass, and a PC of the company allows it (UNIFY-PLAN.md)
      if (!pass.passFor('files')) toast(e.message || "Couldn't connect");
      else try { const w = await cloud.joinWithPass(beam.deviceName() || 'Phone'); haptic('success'); toast(w === 'joined' ? 'Connected to Shivo Labs Cloud' : 'Your PC asks to allow this phone'); }
      catch (e2) { toast(e2.message || "Couldn't connect"); }
    }
    b.disabled = false; paintCloud();
  };
  let qt = 0;
  $('#ccQ', root).oninput = (e) => { clearTimeout(qt); qt = setTimeout(() => { CF.q = e.target.value.trim(); CF.shown = 40; paintCloud(); }, 300); };
  $('#ccMore', root).onclick = () => { CF.shown += 40; paintList(); };
  $('#ccPick', root).onchange = (e) => { const files = [...e.target.files]; e.target.value = ''; if (files.length) addToCloud(files, CF.folder); };
  paintCloud();
  $('#bmPick', root).onchange = (e) => {
    const files = [...e.target.files]; e.target.value = ''; if (!files.length) return;   // reset so the same photo can be picked again
    sendToPC(files);
  };
  // Builds with the file-picker add-on: the phone's own pickers, several items at once, photos and videos mixed,
  // and videos as they are (the web picker shrinks them first). Older builds keep the page's picker above.
  $('#bmSendLbl', root).addEventListener('click', async (e) => {
    const has = (n) => !!globalThis.Capacitor?.isPluginAvailable?.(n);
    if (!has('FilePicker') || BM.busy) return;
    e.preventDefault();
    let which = 0;
    if (has('ActionSheet')) {
      try { which = (await plugin('ActionSheet').showActions({ title: 'Send to the PC', options: [{ title: 'Photos and videos' }, { title: 'Files' }, { title: 'Cancel', style: 'CANCEL' }] })).index; } catch { return; }
      if (which !== 0 && which !== 1) return;
    }
    const FP = plugin('FilePicker');
    let r;
    try { r = which === 0 ? await FP.pickMedia({ limit: 0, skipTranscoding: true }) : await FP.pickFiles({ limit: 0 }); }
    catch (err) { if (!/cancel/i.test(err?.message || '')) toast(err?.message || "Couldn't open the picker"); return; }
    const picked = (r?.files || []).filter((f) => f.path); if (!picked.length) return;
    sendPathsToPC(picked.map((f) => ({ path: f.path, name: f.name || 'file', size: f.size || 0, mimeType: f.mimeType })));
  });
  $('#bmGet', root).onclick = () => receiveNow(true);
}
function paintBeam() {
  const root = $('#beamBody'); if (!root || !$('#bmTitle', root)) return;
  const n = BM.items.length, ph = BM.items.filter((x) => x.kind === 'media').length;
  const toCloud = !BM.pc && !!BM.err && !!cloud.creds();   // the PC is off: what you send waits in the cloud
  bmSet($('#bmTitle', root), `${BM.pc ? esc(BM.pc) : 'Your PC'} <span>${BM.pc ? (beam.viaRelay() ? 'connected from afar' : 'connected') : toCloud ? 'off · files wait in Cloud' : BM.err ? 'not found · why?' : 'looking…'}</span>`);
  $('#czDot', root).className = 'cz-dot' + (BM.pc ? ' on' : BM.err ? ' off' : '');
  const sl = toCloud ? 'Send to Cloud' : 'Send to PC', lbl = $('#bmSendLbl', root).firstChild;
  if (lbl.nodeType === 3 && lbl.textContent !== sl) lbl.textContent = sl;
  const em = toCloud ? '' : BM.err;   // the long reason only when the status line is tapped: it used to appear by itself and push everything down
  const err = $('#bmErr', root); err.hidden = !(em && root.dataset.why === '1'); if (err.textContent !== em) err.textContent = em;
  const busy = $('#bmBusy', root); busy.hidden = !BM.busy;
  if (BM.busy) {
    const ld = $('#bmLd', root); if (!ld.firstChild) ld.innerHTML = loader('wait', 16);
    const secs = Math.floor((Date.now() - BM.since) / 1000);
    const t = BM.busy + (secs >= 4 ? ` · ${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')}` : '');
    const tx = $('#bmBusyTxt', root); if (tx.textContent !== t) tx.textContent = t;
  }
  $('#bmSendLbl', root).classList.toggle('dis', !!BM.busy);
  $('#bmPick', root).disabled = !!BM.busy;
  const get = $('#bmGet', root); get.disabled = !!BM.busy || !n; get.hidden = toCloud || !n;
  const gt = n ? `Save ${n} from the PC` : 'Nothing waiting on the PC'; if (get.textContent !== gt) get.textContent = gt;
  const hint = $('#bmHint', root); hint.hidden = !n;
  if (n) bmSet(hint, `${ph ? `${ph} photo${ph > 1 ? 's' : ''} or video${ph > 1 ? 's' : ''} go to Photos. ` : ''}${n - ph ? 'Other files go to Files, On My iPhone, Shivo Labs, Beam.' : ''}`);
}
setInterval(() => { if (BM.busy && S.app === 'beam') paintBeam(); }, 1000);   // keeps the time counting while a big file saves
// Files already on the phone ({ path, name, size }: the pickers and the Share menu): newer builds hand them to iOS's
// upload service, which keeps going when the phone locks or another app comes up (the web view's upload stopped
// then); older builds read them here and send them from the page
async function sendPathsToPC(list) {
  beam.setHost(S.st.beamHost);
  if (!BM.pc && BM.err && cloud.creds()) return addToCloud(await readPaths(list), 'Beam');
  if (await beam.sendReady()) {
    const total = list.length;
    BM.busy = `Sending ${total} to the PC…`; BM.since = Date.now(); paintBeam();
    try {
      const r = await beam.sendNative(list, (i, t, name) => { BM.busy = `Sent ${i} of ${t}: ${name}`; BM.since = Date.now(); paintBeam(); },
        { to: BM.pc || 'your PC', look: live.look() });
      if (r.failed.length) toast(`${r.sent} sent. ${r.failed.length} couldn't be sent: ${r.failed[0]}`);
      else { toast(`Sent ${r.sent} to the PC`); haptic('success'); }
    } catch (err) { toast(err.message || "Couldn't send"); }
    BM.busy = ''; BM.since = 0; renderBeam(true);
    return;
  }
  const files = await readPaths(list);
  if (files.length) sendToPC(files);
}
// files on the phone ({ path, name, size }) read into the page
async function readPaths(list) {
  BM.busy = `Getting ${list.length} item${list.length > 1 ? 's' : ''} ready…`; BM.since = Date.now(); paintBeam();
  const files = [];
  for (const f of list) {
    try {
      const src = globalThis.Capacitor?.convertFileSrc ? globalThis.Capacitor.convertFileSrc(f.path.startsWith('file:') ? f.path : 'file://' + f.path) : f.path;
      const blob = await (await fetch(src)).blob();
      files.push(new File([blob], f.name || 'file', { type: f.mimeType || blob.type || 'application/octet-stream' }));
    } catch { toast(`Couldn't read ${f.name || 'a file'}`); }
  }
  BM.busy = ''; BM.since = 0; paintBeam();
  return files;
}
// Send files to the PC with progress here and on the live card (the page's own picker in older builds)
async function sendToPC(files) {
  if (!BM.pc && BM.err && cloud.creds()) return addToCloud(files, 'Beam');
  const total = files.reduce((n, f) => n + (f.size || 0), 0);
  try {
    beam.setHost(S.st.beamHost);
    await beam.send(files, (i, t, name) => {
      BM.busy = `Sending ${i + 1} of ${t}: ${name}${bmBig(files[i].size)}`; BM.since = Date.now(); paintBeam();
      const sent = files.slice(0, i).reduce((n, f) => n + (f.size || 0), 0);
      live.show('beam-send', { title: `To ${BM.pc || 'your PC'}`, subtitle: name, progress: total ? sent / total : i / t, count: `${i + 1} of ${t}`, detail: `${t - i - 1} left`, badge: 'arrow.up', icon: 'arrow.up', fileType: (name.split('.').pop() || '').toUpperCase().slice(0, 4) });
    });
    toast(`Sent ${files.length} to the PC`);
    live.done('beam-send', { title: `${files.length} sent to ${BM.pc || 'your PC'}`, subtitle: 'In Downloads › Beam on the PC', done: true });
    haptic('success');
  } catch (err) { toast(err.message); live.done('beam-send', { title: "Couldn't send", subtitle: err.message || '', failed: true }); }
  BM.busy = ''; BM.since = 0; renderBeam(true);
}

// "Open in Shivo Labs" from the Share menu (Files, Mail, Safari...): iOS opens the app with each file; we collect
// them for a moment, then offer them on a Send to PC sheet. Needs no extra signed piece (the free Apple ID's 3 places).
const incoming = [];
async function takeShared(url) {
  const N = plugin('ShivoNative');
  if (!url || !/^file:/i.test(url) || !N?.importFile) return;
  try {
    const f = await N.importFile({ url });
    incoming.push({ name: f.name, size: f.size, path: f.path });
  } catch (e) { toast(e.message || "Couldn't open that file"); return; }
  clearTimeout(takeShared.t); takeShared.t = setTimeout(offerShared, 500);
}
function offerShared() {
  const list = incoming.splice(0);
  if (!list.length) return;
  switchApp('beam');
  const mb = list.reduce((n, f) => n + (f.size || 0), 0) / 1e6;
  openSheet('Send to PC', `
    <p class="sh-p">${list.length === 1 ? esc(list[0].name) : list.length + ' files'}${mb >= 0.1 ? ' · ' + mb.toFixed(1) + ' MB' : ''}</p>
    ${list.slice(0, 6).map((f) => `<div class="row" style="pointer-events:none"><span class="t"><b>${esc(f.name)}</b><small>${bmBytes(f.size || 0)}</small></span></div>`).join('')}
    ${list.length > 6 ? `<p class="hint">and ${list.length - 6} more</p>` : ''}
    <button class="btn pri" id="shSend" style="margin-top:12px">Send to ${esc(BM.pc || 'your PC')}</button>`, (b) => {
    $('#shSend', b).onclick = () => { closeSheet(); sendPathsToPC(list); };
  });
}
// shivolabs://open/<part> (the Controls in Control Centre, on the Lock Screen and on the Action button): open that part
function openPart(url) {
  // shivolabs://join/<id>: a new device's QR, opened with the Camera app: add it (UNIFY-PLAN.md)
  const jn = pass.joinIdOf(url);
  if (jn) { setTimeout(() => addDevice(jn), 350); return true; }
  // shivolabs://code/<code>: an invite code as a QR (Owner page), on a phone that isn't joined yet
  const cd = /^shivolabs:\/\/code\/([A-Z0-9-]{10,14})\/?$/i.exec(url || '');
  if (cd) { setTimeout(() => { if (!$('#gate').hidden) { const k = cd[1].toUpperCase().replace(/[^A-Z0-9]/g, ''); $('#gateCode').value = `${k.slice(0, 5)}-${k.slice(5)}`; $('#gateGo').click(); } }, 350); return true; }
  // shivolabs://look/<code>: a camera look sent by someone (a QR code or a link): the camera opens and adds it (it checks the code itself)
  const lk = /^shivolabs:\/\/look\/([A-Za-z0-9_-]{8,6000})\/?$/.exec(url || '');
  if (lk) { setTimeout(() => { try { switchApp('camera'); switchApp.cam?.importLook(lk[1]); } catch {} }, 350); return true; }
  const m = /^shivolabs:\/\/open\/([a-z]+)/i.exec(url || ''); if (!m) return false;
  const to = m[1].toLowerCase();
  if (['home', 'ai', 'tasks', 'chat', 'beam', 'camera', 'tv'].includes(to)) setTimeout(() => { try { switchApp(to); } catch {} }, 350);
  return true;
}
{
  const A = plugin('App');
  A?.addListener?.('appUrlOpen', (e) => { if (!openPart(e?.url)) takeShared(e?.url); });
  A?.getLaunchUrl?.().then((r) => { if (!openPart(r?.url)) takeShared(r?.url); }).catch(() => {});
  // a notification that says where to go (e.g. "Your roll is ready" opens the camera)
  plugin('LocalNotifications')?.addListener?.('localNotificationActionPerformed', (e) => {
    const to = e?.notification?.extra?.open; if (to) setTimeout(() => { try { switchApp(to); } catch {} }, 350);
  });
}

// Your files: the cloud, folder by folder (folders first, then the newest), 40 at a time, with search across all of it
const CF = { folder: '', path: [], items: [], shown: 40, q: '', note: '', tried: false };
const cfSize = (b) => b >= 1073741824 ? (b / 1073741824).toFixed(1) + ' GB' : b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
const cfWhen = (t) => { const d = new Date(t), now = new Date(); return d.toDateString() === now.toDateString() ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString([], { day: 'numeric', month: 'short', ...(d.getFullYear() !== now.getFullYear() ? { year: 'numeric' } : {}) }); };
const CF_FOLDER = '<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>';
async function paintCloud() {
  const root = $('#beamBody'); if (!root || !$('#ccState', root)) return;
  const st = $('#ccState', root), join = $('#ccJoin', root), tools = $('#ccTools', root), add = $('#ccAddLbl', root);
  if (!cloud.creds()) {
    join.hidden = false; join.textContent = 'Connect'; tools.hidden = add.hidden = true; $('#ccList', root).innerHTML = ''; $('#ccMore', root).hidden = true;
    st.textContent = pass.passFor('files') ? 'Keep your files in Shivo Labs Cloud: here with the PC off, encrypted on your devices. Connect from anywhere; your PC asks to allow this phone.'
      : 'Keep your files in Shivo Labs Cloud: here with the PC off, encrypted on your devices. Connect on the same Wi-Fi as your PC.';
    if (cloud.waiting()) {
      // a PC has to allow this phone: checked every 5 seconds while this screen is open
      join.hidden = true; st.textContent = 'Waiting for your PC. On the PC, Shivo Labs asks to allow this phone: choose Allow.';
      clearTimeout(paintCloud.t);
      paintCloud.t = setTimeout(async () => {
        if (!$('#ccState')?.isConnected) return;
        const s = await cloud.checkWaiting().catch(() => 'waiting');
        if (s === 'joined') { haptic('success'); toast('Connected to Shivo Labs Cloud'); }
        if (s === 'refused') toast('Your PC did not allow this phone');
        paintCloud();
      }, 5000);
    }
    return;
  }
  join.hidden = true; tools.hidden = false; add.hidden = !!CF.q;
  cloud.share().catch(() => {});
  try {
    const [me, items] = await Promise.all([cloud.status(), CF.q ? cloud.search(CF.q) : cloud.list(CF.folder)]);
    CF.items = items;
    if (CF.note) st.textContent = CF.note;
    else st.innerHTML = `<span class="cz-bar${me.used > me.quota * 0.9 ? ' hi' : ''}"><i style="width:${Math.min(100, Math.round(100 * me.used / Math.max(1, me.quota)))}%"></i></span>${cfSize(me.used)} of ${cfSize(me.quota)} used${me.readOnly ? ' · read-only' : ''}`;
    paintList();
  } catch (e) { st.textContent = e.message || "Couldn't reach Shivo Labs Cloud"; if (!cloud.creds()) paintCloud(); }
}
function paintList() {
  const root = $('#beamBody'); if (!root || !$('#ccList', root)) return;
  const crumbs = [{ id: '', name: 'Your files' }, ...CF.path];
  $('#ccCrumbs', root).innerHTML = CF.q ? `<span>${CF.items.length} found</span>` : !CF.path.length ? '' : crumbs.map((c, i) => i === crumbs.length - 1 ? `<b>${esc(c.name)}</b>` : `<button data-go="${i}">${esc(c.name)}</button><span>›</span>`).join('');
  const show = CF.items.slice(0, CF.shown);
  const dots = '<svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg>';
  $('#ccList', root).innerHTML = show.length ? show.map((it, i) => `<div class="cf-item"><button class="cf-row" data-i="${i}">
      <span class="cf-ic${it.kind === 'folder' ? ' dir' : ''}"${cloud.isPicture(it) ? ' data-pic="1"' : ''}>${it.kind === 'folder' ? CF_FOLDER : esc((it.name.match(/\.([a-z0-9]{1,4})$/i)?.[1] || 'file').toUpperCase())}</span>
      <span class="cf-t"><b>${esc(it.name)}</b><small>${CF.q && it.where ? esc(it.where) + ' · ' : ''}${it.kind === 'folder' ? 'Folder' : cfSize(it.size) + ' · ' + cfWhen(it.mtime)}</small></span>${it.kind === 'folder' ? '<svg class="cf-go" viewBox="0 0 24 24"><path d="m9 6 6 6-6 6"/></svg>' : ''}</button>
      <button class="cf-more" data-m="${i}" aria-label="Actions for ${esc(it.name)}">${dots}</button></div>`).join('')
    : `<p class="hint">${CF.q ? 'Nothing with that name.' : CF.folder ? 'This folder is empty.' : 'Nothing here yet. Add files below, or send some from the PC.'}</p>`;
  $('#ccMore', root).hidden = CF.items.length <= CF.shown;
  $$('[data-go]', root).forEach((b) => (b.onclick = () => { const i = Number(b.dataset.go); CF.path = CF.path.slice(0, i); CF.folder = CF.path.at(-1)?.id || ''; CF.shown = 40; paintCloud(); }));
  $$('.cf-row', root).forEach((b) => {
    const it = show[Number(b.dataset.i)]; if (!it) return;
    let hold = 0, fired = false;   // press and hold opens the same menu as the ⋯ button
    b.addEventListener('pointerdown', () => { fired = false; clearTimeout(hold); hold = setTimeout(() => { fired = true; haptic('medium'); cfMenu(it); }, 480); });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach((ev) => b.addEventListener(ev, () => clearTimeout(hold)));
    b.onclick = () => {
      if (fired) { fired = false; return; }
      if (it.kind === 'folder') { CF.q = ''; $('#ccQ', root).value = ''; CF.path = [...CF.path, { id: it.id, name: it.name }]; CF.folder = it.id; CF.shown = 40; haptic('light'); return paintCloud(); }
      openCloudFile(it);
    };
  });
  $$('.cf-more', root).forEach((b) => (b.onclick = () => { const it = show[Number(b.dataset.m)]; if (it) { haptic('light'); cfMenu(it); } }));
  cfThumbs(root, show);
}
// picture thumbnails: only for what is on screen, one at a time pair, and not on mobile data (each one is the whole picture, decrypted here)
let cfObs = null, wifiAt = 0, wifiOk = true;
async function cfWifi() {
  if (Date.now() - wifiAt < 10000) return wifiOk;
  wifiAt = Date.now();
  try { const st = await window.Capacitor?.Plugins?.Network?.getStatus(); wifiOk = !st || st.connectionType !== 'cellular'; } catch { wifiOk = true; }
  return wifiOk;
}
function cfThumbs(root, show) {
  cfObs?.disconnect(); cfObs = null;
  const tiles = $$('.cf-ic[data-pic]', root); if (!tiles.length) return;
  const of = new Map(tiles.map((t) => [t, show[Number(t.closest('.cf-row').dataset.i)]]));
  cfObs = new IntersectionObserver((es) => es.forEach(async (e) => {
    if (!e.isIntersecting) return;
    const t = e.target; cfObs?.unobserve(t);
    const it = of.get(t); if (!it || !(await cfWifi())) return;
    const u = await cloud.thumb(it).catch(() => '');
    if (u && t.isConnected) { t.style.backgroundImage = `url(${u})`; t.classList.add('pic'); }
  }), { root: $('#beamBody'), rootMargin: '160px' });
  tiles.forEach((t) => cfObs.observe(t));
}

// ---- what can be done with a file or folder: open, rename, move, move to the Trash (kept 30 days, brought back from Cloud settings)
const CF_IC = {
  open: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  rename: '<path d="M12 20h8M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  move: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 13h6m0 0-2-2m2 2-2 2"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-12M9 7V4h6v3"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
};
const cfIc = (d) => `<span class="s-ic"><svg viewBox="0 0 24 24">${d}</svg></span>`;
function cfMenu(it) {
  const dir = it.kind === 'folder';
  openSheet(it.name, `<div class="sgroup">
    <button class="row" data-a="open">${cfIc(CF_IC.open)}<span class="t"><b>${dir ? 'Open folder' : 'Open'}</b></span></button>
    <button class="row" data-a="rename">${cfIc(CF_IC.rename)}<span class="t"><b>Rename</b></span></button>
    <button class="row" data-a="move">${cfIc(CF_IC.move)}<span class="t"><b>Move to…</b></span></button>
    <button class="row danger" data-a="trash">${cfIc(CF_IC.trash)}<span class="t"><b>Move to Trash</b><small>Kept for 30 days. You can bring it back.</small></span></button></div>`, (b) => {
    $$('[data-a]', b).forEach((x) => (x.onclick = () => {
      const a = x.dataset.a;
      if (a === 'open') return swapSheet(() => {
        if (!dir) return openCloudFile(it);
        CF.q = ''; const q = $('#ccQ'); if (q) q.value = ''; CF.path = [...CF.path, { id: it.id, name: it.name }]; CF.folder = it.id; CF.shown = 40; paintCloud();
      });
      if (a === 'rename') return swapSheet(() => cfRename(it));
      if (a === 'move') return swapSheet(() => cfMove(it));
      if (a === 'trash') return swapSheet(() => cfTrashAsk(it));
    }));
  });
}
function cfRename(it) {
  openSheet(it.kind === 'folder' ? 'Rename folder' : 'Rename file', `<input class="field" id="cfName" maxlength="200" value="${esc(it.name)}" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="done">
    <button class="btn pri" id="cfSave" style="margin-top:12px">Save</button>`, (b) => {
    const f = $('#cfName', b);
    setTimeout(() => { f.focus(); const dot = it.kind === 'file' ? it.name.lastIndexOf('.') : -1; f.setSelectionRange(0, dot > 0 ? dot : it.name.length); }, 480);   // the name is selected, not its ending
    const go = async () => {
      const n = f.value.trim();
      if (!n || n === it.name) return closeSheet();
      $('#cfSave', b).disabled = true;
      try { await cloud.rename(it, n); haptic('success'); closeSheet(); toast('Renamed'); paintCloud(); }
      catch (e) { $('#cfSave', b).disabled = false; toast(e.message || "Couldn't rename it"); }
    };
    $('#cfSave', b).onclick = go;
    f.onkeydown = (e) => { if (e.key === 'Enter') go(); };
  });
}
// pick a folder: tap one to look inside it, "Move here" puts it there (the item itself is never offered)
async function cfMove(it, at = { id: '', path: [] }) {
  openSheet('Move to…', '<p class="sh-p">Loading…</p>');
  let folders = [];
  try { folders = (await cloud.list(at.id)).filter((x) => x.kind === 'folder' && x.id !== it.id); }
  catch (e) { $('#shBody').innerHTML = `<p class="sh-p">${esc(e.message)}</p>`; return; }
  const where = ['Your files', ...at.path.map((x) => x.name)].join(' › '), same = at.id === (it.parent || '');
  $('#shBody').innerHTML = `${at.path.length ? `<button class="own-back" id="cfUp">${ic('chev')} Back</button>` : ''}
    <p class="sh-p cf-where">${esc(where)}</p>
    <div class="sgroup">${folders.map((f) => `<button class="row" data-f="${f.id}">${cfIc(CF_IC.folder)}<span class="t"><b>${esc(f.name)}</b></span>${ic('chev')}</button>`).join('') || '<p class="sh-p own-none">No folders here.</p>'}</div>
    <button class="btn pri" id="cfHere" style="margin-top:12px" ${same ? 'disabled' : ''}>${same ? 'It is already here' : 'Move here'}</button>`;
  const b = $('#shBody'), up = $('#cfUp', b);
  if (up) up.onclick = () => cfMove(it, { id: at.path.at(-2)?.id || '', path: at.path.slice(0, -1) });
  $$('[data-f]', b).forEach((x) => (x.onclick = () => { const f = folders.find((y) => y.id === x.dataset.f); cfMove(it, { id: f.id, path: [...at.path, { id: f.id, name: f.name }] }); }));
  $('#cfHere', b).onclick = async () => {
    $('#cfHere', b).disabled = true;
    try { await cloud.move(it, at.id); haptic('success'); closeSheet(); toast(`Moved to ${at.path.at(-1)?.name || 'Your files'}`); paintCloud(); }
    catch (e) { $('#cfHere', b).disabled = false; toast(e.message || "Couldn't move it"); }
  };
}
function cfTrashAsk(it) {
  openSheet('Move to Trash?', `<p class="sh-p">“${esc(it.name)}”${it.kind === 'folder' ? ' and what is inside it' : ''} goes to the Trash. Shivo Labs Cloud keeps it for 30 days, and you can bring it back from Cloud settings › Trash.</p>
    <div class="cf-two"><button class="btn" id="cfNo">Cancel</button><button class="btn pri warn" id="cfYes">Move to Trash</button></div>`, (b) => {
    $('#cfNo', b).onclick = closeSheet;
    $('#cfYes', b).onclick = async () => {
      $('#cfYes', b).disabled = true;
      try {
        await cloud.trash(it); haptic('success'); closeSheet(); paintCloud();
        toast('Moved to Trash', ['Undo', async () => { try { await cloud.restore(it); toast('Brought back'); paintCloud(); } catch (e) { toast(e.message || "Couldn't bring it back"); } }]);
      } catch (e) { $('#cfYes', b).disabled = false; toast(e.message || "Couldn't move it to the Trash"); }
    };
  });
}
async function trashSheet() {
  const back = ['Cloud settings', beamSettings];
  openSheet('Trash', '<p class="sh-p">Loading…</p>', null, back);
  let items = [];
  try { items = await cloud.trashed(); } catch (e) { $('#shBody').innerHTML = `<p class="sh-p">${esc(e.message)}</p>`; return; }
  $('#shBody').innerHTML = items.length ? `<p class="sh-p">Deleted files stay here for 30 days, then they are gone for good.</p><div class="sgroup">${items.map((it, i) => `<div class="row">${cfIc(it.kind === 'folder' ? CF_IC.folder : CF_IC.open)}<span class="t"><b>${esc(it.name)}</b><small>${it.kind === 'folder' ? 'Folder · ' : cfSize(it.size || 0) + ' · '}deleted ${cfWhen(it.deleted)}</small></span><span class="own-acts"><button data-r="${i}">Restore</button></span></div>`).join('')}</div>`
    : '<p class="sh-p own-none">The Trash is empty.</p>';
  $$('[data-r]', $('#shBody')).forEach((x) => (x.onclick = async () => {
    x.disabled = true;
    try { await cloud.restore(items[Number(x.dataset.r)]); haptic('success'); toast('Brought back'); paintCloud(); trashSheet(); }
    catch (e) { x.disabled = false; toast(e.message || "Couldn't bring it back"); }
  }));
}
// a file opens here: read and decrypted on the phone, then shown by iOS (Quick Look), where it can be shared or saved
const MIME = { pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', heic: 'image/heic', gif: 'image/gif', mov: 'video/quicktime', mp4: 'video/mp4', m4a: 'audio/mp4', mp3: 'audio/mpeg', txt: 'text/plain', md: 'text/markdown', csv: 'text/csv', doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ppt: 'application/vnd.ms-powerpoint', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', zip: 'application/zip' };
async function openCloudFile(it) {
  if (it.size > 300 * 1048576) return toast('Big file: open it in the Files app › Shivo Labs Cloud');
  const root = $('#beamBody'), st = root && $('#ccState', root);
  CF.note = `Opening ${it.name}…`; if (st) st.textContent = CF.note;
  try {
    const type = MIME[(it.name.split('.').pop() || '').toLowerCase()] || 'application/octet-stream';
    const blob = new Blob(await cloud.read(it), { type });
    const FS = plugin('Filesystem'), FO = plugin('FileOpener'), SH = plugin('Share');
    if (FS && (FO || SH)) {
      const data = await new Promise((ok, bad) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(',')[1] || ''); r.onerror = bad; r.readAsDataURL(blob); });
      const { uri } = await FS.writeFile({ path: 'cloud/' + it.name.replace(/[\/:]/g, '_'), data, directory: 'CACHE', recursive: true });
      if (FO) await FO.open({ filePath: uri, contentType: type }); else await SH.share({ title: it.name, files: [uri] });
    } else window.open(URL.createObjectURL(blob), '_blank');
  } catch (e) { if (!/cancel/i.test(e?.message || '')) toast(e.message || "Couldn't open it"); }
  CF.note = ''; paintCloud();
}
// files from the phone into the cloud: into a folder (its id), or into the top folder with that name ('Beam': the PC
// collects them when it is on)
async function addToCloud(files, into) {
  let parent = into;
  if (into === 'Beam') { parent = await cloud.folderNamed('Beam').catch(() => ''); }
  let ok = 0;
  for (const [i, f] of files.entries()) {
    BM.busy = `Adding ${i + 1} of ${files.length} to Shivo Labs Cloud: ${f.name}`; BM.since = Date.now(); paintBeam();
    try { await cloud.add(parent, f); ok++; } catch (e) { toast(`${f.name}: ${e.message || "couldn't be added"}`); }
  }
  BM.busy = ''; BM.since = 0; paintBeam();
  if (ok) { toast(into === 'Beam' ? `${ok} in Shivo Labs Cloud. They reach the PC when it is on.` : `${ok} added`); haptic('success'); }
  paintCloud();
}

async function renderBeam(check) {
  beam.setHost(S.st.beamHost);
  const root = $('#beamBody'); if (!root) return;
  if (!$('#bmTitle', root)) buildBeam(root);
  paintBeam();
  if (check && !BM.busy) {
    try { BM.pc = await beam.ping(); BM.items = await beam.waiting(); BM.err = ''; }
    catch (err) { BM.pc = ''; BM.items = []; BM.err = err.message; }
    paintBeam();
    // one setup for both: a phone the PC knows joins its Shivo Labs Cloud the first time they meet on the Wi-Fi
    if (BM.pc && !beam.viaRelay() && !cloud.creds() && !CF.tried) {
      CF.tried = true;
      cloud.join().then(() => { toast('Shivo Labs Cloud connected'); paintCloud(); }).catch(() => {});
    }
  }
}

// Saving what the PC sent. Runs by itself while the app is open (asked every few seconds, and at once
// when you come back to it), because iPhone doesn't let apps fetch in the background; and from the Save
// button. Resolves true when the PC answered.
let receiving = false;
const receiveText = (r) => r.done ? `Saved ${r.done} from your PC${r.photos ? ` (${r.photos} in Photos)` : ''}` : '';
async function receiveNow(manual) {
  if (receiving) { if (manual) toast('Already saving…'); return true; }
  if (!plugin('ShivoNative') && !manual) return true;
  receiving = true;
  let up = true;
  try {
    beam.setHost(S.st.beamHost);
    let items;
    const ms = manual ? 75000 : 8000;   // the first ask may sit waiting for Accept on the PC; background checks shouldn't
    try { items = await beam.waiting(ms); BM.err = ''; if (!BM.pc) BM.pc = await beam.ping(ms).catch(() => ''); }
    catch (err) { up = false; if (manual) { BM.pc = ''; BM.err = err.message; } throw err; }
    BM.items = items;
    if (!manual && !items.length) return true;
    let r;
    let batch = await beam.batchReady();
    if (batch) {   // newer builds: iOS downloads the batch (no stalls in the background); the native side moves the card
      r = await beam.receiveBatch(items, (i, t, name, size) => {
        BM.busy = `Saving ${Math.min(i + 1, t)} of ${t}: ${name}${bmBig(size)}`; BM.since = Date.now(); paintBeam();
      }, { from: BM.pc || 'your PC', look: live.look() });
      if (r.stuck) batch = false;   // an old batch iOS dropped blocks the download service: save the plain way instead
    }
    if (!batch) {
      r = await beam.receiveAll((i, t, name, size) => {
        BM.busy = `Saving ${i + 1} of ${t}: ${name}${bmBig(size)}`; BM.since = Date.now(); paintBeam();
        live.show('beam', { title: `From ${BM.pc || 'your PC'}`, subtitle: name, progress: t > 1 ? i / t : -1, count: `${i + 1} of ${t}`, detail: `${t - i - 1} left`, badge: 'arrow.down', icon: 'arrow.down' });
      }, items);
      live.done('beam', { title: r.done ? `${r.done} saved from ${BM.pc || 'your PC'}` : "Couldn't save", subtitle: receiveText(r) || (r.failed[0] || ''), failed: !!r.failed.length, done: !r.failed.length });
    }
    const msg = [receiveText(r), r.failed.length ? `${r.failed.length} couldn't be saved: ${r.failed[0]}` : ''].filter(Boolean).join('. ');
    if (msg || manual) toast(msg || 'Nothing waiting on the PC');
    if (r.done) haptic('success');
    BM.items = await beam.waiting().catch(() => BM.items);
  } catch (err) { if (manual) toast(err.message); }
  finally { receiving = false; BM.busy = ''; BM.since = 0; paintBeam(); }
  return up;
}
let bmDelay = 4000, bmTimer = 0;
async function bmPoll() {
  clearTimeout(bmTimer);
  let up = true;
  if (document.visibilityState === 'visible' && S.st.autoBeam !== false && S.online) up = await receiveNow(false).catch(() => false);
  // through the relay (away from home) every look costs the free Cloudflare plan a little: look every 20 s instead of 4
  bmDelay = up ? (beam.viaRelay() ? 20000 : 4000) : Math.min(bmDelay * 2, 60000);   // PC not there at all: ask less and less often
  bmTimer = setTimeout(bmPoll, bmDelay);
}
// Shivo Labs Cloud: each time the app comes back, the Files app is asked to look for changes (files added on the PC)
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') cloud.share(true).catch(() => {}); });
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible' || S.st.autoBeam === false) return;
  bmDelay = 4000; clearTimeout(bmTimer); bmTimer = setTimeout(bmPoll, 300);
});

/* ---------- settings ---------- */
function keySheet(which) {
  const P = which === 'claude'
    ? { name: 'Claude', ph: 'sk-ant-…', intro: "Paste your API key from the Claude Console (platform.claude.com). It is checked with Anthropic, then kept on this phone. It never goes anywhere else.", tip: 'Tip: make a separate key for your phone in its own Console workspace with a spend limit, so a lost phone can never cost more than that.' }
    : { name: 'Gemini', ph: 'Paste your key', intro: 'Paste the free key from Google AI Studio. It is checked with Google, then kept on this phone. It never goes anywhere else.', tip: 'On the free tier Google may use what you send to improve its products, so keep private work on Claude.' };
  openSheet(`${S.keys[which] ? 'Replace' : 'Add'} your ${P.name} key`, `<p class="sh-p">${P.intro}</p>
    <input class="field" id="gkey" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="${P.ph}">
    <div class="hint" id="gmsg">${P.tip}</div><button class="btn pri" id="gsave" disabled>Check &amp; save</button>`, (b) => {
    const inp = $('#gkey', b), btn = $('#gsave', b), m = $('#gmsg', b);
    inp.oninput = () => { btn.disabled = inp.value.trim().length < 12; m.className = 'hint'; };
    btn.onclick = async () => {
      const k = inp.value.trim(); btn.disabled = true; m.className = 'hint'; m.textContent = `Checking with ${which === 'claude' ? 'Anthropic' : 'Google'}…`;
      try {
        if (which === 'claude') { const r = await checkKey(k); if (!r.ok) throw new Error(r.error); }
        else { const models = await listGeminiModels(k); S.gm = { models, chain: defaultGeminiChain(models) }; store.set('sl.gm', S.gm); }
      } catch (e) { m.className = 'hint err'; m.textContent = e.message; btn.disabled = false; return; }
      S.keys[which] = k; saveKeys(); normalizeModel(); m.textContent = 'Saved on this phone.';
      await sleepMs(500); closeSheet(); paintChips(); updateSend(); toast(`${P.name} added`);
    };
    setTimeout(() => inp.focus({ preventScroll: true }), 450);
  });
}
function providerSheet(which) {
  if (!S.keys[which]) return keySheet(which);
  const name = which === 'claude' ? 'Claude' : 'Gemini';
  openSheet(name, `<p class="sh-p">${which === 'claude' ? "Your Claude key is saved on this phone. Tasks run on Anthropic's servers, so they keep going when your phone locks." : 'A free Gemini key is saved on this phone, with automatic switching between models when one runs out.'}</p>
    <button class="row" id="pvChange"><span class="t"><b>Replace the key</b></span>${ic('chev')}</button>
    <button class="row danger" id="pvRemove"><span class="t"><b>Remove the key from this phone</b></span></button>`, (b) => {
    $('#pvChange', b).onclick = () => subSheet(() => keySheet(which));
    $('#pvRemove', b).onclick = () => { S.keys[which] = ''; saveKeys(); normalizeModel(); paintChips(); updateSend(); closeSheet(); if (!hasClaude() && !hasGemini()) location.reload(); };
  });
}
$('#pcPill').onclick = () => {
  openSheet('Settings', `
    <div class="s-head"><div class="mkw">${mark('loop')}</div><div><b>Shivo Labs</b><small>Version <span id="verTxt">…</span></small></div></div>
    <div class="sh-sub">LABS AI</div><div class="sgroup">
    <button class="row" id="clRow"><span class="s-ic"><svg viewBox="0 0 24 24"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/></svg></span><span class="t"><b>Claude</b><small>${hasClaude() ? 'Key saved. Works anywhere.' : 'Not added yet'}</small></span>${ic('chev')}</button>
    <button class="row" id="gemRow"><span class="s-ic"><svg viewBox="0 0 24 24"><circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3M15 8l2 2"/></svg></span><span class="t"><b>Gemini</b><small>${hasGemini() ? 'Free key saved.' : 'Not added yet. Free from Google.'}</small></span>${ic('chev')}</button>
    <button class="row" id="phRow"><span class="s-ic"><svg viewBox="0 0 24 24"><rect x="7" y="3" width="10" height="18" rx="2.5"/><path d="M11 18h2"/></svg></span><span class="t"><b>Phone access</b><small>Calendar, reminders and what Labs AI may do here.</small></span>${ic('chev')}</button>
    <div class="row" style="pointer-events:none"><span class="s-ic"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 8v8M9.5 10a2.5 2 0 0 1 5 0c0 2.5-5 1.5-5 4a2.5 2 0 0 0 5 0"/></svg></span><span class="t"><b>This month</b><small>An estimate from token use. Gemini free-tier use costs nothing.</small></span><b>${money(monthSpend())}</b></div></div>
    <div class="sh-sub">LOOK</div><div class="sgroup">
    <div class="row wide"><span class="s-ic"><svg viewBox="0 0 24 24"><path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/></svg></span><span class="t"><b>Appearance</b><small>Auto follows the phone.</small></span><div class="seg" id="themeSeg">${['auto', 'light', 'dark'].map((t) => `<button data-t="${t}" class="${t === S.st.theme ? 'on' : ''}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div></div>
    <div class="row wide"><span class="s-ic"><svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="8" rx="4"/><path d="M7 12h6"/></svg></span><span class="t"><b>Live card</b><small>On the Lock Screen. Auto follows the phone.</small></span><div class="seg" id="liveSeg">${['auto', 'dark', 'light', 'glass'].map((t) => `<button data-l="${t}" class="${t === (S.st.liveLook || 'auto') ? 'on' : ''}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div></div>
</div>
    ${store.get('sl.shelf', '') ? `<div class="sh-sub">YOUR PC</div><div class="sgroup">
    <button class="row" id="pcRow"><span class="s-ic"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg></span><span class="t"><b>Shivo Labs on your PC</b><small id="pcTxt">Renews your apps over Wi-Fi.</small></span>${ic('chev')}</button></div>` : ''}
    ${pass.state() ? `<div class="sh-sub">DEVICES</div><div class="sgroup">
    <button class="row" id="addDevRow"><span class="s-ic"><svg viewBox="0 0 24 24"><path d="M4 7V5a1 1 0 0 1 1-1h2M17 4h2a1 1 0 0 1 1 1v2M20 17v2a1 1 0 0 1-1 1h-2M7 20H5a1 1 0 0 1-1-1v-2"/><path d="M9 12h6M12 9v6"/></svg></span><span class="t"><b>Add a device</b><small>A QR for a new phone, or scan a new device's QR.</small></span>${ic('chev')}</button>${pass.isOwner() ? `
    <button class="row" id="ownerRow"><span class="s-ic"><svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0M16 5.5a3 3 0 0 1 0 5.6M18 14.5a5 5 0 0 1 2.5 4.5"/></svg></span><span class="t"><b>Owner</b><small>Customers, invite codes and their devices.</small></span>${ic('chev')}</button>` : ''}</div>` : ''}
    <div class="sh-sub">ABOUT</div><div class="sgroup">
    <button class="row" id="updRow"><span class="s-ic"><svg viewBox="0 0 24 24"><path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/></svg></span><span class="t"><b>Check for updates</b><small id="updTxt">Updates also arrive by themselves when you open the app.</small></span>${ic('chev')}</button></div>
    <p class="foot">Your keys and chats stay on this phone.</p>`, (b) => {
    myVersion().then((v) => { const e = $('#verTxt', b); if (e) e.textContent = v; });
    $('#updRow', b).onclick = async () => {
      const t = $('#updTxt', b), say = (m) => { t.textContent = m; };
      const app = await updateApp({ say }).catch(() => null);   // Android: a newer app first, then the screens
      if (app) return say(app);
      say(await checkForUpdate({ force: true, isIdle: () => !S.run, onStep: say, onApplied: () => toast('Updating Shivo Labs…') }));
    };
    $$('#themeSeg button', b).forEach((x) => (x.onclick = () => { S.st.theme = x.dataset.t; saveSettings(); applyTheme(); $$('#themeSeg button', b).forEach((y) => y.classList.toggle('on', y === x)); }));
    $$('#liveSeg button', b).forEach((x) => (x.onclick = () => { S.st.liveLook = x.dataset.l; saveSettings(); live.setLook(x.dataset.l); $$('#liveSeg button', b).forEach((y) => y.classList.toggle('on', y === x)); }));
    $('#addDevRow', b) && ($('#addDevRow', b).onclick = () => subSheet(() => addDevice()));
    $('#ownerRow', b) && ($('#ownerRow', b).onclick = () => subSheet(() => ownerSheet()));
    $('#phRow', b).onclick = () => subSheet(phoneSheet);
    $('#clRow', b).onclick = () => subSheet(() => providerSheet('claude'));
    $('#gemRow', b).onclick = () => subSheet(() => providerSheet('gemini'));
    if ($('#pcRow', b)) {
      $('#pcRow', b).onclick = () => subSheet(pcSheet);
      pcState().then((st) => { const e = $('#pcTxt', b); if (e && st) e.textContent = st.line; }).catch(() => {});
    }
  });
};

/* ---------- Your PC: Shivo Labs' X Tools on the owner's PC, seen through the Cloudflare shelf (hub/api/pclink.mjs).
   Shows whether it is on and near this iPhone, and asks it to renew this iPhone's apps over Wi-Fi. */
const pcAgo = (ms) => { const m = Math.round(ms / 60000); return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : m < 1440 ? `${Math.round(m / 60)} h ago` : `${Math.round(m / 1440)} days ago`; };
async function pcState() {
  const r = await fetch(store.get('sl.shelf', '') + '/pcs', { cache: 'no-store' });
  if (!r.ok) throw new Error("Your PC can't be reached right now.");
  const j = await r.json(), mine = store.get('sl.myPhone', '');
  const pcs = (j.pcs || []).map((p) => ({ ...p, live: p.on && j.now - p.at < 20 * 60000 })).sort((a, b) => b.at - a.at);
  const pc = pcs.find((p) => p.phones.some((x) => x.udid === mine)) || pcs[0];
  const me = pc?.phones.find((x) => x.udid === mine);
  const ask = (j.asks || []).filter((a) => pc && a.pc === pc.id && a.udid === mine).pop();
  const line = !pc ? 'No PC yet. Open Shivo Labs on your PC.' : !pc.live ? `${pc.name} is off (seen ${pcAgo(j.now - pc.at)})` : me?.nearby ? `${pc.name} is on and near this iPhone` : `${pc.name} is on`;
  return { pc, pcs, me, ask, line, now: j.now };
}
// Follows this phone's own renew request anywhere in the app (sl.pcAsk). iOS won't close an app that is on screen to
// install its update, so when the PC says it is about to renew Shivo Labs, the app steps aside to the Home Screen
// (ShivoNative.goHome). When it opens again, it shows how the renew went.
let askTimer = 0;
function followAsk() {
  clearTimeout(askTimer);
  const mine = store.get('sl.pcAsk', null);
  if (!mine || Date.now() - mine.at > 20 * 60000) { store.set('sl.pcAsk', null); return; }
  askTimer = setTimeout(async () => {
    if (document.visibilityState !== 'visible') return followAsk();
    try {
      const a = (await (await fetch(store.get('sl.shelf', '') + '/pcs', { cache: 'no-store' })).json()).asks.find((x) => x.id === mine.id);
      if (a?.done) { store.set('sl.pcAsk', null); toast(a.ok ? a.status : `Your PC couldn't renew: ${a.status}`); return; }
      if (a && /^Closing Shivo Labs/.test(a.status) && !mine.closing) {
        store.set('sl.pcAsk', { ...mine, closing: true });
        toast('Updating Shivo Labs now. Open it again in a moment.');
        setTimeout(() => plugin('ShivoNative')?.goHome?.().catch(() => {}), 1800);
      }
    } catch {}
    followAsk();
  }, 3000);
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') followAsk(); });

function pcSheet() {
  openSheet('Your PC', `<p class="sh-p" id="pcMsg">Looking…</p><div class="sgroup" id="pcList"></div>
    <button class="btn pri wide" id="pcGo" hidden>Renew my apps now</button><p class="foot" id="pcFoot"></p>`, async (b) => {
    let timer = 0;
    const paint = async () => {
      let st; try { st = await pcState(); } catch (e) { $('#pcMsg', b).textContent = e.message; return; }
      if (!b.isConnected) return clearInterval(timer);
      const { pc, me, ask } = st;
      $('#pcMsg', b).textContent = st.line;
      // which of the PC's phones is this one (an app can't read its own iPhone's id): asked once
      $('#pcList', b).innerHTML = !pc ? '' : me ? `<div class="row"><span class="t"><b>${esc(me.name)}</b><small>${me.nearby ? 'Near your PC: renews right away.' : 'Not near your PC: it renews as soon as this iPhone is on the same Wi-Fi.'}</small></span></div>`
        : `<div class="row" style="pointer-events:none"><span class="t"><b>Which one is this iPhone?</b></span></div>` + pc.phones.map((x) => `<button class="row" data-u="${esc(x.udid)}"><span class="t"><b>${esc(x.name)}</b></span>${ic('chev')}</button>`).join('');
      $$('[data-u]', b).forEach((x) => (x.onclick = () => { store.set('sl.myPhone', x.dataset.u); paint(); }));
      const working = ask && !ask.done;
      $('#pcGo', b).hidden = !me;
      $('#pcGo', b).disabled = !!working;
      $('#pcGo', b).textContent = working ? 'Asked…' : 'Renew my apps now';
      $('#pcFoot', b).textContent = ask && !ask.done && /Shivo Labs/.test(ask.status) ? 'Shivo Labs is being renewed now: it closes in a moment. Open it again in a minute.'
        : ask ? `${ask.status}${ask.done ? '' : '…'} · ${pcAgo(st.now - (ask.updated || ask.at))}` : 'Shivo Labs closes for a moment while it is renewed. Open it again after.';
    };
    $('#pcGo', b).onclick = async () => {
      try {
        const st = await pcState();
        const r = await fetch(store.get('sl.shelf', '') + '/ask', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ pc: st.pc.id, udid: store.get('sl.myPhone', ''), action: 'renew' }) });
        if (!r.ok) throw new Error('Could not reach your PC.');
        const j = await r.json(); store.set('sl.pcAsk', { id: j.ask.id, at: Date.now() }); followAsk();
        toast('Asked your PC'); paint();
      } catch (e) { toast(e.message); }
    };
    await paint(); timer = setInterval(paint, 4000);
  });
}

boot().catch((e) => { console.error(e); $('#splash').classList.add('out'); document.body.insertAdjacentHTML('beforeend', `<pre style="position:fixed;inset:0;z-index:99;background:#fff;color:#900;padding:20px;white-space:pre-wrap">Shivo Labs could not start:\n${esc(e.stack || e.message || e)}</pre>`); });
globalThis.__shivo = { S, send };   // for tests
