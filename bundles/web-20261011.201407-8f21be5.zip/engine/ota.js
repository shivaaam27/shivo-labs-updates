// Over-the-air updates for the app's screens and logic (everything in www/).
// GitHub Actions publishes each new version to the public repo shivaaam27/shivo-labs-updates
// (never any keys). On opening, and when coming back to the app, we check latest.json; a newer
// version is downloaded in the background by the Capgo updater plugin and switched to straight
// away when nothing is running, or the next time the app is closed otherwise.
// If a new version fails to start, the plugin rolls back to the last one that worked.
import { plugin } from './native.js';

const FEED = 'https://raw.githubusercontent.com/shivaaam27/shivo-labs-updates/main/latest.json';
let busy = false, last = 0;

export async function myVersion() {
  try { const r = await fetch('version.json', { cache: 'no-store' }); if (r.ok) return (await r.json()).version || 'built-in'; } catch {}
  return 'built-in';
}

// Call once at startup: tells the plugin this version started fine (otherwise it rolls back).
export async function appReady() {
  const U = plugin('CapacitorUpdater'); if (!U) return;
  try { await U.notifyAppReady(); } catch {}
}

// isIdle(): true when switching now won't interrupt anything. onApplied(v): shown before a switch.
// Returns what happened, in plain words, so Settings can show it. force skips the 1-minute pause.
export async function checkForUpdate({ isIdle, onApplied, force, onStep } = {}) {
  const U = plugin('CapacitorUpdater');
  if (!U) return "This copy of the app can't update itself. Reinstall it once from the PC.";
  if (busy) return 'Already checking…';
  if (!force && Date.now() - last < 60000) return 'Checked a moment ago.';
  busy = true; last = Date.now();
  try {
    onStep?.('Checking…');
    const r = await fetch(FEED + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) return "Couldn't reach the update server (" + r.status + ').';
    const { version, url } = await r.json();
    if (!version || !url) return 'The update server sent nothing usable.';
    if (version === await myVersion()) return "You're up to date.";
    onStep?.('Downloading the new version…');
    const list = (await U.list().catch(() => ({ bundles: [] }))).bundles || [];
    const b = list.find((x) => x.version === version && x.status !== 'error') || await U.download({ url, version });
    if (isIdle?.()) { onApplied?.(version); await new Promise((s) => setTimeout(s, 900)); await U.set({ id: b.id }); return 'Restarting into the new version…'; }
    await U.next({ id: b.id }); return 'Downloaded. It switches over next time you open the app.';
  } catch (e) { return 'Update failed: ' + (e?.message || e); } finally { busy = false; }
}
