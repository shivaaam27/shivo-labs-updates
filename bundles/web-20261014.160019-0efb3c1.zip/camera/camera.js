// Shivo Labs Camera (design v4: minimal). One screen, two engines:
//   web    the camera as a web page gets it (older builds, Android): looks developed live on the graphics chip,
//          exposure and white balance applied to the picture, photos from the video stream (about 12 MP).
//   native the ShivoCamera add-on: the real camera through AVFoundation (focus, ISO, shutter, white balance,
//          lenses, RAW, 48 MP, video, stack, night, depth). Its picture is drawn behind this page.
// The screen asks the engine what it can do (caps) and only shows what works.
//
// Layout (iPhone-like, our own look): a few quiet icons on top; the frame; zoom inside the frame; under it the
// shutter row (depth · shutter · more) and the mode pill (photos · modes · flip). "More" opens one glass card
// (flash, timer, aspect, exposure, looks, depth, format, pro, tools); each opens its own small panel in the card.
// Swipe sideways on the picture to change the look. Tap to focus, drag up or down for brightness, hold to lock.
import { LOOKS, GROUPS as LOOK_GROUPS, lookById } from './looks.js';
import { makeRenderer } from './develop.js';
import { webEngine } from './engine-web.js';
import { nativeEngine } from './engine-native.js';
import * as Roll from './roll.js';
import { SECTIONS, START, norm, studioLook, valuesOf, linkOf, decodeLook, cleanName } from './studio.js';
import { show as liveShow, done as liveDone } from '../engine/live.js';

const ASPECTS = [['4:3', 4 / 3], ['3:2', 3 / 2], ['1:1', 1], ['16:9', 16 / 9], ['FULL', 0]];   // height : width, portrait
const MODES = ['VIDEO', 'PHOTO', 'STACK', 'NIGHT'];
const GUIDES = ['off', 'thirds', 'golden', 'cross', 'square'], GUIDE_NAME = { off: 'OFF', thirds: 'THIRDS', golden: 'GOLDEN RATIO', cross: 'CENTRE CROSS', square: 'SQUARE' };
const DEF = { look: 'natural', amount: 1, grain: 1, framed: true, glass: false, rev: true, roll: true, rollSize: 24, rollDelay: 'hour', ev: 0, k: 0, tint: 0, aspect: '4:3', flash: 'off', timer: 0, every: 0, shots: 20, guide: 'thirds', level: false,
  hist: false, peak: false, zebra: false, fc: false, mirror: true, loc: false, sound: true, stab: true, natural: true, stamp: true,
  facing: 'back', mm: 26, depth: false, ap: 2.8, fmt: 'HEIF', mp: 12, mode: 'PHOTO', iso: 0, ss: 0, mf: -1, k4: false, pro: 'iso' };
// outside the frame (native engine): black, no blur (the add-on's frosting turned all the way down).
const STYLE = { blur: 0, saturation: 0, brightness: -1, contrast: 1 };
const SV = {
  x: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
  flashOff: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/><path d="M4 4l16 16"/>', flashAuto: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/>',
  flashOn: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z" fill="currentColor"/>',
  timer: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9.5V13l2.5 1.5M9.5 2.5h5"/>',
  dots: '<g fill="currentColor" stroke="none"><circle cx="6" cy="6" r="1.7"/><circle cx="12" cy="6" r="1.7"/><circle cx="18" cy="6" r="1.7"/><circle cx="6" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18" cy="12" r="1.7"/><circle cx="6" cy="18" r="1.7"/><circle cx="12" cy="18" r="1.7"/><circle cx="18" cy="18" r="1.7"/></g>',
  moon: '<path d="M19.5 14.6A8 8 0 0 1 9.4 4.5a8 8 0 1 0 10.1 10.1z"/>',
  chev: '<path d="M14.5 5.5 8 12l6.5 6.5"/>',
  ev: '<path d="M12 4.5v7M8.5 8h7M7 18h10"/>',
  aspect: '<path d="M4 9V6.5A2.5 2.5 0 0 1 6.5 4H9M15 4h2.5A2.5 2.5 0 0 1 20 6.5V9M20 15v2.5a2.5 2.5 0 0 1-2.5 2.5H15M9 20H6.5A2.5 2.5 0 0 1 4 17.5V15"/>',
  pro: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
  flip: '<path d="M4 9.5A1.5 1.5 0 0 1 5.5 8h2l1.4-2h6.2l1.4 2h2A1.5 1.5 0 0 1 20 9.5v8a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5z"/><path d="M9 13.2a3.2 3.2 0 0 1 5.6-1.6M15 14a3.2 3.2 0 0 1-5.6 1.6"/><path d="M14.8 10v1.8H13M9.2 17.6v-1.8H11"/>',
  sun: '<circle cx="12" cy="12" r="3.4"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"/>',
  grid: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M9.3 4v16M14.7 4v16M4 9.3h16M4 14.7h16"/>', level: '<path d="M3 12h4M17 12h4M8.5 12.4l7-.8"/>',
  hist: '<path d="M4 19h16"/><path d="M5 19c2-1 2.5-9 4.5-9s2 6 3.5 6 1.8-11 3.5-11 1.5 10 3.5 14"/>', peak: '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>',
  zebra: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 12 12 4M4 18 18 4M9 20l11-11M15 20l5-5"/>', fc: '<circle cx="8" cy="9" r="2.4"/><circle cx="15.5" cy="8" r="2.4"/><circle cx="16" cy="15.5" r="2.4"/><circle cx="8.5" cy="16" r="2.4"/>',
  mirror: '<path d="M12 3v18"/><path d="M8 7 4 12l4 5zM16 7l4 5-4 5z"/>', loc: '<path d="M12 21s-6.5-6.2-6.5-11a6.5 6.5 0 0 1 13 0c0 4.8-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
  sound: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6"/>', stab: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M3 9V5a2 2 0 0 1 2-2h4M21 15v4a2 2 0 0 1-2 2h-4"/>',
  reset: '<path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v4h4"/>',
  film: '<rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 3v18M15 3v18M6 7h3M6 11h3M6 15h3M15 7h3M15 11h3M15 15h3"/>',
  roll: '<rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 3v18M15 3v18M6 7h3M6 11h3M6 15h3M15 7h3M15 11h3M15 15h3"/>',
  frame: '<rect x="3.5" y="3.5" width="17" height="17" rx="2.5"/><rect x="7" y="7" width="10" height="7.5" rx="1"/>',
  rev: '<path d="M4 9a8 8 0 0 1 14.5-3.5M20 4v4h-4"/><path d="M20 15a8 8 0 0 1-14.5 3.5M4 20v-4h4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', pen: '<path d="M14.5 5.5l4 4L8 20H4v-4z"/>', glass: '<rect x="3.5" y="6" width="17" height="12" rx="4"/><path d="M7.5 14.5l4-5M11.5 14.5l2.5-3"/>', looks: '<circle cx="9" cy="9.5" r="5"/><circle cx="15" cy="9.5" r="5"/><circle cx="12" cy="14.8" r="5"/>', framed: '<rect x="3" y="3" width="18" height="18" rx="3"/><rect x="6.5" y="6.5" width="11" height="11" rx="2.5"/>', tools: '<rect x="4" y="4" width="16" height="16" rx="4"/><path d="M12 4v16M4 12h16"/>',
  cam: '<path d="M4 8.5h3l1.8-2.5h6.4L17 8.5h3v10.5H4z"/><circle cx="12" cy="13.5" r="3.6"/>', share: '<path d="M12 3v12M7.5 7.5 12 3l4.5 4.5"/><path d="M5 12v8h14v-8"/>',
  photos: '<rect x="3.5" y="5" width="17" height="14" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="m20 16-4.5-4.5L7 19"/>',
  natural: '<path d="m12 2 9 5-9 5-9-5z"/><path d="m3 12 9 5 9-5M3 17l9 5 9-5"/>',
  stamp: '<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
};
// v6: the refined design (raised controls, card header, grouped tools, gallery strip). Shown in the preview
// (phone/docs/design/camera-v6.html) until approved; then it becomes the default.
const V6 = globalThis.SHIVO_CAM_V6 !== false;
// v6 icon set: one 24-point grid, one line weight, each drawn to sit optically centred (based on Lucide, ISC licence)
Object.assign(SV, {
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  flashOff: '<path d="M10.5 4.5 13 2v7h5l-2.4 3.2M12.8 17.4 11 22v-7H6l3.3-4.4"/><path d="m3 3 18 18"/>',
  flashAuto: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  flashOn: '<path d="M13 2 4 14h7l-1 8 9-12h-7z" fill="currentColor"/>',
  timer: '<path d="M10 2h4M12 14l3-3"/><circle cx="12" cy="14" r="8"/>',
  moon: '<path d="M20.5 14.2A8.5 8.5 0 1 1 9.8 3.5a6.6 6.6 0 0 0 10.7 10.7z"/>',
  chev: '<path d="m15 18-6-6 6-6"/>',
  ev: '<circle cx="12" cy="12" r="9"/><path d="M12 6.8v5M9.5 9.3h5M9 15.6h6"/>',
  aspect: '<path d="M4 9V6.5A2.5 2.5 0 0 1 6.5 4H9M15 4h2.5A2.5 2.5 0 0 1 20 6.5V9M20 15v2.5a2.5 2.5 0 0 1-2.5 2.5H15M9 20H6.5A2.5 2.5 0 0 1 4 17.5V15"/>',
  pro: '<path d="M21 6h-7M10 6H3M21 18h-9M8 18H3M21 12H16M12 12H3"/><circle cx="12" cy="6" r="2"/><circle cx="10" cy="18" r="2"/><circle cx="14" cy="12" r="2"/>',
  flip: '<path d="M11 19H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5"/><path d="M13 5h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-5"/><circle cx="12" cy="12" r="3"/><path d="m18 22-3-3 3-3M6 2l3 3-3 3"/>',
  grid: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/>',
  level: '<path d="M2 12h4M18 12h4"/><path d="M8.5 13.2 15.5 10.8"/><circle cx="12" cy="12" r="9" opacity=".35"/>',
  hist: '<path d="M3 3v18h18"/><path d="M7 17c1.5-1 2-7 4-7s2 4 3.5 4 2-9 4.5-9"/>',
  peak: '<circle cx="12" cy="12" r="3"/><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/>',
  zebra: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="M3 11 11 3M3 18 18 3M9 21 21 9M16 21l5-5"/>',
  fc: '<circle cx="13.5" cy="6.5" r=".9" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".9" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".9" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".9" fill="currentColor"/><path d="M12 2a10 10 0 0 0 0 20c.9 0 1.7-.8 1.7-1.7 0-.4-.2-.8-.4-1.1-.3-.3-.4-.7-.4-1.1 0-.9.8-1.7 1.7-1.7h2a5.6 5.6 0 0 0 5.4-5.4C22 6 17.5 2 12 2z"/>',
  mirror: '<path d="M12 3v18"/><path d="m16 7 4 5-4 5z"/><path d="m8 7-4 5 4 5z"/>',
  loc: '<path d="M20 10c0 5-8 12-8 12s-8-7-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
  sound: '<path d="M11 4.7a.7.7 0 0 0-1.2-.5L6.4 7.6A2 2 0 0 1 5 8.2H3a1 1 0 0 0-1 1v5.6a1 1 0 0 0 1 1h2a2 2 0 0 1 1.4.6l3.4 3.4a.7.7 0 0 0 1.2-.5z"/><path d="M16 9a5 5 0 0 1 0 6M19.4 18.4a9 9 0 0 0 0-12.8"/>',
  stab: '<rect x="7" y="7" width="10" height="10" rx="1.5"/><path d="M3 8V5a2 2 0 0 1 2-2h3M16 3h3a2 2 0 0 1 2 2v3M21 16v3a2 2 0 0 1-2 2h-3M8 21H5a2 2 0 0 1-2-2v-3"/>',
  reset: '<path d="M3 12a9 9 0 1 0 9-9 9.8 9.8 0 0 0-6.7 2.7L3 8"/><path d="M3 3v5h5"/>',
  framed: '<rect x="3" y="3" width="18" height="18" rx="3"/><rect x="7" y="7" width="10" height="10" rx="1.5"/>',
  rev: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
  film: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 7.5h4M3 12h18M3 16.5h4M17 7.5h4M17 16.5h4"/>',
  roll: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 7.5h4M3 12h18M3 16.5h4M17 7.5h4M17 16.5h4"/>',
  frame: '<rect x="3" y="3" width="18" height="18" rx="2"/><rect x="6.5" y="6.5" width="11" height="8.5" rx="1"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  pen: '<path d="M21.2 6.8a2.8 2.8 0 0 0-4-4L4 16v4h4z"/><path d="m15 5 4 4"/>',
  looks: '<circle cx="9" cy="9" r="6.5"/><circle cx="15" cy="15" r="6.5"/>',
  share: '<path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="m16 6-4-4-4 4M12 2v13"/>',
  photos: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
  cam: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3z"/><circle cx="12" cy="13" r="3"/>',
  // depth: an aperture; tools: a cog (not a sun)
  ap: '<circle cx="12" cy="12" r="10"/><path d="m14.3 8 5.7 9.9M9.7 8h11.5M7.4 12l5.7-9.9M9.7 16 4 6.1M14.3 16H2.8M16.6 12l-5.7 9.9"/>',
  gear: '<path d="M12.2 2h-.4a2 2 0 0 0-2 2v.2a2 2 0 0 1-1 1.7l-.4.3a2 2 0 0 1-2 0l-.2-.1a2 2 0 0 0-2.7.7l-.2.4a2 2 0 0 0 .7 2.7l.2.1a2 2 0 0 1 1 1.7v.5a2 2 0 0 1-1 1.7l-.2.1a2 2 0 0 0-.7 2.7l.2.4a2 2 0 0 0 2.7.7l.2-.1a2 2 0 0 1 2 0l.4.3a2 2 0 0 1 1 1.7v.2a2 2 0 0 0 2 2h.4a2 2 0 0 0 2-2v-.2a2 2 0 0 1 1-1.7l.4-.3a2 2 0 0 1 2 0l.2.1a2 2 0 0 0 2.7-.7l.2-.4a2 2 0 0 0-.7-2.7l-.2-.1a2 2 0 0 1-1-1.7v-.5a2 2 0 0 1 1-1.7l.2-.1a2 2 0 0 0 .7-2.7l-.2-.4a2 2 0 0 0-2.7-.7l-.2.1a2 2 0 0 1-2 0l-.4-.3a2 2 0 0 1-1-1.7V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
});
Object.assign(SV, {   // setups, composition guides, sharing
  setups: '<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>',
  mono: '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
  trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  guide: SV.grid, g_thirds: SV.grid,
  g_off: '<rect x="3" y="3" width="18" height="18" rx="2.5" opacity=".5"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18" opacity=".25"/>',
  g_golden: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="M3 9.9h18M3 14.1h18M9.9 3v18M14.1 3v18"/>',
  g_cross: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="M12 3v18M3 12h18"/>',
  g_square: '<rect x="2.5" y="6" width="19" height="12" rx="2" opacity=".45"/><rect x="6" y="6" width="12" height="12" rx="1.5"/>',
});
const ic = (n, w = 22) => `<svg viewBox="0 0 24 24" style="width:${w}px;height:${w}px">${SV[n]}</svg>`;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// dials: values to pick from, how to show them, and "automatic"
const ISO = [0, 32, 50, 64, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400];
const SS = [0, 1 / 8000, 1 / 4000, 1 / 2000, 1 / 1000, 1 / 500, 1 / 250, 1 / 125, 1 / 60, 1 / 30, 1 / 15, 1 / 8, 1 / 4, 1 / 2, 1];
const WB = [0, 2500, 2800, 3200, 3600, 4000, 4500, 5000, 5600, 6200, 7000, 8000, 9000, 10000];
const MF = [-1, 0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1];
const EVS = [-3, -2.7, -2.3, -2, -1.7, -1.3, -1, -0.7, -0.3, 0, 0.3, 0.7, 1, 1.3, 1.7, 2, 2.3, 2.7, 3];
const APS = [1.4, 1.8, 2, 2.8, 4, 5.6, 8, 11, 16];
const fmtSS = (s) => (!s ? 'AUTO' : s >= 1 ? s + '"' : '1/' + Math.round(1 / s));
const fmtEV = (v) => (Math.abs(v) < 0.05 ? '0.0' : (v > 0 ? '+' : '−') + Math.abs(v).toFixed(1));
const DIALS = {
  ev: { name: 'EV', list: EVS, get: (st) => st.ev, set: (st, v) => (st.ev = v), fmt: fmtEV, auto: (v) => !v },
  iso: { name: 'ISO', list: ISO, get: (st) => st.iso, set: (st, v) => (st.iso = v), fmt: (v) => (v ? String(v) : 'AUTO'), auto: (v) => !v, cap: 'iso', live: (m) => m.iso && String(Math.round(m.iso)) },
  ss: { name: 'SHUTTER', list: SS, get: (st) => st.ss, set: (st, v) => (st.ss = v), fmt: fmtSS, auto: (v) => !v, cap: 'shutter', live: (m) => m.ss && fmtSS(m.ss) },
  wb: { name: 'WB', list: WB, get: (st) => st.k, set: (st, v) => (st.k = v), fmt: (v) => (v ? v + 'K' : 'AUTO'), auto: (v) => !v, cap: 'wb', live: (m) => m.k && Math.round(m.k / 50) * 50 + 'K' },
  mf: { name: 'FOCUS', list: MF, get: (st) => st.mf, set: (st, v) => (st.mf = v), fmt: (v) => (v < 0 ? 'AF' : v === 0 ? 'NEAR' : v === 1 ? 'FAR' : Math.round(v * 100) + '%'), auto: (v) => v < 0, cap: 'focus' },
  ap: { name: 'DEPTH', list: [0, ...APS], get: (st) => (st.depth ? st.ap : 0), set: (st, v) => { st.depth = v > 0; if (v) st.ap = v; }, fmt: (v) => (v ? 'ƒ' + v : 'OFF'), auto: (v) => !v, cap: 'depth' },
};

// opts: { toast, haptic, plugin, openURL }
export function mountCamera(root, { toast, haptic = () => {}, plugin = () => null, openURL } = {}) {
  let st = { ...DEF }; try { const s0 = JSON.parse(localStorage.getItem('sl.cam2') || '{}'); if (s0.grid === false && !s0.guide) s0.guide = 'off'; Object.assign(st, s0); } catch {}   // (the old Grid switch became a choice of guides)
  if (!GUIDES.includes(st.guide)) st.guide = 'thirds';
  const save = () => { try { localStorage.setItem('sl.cam2', JSON.stringify(st)); } catch {} };
  if (localStorage.getItem('sl.cam.v') !== '4') { st.look = 'natural'; st.grain = 0; st.amount = 1; st.pro = 'iso'; try { localStorage.setItem('sl.cam.v', '4'); } catch {} save(); }
  if (typeof st.pro !== 'string') st.pro = 'iso';
  if (localStorage.getItem('sl.cam.v5') !== '1') { st.framed = true; st.glass = false; try { localStorage.setItem('sl.cam.v5', '1'); } catch {} save(); }
  st.glass = false;   // no blur anywhere (the add-on's glass stays off)
  // the film engine: the grain slider is the look's own grain (100 = as the look has it); it had been left at 0
  if (localStorage.getItem('sl.cam.film') !== '1') { st.grain = 1; try { localStorage.setItem('sl.cam.film', '1'); } catch {} save(); }
  Object.assign(st, { ev: 0, iso: 0, ss: 0, k: 0, tint: 0, mf: -1 });   // exposure, white balance and focus start automatic each time
  // Look Studio: your own looks, kept on this phone, listed after ours
  const MINE = 'sl.looks.mine';
  const mine = () => { try { return JSON.parse(localStorage.getItem(MINE) || '[]'); } catch { return []; } };
  function mergeMine() { for (let i = LOOKS.length - 1; i >= 0; i--) if (LOOKS[i].mine) LOOKS.splice(i, 1); LOOKS.push(...mine()); }
  mergeMine();
  const C = { R: Roll.load(), studio: null, on: false, busy: false, rec: false, recT: 0, shots: [], tilt: 0, turn: 0, motion: false, dial: '', panel: '', card: false,
    frame: { top: 0, h: 0, W: 0, H: 0 }, meter: {}, loc: null, locAt: 0, pd: null };

  root.innerHTML = `<div class="cm${V6 ? ' v6' : ''}" id="cm">
    <video id="cmVid" playsinline muted autoplay></video>
    <canvas id="cmGL"></canvas>
    <div class="cm-veil t" id="cmVt"></div><div class="cm-veil b" id="cmVb"></div>
    <div class="cm-frame" id="cmFrame"><canvas id="cmFG"></canvas><div class="cm-grid"><i></i><i></i><i></i><i></i><u></u></div><div class="cm-int" id="cmInt" hidden></div><div class="cm-level" id="cmLevel" hidden><b></b><i></i><b></b></div><b class="cm-date" id="cmDate" hidden></b></div>
    <div class="cm-mat" id="cmMat"></div>
    <div class="cm-touch" id="cmTouch"></div>
    <div class="cm-fbox" id="cmFbox"><div class="sq"></div><div class="sun">${ic('sun', 18)}</div><span class="ev" id="cmFev"></span></div>
    <div class="cm-chip" id="cmLock">AE/AF LOCK</div>
    <div class="cm-chip name" id="cmName"></div>
    <div class="cm-mods" id="cmMods"></div>
    <div class="cm-hist" id="cmHist" hidden><canvas width="216" height="92"></canvas></div>
    <div class="cm-count" id="cmCount"></div>

    <header class="cm-top">
      <button class="cm-ib" id="cmClose" aria-label="Close">${ic('x', 22)}</button>
      <div class="cm-mid" id="cmMid">
        <button class="cm-ib cm-rot" id="cmFlash" aria-label="Flash"></button>
        <button class="cm-ib cm-rot" id="cmMoon" aria-label="Night" hidden>${ic('moon', 21)}</button>
        <span class="cm-rec" id="cmRec"><i></i><b id="cmRecT">00:00</b></span>
      </div>
      <button class="cm-fmt" id="cmFmt" aria-label="Format"></button>
    </header>

    <div class="cm-zoom" id="cmZoom"></div>
    <div class="cm-zw" id="cmZW"><div class="tr" id="cmZWTr"></div><b class="nd"></b></div>
    <div class="cm-line" id="cmLine"></div>

    <div class="cm-row" id="cmRow">
      <button class="cm-rb cm-rot" id="cmDepth" aria-label="Depth"><span>ƒ</span></button>
      <button class="cm-shutter" id="cmShot" aria-label="Take photo"><b></b></button>
      <button class="cm-rb cm-rot" id="cmMore" aria-label="Camera controls">${ic('dots', 20)}</button>
    </div>
    <div class="cm-low" id="cmLow">
      <button class="cm-thumb cm-rot" id="cmThumb" aria-label="Photos taken"></button>
      <div class="cm-modes" id="cmModes"><div class="vp"><div class="tr" id="cmModesTr"></div></div></div>
      <button class="cm-rb cm-rot" id="cmFlip" aria-label="Front or back camera">${ic('flip', 24)}</button>
    </div>
    <div class="cm-scrim" id="cmScrim"></div>
    <div class="cm-card" id="cmCard"><div class="gr"></div><div class="in" id="cmCardIn"></div></div>
    <div class="cm-blink" id="cmBlink"></div>
    <div class="cm-ff" id="cmFF"></div>
    <div class="cm-viewer" id="cmViewer" hidden></div>
    <div class="cm-gate" id="cmGate" hidden></div>
  </div>`;
  const $ = (s) => root.querySelector(s), $$ = (s) => [...root.querySelectorAll(s)];
  const cm = $('#cm'), vid = $('#cmVid'), glc = $('#cmGL');

  /* ---------- the engine: native when this build has the camera add-on, else the web camera ---------- */
  let E = null;
  const ctx = { vid, glc, makeRenderer, view: () => view(), onFrame: () => {}, onHist: (h) => drawHist(h), plugin,
    onMeter: (m) => { C.meter = m || {}; if (C.panel === 'pro') C.pd?.paint(); paintTop(); }, onProgress: (p) => progress(p),
    onPress: () => { if (C.on && $('#cmViewer').hidden && $('#cmGate').hidden) $('#cmShot').click(); },
    onControl: (c) => controlled(c) };
  async function pickEngine() {
    if (E) return E;
    const N = await nativeEngine(ctx).catch(() => null);
    E = N || webEngine(ctx);
    cm.classList.toggle('native', E.kind === 'native');
    cm.classList.toggle('glass', E.kind === 'web' || !!E.caps?.()?.glass);
    return E;
  }
  const caps = () => E?.caps?.() || {};
  const modes = () => MODES.filter((m) => m === 'PHOTO' || (caps().modes || []).includes(m));
  const tools = () => caps().tools || [];
  // depth is switched off for now (it wasn't good enough yet); turn DEPTH_ON back on to offer it again
  const DEPTH_ON = false;
  const canDepth = () => DEPTH_ON && !!caps().depth && st.mode === 'PHOTO';
  const view = () => ({ look: C.studio || lookById(st.look), amount: C.studio ? 1 : st.amount, grain: C.studio ? 1 : st.grain, ev: st.ev, k: st.k || 5600, tint: st.tint,
    mirror: st.facing === 'front' && st.mirror, zoom: E?.digitalZoom?.(st.mm) || 1, zebra: st.zebra, false: st.fc, peak: st.peak });
  const toolsFor = () => ({ ...st, lookName: lookById(st.look).name, rev: !!st.rev && caps().reversible && !C.R.cur, natural: naturalOn() });
  // natural capture: RAW frames merged and developed by us; 12 MP photos (HEIF/JPEG), back camera, no flash or depth
  const naturalOn = () => !!st.natural && !!caps().natural && +st.mp <= 12;
  // the digicam date: on looks that offer it, when Date stamp is on ('YY MM DD, as the cameras printed it)
  const stampText = () => {
    if (!st.stamp || !caps().stamp || !(C.studio || lookById(st.look)).stamp) return '';
    const d = new Date(), two = (n) => String(n).padStart(2, '0');
    return `'${two(d.getFullYear() % 100)} ${two(d.getMonth() + 1)} ${two(d.getDate())}`;
  };
  function paintDate() {
    const el = $('#cmDate'), t = stampText(); el.hidden = !t || st.mode === 'VIDEO'; el.textContent = t;
    Object.assign(el.style, { left: '', top: '', right: '', bottom: '', transform: '' });
    if (el.hidden) return;
    if (!C.turn) {   // above the zoom buttons when they are over the bottom of the picture
      const f = C.frame, z = $('#cmZoom');
      if (!z.hidden && C.zt && f.h) el.style.bottom = Math.max(f.h * 0.045, f.top + f.h - C.zt + 10) + 'px';
      return;
    }
    // held sideways: in the corner that is bottom right for the person, standing upright for them
    const F = $('#cmFrame'), w = el.offsetWidth, h = el.offsetHeight, FW = F.clientWidth, FH = F.clientHeight;
    const cx = C.turn === 90 ? FW * 0.045 + h / 2 : FW - FW * 0.045 - h / 2, cy = C.turn === 90 ? FH - FH * 0.03 - w / 2 : FH * 0.03 + w / 2;
    Object.assign(el.style, { left: cx - w / 2 + 'px', top: cy - h / 2 + 'px', right: 'auto', bottom: 'auto', transform: `rotate(${C.turn}deg)` });
  }
  const canRoll = () => E?.kind === 'native' && !!caps().keep;
  const aspectNow = () => (st.mode === 'VIDEO' ? 16 / 9 : (ASPECTS.find((x) => x[0] === st.aspect) || ASPECTS[0])[1]);

  /* ---------- layout: controls keep their places; the frame (chosen aspect) sits under the top icons ---------- */
  function layout() {
    if (!cm.clientWidth) return;
    if (!C.card || !C.geo) {   // (the screen's own size, not a turned box: offsets, not on-screen rectangles)
      const W0 = cm.clientWidth, H0 = cm.clientHeight, tb = $('.cm-top');
      C.geo = { W: W0, H: H0, topBar: tb.offsetTop + tb.offsetHeight,
        ctl: H0 - parseFloat(getComputedStyle($('#cmRow')).bottom) - $('#cmRow').offsetHeight };   // where the shutter row starts
    }
    const { W, H, topBar, ctl } = C.geo;
    cm.style.setProperty('--cw', W + 'px'); cm.style.setProperty('--ch', H + 'px');   // the screen's size (landscape panels)
    const a = aspectNow(), rowH = $('#cmRow').offsetHeight || 84, shutR = ($('#cmShot').offsetWidth || 78) / 2;
    const fit = E?.kind === 'native' && !!caps().framew;   // builds that can draw the picture narrower than the screen
    let top, h, w = W;
    if (!a) { top = 0; h = H; }
    else {
      // every ratio starts under the top icons, with a black border above it. 4:3 fills the space above the shutter
      // and 1:1 sits in the middle of it; 3:2 runs on behind the shutter; 16:9 (photo and video) is too tall for
      // that, so it gets narrower (black at its sides) and ends just below the shutter, clear of the modes
      const topY = topBar + 10, above = ctl - 4 - topY, maxBottom = ctl + rowH / 2 + shutR + 10;
      const slotH = Math.min(Math.round(W * 4 / 3), above);
      h = Math.round(W * a); top = topY;
      if (h <= slotH) top = topY + Math.round((slotH - h) / 2);
      else if (topY + h > maxBottom && fit) { h = Math.round(maxBottom - topY); w = Math.round(h / a); }
    }
    const side = Math.max(0, Math.round((W - w) / 2));
    const nf = E?.kind === 'native' && !!caps().frame, fr = st.framed && !!a;
    cm.classList.toggle('nframe', nf); cm.classList.toggle('narrow', side > 0);
    C.frame = { top, h, W, H, inset: nf ? (side || (fr ? 12 : 0)) : 0, radius: fr ? 26 : side ? 4 : 0 };
    $('#cmVt').style.height = top + 'px'; $('#cmVb').style.height = Math.max(0, H - top - h) + 'px';
    for (const el of [$('#cmFrame'), $('#cmTouch')]) { el.style.top = top + 'px'; el.style.height = h + 'px'; el.style.left = el.style.right = side + 'px'; }
    const seen = Math.min(top + h, ctl - 6);              // the lowest point of the frame not under the controls
    const zt = seen - 14 - 40;
    $('#cmZoom').style.top = zt + 'px'; C.zt = zt;
    $('#cmLine').style.top = (zt - 34) + 'px';
    cm.style.setProperty('--fmid', (top + h / 2) + 'px');   // the middle of the picture (landscape notes)
    const m = $('#cmMat'); m.style.top = top + 'px'; m.style.height = Math.min(h, H - top) + 'px';
    $('#cmFrame').style.setProperty('--under', Math.max(0, top + h - ctl) + 'px');
    const chipTop = Math.max(top + 12, topBar + 6);
    $('#cmLock').style.top = chipTop + 'px'; $('#cmName').style.top = chipTop + 'px'; $('#cmHist').style.top = chipTop + 'px';
    const mods = $('#cmMods'); mods.style.top = chipTop + 'px'; mods.style.right = side + 12 + 'px';
    E?.layout?.(C.frame); glassFollow(); paintDate();
  }
  new ResizeObserver(() => layout()).observe(cm);

  // glass: the native engine blurs its picture under these shapes (the page can't blur what is drawn behind it)
  let lastGlass = '', gT = 0;
  function glassRects() {
    if (E?.kind !== 'native' || !caps().glass || !C.on || !st.glass) return;
    const R = cm.getBoundingClientRect(), out = [];
    $$('#cmCard, #cmRow .cm-rb, #cmLow .cm-rb, #cmThumb, #cmModes, #cmZoom').forEach((el) => {
      let o = 1;
      for (let q = el; q && q !== cm; q = q.parentElement) { const cs = getComputedStyle(q); if (cs.display === 'none' || cs.visibility === 'hidden') return; o *= +cs.opacity; }
      if (o < 0.08) return;
      const r = el.getBoundingClientRect(); if (r.bottom <= R.top + 1 || r.top >= R.bottom - 1 || r.width < 2) return;
      out.push({ x: r.left - R.left, y: r.top - R.top, w: r.width, h: r.height, r: Math.min(parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0, r.height / 2, r.width / 2) });
    });
    const key = JSON.stringify(out.map((g) => [g.x, g.y, g.w, g.h].map(Math.round)));
    if (key !== lastGlass) { lastGlass = key; E.setGlass?.(out); }
  }
  function glassFollow(ms = 650) {   // follows the shapes while they move (the card sliding, modes changing)
    if (E?.kind !== 'native' || !caps().glass || !st.glass) return;
    const end = performance.now() + ms; cancelAnimationFrame(gT);
    const f = () => { glassRects(); if (performance.now() < end) gT = requestAnimationFrame(f); }; f();
  }
  const line = (t) => { const e = $('#cmLine'); e.textContent = t; e.classList.add('show'); clearTimeout(line.t); line.t = setTimeout(() => e.classList.remove('show'), 1600); };
  const chip = (t) => { const e = $('#cmName'); e.textContent = t; e.classList.add('on'); clearTimeout(chip.t); chip.t = setTimeout(() => e.classList.remove('on'), 1400); };

  /* ---------- start and stop ---------- */
  async function start() {
    C.on = true; await pickEngine(); paintAll(); layout();
    if (!E.available()) return gate('none');
    if (E.kind === 'web' && !localStorage.getItem('sl.cam.asked')) return gate('ask');
    try {
      if (!modes().includes(st.mode)) st.mode = 'PHOTO';
      await E.start({ facing: st.facing, mm: st.mm, mp: st.mp, mode: st.mode, k4: st.k4 });
      if (!C.on) return E.stop();
      $('#cmGate').hidden = true;
      if (!modes().includes(st.mode)) st.mode = 'PHOTO';
      if (!lensList().some((l) => l.mm === st.mm)) st.mm = (lensList().find((l) => l.zoom === 1) || lensList()[0]).mm;
      E.setStyle?.(STYLE); if (!st.glass) E.setGlass?.([]);
      await applyAll(); paintAll(); layout(); syncControls();
      developDue(); tips();
    } catch (e) {
      console.error(e);
      if (e.name === 'NotAllowedError' || e.name === 'SecurityError' || /denied|not allowed/i.test(e.message || '')) gate('denied');
      else gate('error', e.message);
    }
  }
  async function stop() { C.on = false; stopInt(); if (C.rec) await recStop().catch(() => {}); E?.stop(); closeCard(); }
  // after a restart, the camera gets every setting again
  async function applyAll() {
    const c = caps();
    await E.setLens?.(st.mm);
    if (st.z && canZoom()) E.setZoom?.(st.z);
    if (c.iso || c.shutter || st.ev) await E.setExposure?.({ iso: st.iso, ss: st.ss, ev: st.ev });
    if (c.wb && E.kind === 'native') await E.setWB?.({ k: st.k, tint: st.tint });
    if (c.focus) await E.setFocus?.({ pos: st.mf });
    if (c.depth) E.setDepth?.({ on: canDepth() && st.depth, ap: st.ap });
    E.setTools?.(toolsFor()); E.setLook?.(view());
  }

  /* ---------- live helpers ---------- */
  function drawHist(H) {
    if (!st.hist || !H) return;
    const cv = $('#cmHist canvas'), x = cv.getContext('2d'), W = cv.width, Ht = cv.height, B = H[0].length;
    const max = Math.max(...H.map((a) => Math.max(...Array.from(a).slice(1, B - 1)))) || 1;
    x.clearRect(0, 0, W, Ht); x.globalCompositeOperation = 'lighter';
    [['rgba(232,84,70,.55)', 0], ['rgba(110,200,120,.55)', 1], ['rgba(80,130,235,.6)', 2]].forEach(([col, c]) => {
      x.beginPath(); x.moveTo(0, Ht);
      for (let i = 0; i < B; i++) x.lineTo(i / (B - 1) * W, Ht - Math.min(1, H[c][i] / max) * (Ht - 4));
      x.lineTo(W, Ht); x.closePath(); x.fillStyle = col; x.fill();
    });
    x.globalCompositeOperation = 'source-over'; x.beginPath();
    for (let i = 0; i < B; i++) x.lineTo(i / (B - 1) * W, Ht - Math.min(1, H[3][i] / max) * (Ht - 4));
    x.strokeStyle = 'rgba(255,255,255,.85)'; x.lineWidth = 2; x.stroke();
  }
  function progress(p) { $('#cmShot').style.setProperty('--p', clamp(p, 0, 1) + 'turn'); }

  /* ---------- top: close · flash, night, recording time · format ---------- */
  const flashIcon = () => ic(st.flash === 'on' ? 'flashOn' : st.flash === 'auto' ? 'flashAuto' : 'flashOff', 21);
  function fmtParts() {
    const c = caps();
    if (st.mode === 'VIDEO') return [st.k4 && c.k4 ? '4K' : 'HD', '30'];
    if (st.mode !== 'PHOTO') return [st.fmt === 'JPEG' ? 'JPEG' : (c.formats || []).includes('HEIF') ? 'HEIF' : 'JPEG', '12'];
    const raw = st.fmt.startsWith('RAW') && c.raw;
    const f = raw ? (st.fmt === 'RAW+' ? 'RAW+' : 'RAW') : (c.formats || ['JPEG']).includes(st.fmt) ? st.fmt : 'JPEG';
    return [f, String(raw ? rawMP() : E?.mpFor?.(st) || st.mp)];
  }
  const rawMP = () => caps().rawMP || 12;   // Bayer RAW is 12 MP on iPhones without ProRAW
  function paintTop() {
    const fl = $('#cmFlash'), video = st.mode === 'VIDEO';
    fl.hidden = video || st.mode !== 'PHOTO'; fl.innerHTML = flashIcon(); fl.classList.toggle('lit', st.flash === 'on');
    const moon = $('#cmMoon'), night = modes().includes('NIGHT');
    moon.hidden = !night || video || !(st.mode === 'NIGHT' || (st.mode === 'PHOTO' && C.meter.dark));
    moon.classList.toggle('lit', st.mode === 'NIGHT');
    const [f, s] = fmtParts(), roll = C.R.cur && st.mode !== 'VIDEO';
    $('#cmFmt').innerHTML = roll ? `${ic('film', 14)}<b>ROLL</b><small>${Roll.left(C.R.cur)}</small>` : `<b>${f}</b><small>${s}</small>`;
    $('#cmFmt').classList.toggle('raw', !roll && f.startsWith('RAW')); $('#cmFmt').classList.toggle('roll', !!roll);
  }
  $('#cmFlash').onclick = () => { const opts = caps().flash ? ['off', 'auto', 'on'] : ['off', 'on']; st.flash = opts[(opts.indexOf(st.flash) + 1) % opts.length]; haptic('selection'); save(); paintTop(); chip('FLASH ' + st.flash.toUpperCase()); };
  $('#cmMoon').onclick = () => setMode(st.mode === 'NIGHT' ? 'PHOTO' : 'NIGHT');
  $('#cmFmt').onclick = () => openCard(C.R.cur && st.mode !== 'VIDEO' ? 'roll' : 'format');
  $('#cmClose').onclick = () => root.dispatchEvent(new CustomEvent('camera-close', { bubbles: true }));

  /* ---------- zoom inside the frame: ultra-wide · main (tap again: 28, 35, 50) · 2x ---------- */
  const lensList = () => E?.lenses?.(st.facing) || [{ mm: 26, kind: 'optical', zoom: 1 }];
  const MAIN = [26, 28, 35, 50];
  function paintZoom() {
    const L = lensList(), has = (m) => L.some((l) => l.mm === m);
    const z = $('#cmZoom');
    if (st.facing === 'front' || L.length < 2) { z.innerHTML = ''; z.hidden = true; return; }
    z.hidden = false;
    const fam = MAIN.filter(has), inFam = fam.includes(st.mm);
    const btn = (mm, label, on) => `<button class="${on ? 'on' : ''}" data-mm="${mm}"><span>${on ? `${label}<small>mm</small>` : label}</span></button>`;
    if (st.z && canZoom()) {   // a free zoom: its focal length on the button it falls under
      const zz = st.z, w = zz < 1 ? 13 : zz < 2 || !has(52) ? 26 : 52, lbl = String(mmOf(zz));
      $('#cmZoom').innerHTML = (has(13) ? btn(13, w === 13 ? lbl : '13', w === 13) : '') + btn(26, w === 26 ? lbl : '26', w === 26) + (has(52) ? btn(52, w === 52 ? lbl : '52', w === 52) : '');
      $$('#cmZoom button').forEach((b) => (b.onclick = () => { if (tapOk()) setLens(+b.dataset.mm); }));
      return;
    }
    z.innerHTML = (has(13) ? btn(13, '13', st.mm === 13) : '') + btn(inFam ? st.mm : 26, inFam ? String(st.mm) : '26', inFam) + (has(52) ? btn(52, '52', st.mm === 52) : '');
    $$('#cmZoom button').forEach((b) => (b.onclick = () => {
      if (!tapOk()) return;
      let mm = +b.dataset.mm;
      if (b.classList.contains('on') && fam.includes(mm)) mm = fam[(fam.indexOf(mm) + 1) % fam.length];   // tap the main again: the next crop
      else if (b.classList.contains('on')) return;
      setLens(mm);
    }));
  }
  // the zoom wheel: drag along the zoom buttons and a ruler of every lens slides under the finger. Builds with free
  // zoom (caps.zoom) zoom smoothly the whole way, the lenses are gentle stops; older builds step from lens to lens.
  const ZW = 58, zw = $('#cmZW'), zwTr = $('#cmZWTr');
  let zwList = [], zwX = 0, zwT = 0, zwRaf = 0, zwStops = [], zwSide = 1;
  const canZoom = () => E?.kind === 'native' && !!caps().zoom && st.facing === 'back';
  const zOf = (mm) => (mm === 13 ? 0.5 : mm / 26);                       // a lens as a zoom (26 mm = 1)
  const zNow = () => (st.z && canZoom() ? st.z : zOf(st.mm));
  const mmOf = (z) => Math.round(z * 26);
  const zwPos = (i) => zw.clientWidth / 2 - (i * ZW + ZW / 2);
  // the ultra-wide and the main camera change over once the zoom is clearly past 1x (5% either way), so a finger
  // resting near 1x doesn't switch them back and forth
  const across = (z) => { if (zwSide < 1 && z >= 1.05) zwSide = 1; else if (zwSide >= 1 && z <= 0.95) zwSide = 0.5; return zwSide < 1 ? Math.min(z, 0.99) : Math.max(z, 1); };
  // where on the ruler is a zoom, and which zoom is a place on the ruler (between two marks: in proportion, by ratio)
  const zwAt = (x) => {
    const f = (zw.clientWidth / 2 - x - ZW / 2) / ZW, i = clamp(Math.floor(f), 0, zwList.length - 2), t = clamp(f - i, 0, 1);
    if (zwList.length < 2) return zOf(zwList[0] || 26);
    const a = zOf(zwList[i]), b = zOf(zwList[i + 1]);
    return a * Math.pow(b / a, t);
  };
  const zwXOf = (z) => { for (let i = 0; i < zwList.length - 1; i++) { const a = zOf(zwList[i]), b = zOf(zwList[i + 1]); if (z <= b || i === zwList.length - 2) return zwPos(i) - ZW * clamp(Math.log(z / a) / Math.log(b / a), 0, 1); } return zwPos(0); };
  function zwOpen() {
    zwList = lensList().map((l) => l.mm).sort((a, b) => a - b);
    if (canZoom()) for (const m of [78, 130, 260]) if (zOf(m) <= (caps().zoomMax || 10) && m > zwList[zwList.length - 1]) zwList.push(m);   // 3x, 5x, 10x (cut from the picture)
    zwTr.innerHTML = zwList.map((mm) => `<button data-mm="${mm}"><span>${mm}</span></button>`).join('');
    zwTr.style.width = zwList.length * ZW + 'px';
    // the ruler's stops: the lenses (they hold the ruler a little), and with free zoom every few points between them
    zwStops = zwList.map((_, i) => zwPos(i));
    if (canZoom()) for (let x = zwPos(zwList.length - 1); x <= zwPos(0); x += 2) if (zwStops.every((s) => Math.abs(s - x) > 9)) zwStops.push(x);
    zw.style.top = $('#cmZoom').style.top;
    zwSide = zNow(); clearTimeout(zwT); cm.classList.add('zw'); zwG.jump(canZoom() ? zwXOf(zNow()) : zwPos(Math.max(0, zwList.indexOf(st.mm))));
  }
  let zLastTap = 0;
  $('#cmZoom').addEventListener('click', () => {   // a double tap on the zoom buttons: back to 1x (26 mm)
    const t = Date.now(); if (t - zLastTap < 320) { zLastTap = 0; if (st.z || st.mm !== 26) { st.z = null; st.mm = 0; setLens(26); } } else zLastTap = t;
  });
  function zwClose(ms = 1100) { clearTimeout(zwT); zwT = setTimeout(() => cm.classList.remove('zw'), ms); }
  function zwShow(x) {   // the mark nearest the middle lights up; with free zoom the camera follows the finger
    const near = Math.round((zw.clientWidth / 2 - x - ZW / 2) / ZW);
    zwTr.querySelectorAll('button').forEach((b, j) => b.classList.toggle('on', j === near && Math.abs(zwPos(j) - x) < 10));
    if (!canZoom()) return;
    const z = zwAt(x), live = across(z);
    cancelAnimationFrame(zwRaf); zwRaf = requestAnimationFrame(() => E.setZoom?.(live));
  }
  const zwG = glide({ el: $('#cmZoom'), axis: (dx, dy) => [dx, dy], get: () => zwX,
    set: (x) => { zwX = x; zwTr.style.transform = `translateX(${x}px)`; zwShow(x); },
    stops: () => zwStops,
    onStart: () => { if (st.facing === 'front') return; zwOpen(); },
    onNear: (i) => {
      if (i >= zwList.length) return;   // (a stop between the lenses)
      const mm = zwList[i]; haptic('selection');
      if (!canZoom() && MAIN.includes(mm) && MAIN.includes(st.mm)) setLens(mm);   // crops of the main camera change at once (no camera switch)
    },
    onStop: (i) => {
      zwClose();
      if (!canZoom()) { const mm = zwList[i]; if (mm != null) setLens(mm); return; }
      setZoom(zwAt(zwStops[i]));
    } });
  // a free zoom (the wheel, pinching): the camera has it already; remember it and say it
  function setZoom(z, quiet) {
    z = clamp(z, lensList().some((l) => l.mm === 13) ? 0.5 : 1, caps().zoomMax || 10);
    const lens = lensList().find((l) => Math.abs(zOf(l.mm) - z) < 0.02);
    st.z = lens ? null : z; st.mm = lens ? lens.mm : z < 1 ? 13 : 26; save();
    E.setZoom?.(lens ? zOf(lens.mm) : z);
    paintZoom(); paintTop(); paintMods(); if (!quiet) chip(`${mmOf(z)} MM`);
  }
  async function setLens(mm) {
    if (mm === st.mm && !st.z) return;
    st.mm = mm; st.z = null; save(); haptic('selection'); paintZoom(); paintTop(); paintMods();
    const l = lensList().find((x) => x.mm === mm);
    chip(`${mm} MM${l?.kind === 'crop' ? ' · CROP' : ''}`);
    await E.setLens?.(mm); E.setLook?.(view());
  }

  /* ---------- back to normal: each setting's default, and easy ways back to it ----------
     tap the chosen option again · RESET (or AUTO) in a panel's header · hold a tile in the card · the small chips on
     the picture for what is changed (tap one to undo it) */
  const RESET = {
    flash: { is: () => st.flash === 'off', go: () => { st.flash = 'off'; }, say: 'FLASH OFF' },
    timer: { is: () => !st.timer && !st.every, go: () => { st.timer = 0; st.every = 0; }, say: 'TIMER OFF' },
    aspect: { is: () => st.aspect === '4:3', go: () => { st.aspect = '4:3'; cm.classList.remove('full'); layout(); }, say: 'ASPECT 4:3' },
    ev: { is: () => Math.abs(st.ev) < 0.05, go: () => { st.ev = 0; paintSun(); return E.setExposure?.({ iso: st.iso, ss: st.ss, ev: 0 }); }, say: 'EXPOSURE 0' },
    looks: { is: () => st.look === 'natural' && st.amount === 1 && st.grain === 1,
      go: () => { if (C.R.cur) { chip('LOOK SET FOR THIS ROLL'); return false; } st.amount = 1; st.grain = 1; setLook('natural'); }, say: 'NATURAL' },
    depth: { is: () => !st.depth, go: () => { st.depth = false; E.setDepth?.({ on: false, ap: st.ap }); paintRow(); syncControls(); }, say: 'DEPTH OFF' },
    pro: { is: () => !manual(), say: 'ALL AUTOMATIC',
      go: async () => { Object.assign(st, { iso: 0, ss: 0, k: 0, tint: 0, mf: -1 }); await E.setExposure?.({ iso: 0, ss: 0, ev: st.ev }); await E.setWB?.({ k: 0, tint: 0 }); await E.setFocus?.({ pos: -1 }); } },
    format: { is: () => (st.mode === 'VIDEO' ? !st.k4 : st.fmt === fmtDefault() && +st.mp === 12),
      go: async () => { if (st.mode === 'VIDEO') { st.k4 = false; await E.setMode?.({ mode: 'VIDEO', k4: false }); } else { st.fmt = fmtDefault(); st.mp = 12; E.setResolution?.(12); } },
      say: 'FORMAT BACK TO NORMAL' },
  };
  const fmtDefault = () => ((caps().formats || []).includes('HEIF') ? 'HEIF' : 'JPEG');
  async function resetTo(k) {
    const R = RESET[k]; if (!R || R.is()) return;
    if ((await R.go()) === false) return;
    save(); haptic('light'); chip(R.say); paintAll(); if (C.card) paintCard();
  }
  // the picture's chips: what is changed from normal, each undone with a tap
  function paintMods() {
    const list = [st.look !== 'natural' && !C.R.cur && !C.studio && ['look', lookById(st.look).name], Math.abs(st.ev) > 0.05 && ['ev', 'EV ' + fmtEV(st.ev)],
      manual() && ['pro', 'MANUAL'], st.facing === 'back' && (st.z || st.mm !== 26) && ['zoom', `${st.z && canZoom() ? mmOf(st.z) : st.mm} MM`]].filter(Boolean);
    const el = $('#cmMods'), key = JSON.stringify(list);
    if (el.dataset.k === key) return;
    el.dataset.k = key;
    el.innerHTML = list.map(([k, t]) => `<button data-k="${k}" aria-label="Back to normal: ${esc(t)}"><span>${esc(t.toUpperCase())}</span>${ic('x', 11)}</button>`).join('');
    el.querySelectorAll('button').forEach((b) => (b.onclick = () => {
      if (b.dataset.k === 'look') { setLook('natural'); paintMods(); }
      else if (b.dataset.k === 'zoom') { st.z = null; st.mm = 0; setLens(26); }   // back to 1x
      else resetTo(b.dataset.k);
    }));
  }

  /* ---------- glide: strips that follow the finger, glide on when let go, and settle on a stop ----------
     (the mode pill, the zoom wheel, the pro names, the dials). o: { el, axis(dx, dy) -> [along, across], get(), set(x),
     stops() -> positions, onStart(), onNear(i) while passing stops, onStop(i) once it has settled } */
  const held = (dx, dy) => (C.turn === -90 ? [-dy, dx] : C.turn === 90 ? [dy, -dx] : [dx, dy]);   // a drag as the person sees it
  function glide(o) {
    let id = null, x0 = 0, y0 = 0, start = 0, pos = 0, moved = false, samples = [], raf = 0, near = -1, gliding = false;
    const S = () => o.stops();
    const capture = (e) => { try { o.el.setPointerCapture(e.pointerId); } catch {} };
    const nearest = (x) => { const L = S(); let b = 0; L.forEach((v, i) => { if (Math.abs(v - x) < Math.abs(L[b] - x)) b = i; }); return b; };
    const ends = () => { const L = S(); return [Math.min(...L), Math.max(...L)]; };
    const rubber = (x) => { const [lo, hi] = ends(); return x < lo ? lo - (lo - x) * 0.3 : x > hi ? hi + (x - hi) * 0.3 : x; };
    const show = (x) => { pos = x; o.set(x); const i = nearest(x); if (i !== near) { near = i; o.onNear?.(i); } };
    function settle(v) {   // v: points per millisecond when let go; a spring carries on from there to the stop
      const L = S(); if (!L.length) return;
      const [lo, hi] = ends(), here = nearest(pos);
      let i = nearest(clamp(pos + v * (o.reach ?? 240), lo, hi));
      if (o.maxStep != null) i = clamp(i, here - o.maxStep, here + o.maxStep);   // a flick moves at most this many stops on
      const to = L[i];
      let x = pos, vel = v * 1000, last = performance.now();
      const k = 300, c = 2 * Math.sqrt(k) * 0.9;
      cancelAnimationFrame(raf); gliding = true;
      const step = (t) => {
        const dt = Math.min(0.032, Math.max(0.001, (t - last) / 1000)); last = t;
        vel += (-k * (x - to) - c * vel) * dt; x += vel * dt;
        if (Math.abs(x - to) < 0.4 && Math.abs(vel) < 12) { gliding = false; show(to); return o.onStop?.(i); }
        show(x); raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    }
    o.el.addEventListener('pointerdown', (e) => {
      if (id != null) return;
      const was = gliding; cancelAnimationFrame(raf); gliding = false;
      id = e.pointerId; x0 = e.clientX; y0 = e.clientY; start = pos = o.get(); moved = false; near = nearest(pos); samples = [[performance.now(), 0]];
      if (was) { moved = true; capture(e); o.onStart?.(); }   // caught while gliding: hold it there
    });
    o.el.addEventListener('pointermove', (e) => {
      if (e.pointerId !== id) return;
      const [d, across] = o.axis(e.clientX - x0, e.clientY - y0);
      if (!moved) {
        if (Math.abs(d) < 7) return;
        if (Math.abs(across) > Math.abs(d)) { id = null; return; }   // a swipe the other way: not ours
        moved = true; capture(e); o.onStart?.(); start = o.get() - d; samples = [[performance.now(), d]];
      }
      show(rubber(start + d));
      const t = performance.now(); samples.push([t, d]); while (samples.length > 2 && t - samples[0][0] > 90) samples.shift();
    });
    const up = (e) => {
      if (e.pointerId !== id) return; id = null;
      if (!moved) return;   // a tap: the button's own click does it
      C.swiped = Date.now();
      const [ta, da] = samples[0], [tb, db] = samples[samples.length - 1];
      settle(tb - ta > 20 ? clamp((db - da) / (tb - ta), -3, 3) : 0);   // (too short to tell a speed: just settle)
    };
    o.el.addEventListener('pointerup', up); o.el.addEventListener('pointercancel', up);
    return { jump(x) { cancelAnimationFrame(raf); gliding = false; pos = x; near = nearest(x); o.set(x); }, get moving() { return (id != null && moved) || gliding; } };
  }
  const tapOk = () => Date.now() - (C.swiped || 0) > 350;   // a button's click right after a drag is the drag's

  /* ---------- pro: one panel in the card; swipe the names, the dial below follows (sage = automatic) ---------- */
  const PRO = ['ev', 'iso', 'ss', 'wb', 'mf'];
  const proKeys = () => PRO.filter((k) => !DIALS[k].cap || caps()[DIALS[k].cap]);
  const manual = () => !!(st.iso || st.ss || st.k || st.mf >= 0);
  async function toAuto(k) {
    const D = DIALS[k];
    D.set(st, D.list[k === 'ev' ? EVS.indexOf(0) : 0]); if (k === 'wb') st.tint = 0;
    save(); C.pd?.paint(); await applyDial(k); chip(k === 'ev' ? 'EXPOSURE 0' : k === 'ap' ? 'DEPTH OFF' : 'AUTOMATIC'); haptic('light');
  }
  async function applyDial(k) {
    if (k === 'ev' || k === 'iso' || k === 'ss') await E.setExposure?.({ iso: st.iso, ss: st.ss, ev: st.ev });
    else if (k === 'wb') await E.setWB?.({ k: st.k, tint: st.tint });
    else if (k === 'mf') await E.setFocus?.({ pos: st.mf });
    else if (k === 'ap') { E.setDepth?.({ on: st.depth, ap: st.ap }); paintRow(); }
    E.setLook?.(view()); paintMods();
  }

  // a dial: a ruler that slides under a fixed needle; drag sideways. host gets the value and the ruler.
  const STEP = 16;
  function dial(host, k, after) {
    const D = DIALS[k], idx = () => Math.max(0, D.list.indexOf(D.get(st)));
    host.innerHTML = `<div class="cm-val" id="dv"></div><div class="cm-ruler"><div class="tk">${D.list.map((v, i) => `<i class="${i % 3 === 0 ? 'M' : ''}${D.auto(v) ? ' A' : ''}"></i>`).join('')}</div><b class="nd"></b></div>`;
    const tk = host.querySelector('.tk'), val = host.querySelector('.cm-val'), ru = host.querySelector('.cm-ruler');
    const xOf = (i) => -i * STEP - STEP / 2;
    let x = xOf(idx()), busy = false, again = false;
    tk.style.transition = 'none';
    const showVal = () => { const v = D.get(st); val.textContent = D.auto(v) && D.live?.(C.meter) ? D.live(C.meter) : D.fmt(v); val.classList.toggle('auto', D.auto(v)); };
    const apply = async () => {   // the camera gets every change, one at a time, ending on the last
      if (busy) { again = true; return; }
      busy = true; do { again = false; await applyDial(k).catch(() => {}); } while (again); busy = false;
    };
    const g = glide({ el: ru, axis: (dx, dy) => (V6 && C.turn ? held(dx, dy) : [dx, dy]), get: () => x, reach: 160,
      set: (v) => { x = v; tk.style.transform = `translateX(${v}px)`; }, stops: () => D.list.map((_, i) => xOf(i)),
      onNear: (i) => { if (D.list[i] === D.get(st)) return; D.set(st, D.list[i]); haptic('selection'); showVal(); after?.(); if (k === 'ev') paintSun(); apply(); },
      onStop: () => { save(); apply(); } });
    const paint = () => { if (!g.moving) g.jump(xOf(idx())); showVal(); };   // (the meter repaints twice a second: never mid-drag)
    paint();
    val.onclick = () => toAuto(k).then(paint);   // one tap on the value: back to automatic
    return { paint };
  }

  /* ---------- tap: focus; then drag up or down for brightness; hold: lock; swipe sideways: the next look ---------- */
  const fb = $('#cmFbox');
  const paintSun = () => { fb.style.setProperty('--sy', -st.ev * 14 + 'px'); $('#cmFev').textContent = st.ev ? fmtEV(st.ev) : ''; };
  (() => {
    const t = $('#cmTouch'); let hideT = 0, holdT = 0, ev0 = 0, y0 = null, x0 = 0, how = '', locked = false, active = false, held = false, nearZoom = false;
    const pts = new Map(); let pinch = null;
    const lensSteps = () => lensList().map((l) => l.mm).sort((a, b) => a - b);
    t.addEventListener('pointerdown', (e) => {
      pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pts.size === 2) {
        clearTimeout(holdT); how = 'pinch'; const [a, b] = [...pts.values()];
        const L = lensSteps(); pinch = { d0: Math.hypot(a[0] - b[0], a[1] - b[1]) || 1, i0: Math.max(0, L.indexOf(st.mm)), L, z0: zNow(), raf: 0 };
      }
    });
    t.addEventListener('pointermove', (e) => {
      if (!pts.has(e.pointerId)) return; pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (!pinch || pts.size < 2) return;
      const [a, b] = [...pts.values()], r = Math.hypot(a[0] - b[0], a[1] - b[1]) / pinch.d0;
      if (canZoom()) {   // the picture follows the fingers
        const z = clamp(pinch.z0 * r, pinch.L[0] === 13 ? 0.5 : 1, caps().zoomMax || 10), P = pinch;
        if (P.side == null) zwSide = P.z0;
        P.side = 1; const live = across(z);
        P.z = z; cancelAnimationFrame(P.raf); P.raf = requestAnimationFrame(() => E.setZoom?.(live));
        return;
      }
      const i = clamp(pinch.i0 + Math.round(Math.log(r) / Math.log(1.3)), 0, pinch.L.length - 1);
      if (pinch.L[i] !== st.mm) setLens(pinch.L[i]);
    });
    const lift = (e) => { pts.delete(e.pointerId); if (pts.size < 2 && pinch) { if (pinch.z) setZoom(pinch.z); pinch = null; how = 'pinch'; } };
    t.addEventListener('pointerup', lift); t.addEventListener('pointercancel', lift);
    const show = () => { fb.classList.add('in'); clearTimeout(hideT); hideT = setTimeout(() => { if (!locked) { fb.classList.remove('in'); active = false; } }, 3200); };
    const place = (x, y) => {
      fb.style.left = x + 'px'; fb.style.top = y + 'px'; fb.classList.remove('in'); void fb.offsetWidth;
      const f = C.frame; E.focusAt?.({ x: x / f.W, y: y / f.H }); haptic('light'); active = true; paintSun(); show();
    };
    const at = (e) => { const r = cm.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    t.addEventListener('pointerdown', (e) => {
      if (!E?.running?.()) return;
      y0 = e.clientY; x0 = e.clientX; ev0 = st.ev; how = ''; held = false; t.setPointerCapture(e.pointerId);
      const [x, y] = at(e);
      // started close to the zoom buttons: a zoom that missed them, never a change of look
      nearZoom = !$('#cmZoom').hidden && !!C.zt && Math.abs(y - (C.zt + 23)) < 64;
      holdT = setTimeout(() => {
        held = true; place(x, y); locked = true; $('#cmLock').classList.add('on'); clearTimeout(hideT); E.lock?.(true); haptic('medium');
      }, 600);
    });
    // a drag as the person sees it (sideways phone: their "up" is the screen's side)
    const asHeld = (dx, dy) => (C.turn === -90 ? [-dy, dx] : C.turn === 90 ? [dy, -dx] : [dx, dy]);
    t.addEventListener('pointermove', (e) => {
      if (y0 == null) return;
      const [dx, dy] = asHeld(e.clientX - x0, e.clientY - y0);
      if (how === 'pinch') return;
      if (!how && Math.hypot(dx, dy) > 9) { clearTimeout(holdT); how = Math.abs(dx) > Math.abs(dy) * 1.8 ? (nearZoom ? 'none' : 'look') : Math.abs(dy) > Math.abs(dx) && active ? 'ev' : 'none'; }
      if (how !== 'ev') return;
      const v = Math.round(clamp(ev0 - dy / 40, -3, 3) * 10) / 10;
      if (v !== st.ev) { st.ev = v; paintSun(); C.pd?.paint(); E.setExposure?.({ iso: st.iso, ss: st.ss, ev: st.ev }); E.setLook?.(view()); paintMods(); }
      show();
    });
    const end = (e) => {
      clearTimeout(holdT); if (y0 == null) return;
      const [dx] = asHeld(e.clientX - x0, e.clientY - y0);
      if (how === 'pinch') { if (!pts.size) y0 = null; return; }
      if (!how && !held) {
        if (locked) { locked = false; $('#cmLock').classList.remove('on'); E.lock?.(false); }
        const [x, y] = at(e); place(x, y);
      } else if (how === 'look' && Math.abs(dx) > 70 && tapOk()) nextLook(dx < 0 ? 1 : -1);   // a clear sideways swipe only
      else if (how === 'ev') save();
      y0 = null;
    };
    t.addEventListener('pointerup', end); t.addEventListener('pointercancel', () => { clearTimeout(holdT); y0 = null; });
  })();
  function nextLook(d) { const i = LOOKS.findIndex((l) => l.id === st.look); setLook(LOOKS[(i + d + LOOKS.length) % LOOKS.length].id); }
  // the Camera Control button (iPhone 16 and later) offers the looks and depth; it tells us what was picked
  // Only when what it offers changes (the list of looks, depth on or off): moving the button's own picker from here
  // crashed some builds, and the button keeps its own place anyway.
  let sentControls = '';
  function syncControls() {
    const o = { looks: LOOKS.map((l) => l.name), look: Math.max(0, LOOKS.findIndex((l) => l.id === st.look)), depth: canDepth() && st.depth, ap: st.ap };
    const key = o.looks.join('|') + '#' + o.depth;
    if (key === sentControls || !caps().controls2) return;   // controls2: builds where the button's picker is changed safely
    sentControls = key; E?.setControls?.(o);
  }
  function controlled(c) {
    if (typeof c?.look === 'number' && LOOKS[c.look]) setLook(LOOKS[c.look].id, true);
    if (typeof c?.ap === 'number' && canDepth()) { st.ap = Math.round(c.ap * 10) / 10; st.depth = true; save(); E.setDepth?.({ on: true, ap: st.ap }); paintRow(); if (C.panel === 'depth') paintCard(); }
  }
  function setLook(id, fromButton) {
    if (C.R.cur && id !== C.R.cur.look) { chip('LOOK SET FOR THIS ROLL'); return; }
    if (st.look !== id) { haptic('selection'); chip(lookById(id).name.toUpperCase()); }
    st.look = id; save(); paintDate(); paintMods(); E?.setLook?.(view()); E?.setTools?.(toolsFor()); if (!fromButton) syncControls();
    if (C.panel === 'looks') paintCard();
  }

  /* ---------- modes: a glass pill, the chosen one in the middle; swipe it or tap one ---------- */
  function paintModes() {
    const M = modes(), el = $('#cmModes'), tr = $('#cmModesTr');
    el.hidden = M.length < 2;
    tr.innerHTML = M.map((m) => `<button data-m="${m}" class="${m === st.mode ? 'on' : ''}"><span>${m}</span></button>`).join('');
    $$('#cmModesTr button').forEach((b) => (b.onclick = () => { if (tapOk()) setMode(b.dataset.m); }));
    requestAnimationFrame(() => { const i = M.indexOf(st.mode); if (i >= 0) { mx = modeX(i); tr.style.transform = `translateX(${mx}px)`; } });
  }
  let mx = 0;
  const modeX = (i) => { const el = $('#cmModes'), b = $('#cmModesTr').children[i]; return b ? el.clientWidth / 2 - (b.offsetLeft + b.offsetWidth / 2) : 0; };
  glide({ el: $('#cmModes'), axis: (dx, dy) => [dx, dy], get: () => mx, stops: () => modes().map((_, i) => modeX(i)), reach: 140, maxStep: 1,
    set: (x) => { mx = x; $('#cmModesTr').style.transform = `translateX(${x}px)`; },
    onStart: () => { if (C.rec || C.busy) return; $('#cmModesTr').style.transition = 'none'; },
    onNear: (i) => { $$('#cmModesTr button').forEach((b, j) => b.classList.toggle('on', j === i)); haptic('selection'); },
    onStop: (i) => {
      $('#cmModesTr').style.transition = '';
      const m = modes()[i];
      if (m && m !== st.mode && !C.rec && !C.busy) setMode(m); else paintModes();
    } });
  (() => {   // the lower area: swipe up for the card
    const low = [$('#cmLow'), $('#cmRow')]; let p0 = null;
    low.forEach((el) => {
      el.addEventListener('pointerdown', (e) => { p0 = [e.clientX, e.clientY]; });
      el.addEventListener('pointerup', (e) => {
        if (!p0) return; const dx = e.clientX - p0[0], dy = e.clientY - p0[1]; p0 = null;
        if (dy < -40 && Math.abs(dy) > Math.abs(dx) * 1.3 && !C.card && !C.rec) { C.swiped = Date.now(); openCard(''); }
      });
    });
  })();
  async function setMode(m) {
    if (m === st.mode || C.rec || C.busy) return;
    const was = st.mode; st.mode = m; save(); haptic('selection');
    chip({ VIDEO: 'VIDEO', PHOTO: 'PHOTO', STACK: 'STACK · FRAMES MERGED', NIGHT: 'NIGHT · HOLD STILL' }[m]);
    if (m === 'VIDEO' || was === 'VIDEO') await E.setMode?.({ mode: m, k4: st.k4 });
    if (caps().depth) E.setDepth?.({ on: DEPTH_ON && st.depth && m === 'PHOTO', ap: st.ap });
    closeCard(); paintAll(); layout(); syncControls();
  }

  /* ---------- the shutter row and the lower row ---------- */
  function paintRow() {
    const d = $('#cmDepth'), ok = canDepth();
    d.hidden = !ok; d.classList.toggle('lit', ok && st.depth);
    d.innerHTML = V6 ? `${ic('ap', 22)}${ok && st.depth ? `<small>ƒ${st.ap}</small>` : ''}` : ok && st.depth ? `<span>ƒ</span><small>${st.ap}</small>` : '<span>ƒ</span>';
    d.classList.toggle('num', ok && st.depth);
    const s = $('#cmShot');
    s.classList.toggle('vid', st.mode === 'VIDEO'); s.classList.toggle('stack', st.mode === 'STACK' || st.mode === 'NIGHT');
    s.classList.toggle('raw', st.mode === 'PHOTO' && fmtParts()[0].startsWith('RAW'));
    s.setAttribute('aria-label', C.int ? 'Stop the interval' : st.mode === 'VIDEO' ? (C.rec ? 'Stop recording' : 'Record video') : st.every ? 'Start the interval' : 'Take photo');
    $('#cmMore').classList.toggle('on', C.card);
  }
  $('#cmDepth').onclick = () => {
    st.depth = !st.depth; if (st.depth && !st.ap) st.ap = 2.8; save(); haptic('selection');
    E.setDepth?.({ on: st.depth, ap: st.ap }); chip(st.depth ? 'DEPTH ƒ' + st.ap : 'DEPTH OFF'); paintRow(); syncControls();
    if (C.panel === 'depth') paintCard();
  };
  $('#cmMore').onclick = () => (C.card ? closeCard() : openCard(''));

  /* ---------- the card: everything else, in one glass sheet ---------- */
  function items() {
    const c = caps(), M = st.mode, photo = M === 'PHOTO';
    const [f, s] = fmtParts();
    return [
      photo && { k: 'flash', n: 'FLASH', i: flashIcon(), on: st.flash !== 'off' },
      M !== 'VIDEO' && { k: 'timer', n: 'TIMER', i: st.every ? `<b class="tx two">${st.every}s<small>${st.shots ? '×' + st.shots : '∞'}</small></b>` : st.timer ? `<b class="tx">${st.timer}s</b>` : ic('timer', 22), on: !!st.timer || !!st.every },
      M !== 'VIDEO' && { k: 'aspect', n: 'ASPECT', i: V6 ? `<b class="asp2">${st.aspect}</b>` : `<span class="asp">${ic('aspect', 30)}<b>${st.aspect === 'FULL' ? 'FULL' : st.aspect}</b></span>` },
      { k: 'ev', n: 'EXPOSURE', i: Math.abs(st.ev) > 0.05 ? `<b class="tx">${fmtEV(st.ev)}</b>` : ic('ev', 22), on: Math.abs(st.ev) > 0.05 },
      { k: 'looks', n: 'LOOKS', i: ic('looks', 24), on: st.look !== 'natural' },
      { k: 'setups', n: 'SETUPS', i: ic('setups', 22), on: !!activeSetup() && activeSetup().id !== 'b-everyday' },
      canRoll() && st.roll !== false && M !== 'VIDEO' && { k: 'roll', n: 'FILM ROLL', i: C.R.cur ? `<b class="tx">${Roll.left(C.R.cur)}</b>` : ic('film', 22), on: !!C.R.cur },
      canDepth() && { k: 'depth', n: 'DEPTH', i: V6 ? (st.depth ? `<b class="tx">ƒ${st.ap}</b>` : ic('ap', 22)) : `<b class="tx f">ƒ${st.depth ? st.ap : ''}</b>`, on: st.depth },
      { k: 'format', n: M === 'VIDEO' ? 'QUALITY' : 'FORMAT', i: `<b class="tx two">${f}<small>${s}</small></b>` },
      proKeys().length > 1 && { k: 'pro', n: 'PRO', i: ic('pro', 22), on: manual() },
      { k: 'tools', n: 'TOOLS', i: ic('tools', 22) },
    ].filter(Boolean).slice(0, 12);
  }
  const TITLE = { flash: 'FLASH', timer: 'TIMER', aspect: 'ASPECT', ev: 'EXPOSURE', looks: 'LOOKS', depth: 'DEPTH', format: 'FORMAT', tools: 'TOOLS', pro: 'PRO', roll: 'FILM ROLL', studio: 'LOOK STUDIO', setups: 'SETUPS', setup: 'EDIT SETUP', share: 'SHARE LOOK' };
  function paintCard() {
    const inEl = $('#cmCardIn'), p = C.panel;
    if (!p) {
      const tile = (x) => `<button data-k="${x.k}" class="${x.on ? 'on' : ''}"><span class="o">${x.i}</span><b>${x.n}</b></button>`;
      if (V6) {
        const [f, s2] = fmtParts();
        inEl.innerHTML = `<div class="cm-hd"><button class="cm-hdb" data-k="format"><b>${f}</b><small>${s2}</small></button><span class="cm-hdt">${{ VIDEO: 'VIDEO', STACK: 'STACK', NIGHT: 'NIGHT' }[st.mode] || 'PHOTO'}</span><button class="cm-hdb ic" data-k="tools" aria-label="Tools">${ic('gear', 19)}</button></div>
          <div class="cm-grid9 v6${items().length > 10 ? ' five' : ''}">${items().filter((x) => x.k !== 'format' && x.k !== 'tools').map(tile).join('')}</div>`;
      } else inEl.innerHTML = `<div class="cm-grid9">${items().map(tile).join('')}</div>`;
      $$('#cmCardIn .cm-grid9 button, #cmCardIn .cm-hdb').forEach((b) => {
        let held = 0, t = 0;
        b.onpointerdown = () => { held = 0; clearTimeout(t); if (RESET[b.dataset.k] && !RESET[b.dataset.k].is()) t = setTimeout(() => { held = 1; resetTo(b.dataset.k); }, 550); };
        b.onpointerup = b.onpointerleave = b.onpointercancel = () => clearTimeout(t);
        b.onclick = () => { if (held) return; haptic('selection'); C.panel = b.dataset.k; paintCard(); };
      });
      return sizeCard();
    }
    const side = RESET[p] ? `<button class="cm-auto${RESET[p].is() ? ' off' : ''}" id="cmAuto">${p === 'ev' || p === 'pro' ? 'AUTO' : 'RESET'}</button>` : '<span></span>';
    const head = `<div class="cm-ph"><button class="cm-back" id="cmBack" aria-label="Back">${ic('chev', 20)}</button><h4>${p === 'format' && st.mode === 'VIDEO' ? 'QUALITY' : TITLE[p]}</h4>${side}</div>`;
    let body = '';
    const opts = (list, cur, key) => `<div class="cm-opts" data-k="${key}">${list.map(([v, label, icon]) => `<button data-v="${v}" class="${String(cur) === String(v) ? 'on' : ''}"><span class="o">${icon || `<b class="tx">${label}</b>`}</span><b>${label.toUpperCase()}</b></button>`).join('')}</div>`;
    if (p === 'flash') body = opts([['off', 'Off', ic('flashOff', 22)], ...(caps().flash ? [['auto', 'Auto', ic('flashAuto', 22)]] : []), ['on', 'On', ic('flashOn', 22)]], st.flash, 'flash');
    else if (p === 'timer') body = opts([['0', 'Off', ic('timer', 22)], ['3', '3 s'], ['10', '10 s']], st.timer, 'timer') + intervalBody();
    else if (p === 'aspect') body = `<div class="cm-chips" data-k="aspect">${ASPECTS.map(([a]) => `<button data-v="${a}" class="${st.aspect === a ? 'on' : ''}">${a}</button>`).join('')}</div>`;
    else if (p === 'ev') body = `<div class="cm-pd" id="cmPD"></div>`;
    else if (p === 'depth') body = `<div class="cm-pd" id="cmPD"></div><p class="cm-note">The subject stays sharp, the rest softens. Lower ƒ, more blur.</p>`;
    else if (p === 'pro') { if (!proKeys().includes(st.pro)) st.pro = proKeys()[0]; body = `<div class="cm-sel" id="cmSel"><div class="tr">${proKeys().map((k) => `<button data-d="${k}" class="${k === st.pro ? 'on' : ''}">${DIALS[k].name}</button>`).join('')}</div></div><div class="cm-pd" id="cmPD"></div>`; }
    else if (p === 'roll') body = rollBody();
    else if (p === 'studio') body = studioBody();
    else if (p === 'setups') body = setupsBody();
    else if (p === 'setup') body = setupBody();
    else if (p === 'share') body = shareBody();
    else if (p === 'looks') body = `${lookGroups().length > 1 ? `<div class="cm-lg" id="cmLG">${lookGroups().map(([g, n]) => `<button data-g="${g}" class="${(lookById(st.look).g || 'mine') === g ? 'on' : ''}">${n}</button>`).join('')}</div>` : ''}
      <div class="cm-sws" id="cmSws">${lookGroups().map(([g]) => LOOKS.filter((l) => (l.g || 'mine') === g).map((l) => `<button data-look="${l.id}" data-g="${g}" class="${l.id === st.look ? 'on' : ''}"><span class="sw" style="background:linear-gradient(135deg,${l.sw[0]} 0 50%,${l.sw[1]} 50%)"></span><b>${esc(l.name)}</b></button>`).join('')).join('')}</div>
      <div class="cm-slider"><span>STRENGTH</span><input type="range" min="0" max="100" value="${Math.round(st.amount * 100)}" id="cmAmt"><b>${Math.round(st.amount * 100)}</b></div>
      <div class="cm-slider"><span>GRAIN</span><input type="range" min="0" max="200" value="${Math.round(st.grain * 100)}" id="cmGr"><b>${Math.round(st.grain * 100)}</b></div>
      <div class="cm-acts"><button class="cm-act" id="cmNewLook">${ic('plus', 16)}NEW</button><button class="cm-act" id="cmEditLook">${ic('pen', 16)}${lookById(st.look).mine ? 'EDIT' : 'EDIT A COPY'}</button><button class="cm-act" id="cmShareLook">${ic('share', 16)}SHARE</button></div>`;
    else if (p === 'format') body = formatBody();
    else if (p === 'tools') body = toolsBody();
    inEl.innerHTML = head + `<div class="cm-pb">${body}</div>`;
    C.pd = null;
    $('#cmBack').onclick = () => { const was = C.panel; C.panel = { studio: 'looks', share: 'looks', setup: 'setups' }[was] || ''; C.pd = null; if (was === 'studio') endStudio(); paintCard(); };
    const au = $('#cmAuto'); if (au) au.onclick = () => resetTo(p);
    wirePanel(p);
    sizeCard();
  }
  // the look groups that have looks (your own looks last, as MINE)
  const lookGroups = () => [...LOOK_GROUPS, ['mine', 'MINE']].filter(([g]) => LOOKS.some((l) => (l.g || 'mine') === g));
  function formatBody() {
    const c = caps();
    if (st.mode === 'VIDEO') return `<div class="cm-chips" data-k="k4"><button data-v="0" class="${st.k4 && c.k4 ? '' : 'on'}">HD 1080p</button><button data-v="1" class="${st.k4 && c.k4 ? 'on' : ''}${c.k4 ? '' : ' off'}">4K</button></div><p class="cm-note">16:9, 30 frames a second, with your look and sound.</p>`;
    if (st.mode !== 'PHOTO') return `<div class="cm-chips" data-k="fmt">${['HEIF', 'JPEG'].filter((f) => (c.formats || ['JPEG']).includes(f)).map((f) => `<button data-v="${f}" class="${(st.fmt === 'JPEG' ? 'JPEG' : 'HEIF') === f ? 'on' : ''}">${f}</button>`).join('')}</div><p class="cm-note">${st.mode === 'NIGHT' ? 'Night' : 'Stack'} merges several 12 MP frames into one clean photo.</p>`;
    const F = ['RAW+', 'RAW', 'HEIF', 'JPEG'].filter((f) => (f.startsWith('RAW') ? c.raw : (c.formats || ['JPEG']).includes(f)));
    const M = [12, 24, 48].filter((m) => (c.mp || [12]).includes(m)), raw = st.fmt.startsWith('RAW') && c.raw, [f, sz] = fmtParts();
    const say = raw ? `RAW files from this iPhone are ${rawMP()} MP (48 MP RAW is ProRAW, on Pro iPhones only).`
      : (st.fmt === 'JPEG' ? 'With your look; opens everywhere.' : 'With your look; small files.')
        + (naturalOn() ? ' Natural capture: RAW frames merged and developed gently (not with flash or depth).' : st.natural && caps().natural ? ' Natural capture works at 12 MP.' : '');
    return `<div class="cm-big">${f === 'RAW+' ? 'RAW+HEIF' : f}<small>${sz} MP</small></div>
      <div class="cm-chips" data-k="fmt">${F.map((x) => `<button data-v="${x}" class="${st.fmt === x ? 'on' : ''}">${x}</button>`).join('')}</div>
      ${M.length > 1 ? `<div class="cm-chips" data-k="mp">${M.map((m) => `<button data-v="${m}" class="${(raw ? rawMP() : +st.mp) === m ? 'on' : ''}${raw && m !== rawMP() ? ' off' : ''}">${m} MP</button>`).join('')}</div>` : ''}
      <p class="cm-note">${say}</p>`;
  }
  const TOOLS = [['framed', 'Framed'], ['rev', 'Reversible'], ['roll', 'Film roll'], ['guide', 'Guide'], ['level', 'Level'], ['hist', 'Histogram'], ['peak', 'Peaking'], ['zebra', 'Zebra'], ['fc', 'False colour'],
    ['mirror', 'Mirror selfie'], ['loc', 'Location'], ['sound', 'Shutter sound'], ['stab', 'Stabilise video'], ['natural', 'Natural capture'], ['stamp', 'Date stamp'], ['reset', 'Reset']];
  const GROUPS = [['GUIDES', ['guide', 'level', 'hist']], ['FOCUS AND EXPOSURE', ['peak', 'zebra', 'fc']], ['CAPTURE', ['natural', 'framed', 'rev', 'roll', 'stamp', 'loc', 'sound', 'stab', 'mirror']]];
  function toolsBody() {
    const T = tools(), ok = (k) => (k === 'rev' ? !!caps().reversible : k === 'roll' ? canRoll() : k === 'natural' ? !!caps().natural : k === 'stamp' ? !!caps().stamp
      : !['loc', 'sound', 'stab'].includes(k) || T.includes(k));
    if (V6) {
      const name = Object.fromEntries(TOOLS);
      return `<div class="cm-list">${GROUPS.map(([g, ks]) => { const rows = ks.filter(ok); return rows.length ? `<h5>${g}</h5><div class="cm-grp">${rows.map((k) => k === 'guide' ? `<button class="cm-li${st.guide !== 'off' ? ' on' : ''}" data-k="guide"><span class="i">${ic('g_' + st.guide, 18)}</span><b>Guide</b><em class="gv">${GUIDE_NAME[st.guide]}</em></button>`
          : `<button class="cm-li${st[k] ? ' on' : ''}" data-k="${k}"><span class="i">${ic(k, 18)}</span><b>${name[k]}</b><i class="tg"></i></button>`).join('')}</div>` : ''; }).join('')}
        <button class="cm-reset" data-k="reset">${ic('reset', 16)}RESET THE CAMERA</button></div>`;
    }
    return `<div class="cm-grid9 cm-tools">${TOOLS.filter(([k]) => ok(k)).map(([k, n]) => `<button class="${k !== 'reset' && (k === 'guide' ? st.guide !== 'off' : st[k]) ? 'on' : ''}" data-k="${k}"><span class="o">${ic(k, 22)}</span><b>${n.toUpperCase()}</b></button>`).join('')}</div>`;
  }
  function wirePanel(p) {
    $$('#cmCardIn .cm-opts, #cmCardIn .cm-chips').forEach((g) => g.querySelectorAll('button').forEach((b) => (b.onclick = async () => {
      const k = g.dataset.k, v = b.dataset.v;
      if (b.classList.contains('off')) { if (k === 'mp') line(`RAW is ${rawMP()} MP on this iPhone. Choose HEIF or JPEG for ${v} MP.`); return; }
      const back = { flash: 'flash', timer: 'timer', aspect: 'aspect', fmt: 'format', mp: 'format', k4: 'format' }[k];
      if (back && b.classList.contains('on')) return resetTo(back);   // the chosen one again: back to normal
      haptic('selection');
      if (k === 'flash') st.flash = v;
      else if (k === 'timer') st.timer = +v;
      else if (k === 'every') st.every = st.every === +v ? 0 : +v;   // (the chosen one again: off)
      else if (k === 'shots') st.shots = +v;
      else if (k === 'aspect') { st.aspect = v; cm.classList.toggle('full', !aspectNow()); layout(); }
      else if (k === 'fmt') st.fmt = v;
      else if (k === 'mp') { st.mp = +v; E.setResolution?.(+v); }
      else if (k === 'k4') { st.k4 = v === '1'; await E.setMode?.({ mode: 'VIDEO', k4: st.k4 }); }
      else if (k === 'rsize') st.rollSize = +v;
      else if (k === 'rdelay') st.rollDelay = v;
      save(); paintAll(); paintCard();
    })));
    if (p === 'ev') C.pd = dial($('#cmPD'), 'ev');
    if (p === 'depth') C.pd = dial($('#cmPD'), 'ap', () => paintRow());
    if (p === 'pro') {
      C.pd = dial($('#cmPD'), st.pro);
      const sel = $('#cmSel'), tr = sel.querySelector('.tr'), keys = proKeys();
      const centre = () => pg.jump(posOf(Math.max(0, keys.indexOf(st.pro))));
      const pick = (k) => { if (!k || k === st.pro) return; st.pro = k; save(); tr.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x.dataset.d === k)); centre(); C.pd = dial($('#cmPD'), k); };
      tr.querySelectorAll('button').forEach((x) => (x.onclick = () => { if (tapOk()) pick(x.dataset.d); }));
      const posOf = (i) => { const b = tr.children[i]; return b ? sel.clientWidth / 2 - (b.offsetLeft + b.offsetWidth / 2) : 0; };
      let px = 0;
      const pg = glide({ el: sel, axis: (dx, dy) => (V6 && C.turn ? held(dx, dy) : [dx, dy]), get: () => px, reach: 140, maxStep: 1,
        set: (v) => { px = v; tr.style.transform = `translateX(${v}px)`; }, stops: () => keys.map((_, i) => posOf(i)),
        onStart: () => { tr.style.transition = 'none'; },
        onNear: (i) => { tr.querySelectorAll('button').forEach((b, j) => b.classList.toggle('on', j === i)); haptic('selection'); },
        onStop: (i) => { tr.style.transition = ''; pick(keys[i]); } });
      requestAnimationFrame(() => pg.jump(posOf(Math.max(0, keys.indexOf(st.pro)))));
    }
    if (p === 'roll') wireRoll();
    if (p === 'studio') wireStudio();
    if (p === 'setups') wireSetups();
    if (p === 'setup') wireSetup();
    if (p === 'share') wireShare();
    if (p === 'looks') {
      const nl = $('#cmNewLook'); if (nl) nl.onclick = () => openStudio(null);
      const el = $('#cmEditLook'); if (el) el.onclick = () => { const L = lookById(st.look); openStudio(L, !L.mine); };   // (ours: a copy to change)
      const sh = $('#cmShareLook'); if (sh) sh.onclick = () => { haptic('selection'); C.panel = 'share'; paintCard(); };
      const sws = $('#cmSws');
      sws.querySelectorAll('button').forEach((b) => (b.onclick = () => { setLook(b.dataset.look === st.look ? 'natural' : b.dataset.look); }));   // the chosen look again: Natural
      const on = sws.querySelector('.on'); if (on) sws.scrollLeft = on.offsetLeft + on.offsetWidth / 2 - sws.clientWidth / 2;
      const lg = $('#cmLG');
      if (lg) {
        lg.querySelectorAll('button').forEach((b) => (b.onclick = () => {
          const first = sws.querySelector(`[data-g="${b.dataset.g}"]`); haptic('selection');
          lg.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); lgHold = Date.now();
          if (first) sws.scrollTo({ left: first.offsetLeft - 8, behavior: 'smooth' });
        }));
        let lgHold = 0;
        sws.addEventListener('scroll', () => {   // the group in the middle of the strip lights up
          if (Date.now() - lgHold < 700) return;   // (while a tap on a group scrolls there)
          const mid = sws.scrollLeft + sws.clientWidth / 2, cur = [...sws.children].find((b) => b.offsetLeft + b.offsetWidth > mid);
          if (cur) lg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.g === cur.dataset.g));
        }, { passive: true });
      }
      const amt = $('#cmAmt'), gr = $('#cmGr');
      amt.oninput = () => { st.amount = amt.value / 100; amt.nextElementSibling.textContent = amt.value; E.setLook?.(view()); };
      for (const r of [amt, gr]) {   // tap the number (or the name): back to 100
        const to100 = () => { r.value = 100; r.dispatchEvent(new Event('input')); save(); haptic('light'); };
        r.nextElementSibling.onclick = to100; r.previousElementSibling.onclick = to100;
      }
      gr.oninput = () => { st.grain = gr.value / 100; gr.nextElementSibling.textContent = gr.value; E.setLook?.(view()); };
      amt.onchange = gr.onchange = save;
    }
    if (p === 'tools') $$('#cmCardIn .cm-tools button, #cmCardIn .cm-list [data-k]').forEach((b) => (b.onclick = async () => {
      const k = b.dataset.k; haptic('selection');
      if (k === 'reset') { const keep = { facing: st.facing, look: st.look, mode: st.mode }; st = { ...DEF, ...keep }; await applyAll(); chip('BACK TO THE START'); }
      else if (k === 'guide') { st.guide = GUIDES[(GUIDES.indexOf(st.guide) + 1) % GUIDES.length]; chip('GUIDE · ' + GUIDE_NAME[st.guide]); }
      else if (k === 'level' && !st.level) { if (!(await askMotion())) return; st.level = true; }
      else if (k === 'loc' && !st.loc) { if (!(await askLocation())) return; st.loc = true; }
      else st[k] = !st[k];
      if (k === 'roll' && !st.roll && C.R.cur) { C.R.cur.delay = 'now'; finishRoll(); }
      if (k === 'rev') chip(st.rev ? 'REVERSIBLE · PHOTOS CAN TAKE THE LOOK OFF' : 'LOOK BAKED IN');
      if (k === 'natural') chip(st.natural ? 'NATURAL · RAW FRAMES MERGED, NO HDR LOOK' : "APPLE'S PROCESSING");
      if (k === 'stamp') chip(st.stamp ? 'DATE ON DIGICAM LOOKS' : 'NO DATE');
      save(); paintAll(); paintCard(); E.setTools?.(toolsFor()); E.setLook?.(view());
    }));
  }
  /* ---------- Film Roll ---------- */
  function rollBody() {
    const r = C.R.cur, ready = C.R.list.slice(0, 6);
    const list = ready.length ? `<div class="cm-rolls">${ready.map((x, i) => `<button data-roll="${i}" class="${x.state === 'ready' ? '' : 'dev'}"><span class="rt">${ic('film', 18)}</span><span class="rn"><b>${x.shots.length} · ${esc(x.lookName)}</b><small>${x.state === 'ready' ? 'Developed ' + new Date(x.readyAt || x.devAt).toLocaleDateString([], { day: 'numeric', month: 'short' }) : 'Ready ' + Roll.when(x.devAt)}</small></span>${x.state === 'ready' ? ic('chev', 16) : ''}</button>`).join('')}</div>` : '';
    if (r) return `<div class="cm-big">${Roll.left(r)}<small>of ${r.size} left</small></div>
      <p class="cm-note">${esc(r.lookName)} · develops ${(Roll.DELAYS.find((d) => d[0] === r.delay) || Roll.DELAYS[0])[1].toLowerCase()} after the last shot</p>
      <div class="cm-acts"><button class="cm-act" id="cmRollStop">STOP ROLL</button><button class="cm-act pri" id="cmRollEnd">DEVELOP NOW</button></div>
      <p class="cm-note">Stop: the shots so far go to Photos now and the camera is back to normal.</p>${list}`;
    return `<div class="cm-chips" data-k="rsize">${Roll.SIZES.map((n) => `<button data-v="${n}" class="${+st.rollSize === n ? 'on' : ''}">${n}</button>`).join('')}</div>
      <div class="cm-chips small" data-k="rdelay">${Roll.DELAYS.map(([v, l]) => `<button data-v="${v}" class="${st.rollDelay === v ? 'on' : ''}">${l}</button>`).join('')}</div>
      <p class="cm-note">One look for the whole roll (${esc(lookById(st.look).name)}). The photos stay hidden until the roll develops, then go to Photos together.</p>
      <div class="cm-acts"><button class="cm-act pri" id="cmRollGo">${ic('film', 16)}LOAD ${st.rollSize} SHOTS</button></div>${list}`;
  }
  function wireRoll() {
    const go = $('#cmRollGo'); if (go) go.onclick = () => {
      const L = lookById(st.look);
      C.R.cur = { id: Date.now(), look: L.id, lookName: L.name, size: +st.rollSize || 24, delay: st.rollDelay || 'hour', shots: [], at: Date.now() };
      Roll.store(C.R); haptic('medium'); closeCard(); paintAll(); paintThumb(); chip(`ROLL LOADED · ${C.R.cur.size} SHOTS`);
    };
    const end = $('#cmRollEnd'); if (end) end.onclick = () => { closeCard(); finishRoll(); };
    const stopR = $('#cmRollStop'); if (stopR) stopR.onclick = () => { if (C.R.cur) C.R.cur.delay = 'now'; closeCard(); finishRoll(); };
    $$('#cmCardIn .cm-rolls button').forEach((b) => (b.onclick = () => { const r = C.R.list[+b.dataset.roll]; if (r?.state === 'ready') openRoll(r); else if (r) chip('READY ' + Roll.when(r.devAt).toUpperCase()); }));
  }
  function rollShot(shot) {
    const r = C.R.cur; if (!r) return;
    r.shots.push({ name: String(shot.uri || '').split('/').pop(), w: shot.w, h: shot.h, at: Date.now(), meta: shot.meta });
    Roll.store(C.R); paintTop(); paintThumb();
    const n = Roll.left(r); if (n > 0 && n <= 3) chip(`${n} LEFT ON THIS ROLL`);
    if (n <= 0) finishRoll();
  }
  async function finishRoll() {
    const r = C.R.cur; if (!r) return;
    C.R.cur = null;
    if (!r.shots.length) { Roll.store(C.R); paintAll(); paintThumb(); return chip('ROLL UNLOADED'); }
    r.state = 'developing'; r.devAt = Roll.readyAt(r.delay); C.R.list.unshift(r); Roll.store(C.R);
    paintAll(); paintThumb(); E?.setTools?.(toolsFor());
    if (r.devAt - Date.now() < 5000) return developDue();
    chip('ROLL DEVELOPING · READY ' + Roll.when(r.devAt).toUpperCase()); haptic('medium');
    liveShow('roll', { title: 'Roll developing', subtitle: `${r.shots.length} photos · ${r.lookName}`, icon: 'film', timerEnd: r.devAt, progress: -1 });
    const LN = plugin('LocalNotifications');
    try {
      const p = await LN?.requestPermissions?.();
      if (p?.display === 'granted') await LN.schedule({ notifications: [{ id: r.id % 2000000000, title: 'Your roll is ready', body: `${r.shots.length} photos · ${r.lookName}. Tap to see them.`, schedule: { at: new Date(r.devAt) }, extra: { open: 'camera' } }] });
    } catch {}
  }
  // rolls whose time has come: their photos go to Photos together, then they open
  async function developDue() {
    if (C.developing) return;
    const due = C.R.list.filter((r) => r.state === 'developing' && r.devAt <= Date.now());
    if (!due.length) return;
    C.developing = true;
    const N = plugin('ShivoNative');
    try {
      for (const r of due) {
        for (const sh of r.shots) {
          const uri = await Roll.fileOf(plugin, sh.name);
          if (uri && N?.saveFromURL) await N.saveFromURL({ url: uri, name: sh.name, kind: 'media' }).catch(() => {});
        }
        r.state = 'ready'; r.readyAt = Date.now(); Roll.store(C.R);
        liveDone('roll', { title: 'Roll ready', subtitle: `${r.shots.length} photos · ${r.lookName}` });
      }
      haptic('success'); chip('ROLL READY · IN PHOTOS');
      if (C.on) openRoll(due[0]);
    } finally { C.developing = false; }
  }
  async function openRoll(r) {
    const list = [];
    for (const sh of r.shots) {
      const uri = await Roll.fileOf(plugin, sh.name);
      if (uri) list.push({ url: Roll.shown(uri), uri, w: sh.w, h: sh.h, look: r.lookName, saved: true, meta: sh.meta });
    }
    if (list.length) openViewer(list); else toast?.("This roll's photos aren't on this phone any more (they're in Photos)");
  }

  /* ---------- Look Studio: your own looks, built with sliders, live in the viewfinder ----------
     (the maths is in studio.js: SECTIONS are the sliders, studioLook() makes the look, valuesOf() opens any look as sliders) */
  function openStudio(edit, copy) {
    const base = edit ? (edit.v ? norm(edit.v) : valuesOf(edit)) : START();
    C.edit = { id: edit && !copy ? edit.id : 'mine-' + Date.now(), name: edit ? (copy ? cleanName(edit.name + ' copy', 'My look') : edit.name) : `My look ${mine().length + 1}`, v: { ...base }, old: !!edit && !copy, n: 0 };
    C.studio = studioLook(C.edit.v, 'studio-0', C.edit.name); E?.setLook?.(view()); paintDate();
    C.panel = 'studio'; paintCard();
  }
  function endStudio() { C.studio = null; C.edit = null; E?.setLook?.(view()); paintDate(); }
  function studioBody() {
    const e = C.edit, v = e.v;
    const sl = ([k, n, lo, hi, d]) => `<div class="cm-slider"><span data-d="${d}">${n}</span><input type="range" min="${lo}" max="${hi}" value="${v[k]}" data-k="${k}"><b>${v[k]}</b></div>`;
    const sw = (k, n, icon) => `<button class="cm-li${v[k] ? ' on' : ''}" data-t="${k}"><span class="i">${ic(icon, 18)}</span><b>${n}</b><i class="tg"></i></button>`;
    return `<button class="cm-name" id="cmLookName">${esc(e.name)}${ic('pen', 14)}</button>
      <div class="cm-list st">${SECTIONS.map(([h, rows]) => `<h5>${h}</h5><div class="cm-grp">${rows.map(sl).join('')}</div>`).join('')}
        <h5>LOOK</h5><div class="cm-grp">${sw('mono', 'Black &amp; white', 'mono')}${caps().stamp ? sw('stamp', 'Date stamp', 'stamp') : ''}</div></div>
      <div class="cm-acts">${e.old ? '<button class="cm-act" id="cmDelLook">DELETE</button>' : ''}<button class="cm-act pri" id="cmSaveLook">SAVE LOOK</button></div>`;
  }
  function wireStudio() {
    const e = C.edit; let raf = 0;
    const live = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => { e.n++; C.studio = studioLook(e.v, 'studio-' + e.n, e.name); E?.setLook?.(view()); paintDate(); }); };
    $$('#cmCardIn .cm-slider input').forEach((i) => (i.oninput = () => { e.v[i.dataset.k] = +i.value; i.nextElementSibling.textContent = i.value; live(); }));
    $$('#cmCardIn .cm-slider span').forEach((n) => (n.onclick = () => { const i = n.nextElementSibling; i.value = n.dataset.d; i.dispatchEvent(new Event('input')); haptic('light'); }));   // tap a name: back to its usual value
    $$('#cmCardIn [data-t]').forEach((b) => (b.onclick = () => { const k = b.dataset.t; e.v[k] = !e.v[k]; b.classList.toggle('on', e.v[k]); haptic('selection'); live(); }));
    $('#cmLookName').onclick = () => { const n = cleanName(prompt('Name this look', e.name), ''); if (n) { e.name = n; paintCard(); } };
    $('#cmSaveLook').onclick = () => {
      const list = mine().filter((l) => l.id !== e.id); list.push(studioLook(e.v, e.id, e.name));
      try { localStorage.setItem(MINE, JSON.stringify(list)); } catch {}
      mergeMine(); sentControls = '';
      C.studio = null; st.look = e.id; save(); E?.setLook?.(view()); syncControls(); paintDate(); haptic('success');
      chip(e.name.toUpperCase() + ' SAVED'); C.edit = null; C.panel = 'looks'; paintCard();
    };
    const del = $('#cmDelLook'); if (del) del.onclick = () => {
      try { localStorage.setItem(MINE, JSON.stringify(mine().filter((l) => l.id !== e.id))); } catch {}
      mergeMine(); sentControls = '';
      C.studio = null; if (st.look === e.id) st.look = 'natural'; save(); E?.setLook?.(view()); syncControls(); paintDate();
      chip('LOOK DELETED'); C.edit = null; C.panel = 'looks'; paintCard();
    };
  }

  /* ---------- sharing a look: a link (and its QR code) that adds the look to someone else's camera ---------- */
  function shareBody() {
    const L = lookById(st.look);
    return `<div class="cm-qr"><div class="q" id="cmQr"></div><b>${esc(L.name)}</b></div>
      <div class="cm-acts"><button class="cm-act pri" id="cmShareGo">${ic('share', 16)}SHARE LINK</button></div>
      <p class="cm-note">Scan this with an iPhone camera: the look is added to Shivo Labs Camera.</p>`;
  }
  async function wireShare() {
    const L = lookById(st.look), link = linkOf(L), q = $('#cmQr');
    try {
      const { default: qrcode } = await import('../kit/qrcode.mjs');
      const code = qrcode(0, 'L'); code.addData(link); code.make();
      if (q && C.panel === 'share') q.innerHTML = code.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
    } catch (e) { console.warn('qr', e); if (q) q.innerHTML = '<p class="cm-note">The code could not be drawn. Use Share link.</p>'; }
    const go = $('#cmShareGo'); if (!go) return;
    go.onclick = async () => {
      haptic('selection');
      const text = `${L.name}: a look for Shivo Labs Camera. Open this link on an iPhone with Shivo Labs to add it.\n${link}`;
      try {
        const SH = plugin('Share');
        if (SH) await SH.share({ title: L.name, text, dialogTitle: 'Share look' });
        else if (navigator.share) await navigator.share({ title: L.name, text });
        else { await navigator.clipboard.writeText(link); chip('LINK COPIED'); }
      } catch {}
    };
  }
  // a look arrives (a scanned code or a link): checked, then added to your own looks and chosen
  function importLook(code) {
    const c = decodeLook(code);
    if (!c) { chip("THAT LOOK LINK DIDN'T WORK"); toast?.("That look link didn't work"); return false; }
    const L = studioLook(valuesOf(c), 'mine-' + Date.now(), c.name), sig = JSON.stringify(L.v), list = mine();
    const have = list.find((l) => l.name === L.name && JSON.stringify(l.v) === sig);
    if (!have && list.length >= 60) { toast?.('You have 60 looks of your own: delete one to add this'); return false; }
    if (!have) { list.push(L); try { localStorage.setItem(MINE, JSON.stringify(list)); } catch {} }
    const use = have || L;
    mergeMine(); sentControls = '';
    if (!C.R.cur) st.look = use.id;
    save(); paintAll(); syncControls(); haptic('success'); chip('LOOK ADDED · ' + use.name.toUpperCase());
    if (C.panel === 'looks') paintCard();
    return true;
  }

  /* ---------- Setups: the camera's whole mood under a name (look, strength, aspect, format, flash, timer, date, natural, guide, mode) ---------- */
  const SETS = 'sl.cam.setups';
  const BUILT = [   // ours: they can't be deleted
    { id: 'b-everyday', name: 'Everyday', built: true, look: 'natural', amount: 1, grain: 1, aspect: '4:3', flash: 'off', timer: 0, natural: true, stamp: true, guide: 'thirds', mode: 'PHOTO' },
    { id: 'b-street', name: 'Street', built: true, look: 'silver', amount: 1, grain: 1, aspect: '3:2', flash: 'off', timer: 0, natural: true, stamp: true, guide: 'thirds', mode: 'PHOTO' },
    { id: 'b-night', name: 'Night out', built: true, look: 'tungsten', amount: 1, grain: 1, aspect: '4:3', flash: 'off', timer: 0, natural: true, stamp: true, guide: 'off', mode: 'PHOTO' },
  ];
  const mineSetups = () => { try { const a = JSON.parse(localStorage.getItem(SETS) || '[]'); return Array.isArray(a) ? a.filter((x) => x && typeof x.id === 'string' && typeof x.name === 'string').slice(0, 24) : []; } catch { return []; } };
  const setups = () => [...BUILT, ...mineSetups()];
  const SKEYS = ['look', 'amount', 'grain', 'aspect', 'fmt', 'mp', 'flash', 'timer', 'stamp', 'natural', 'guide', 'mode'];
  const sameSetup = (x) => SKEYS.every((k) => x[k] === undefined || x[k] === st[k]);
  const activeSetup = () => setups().find(sameSetup);
  const suSub = (x) => [lookById(x.look || st.look).name, x.aspect, x.mode && x.mode !== 'PHOTO' ? x.mode : '', x.fmt ? x.fmt + (x.mp ? ' ' + x.mp : '') : '', x.flash && x.flash !== 'off' ? 'FLASH ' + x.flash.toUpperCase() : '', x.timer ? x.timer + 's TIMER' : '', x.guide === 'off' ? 'NO GUIDE' : ''].filter(Boolean).join(' · ');
  function setupsBody() {
    const all = setups(), cur = all.find(sameSetup);
    return `<div class="cm-list su"><h5>SETUPS</h5><div class="cm-grp">${all.map((x) => `<div class="cm-su${x === cur ? ' on' : ''}" data-id="${esc(x.id)}"><button class="go"><span class="i">${ic(x === cur ? 'check' : 'setups', 18)}</span><b>${esc(x.name)}<small>${esc(suSub(x))}</small></b></button>${x.built ? '' : `<button class="ed" aria-label="Edit ${esc(x.name)}">${ic('pen', 16)}</button>`}</div>`).join('')}</div></div>
      <div class="cm-acts"><button class="cm-act pri" id="cmSuSave">${ic('plus', 16)}SAVE CURRENT</button></div>`;
  }
  function wireSetups() {
    $$('#cmCardIn .cm-su').forEach((r) => {
      const x = setups().find((q) => q.id === r.dataset.id), go = r.querySelector('.go'), ed = r.querySelector('.ed'); let t = 0, held = 0;
      const edit = () => { haptic('medium'); C.suId = x.id; C.panel = 'setup'; paintCard(); };
      if (ed) ed.onclick = edit;
      go.onpointerdown = () => { held = 0; clearTimeout(t); if (!x.built) t = setTimeout(() => { held = 1; edit(); }, 600); };
      go.onpointerup = go.onpointerleave = go.onpointercancel = () => clearTimeout(t);
      go.onclick = () => { if (!held) useSetup(x); };
    });
    $('#cmSuSave').onclick = () => {
      const list = mineSetups(); if (list.length >= 24) return chip('24 SETUPS IS THE MOST');
      const name = cleanName(prompt('Name this setup', `${lookById(st.look).name} ${st.aspect}`), ''); if (!name) return;
      list.push({ id: 's-' + Date.now(), name, ...Object.fromEntries(SKEYS.map((k) => [k, st[k]])) });
      try { localStorage.setItem(SETS, JSON.stringify(list)); } catch {}
      haptic('success'); chip('SETUP SAVED · ' + name.toUpperCase()); paintCard();
    };
  }
  function setupBody() {
    const x = mineSetups().find((q) => q.id === C.suId);
    if (!x) return '<p class="cm-note">This setup is gone.</p>';
    return `<button class="cm-name" id="cmSuName">${esc(x.name)}${ic('pen', 14)}</button><p class="cm-note">${esc(suSub(x))}</p>
      <div class="cm-acts"><button class="cm-act" id="cmSuDel">${ic('trash', 16)}DELETE</button><button class="cm-act" id="cmSuUpd">${ic('reset', 16)}USE CAMERA NOW</button></div>
      <p class="cm-note">Use camera now: replaces this setup with the camera as it is at the moment.</p>`;
  }
  function wireSetup() {
    const put = (f) => { const list = mineSetups(), i = list.findIndex((q) => q.id === C.suId); if (i < 0) return; f(list, i); try { localStorage.setItem(SETS, JSON.stringify(list)); } catch {} };
    const nm = $('#cmSuName'); if (!nm) return;
    nm.onclick = () => { const n = cleanName(prompt('Name this setup', mineSetups().find((q) => q.id === C.suId)?.name), ''); if (n) { put((l, i) => (l[i].name = n)); paintCard(); } };
    $('#cmSuDel').onclick = () => { put((l, i) => l.splice(i, 1)); haptic('medium'); chip('SETUP DELETED'); C.panel = 'setups'; paintCard(); };
    $('#cmSuUpd').onclick = () => { put((l, i) => Object.assign(l[i], Object.fromEntries(SKEYS.map((k) => [k, st[k]])))); haptic('success'); chip('SETUP UPDATED'); paintCard(); };
  }
  // one tap: every part of the setup goes through the same paths as its own panel, so the camera follows
  async function useSetup(x) {
    if (C.rec || C.busy || C.int) return chip('FINISH THE SHOT FIRST');
    const c = caps(), was = { mode: st.mode, mp: +st.mp };
    if (x.look && !C.R.cur) st.look = lookById(x.look).id;   // (a loaded roll keeps its own look)
    if (typeof x.amount === 'number') st.amount = clamp(x.amount, 0, 1);
    if (typeof x.grain === 'number') st.grain = clamp(x.grain, 0, 2);
    if (ASPECTS.some((a) => a[0] === x.aspect)) st.aspect = x.aspect;
    if (typeof x.fmt === 'string' && (x.fmt.startsWith('RAW') ? !!c.raw && ['RAW', 'RAW+'].includes(x.fmt) : (c.formats || ['JPEG']).includes(x.fmt))) st.fmt = x.fmt;
    if ((c.mp || [12]).includes(+x.mp)) st.mp = +x.mp;
    if (x.flash === 'off' || x.flash === 'on' || (x.flash === 'auto' && c.flash)) st.flash = x.flash;
    if ([0, 3, 10].includes(x.timer)) st.timer = x.timer;
    if (typeof x.stamp === 'boolean') st.stamp = x.stamp;
    if (typeof x.natural === 'boolean') st.natural = x.natural;
    if (GUIDES.includes(x.guide)) st.guide = x.guide;
    const m = modes().includes(x.mode) ? x.mode : st.mode;
    st.mode = m; save(); closeCard(); haptic('medium');
    if (m === 'VIDEO' || was.mode === 'VIDEO') await E.setMode?.({ mode: m, k4: st.k4 });
    if (c.depth) E.setDepth?.({ on: DEPTH_ON && st.depth && m === 'PHOTO', ap: st.ap });
    if (+st.mp !== was.mp) E.setResolution?.(+st.mp);
    cm.classList.toggle('full', !aspectNow());
    paintAll(); layout(); syncControls(); chip('SETUP · ' + x.name.toUpperCase());
  }

  /* ---------- interval: a photo every few seconds, for a number of shots or until the shutter is tapped ---------- */
  const EVERY = [0, 2, 5, 10, 30], SHOTS = [10, 20, 50, 0];
  const intervalBody = () => `<div class="cm-sub"><span>INTERVAL</span><div class="cm-chips small" data-k="every">${EVERY.map((v) => `<button data-v="${v}" class="${st.every === v ? 'on' : ''}">${v ? v + 's' : 'OFF'}</button>`).join('')}</div></div>
    ${st.every ? `<div class="cm-sub"><span>SHOTS</span><div class="cm-chips small" data-k="shots">${SHOTS.map((v) => `<button data-v="${v}" class="${st.shots === v ? 'on' : ''}">${v || '∞'}</button>`).join('')}</div></div>` : ''}
    <p class="cm-note">${st.every ? `A photo every ${st.every} seconds${st.shots ? `, ${st.shots} in all` : ' until you stop'}. Tap the shutter to start, and again to stop.` : 'Photos on their own, one every few seconds (a time-lapse).'}</p>`;
  async function interval() {
    if (C.int || C.busy || !E?.running?.()) return;
    const I = C.int = { n: 0, stop: false, every: st.every * 1000, total: st.shots || Infinity }; let fails = 0;
    closeCard(); cm.classList.add('int'); paintInt(); paintRow(); line('Tap the shutter to stop');
    try {
      while (!I.stop && I.n < I.total && C.on && !C.rec && st.mode !== 'VIDEO') {
        const t0 = Date.now(), r = await shoot({ again: I.n > 0 });
        if (r === 'busy') { await sleep(120); continue; }
        if (r === 'ok') { I.n++; fails = 0; } else if (++fails >= 3) break;
        paintInt();
        while (!I.stop && I.n < I.total && Date.now() - t0 < I.every) { ring((Date.now() - t0) / I.every); await sleep(100); }   // (the ring fills until the next one)
      }
    } finally {
      C.int = null; cm.classList.remove('int'); ring(0); paintInt(); paintRow();
      if (I.n) { haptic('success'); chip(`INTERVAL · ${I.n} PHOTO${I.n === 1 ? '' : 'S'}`); }
    }
  }
  const ring = (p) => $('#cmShot').style.setProperty('--ip', clamp(p, 0, 1) + 'turn');   // (the ring round the shutter fills until the next photo)
  function stopInt() { if (C.int && !C.int.stop) { C.int.stop = true; haptic('medium'); } }
  function paintInt() {
    const e = $('#cmInt'), I = C.int; e.hidden = !I;
    if (I) e.innerHTML = `<i></i><b>${I.n}${I.total < Infinity ? ' / ' + I.total : ''}</b><small>EVERY ${I.every / 1000}S</small>`;
  }

  /* ---------- first time: three short tips ---------- */
  function tips() {
    if (localStorage.getItem('sl.cam.tips') || E?.kind !== 'native') return;
    try { localStorage.setItem('sl.cam.tips', '1'); } catch {}
    const T = ['Swipe the picture sideways for another look', 'Swipe up from the bottom for all controls', caps().buttons ? 'The volume and side buttons take the photo too' : 'Pinch to change the lens'];
    T.forEach((t, i) => setTimeout(() => { if (C.on && !C.card) line(t); }, 900 + i * 2200));
  }

  function sizeCard() {
    requestAnimationFrame(() => {
      const h = $('#cmCard').offsetHeight;
      cm.style.setProperty('--cardH', h + 'px'); glassFollow();
    });
  }
  function openCard(panel) {
    C.card = true; C.panel = panel || ''; paintCard();
    cm.classList.add('card'); haptic('light'); paintRow(); glassFollow();
  }
  function closeCard() { if (!C.card) return; C.card = false; C.panel = ''; C.pd = null; cm.classList.remove('card'); paintRow(); glassFollow(); }
  $('#cmScrim').onclick = closeCard;
  (() => {   // swipe the card down to close it
    const c = $('#cmCard'); let y0 = null;
    c.addEventListener('pointerdown', (e) => { if (!e.target.closest('input,.cm-ruler,.cm-sws')) y0 = e.clientY; });
    c.addEventListener('pointerup', (e) => { if (y0 != null && e.clientY - y0 > 50) closeCard(); y0 = null; });
  })();

  /* ---------- the level, and turning photos when the phone is held sideways ---------- */
  // landscape: icons and labels stand upright, the card becomes a side panel, the gallery turns (camera-v6.css, .land)
  function setTurn(turn) {
    C.turn = turn; cm.style.setProperty('--turn', turn + 'deg');
    cm.classList.toggle('land', turn !== 0); cm.dataset.turn = String(turn);
    if (C.card) sizeCard();
    requestAnimationFrame(() => { paintModes(); paintDate(); });
  }
  root.addEventListener('camturn', (e) => setTurn(+e.detail || 0));   // previews turn the phone this way
  function onMotion(e) {
    const g = e.accelerationIncludingGravity; if (!g || g.x == null) return;
    const ax = g.x, ay = g.y, flat = Math.abs(g.z) > 8.6;
    const turn = flat ? C.turn : Math.abs(ax) > Math.abs(ay) * 1.2 ? (ax > 0 ? -90 : 90) : Math.abs(ay) > Math.abs(ax) * 1.2 ? 0 : C.turn;
    if (turn !== C.turn && !C.rec) setTurn(turn);
    let a = Math.atan2(ax, -ay) * 180 / Math.PI; if (C.turn === 90) a -= 90; else if (C.turn === -90) a += 90;
    C.tilt = a; if (!st.level) return;
    const lv = $('#cmLevel'), ok = Math.abs(a) < 1;
    lv.style.setProperty('--tilt', (ok ? 0 : -a) + 'deg');
    if (ok && !lv.classList.contains('ok')) haptic('selection');
    lv.classList.toggle('ok', ok);
  }
  async function askMotion() {
    try {
      const D = window.DeviceMotionEvent;
      if (D?.requestPermission && (await D.requestPermission()) !== 'granted') throw new Error('no');
      if (!C.motion) { addEventListener('devicemotion', onMotion); C.motion = true; }
      localStorage.setItem('sl.cam.motion', '1'); return true;
    } catch { toast?.('Allow Motion for the level and turning photos'); return false; }
  }
  // which way up the phone is held (the icons turn, photos come out the right way): iOS asks once, on the first touch
  if (localStorage.getItem('sl.cam.motion') || !localStorage.getItem('sl.cam.motionAsked')) cm.addEventListener('pointerdown', () => {
    if (C.motion) return; try { localStorage.setItem('sl.cam.motionAsked', '1'); } catch {}
    const D = window.DeviceMotionEvent; if (!D?.requestPermission) return askMotion();
    D.requestPermission().then((r) => { if (r === 'granted') askMotion(); }).catch(() => {});
  }, { once: true });
  if (window.DeviceMotionEvent && !window.DeviceMotionEvent.requestPermission) { addEventListener('devicemotion', onMotion); C.motion = true; }

  /* ---------- location for photos and videos (when turned on) ---------- */
  async function askLocation() {
    const G = plugin('Geolocation');
    try {
      if (!G) throw new Error('none');
      const p = await G.requestPermissions?.().catch(() => null);
      if (p && p.location === 'denied') throw new Error('denied');
      await where(true); if (!C.loc) throw new Error('no fix');
      return true;
    } catch { toast?.('Allow Location for Shivo Labs to add where photos were taken'); return false; }
  }
  async function where(fresh) {
    if (!st.loc && !fresh) return null;
    if (!fresh && C.loc && Date.now() - C.locAt < 120000) return C.loc;
    const G = plugin('Geolocation'); if (!G) return null;
    try {
      const p = await G.getCurrentPosition({ enableHighAccuracy: false, timeout: 4000, maximumAge: 120000 });
      C.loc = { lat: p.coords.latitude, lon: p.coords.longitude }; C.locAt = Date.now();
    } catch {}
    return C.loc;
  }

  /* ---------- the shutter: photo, stack, night, or video ---------- */
  $('#cmShot').onclick = () => (C.int ? stopInt() : st.mode === 'VIDEO' ? (C.rec ? recStop() : recStart()) : st.every ? interval() : shoot());
  async function shoot(o = {}) {   // (o.again: the next one of an interval, no timer and the card stays as it is) gives 'ok', 'busy' or 'fail'
    if (!E?.running?.()) return 'fail';
    if (C.busy) return 'busy';
    C.busy = true; $('#cmShot').classList.add('busy'); if (!o.again) closeCard();
    let res = 'fail';
    const stack = st.mode === 'STACK' || st.mode === 'NIGHT';
    let freed = false;
    const free = () => { if (freed) return; freed = true; C.busy = false; $('#cmShot').classList.remove('busy'); count(''); $('#cmFF').classList.remove('on'); };
    try {
      if (st.timer && !o.again) for (let s = st.timer; s > 0; s--) { count(s); haptic('light'); await sleep(1000); }
      count('');
      if (stack) { progress(0); line(st.mode === 'NIGHT' ? 'Hold still…' : 'Hold steady…'); }
      const loc = st.loc ? await where() : null;
      const a = aspectNow() || C.frame.H / C.frame.W;
      const roll = !!C.R.cur && canRoll();
      const meta = { mm: st.z && canZoom() ? mmOf(st.z) : st.mm, iso: Math.round(st.iso || C.meter.iso || 0), ss: st.ss || C.meter.ss || 0, ap: canDepth() && st.depth ? st.ap : 0 };
      const pending = E.shoot({ ...st, keep: roll, fmt: roll && st.fmt.startsWith('RAW') ? 'HEIF' : st.fmt, aspect: a, turn: C.turn, view: view(), loc, stamp: stampText(),
        onCapture: () => { if (!stack) { blink(); haptic('medium'); free(); } },
        flashFront: async (on) => { $('#cmFF').classList.toggle('on', on); if (on) await sleep(320); } });
      const shot = await pending;
      if (stack) { blink(); haptic('medium'); line(shot?.saved ? 'Saved' : ''); progress(0); }
      if (!shot) return 'fail';
      shot.look = lookById(st.look).name; shot.meta = meta;
      if (shot.error) toast?.(shot.error);
      res = shot.error ? 'fail' : 'ok';
      if (roll && shot.kept) { rollShot(shot); return res; }
      C.shots.unshift(shot); paintThumb();
    } catch (e) { console.error(e); toast?.('Photo not taken: ' + (e.message || e)); }
    finally { free(); }
    return res;
  }
  async function recStart() {
    if (!E?.running?.() || C.busy || !E.record) return;
    C.busy = true; closeCard();
    try {
      await E.record({ on: true, turn: C.turn });
      C.rec = true; C.recT = Date.now(); cm.classList.add('rec'); haptic('medium'); paintRow(); tick();
    } catch (e) { toast?.('Video not started: ' + (e.message || e)); }
    finally { C.busy = false; }
  }
  function tick() {
    if (!C.rec) return;
    const s = Math.floor((Date.now() - C.recT) / 1000);
    $('#cmRecT').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
    setTimeout(tick, 250);
  }
  async function recStop() {
    if (!C.rec) return;
    C.rec = false; cm.classList.remove('rec'); haptic('medium'); paintRow(); $('#cmRecT').textContent = '00:00';
    C.busy = true;
    try {
      const loc = st.loc ? await where() : null;
      const shot = await E.record({ on: false, loc });
      if (shot) { shot.look = lookById(st.look).name; C.shots.unshift(shot); paintThumb(); if (shot.error) toast?.(shot.error); }
    } catch (e) { toast?.('Video not saved: ' + (e.message || e)); }
    finally { C.busy = false; }
  }
  function count(n) { const c = $('#cmCount'); c.textContent = n; c.classList.toggle('on', n !== ''); }
  function blink() { const b = $('#cmBlink'); b.classList.remove('on'); void b.offsetWidth; b.classList.add('on'); }

  /* ---------- photos taken: the corner thumbnail and the viewer ---------- */
  function paintThumb() {
    const t = $('#cmThumb'), s = C.shots[0], r = C.R.cur;
    t.classList.toggle('roll', !!r);
    t.innerHTML = r ? `${ic('film', 20)}<b>${r.shots.length}</b>` : s?.url ? `<img src="${s.url}" alt="">` : '';
    if (s || r) { t.classList.remove('pop'); void t.offsetWidth; t.classList.add('pop'); }
  }
  $('#cmThumb').onclick = () => { if (C.R.cur) openCard('roll'); else if (C.shots.length) openViewer(); else (openURL ? openURL('photos-redirect://') : null)?.catch?.(() => {}); };
  function openViewer(list = C.shots) {
    const v = $('#cmViewer'), framesOk = !!E?.frameImage && caps().frames;
    v.innerHTML = (V6 ? `<div class="cv-top"><button class="cm-rb" id="cvClose" aria-label="Close">${ic('x', 20)}</button><span class="cv-t"><b id="cvL"></b><small id="cvD"></small></span><span class="cv-n" id="cvN"></span></div>
      <div class="cv-strip" id="cvStrip">${list.map((s) => `<figure>${s.video ? `<video src="${s.src}" poster="${s.url}" controls playsinline></video>` : `<img src="${s.url}" alt="">`}</figure>`).join('')}</div>
      <div class="cv-info" id="cvI"></div>`
      : `<div class="cv-top"><button class="cm-rb" id="cvClose" aria-label="Close">${ic('x', 20)}</button><span class="cv-t"><span id="cvN"></span><small id="cvD"></small></span><span class="cv-sp"></span></div>
      <div class="cv-strip" id="cvStrip">${list.map((s) => `<figure>${s.video ? `<video src="${s.src}" poster="${s.url}" controls playsinline></video>` : `<img src="${s.url}" alt="">`}<figcaption>${esc(s.look || '')} · ${s.video ? 'Video' : (s.w * s.h / 1e6).toFixed(1) + ' MP'}${s.raw ? ' · RAW' : ''}</figcaption></figure>`).join('')}</div>`) + `
      ${V6 && list.length > 1 ? `<div class="cv-film" id="cvFilm">${list.slice(0, 60).map((s, i) => `<button data-i="${i}">${s.url ? `<img src="${s.url}" alt="">` : ''}</button>`).join('')}</div>` : ''}
      <div class="cv-bar"><button class="cv-btn" id="cvShare">${ic('share', 22)}<span>Share</span></button>${framesOk ? `<button class="cv-btn" id="cvFrame">${ic('frame', 22)}<span>Frame</span></button>` : ''}<button class="cv-btn" id="cvPhotos">${ic('photos', 22)}<span>Photos</span></button></div>
      <div class="cv-fr" id="cvFr" hidden><div class="cvf-pic"><img id="cvfImg" alt=""><span id="cvfWait">Printing…</span></div>
        <div class="cm-chips" id="cvfStyles">${[['white', 'White'], ['black', 'Black'], ['film', 'Film']].map(([k, n], i) => `<button data-v="${k}" class="${i === 0 ? 'on' : ''}">${V6 ? `<i class="fs fs-${k}"></i>` : ''}${n}</button>`).join('')}</div>
        <div class="cm-acts"><button class="cm-act" id="cvfDone">DONE</button><button class="cm-act" id="cvfSave">SAVE</button><button class="cm-act pri" id="cvfShare">SHARE</button></div></div>`;
    v.hidden = false; requestAnimationFrame(() => v.classList.add('in'));
    const strip = $('#cvStrip'), at = () => Math.round(strip.scrollLeft / strip.clientWidth);
    const paint = () => {
      const i = at(), sh = list[i]; $('#cvN').textContent = V6 ? `${i + 1} / ${list.length}` : `${i + 1} of ${list.length}`; const f = $('#cvFrame'); if (f) f.hidden = !!sh?.video;
      const L = $('#cvL'); if (L) L.textContent = sh?.look || 'Shivo Labs';
      const I = $('#cvI'); if (I && sh) { const m = sh.meta || {}; I.innerHTML = [m.mm && `${m.mm} mm`, m.ap && `ƒ${m.ap}`, m.ss && fmtSS(m.ss), m.iso && `ISO ${m.iso}`, sh.video ? 'VIDEO' : sh.w && `${(sh.w * sh.h / 1e6).toFixed(1)} MP`, sh.raw && 'RAW'].filter(Boolean).map((t) => `<span>${t}</span>`).join(''); }
      const d = new Date(sh?.at || Date.now()); $('#cvD').textContent = `${d.toLocaleDateString([], { day: 'numeric', month: 'short' })} · ${d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
      $$('#cvFilm button').forEach((b) => b.classList.toggle('on', +b.dataset.i === i));
    };
    $$('#cvFilm button').forEach((b) => (b.onclick = () => strip.scrollTo({ left: +b.dataset.i * strip.clientWidth, behavior: 'smooth' })));
    strip.addEventListener('scroll', paint, { passive: true }); paint();
    $('#cvClose').onclick = () => { v.querySelectorAll('video').forEach((x) => x.pause()); v.classList.remove('in'); setTimeout(() => (v.hidden = true), 300); };
    $('#cvPhotos').onclick = () => (openURL ? openURL('photos-redirect://') : null)?.catch?.(() => {});
    const share = async (uri) => { try { const SH = plugin('Share'); if (SH && uri) await SH.share({ files: [uri] }); else toast?.('Sharing isn\'t available here'); } catch {} };
    $('#cvShare').onclick = () => share(list[at()]?.uri);
    // Frames: a printed border with the look and the shot's details, made on the phone; the photo itself stays as it is
    let framed = null, style = 'white';
    const fr = $('#cvFr');
    const make = async () => {
      const s = list[at()]; if (!s?.uri) return;
      $('#cvfWait').hidden = false; $('#cvfImg').style.opacity = '.35';
      const m = s.meta || {}, d = new Date(s.at || Date.now());
      const detail = [m.mm && `${m.mm} mm`, m.ap && `ƒ${m.ap}`, m.ss && fmtSS(m.ss), m.iso && `ISO ${m.iso}`, d.toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' })].filter(Boolean).join('  ·  ');
      try { framed = await E.frameImage({ file: s.uri, style, title: s.look || 'Shivo Labs', detail, mark: 'SHIVO LABS' }); $('#cvfImg').src = framed.url; }
      catch (e) { toast?.('The frame wasn\'t made: ' + (e.message || e)); }
      $('#cvfWait').hidden = true; $('#cvfImg').style.opacity = '1';
    };
    const fb = $('#cvFrame'); if (fb) fb.onclick = () => { fr.hidden = false; haptic('light'); make(); };
    $$('#cvfStyles button').forEach((b) => (b.onclick = () => { style = b.dataset.v; $$('#cvfStyles button').forEach((x) => x.classList.toggle('on', x === b)); haptic('selection'); make(); }));
    $('#cvfDone').onclick = () => { fr.hidden = true; };
    $('#cvfShare').onclick = () => framed && share(framed.file);
    $('#cvfSave').onclick = async () => {
      const N = plugin('ShivoNative'); if (!framed || !N?.saveFromURL) return;
      try { await N.saveFromURL({ url: framed.file, name: 'SL_frame_' + Date.now() + '.jpg', kind: 'media' }); chip('FRAMED COPY SAVED'); haptic('success'); } catch (e) { toast?.(e.message || 'Not saved'); }
    };
  }

  /* ---------- flip between back and front ---------- */
  $('#cmFlip').onclick = async () => {
    if (C.rec || C.busy) return;
    st.facing = st.facing === 'front' ? 'back' : 'front'; st.mm = 26; st.z = null; save(); haptic('light');
    const f = $('#cmFlip'); f.classList.toggle('spin'); cm.classList.add('swap'); setTimeout(() => cm.classList.remove('swap'), 420);
    await E?.stop(); start();
  };

  /* ---------- asking for the camera, and when it is off ---------- */
  function gate(kind, detail) {
    const g = $('#cmGate'); g.hidden = false;
    const T = {
      ask: ['Shivo Labs Camera', 'Film looks, live in the viewfinder. Photos go straight to your Photos.', 'Allow camera', 'iPhone will ask you once.'],
      denied: ['Camera is off', 'Shivo Labs isn\'t allowed to use the camera. Turn on Camera for Shivo Labs in Settings, then come back.', 'Open Settings', ''],
      none: ['No camera here', 'This device has no camera Shivo Labs can use.', '', ''],
      error: ['The camera didn\'t start', detail || 'Something else may be using it. Close other camera apps and try again.', 'Try again', ''],
    }[kind];
    g.innerHTML = `<button class="cm-rb cg-x" id="cgX" aria-label="Close">${ic('x', 20)}</button><div class="cg-in"><span class="cg-ic">${ic('cam', 44)}</span><h2>${T[0]}</h2><p>${esc(T[1])}</p>
      ${T[2] ? `<button class="cg-go" id="cgGo">${T[2]}</button>` : ''}${kind === 'denied' ? '<button class="cg-alt" id="cgAgain">Try again</button>' : ''}<small>${T[3]}</small></div>`;
    const go = $('#cgGo');
    if (go) go.onclick = () => { if (kind === 'denied') return (openURL ? openURL('app-settings:') : Promise.reject()).catch(() => toast?.('Open Settings, then Shivo Labs, then Camera')); localStorage.setItem('sl.cam.asked', '1'); start(); };
    $('#cgX').onclick = () => $('#cmClose').click();
    const again = $('#cgAgain'); if (again) again.onclick = start;
  }

  function paintAll() {
    cm.dataset.grid = st.guide !== 'off' ? '1' : ''; cm.dataset.guide = st.guide; cm.classList.toggle('framed', !!st.framed);
    cm.classList.toggle('full', !aspectNow()); $('#cmLevel').hidden = !st.level; $('#cmHist').hidden = !st.hist;
    cm.dataset.mode = st.mode;
    paintTop(); paintZoom(); paintModes(); paintRow(); paintDate(); paintMods(); E?.setTools?.(toolsFor()); E?.setLook?.(view()); glassFollow();
  }
  paintAll(); paintThumb();

  // the camera stops when the app goes to the background and comes back with it
  document.addEventListener('visibilitychange', () => { if (!C.on) return; if (document.hidden) { stopInt(); if (C.rec) recStop(); E?.stop(); } else start(); });
  setInterval(() => { if (C.on) developDue(); }, 30000);

  return { start, stop, importLook, get on() { return C.on; } };
}
