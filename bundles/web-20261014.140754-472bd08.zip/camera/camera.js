// Shivo Labs Camera (design v4: minimal). One screen, two engines:
//   web    the camera as a web page gets it (older builds, Android): looks developed live on the graphics chip,
//          exposure and white balance applied to the picture, photos from the video stream (about 12 MP).
//   native the ShivoCamera add-on: the real camera through AVFoundation (focus, ISO, shutter, white balance,
//          lenses, RAW, 48 MP, video, stack, night, depth). Its picture is drawn behind this page.
// The screen asks the engine what it can do (caps) and only shows what works.
//
// Layout (iPhone-like, our own look): a few quiet icons on top; the frame; zoom inside the frame; under it the
// shutter row (depth · shutter · more) and the mode pill (photos · modes · flip). "More" opens one glass card
// (flash, timer, aspect, exposure, looks, depth, format, pro, tools); each opens its own small panel in the card.
// Swipe sideways on the picture to change the look. Tap to focus, drag up or down for brightness, hold to lock.
import { LOOKS, lookById } from './looks.js';
import { makeRenderer } from './develop.js';
import { webEngine } from './engine-web.js';
import { nativeEngine } from './engine-native.js';
import * as Roll from './roll.js';
import { show as liveShow, done as liveDone } from '../engine/live.js';

const ASPECTS = [['4:3', 4 / 3], ['3:2', 3 / 2], ['1:1', 1], ['16:9', 16 / 9], ['FULL', 0]];   // height : width, portrait
const MODES = ['VIDEO', 'PHOTO', 'STACK', 'NIGHT'];
const DEF = { look: 'natural', amount: 1, grain: 0, framed: true, glass: false, rev: true, roll: true, rollSize: 24, rollDelay: 'hour', ev: 0, k: 0, tint: 0, aspect: '4:3', flash: 'off', timer: 0, grid: true, level: false,
  hist: false, peak: false, zebra: false, fc: false, mirror: true, loc: false, sound: true, stab: true,
  facing: 'back', mm: 26, depth: false, ap: 2.8, fmt: 'HEIF', mp: 12, mode: 'PHOTO', iso: 0, ss: 0, mf: -1, k4: false, pro: 'iso' };
// outside the frame (native engine): black, no blur (the add-on's frosting turned all the way down).
const STYLE = { blur: 0, saturation: 0, brightness: -1, contrast: 1 };
const SV = {
  x: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
  flashOff: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/><path d="M4 4l16 16"/>', flashAuto: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/>',
  flashOn: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z" fill="currentColor"/>',
  timer: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9.5V13l2.5 1.5M9.5 2.5h5"/>',
  dots: '<g fill="currentColor" stroke="none"><circle cx="6" cy="6" r="1.7"/><circle cx="12" cy="6" r="1.7"/><circle cx="18" cy="6" r="1.7"/><circle cx="6" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="18" cy="12" r="1.7"/><circle cx="6" cy="18" r="1.7"/><circle cx="12" cy="18" r="1.7"/><circle cx="18" cy="18" r="1.7"/></g>',
  moon: '<path d="M19.5 14.6A8 8 0 0 1 9.4 4.5a8 8 0 1 0 10.1 10.1z"/>',
  chev: '<path d="M14.5 5.5 8 12l6.5 6.5"/>',
  ev: '<path d="M12 4.5v7M8.5 8h7M7 18h10"/>',
  aspect: '<path d="M4 9V6.5A2.5 2.5 0 0 1 6.5 4H9M15 4h2.5A2.5 2.5 0 0 1 20 6.5V9M20 15v2.5a2.5 2.5 0 0 1-2.5 2.5H15M9 20H6.5A2.5 2.5 0 0 1 4 17.5V15"/>',
  pro: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
  flip: '<path d="M4 9.5A1.5 1.5 0 0 1 5.5 8h2l1.4-2h6.2l1.4 2h2A1.5 1.5 0 0 1 20 9.5v8a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5z"/><path d="M9 13.2a3.2 3.2 0 0 1 5.6-1.6M15 14a3.2 3.2 0 0 1-5.6 1.6"/><path d="M14.8 10v1.8H13M9.2 17.6v-1.8H11"/>',
  sun: '<circle cx="12" cy="12" r="3.4"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"/>',
  grid: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M9.3 4v16M14.7 4v16M4 9.3h16M4 14.7h16"/>', level: '<path d="M3 12h4M17 12h4M8.5 12.4l7-.8"/>',
  hist: '<path d="M4 19h16"/><path d="M5 19c2-1 2.5-9 4.5-9s2 6 3.5 6 1.8-11 3.5-11 1.5 10 3.5 14"/>', peak: '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>',
  zebra: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 12 12 4M4 18 18 4M9 20l11-11M15 20l5-5"/>', fc: '<circle cx="8" cy="9" r="2.4"/><circle cx="15.5" cy="8" r="2.4"/><circle cx="16" cy="15.5" r="2.4"/><circle cx="8.5" cy="16" r="2.4"/>',
  mirror: '<path d="M12 3v18"/><path d="M8 7 4 12l4 5zM16 7l4 5-4 5z"/>', loc: '<path d="M12 21s-6.5-6.2-6.5-11a6.5 6.5 0 0 1 13 0c0 4.8-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
  sound: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6"/>', stab: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M3 9V5a2 2 0 0 1 2-2h4M21 15v4a2 2 0 0 1-2 2h-4"/>',
  reset: '<path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v4h4"/>',
  film: '<rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 3v18M15 3v18M6 7h3M6 11h3M6 15h3M15 7h3M15 11h3M15 15h3"/>',
  roll: '<rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 3v18M15 3v18M6 7h3M6 11h3M6 15h3M15 7h3M15 11h3M15 15h3"/>',
  frame: '<rect x="3.5" y="3.5" width="17" height="17" rx="2.5"/><rect x="7" y="7" width="10" height="7.5" rx="1"/>',
  rev: '<path d="M4 9a8 8 0 0 1 14.5-3.5M20 4v4h-4"/><path d="M20 15a8 8 0 0 1-14.5 3.5M4 20v-4h4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', pen: '<path d="M14.5 5.5l4 4L8 20H4v-4z"/>', glass: '<rect x="3.5" y="6" width="17" height="12" rx="4"/><path d="M7.5 14.5l4-5M11.5 14.5l2.5-3"/>', looks: '<circle cx="9" cy="9.5" r="5"/><circle cx="15" cy="9.5" r="5"/><circle cx="12" cy="14.8" r="5"/>', framed: '<rect x="3" y="3" width="18" height="18" rx="3"/><rect x="6.5" y="6.5" width="11" height="11" rx="2.5"/>', tools: '<rect x="4" y="4" width="16" height="16" rx="4"/><path d="M12 4v16M4 12h16"/>',
  cam: '<path d="M4 8.5h3l1.8-2.5h6.4L17 8.5h3v10.5H4z"/><circle cx="12" cy="13.5" r="3.6"/>', share: '<path d="M12 3v12M7.5 7.5 12 3l4.5 4.5"/><path d="M5 12v8h14v-8"/>',
  photos: '<rect x="3.5" y="5" width="17" height="14" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="m20 16-4.5-4.5L7 19"/>',
};
// v6: the refined design (raised controls, card header, grouped tools, gallery strip). Shown in the preview
// (phone/docs/design/camera-v6.html) until approved; then it becomes the default.
const V6 = globalThis.SHIVO_CAM_V6 !== false;
// v6 icon set: one 24-point grid, one line weight, each drawn to sit optically centred (based on Lucide, ISC licence)
Object.assign(SV, {
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  flashOff: '<path d="M10.5 4.5 13 2v7h5l-2.4 3.2M12.8 17.4 11 22v-7H6l3.3-4.4"/><path d="m3 3 18 18"/>',
  flashAuto: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  flashOn: '<path d="M13 2 4 14h7l-1 8 9-12h-7z" fill="currentColor"/>',
  timer: '<path d="M10 2h4M12 14l3-3"/><circle cx="12" cy="14" r="8"/>',
  moon: '<path d="M20.5 14.2A8.5 8.5 0 1 1 9.8 3.5a6.6 6.6 0 0 0 10.7 10.7z"/>',
  chev: '<path d="m15 18-6-6 6-6"/>',
  ev: '<circle cx="12" cy="12" r="9"/><path d="M12 6.8v5M9.5 9.3h5M9 15.6h6"/>',
  aspect: '<path d="M4 9V6.5A2.5 2.5 0 0 1 6.5 4H9M15 4h2.5A2.5 2.5 0 0 1 20 6.5V9M20 15v2.5a2.5 2.5 0 0 1-2.5 2.5H15M9 20H6.5A2.5 2.5 0 0 1 4 17.5V15"/>',
  pro: '<path d="M21 6h-7M10 6H3M21 18h-9M8 18H3M21 12H16M12 12H3"/><circle cx="12" cy="6" r="2"/><circle cx="10" cy="18" r="2"/><circle cx="14" cy="12" r="2"/>',
  flip: '<path d="M11 19H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5"/><path d="M13 5h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-5"/><circle cx="12" cy="12" r="3"/><path d="m18 22-3-3 3-3M6 2l3 3-3 3"/>',
  grid: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/>',
  level: '<path d="M2 12h4M18 12h4"/><path d="M8.5 13.2 15.5 10.8"/><circle cx="12" cy="12" r="9" opacity=".35"/>',
  hist: '<path d="M3 3v18h18"/><path d="M7 17c1.5-1 2-7 4-7s2 4 3.5 4 2-9 4.5-9"/>',
  peak: '<circle cx="12" cy="12" r="3"/><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/>',
  zebra: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><path d="M3 11 11 3M3 18 18 3M9 21 21 9M16 21l5-5"/>',
  fc: '<circle cx="13.5" cy="6.5" r=".9" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".9" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".9" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".9" fill="currentColor"/><path d="M12 2a10 10 0 0 0 0 20c.9 0 1.7-.8 1.7-1.7 0-.4-.2-.8-.4-1.1-.3-.3-.4-.7-.4-1.1 0-.9.8-1.7 1.7-1.7h2a5.6 5.6 0 0 0 5.4-5.4C22 6 17.5 2 12 2z"/>',
  mirror: '<path d="M12 3v18"/><path d="m16 7 4 5-4 5z"/><path d="m8 7-4 5 4 5z"/>',
  loc: '<path d="M20 10c0 5-8 12-8 12s-8-7-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
  sound: '<path d="M11 4.7a.7.7 0 0 0-1.2-.5L6.4 7.6A2 2 0 0 1 5 8.2H3a1 1 0 0 0-1 1v5.6a1 1 0 0 0 1 1h2a2 2 0 0 1 1.4.6l3.4 3.4a.7.7 0 0 0 1.2-.5z"/><path d="M16 9a5 5 0 0 1 0 6M19.4 18.4a9 9 0 0 0 0-12.8"/>',
  stab: '<rect x="7" y="7" width="10" height="10" rx="1.5"/><path d="M3 8V5a2 2 0 0 1 2-2h3M16 3h3a2 2 0 0 1 2 2v3M21 16v3a2 2 0 0 1-2 2h-3M8 21H5a2 2 0 0 1-2-2v-3"/>',
  reset: '<path d="M3 12a9 9 0 1 0 9-9 9.8 9.8 0 0 0-6.7 2.7L3 8"/><path d="M3 3v5h5"/>',
  framed: '<rect x="3" y="3" width="18" height="18" rx="3"/><rect x="7" y="7" width="10" height="10" rx="1.5"/>',
  rev: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
  film: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 7.5h4M3 12h18M3 16.5h4M17 7.5h4M17 16.5h4"/>',
  roll: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 7.5h4M3 12h18M3 16.5h4M17 7.5h4M17 16.5h4"/>',
  frame: '<rect x="3" y="3" width="18" height="18" rx="2"/><rect x="6.5" y="6.5" width="11" height="8.5" rx="1"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  pen: '<path d="M21.2 6.8a2.8 2.8 0 0 0-4-4L4 16v4h4z"/><path d="m15 5 4 4"/>',
  looks: '<circle cx="9" cy="9" r="6.5"/><circle cx="15" cy="15" r="6.5"/>',
  share: '<path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="m16 6-4-4-4 4M12 2v13"/>',
  photos: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
  cam: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3z"/><circle cx="12" cy="13" r="3"/>',
  // depth: an aperture; tools: a cog (not a sun)
  ap: '<circle cx="12" cy="12" r="10"/><path d="m14.3 8 5.7 9.9M9.7 8h11.5M7.4 12l5.7-9.9M9.7 16 4 6.1M14.3 16H2.8M16.6 12l-5.7 9.9"/>',
  gear: '<path d="M12.2 2h-.4a2 2 0 0 0-2 2v.2a2 2 0 0 1-1 1.7l-.4.3a2 2 0 0 1-2 0l-.2-.1a2 2 0 0 0-2.7.7l-.2.4a2 2 0 0 0 .7 2.7l.2.1a2 2 0 0 1 1 1.7v.5a2 2 0 0 1-1 1.7l-.2.1a2 2 0 0 0-.7 2.7l.2.4a2 2 0 0 0 2.7.7l.2-.1a2 2 0 0 1 2 0l.4.3a2 2 0 0 1 1 1.7v.2a2 2 0 0 0 2 2h.4a2 2 0 0 0 2-2v-.2a2 2 0 0 1 1-1.7l.4-.3a2 2 0 0 1 2 0l.2.1a2 2 0 0 0 2.7-.7l.2-.4a2 2 0 0 0-.7-2.7l-.2-.1a2 2 0 0 1-1-1.7v-.5a2 2 0 0 1 1-1.7l.2-.1a2 2 0 0 0 .7-2.7l-.2-.4a2 2 0 0 0-2.7-.7l-.2.1a2 2 0 0 1-2 0l-.4-.3a2 2 0 0 1-1-1.7V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
});
const ic = (n, w = 22) => `<svg viewBox="0 0 24 24" style="width:${w}px;height:${w}px">${SV[n]}</svg>`;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// dials: values to pick from, how to show them, and "automatic"
const ISO = [0, 32, 50, 64, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400];
const SS = [0, 1 / 8000, 1 / 4000, 1 / 2000, 1 / 1000, 1 / 500, 1 / 250, 1 / 125, 1 / 60, 1 / 30, 1 / 15, 1 / 8, 1 / 4, 1 / 2, 1];
const WB = [0, 2500, 2800, 3200, 3600, 4000, 4500, 5000, 5600, 6200, 7000, 8000, 9000, 10000];
const MF = [-1, 0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1];
const EVS = [-3, -2.7, -2.3, -2, -1.7, -1.3, -1, -0.7, -0.3, 0, 0.3, 0.7, 1, 1.3, 1.7, 2, 2.3, 2.7, 3];
const APS = [1.4, 1.8, 2, 2.8, 4, 5.6, 8, 11, 16];
const fmtSS = (s) => (!s ? 'AUTO' : s >= 1 ? s + '"' : '1/' + Math.round(1 / s));
const fmtEV = (v) => (Math.abs(v) < 0.05 ? '0.0' : (v > 0 ? '+' : '−') + Math.abs(v).toFixed(1));
const DIALS = {
  ev: { name: 'EV', list: EVS, get: (st) => st.ev, set: (st, v) => (st.ev = v), fmt: fmtEV, auto: (v) => !v },
  iso: { name: 'ISO', list: ISO, get: (st) => st.iso, set: (st, v) => (st.iso = v), fmt: (v) => (v ? String(v) : 'AUTO'), auto: (v) => !v, cap: 'iso', live: (m) => m.iso && String(Math.round(m.iso)) },
  ss: { name: 'SHUTTER', list: SS, get: (st) => st.ss, set: (st, v) => (st.ss = v), fmt: fmtSS, auto: (v) => !v, cap: 'shutter', live: (m) => m.ss && fmtSS(m.ss) },
  wb: { name: 'WB', list: WB, get: (st) => st.k, set: (st, v) => (st.k = v), fmt: (v) => (v ? v + 'K' : 'AUTO'), auto: (v) => !v, cap: 'wb', live: (m) => m.k && Math.round(m.k / 50) * 50 + 'K' },
  mf: { name: 'FOCUS', list: MF, get: (st) => st.mf, set: (st, v) => (st.mf = v), fmt: (v) => (v < 0 ? 'AF' : v === 0 ? 'NEAR' : v === 1 ? 'FAR' : Math.round(v * 100) + '%'), auto: (v) => v < 0, cap: 'focus' },
  ap: { name: 'DEPTH', list: [0, ...APS], get: (st) => (st.depth ? st.ap : 0), set: (st, v) => { st.depth = v > 0; if (v) st.ap = v; }, fmt: (v) => (v ? 'ƒ' + v : 'OFF'), auto: (v) => !v, cap: 'depth' },
};

// opts: { toast, haptic, plugin, openURL }
export function mountCamera(root, { toast, haptic = () => {}, plugin = () => null, openURL } = {}) {
  let st = { ...DEF }; try { Object.assign(st, JSON.parse(localStorage.getItem('sl.cam2') || '{}')); } catch {}
  const save = () => { try { localStorage.setItem('sl.cam2', JSON.stringify(st)); } catch {} };
  if (localStorage.getItem('sl.cam.v') !== '4') { st.look = 'natural'; st.grain = 0; st.amount = 1; st.pro = 'iso'; try { localStorage.setItem('sl.cam.v', '4'); } catch {} save(); }
  if (typeof st.pro !== 'string') st.pro = 'iso';
  if (localStorage.getItem('sl.cam.v5') !== '1') { st.framed = true; st.glass = false; try { localStorage.setItem('sl.cam.v5', '1'); } catch {} save(); }
  st.glass = false;   // no blur anywhere (the add-on's glass stays off)
  Object.assign(st, { ev: 0, iso: 0, ss: 0, k: 0, tint: 0, mf: -1 });   // exposure, white balance and focus start automatic each time
  // Look Studio: your own looks, kept on this phone, listed after ours
  const MINE = 'sl.looks.mine';
  const mine = () => { try { return JSON.parse(localStorage.getItem(MINE) || '[]'); } catch { return []; } };
  function mergeMine() { for (let i = LOOKS.length - 1; i >= 0; i--) if (LOOKS[i].mine) LOOKS.splice(i, 1); LOOKS.push(...mine()); }
  mergeMine();
  const C = { R: Roll.load(), studio: null, on: false, busy: false, rec: false, recT: 0, shots: [], tilt: 0, turn: 0, motion: false, dial: '', panel: '', card: false,
    frame: { top: 0, h: 0, W: 0, H: 0 }, meter: {}, loc: null, locAt: 0, pd: null };

  root.innerHTML = `<div class="cm${V6 ? ' v6' : ''}" id="cm">
    <video id="cmVid" playsinline muted autoplay></video>
    <canvas id="cmGL"></canvas>
    <div class="cm-veil t" id="cmVt"></div><div class="cm-veil b" id="cmVb"></div>
    <div class="cm-frame" id="cmFrame"><canvas id="cmFG"></canvas><div class="cm-grid"><i></i><i></i><i></i><i></i></div><div class="cm-level" id="cmLevel" hidden><b></b><i></i><b></b></div></div>
    <div class="cm-mat" id="cmMat"></div>
    <div class="cm-touch" id="cmTouch"></div>
    <div class="cm-fbox" id="cmFbox"><div class="sq"></div><div class="sun">${ic('sun', 18)}</div><span class="ev" id="cmFev"></span></div>
    <div class="cm-chip" id="cmLock">AE/AF LOCK</div>
    <div class="cm-chip name" id="cmName"></div>
    <div class="cm-hist" id="cmHist" hidden><canvas width="216" height="92"></canvas></div>
    <div class="cm-count" id="cmCount"></div>

    <header class="cm-top">
      <button class="cm-ib" id="cmClose" aria-label="Close">${ic('x', 22)}</button>
      <div class="cm-mid" id="cmMid">
        <button class="cm-ib cm-rot" id="cmFlash" aria-label="Flash"></button>
        <button class="cm-ib cm-rot" id="cmMoon" aria-label="Night" hidden>${ic('moon', 21)}</button>
        <span class="cm-rec" id="cmRec"><i></i><b id="cmRecT">00:00</b></span>
      </div>
      <button class="cm-fmt cm-rot" id="cmFmt" aria-label="Format"></button>
    </header>

    <div class="cm-zoom" id="cmZoom"></div>
    <div class="cm-line" id="cmLine"></div>

    <div class="cm-row" id="cmRow">
      <button class="cm-rb cm-rot" id="cmDepth" aria-label="Depth"><span>ƒ</span></button>
      <button class="cm-shutter" id="cmShot" aria-label="Take photo"><b></b></button>
      <button class="cm-rb cm-rot" id="cmMore" aria-label="Camera controls">${ic('dots', 20)}</button>
    </div>
    <div class="cm-low" id="cmLow">
      <button class="cm-thumb cm-rot" id="cmThumb" aria-label="Photos taken"></button>
      <div class="cm-modes" id="cmModes"><div class="tr" id="cmModesTr"></div></div>
      <button class="cm-rb cm-rot" id="cmFlip" aria-label="Front or back camera">${ic('flip', 24)}</button>
    </div>
    <div class="cm-scrim" id="cmScrim"></div>
    <div class="cm-card" id="cmCard"><div class="gr"></div><div class="in" id="cmCardIn"></div></div>
    <div class="cm-blink" id="cmBlink"></div>
    <div class="cm-ff" id="cmFF"></div>
    <div class="cm-viewer" id="cmViewer" hidden></div>
    <div class="cm-gate" id="cmGate" hidden></div>
  </div>`;
  const $ = (s) => root.querySelector(s), $$ = (s) => [...root.querySelectorAll(s)];
  const cm = $('#cm'), vid = $('#cmVid'), glc = $('#cmGL');

  /* ---------- the engine: native when this build has the camera add-on, else the web camera ---------- */
  let E = null;
  const ctx = { vid, glc, makeRenderer, view: () => view(), onFrame: () => {}, onHist: (h) => drawHist(h), plugin,
    onMeter: (m) => { C.meter = m || {}; if (C.panel === 'pro') C.pd?.paint(); paintTop(); }, onProgress: (p) => progress(p),
    onPress: () => { if (C.on && $('#cmViewer').hidden && $('#cmGate').hidden) $('#cmShot').click(); },
    onControl: (c) => controlled(c) };
  async function pickEngine() {
    if (E) return E;
    const N = await nativeEngine(ctx).catch(() => null);
    E = N || webEngine(ctx);
    cm.classList.toggle('native', E.kind === 'native');
    cm.classList.toggle('glass', E.kind === 'web' || !!E.caps?.()?.glass);
    return E;
  }
  const caps = () => E?.caps?.() || {};
  const modes = () => MODES.filter((m) => m === 'PHOTO' || (caps().modes || []).includes(m));
  const tools = () => caps().tools || [];
  const canDepth = () => !!caps().depth && st.mode === 'PHOTO';
  const view = () => ({ look: C.studio || lookById(st.look), amount: C.studio ? 1 : st.amount, grain: st.grain, ev: st.ev, k: st.k || 5600, tint: st.tint,
    mirror: st.facing === 'front' && st.mirror, zoom: E?.digitalZoom?.(st.mm) || 1, zebra: st.zebra, false: st.fc, peak: st.peak });
  const toolsFor = () => ({ ...st, lookName: lookById(st.look).name, rev: !!st.rev && caps().reversible && !C.R.cur });
  const canRoll = () => E?.kind === 'native' && !!caps().keep;
  const aspectNow = () => (st.mode === 'VIDEO' ? 16 / 9 : (ASPECTS.find((x) => x[0] === st.aspect) || ASPECTS[0])[1]);

  /* ---------- layout: controls keep their places; the frame (chosen aspect) sits under the top icons ---------- */
  function layout() {
    const R = cm.getBoundingClientRect(); if (!R.width) return;
    if (!C.card || !C.geo) {
      const W0 = R.width, H0 = R.height;
      C.geo = { W: W0, H: H0, topBar: $('.cm-top').getBoundingClientRect().bottom - R.top,
        ctl: H0 - parseFloat(getComputedStyle($('#cmRow')).bottom) - $('#cmRow').offsetHeight };   // where the shutter row starts
    }
    const { W, H, topBar, ctl } = C.geo;
    const a = aspectNow(), rowH = $('#cmRow').offsetHeight || 84, shutR = ($('#cmShot').offsetWidth || 78) / 2;
    const fit = E?.kind === 'native' && !!caps().framew;   // builds that can draw the picture narrower than the screen
    let top, h, w = W;
    if (!a) { top = 0; h = H; }
    else {
      // every ratio starts under the top icons, with a black border above it. 4:3 fills the space above the shutter
      // and 1:1 sits in the middle of it; 3:2 runs on behind the shutter; 16:9 (photo and video) is too tall for
      // that, so it gets narrower (black at its sides) and ends just below the shutter, clear of the modes
      const topY = topBar + 10, above = ctl - 4 - topY, maxBottom = ctl + rowH / 2 + shutR + 10;
      const slotH = Math.min(Math.round(W * 4 / 3), above);
      h = Math.round(W * a); top = topY;
      if (h <= slotH) top = topY + Math.round((slotH - h) / 2);
      else if (topY + h > maxBottom && fit) { h = Math.round(maxBottom - topY); w = Math.round(h / a); }
    }
    const side = Math.max(0, Math.round((W - w) / 2));
    const nf = E?.kind === 'native' && !!caps().frame, fr = st.framed && !!a;
    cm.classList.toggle('nframe', nf); cm.classList.toggle('narrow', side > 0);
    C.frame = { top, h, W, H, inset: nf ? (side || (fr ? 12 : 0)) : 0, radius: fr ? 26 : side ? 4 : 0 };
    $('#cmVt').style.height = top + 'px'; $('#cmVb').style.height = Math.max(0, H - top - h) + 'px';
    for (const el of [$('#cmFrame'), $('#cmTouch')]) { el.style.top = top + 'px'; el.style.height = h + 'px'; el.style.left = el.style.right = side + 'px'; }
    const seen = Math.min(top + h, ctl - 6);              // the lowest point of the frame not under the controls
    const zt = seen - 14 - 40;
    $('#cmZoom').style.top = zt + 'px';
    $('#cmLine').style.top = (zt - 34) + 'px';
    const m = $('#cmMat'); m.style.top = top + 'px'; m.style.height = Math.min(h, H - top) + 'px';
    $('#cmFrame').style.setProperty('--under', Math.max(0, top + h - ctl) + 'px');
    const chipTop = Math.max(top + 12, topBar + 6);
    $('#cmLock').style.top = chipTop + 'px'; $('#cmName').style.top = chipTop + 'px'; $('#cmHist').style.top = chipTop + 'px';
    E?.layout?.(C.frame); glassFollow();
  }
  new ResizeObserver(() => layout()).observe(cm);

  // glass: the native engine blurs its picture under these shapes (the page can't blur what is drawn behind it)
  let lastGlass = '', gT = 0;
  function glassRects() {
    if (E?.kind !== 'native' || !caps().glass || !C.on || !st.glass) return;
    const R = cm.getBoundingClientRect(), out = [];
    $$('#cmCard, #cmRow .cm-rb, #cmLow .cm-rb, #cmThumb, #cmModes, #cmZoom').forEach((el) => {
      let o = 1;
      for (let q = el; q && q !== cm; q = q.parentElement) { const cs = getComputedStyle(q); if (cs.display === 'none' || cs.visibility === 'hidden') return; o *= +cs.opacity; }
      if (o < 0.08) return;
      const r = el.getBoundingClientRect(); if (r.bottom <= R.top + 1 || r.top >= R.bottom - 1 || r.width < 2) return;
      out.push({ x: r.left - R.left, y: r.top - R.top, w: r.width, h: r.height, r: Math.min(parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0, r.height / 2, r.width / 2) });
    });
    const key = JSON.stringify(out.map((g) => [g.x, g.y, g.w, g.h].map(Math.round)));
    if (key !== lastGlass) { lastGlass = key; E.setGlass?.(out); }
  }
  function glassFollow(ms = 650) {   // follows the shapes while they move (the card sliding, modes changing)
    if (E?.kind !== 'native' || !caps().glass || !st.glass) return;
    const end = performance.now() + ms; cancelAnimationFrame(gT);
    const f = () => { glassRects(); if (performance.now() < end) gT = requestAnimationFrame(f); }; f();
  }
  const line = (t) => { const e = $('#cmLine'); e.textContent = t; e.classList.add('show'); clearTimeout(line.t); line.t = setTimeout(() => e.classList.remove('show'), 1600); };
  const chip = (t) => { const e = $('#cmName'); e.textContent = t; e.classList.add('on'); clearTimeout(chip.t); chip.t = setTimeout(() => e.classList.remove('on'), 1400); };

  /* ---------- start and stop ---------- */
  async function start() {
    C.on = true; await pickEngine(); paintAll(); layout();
    if (!E.available()) return gate('none');
    if (E.kind === 'web' && !localStorage.getItem('sl.cam.asked')) return gate('ask');
    try {
      if (!modes().includes(st.mode)) st.mode = 'PHOTO';
      await E.start({ facing: st.facing, mm: st.mm, mp: st.mp, mode: st.mode, k4: st.k4 });
      if (!C.on) return E.stop();
      $('#cmGate').hidden = true;
      if (!modes().includes(st.mode)) st.mode = 'PHOTO';
      if (!lensList().some((l) => l.mm === st.mm)) st.mm = (lensList().find((l) => l.zoom === 1) || lensList()[0]).mm;
      E.setStyle?.(STYLE); if (!st.glass) E.setGlass?.([]);
      await applyAll(); paintAll(); layout(); syncControls();
      developDue(); tips();
    } catch (e) {
      console.error(e);
      if (e.name === 'NotAllowedError' || e.name === 'SecurityError' || /denied|not allowed/i.test(e.message || '')) gate('denied');
      else gate('error', e.message);
    }
  }
  async function stop() { C.on = false; if (C.rec) await recStop().catch(() => {}); E?.stop(); closeCard(); }
  // after a restart, the camera gets every setting again
  async function applyAll() {
    const c = caps();
    await E.setLens?.(st.mm);
    if (c.iso || c.shutter || st.ev) await E.setExposure?.({ iso: st.iso, ss: st.ss, ev: st.ev });
    if (c.wb && E.kind === 'native') await E.setWB?.({ k: st.k, tint: st.tint });
    if (c.focus) await E.setFocus?.({ pos: st.mf });
    if (c.depth) E.setDepth?.({ on: st.depth && st.mode === 'PHOTO', ap: st.ap });
    E.setTools?.(toolsFor()); E.setLook?.(view());
  }

  /* ---------- live helpers ---------- */
  function drawHist(H) {
    if (!st.hist || !H) return;
    const cv = $('#cmHist canvas'), x = cv.getContext('2d'), W = cv.width, Ht = cv.height, B = H[0].length;
    const max = Math.max(...H.map((a) => Math.max(...Array.from(a).slice(1, B - 1)))) || 1;
    x.clearRect(0, 0, W, Ht); x.globalCompositeOperation = 'lighter';
    [['rgba(232,84,70,.55)', 0], ['rgba(110,200,120,.55)', 1], ['rgba(80,130,235,.6)', 2]].forEach(([col, c]) => {
      x.beginPath(); x.moveTo(0, Ht);
      for (let i = 0; i < B; i++) x.lineTo(i / (B - 1) * W, Ht - Math.min(1, H[c][i] / max) * (Ht - 4));
      x.lineTo(W, Ht); x.closePath(); x.fillStyle = col; x.fill();
    });
    x.globalCompositeOperation = 'source-over'; x.beginPath();
    for (let i = 0; i < B; i++) x.lineTo(i / (B - 1) * W, Ht - Math.min(1, H[3][i] / max) * (Ht - 4));
    x.strokeStyle = 'rgba(255,255,255,.85)'; x.lineWidth = 2; x.stroke();
  }
  function progress(p) { $('#cmShot').style.setProperty('--p', clamp(p, 0, 1) + 'turn'); }

  /* ---------- top: close · flash, night, recording time · format ---------- */
  const flashIcon = () => ic(st.flash === 'on' ? 'flashOn' : st.flash === 'auto' ? 'flashAuto' : 'flashOff', 21);
  function fmtParts() {
    const c = caps();
    if (st.mode === 'VIDEO') return [st.k4 && c.k4 ? '4K' : 'HD', '30'];
    if (st.mode !== 'PHOTO') return [st.fmt === 'JPEG' ? 'JPEG' : (c.formats || []).includes('HEIF') ? 'HEIF' : 'JPEG', '12'];
    const raw = st.fmt.startsWith('RAW') && c.raw;
    const f = raw ? (st.fmt === 'RAW+' ? 'RAW+' : 'RAW') : (c.formats || ['JPEG']).includes(st.fmt) ? st.fmt : 'JPEG';
    return [f, String(raw ? rawMP() : E?.mpFor?.(st) || st.mp)];
  }
  const rawMP = () => caps().rawMP || 12;   // Bayer RAW is 12 MP on iPhones without ProRAW
  function paintTop() {
    const fl = $('#cmFlash'), video = st.mode === 'VIDEO';
    fl.hidden = video || st.mode !== 'PHOTO'; fl.innerHTML = flashIcon(); fl.classList.toggle('lit', st.flash === 'on');
    const moon = $('#cmMoon'), night = modes().includes('NIGHT');
    moon.hidden = !night || video || !(st.mode === 'NIGHT' || (st.mode === 'PHOTO' && C.meter.dark));
    moon.classList.toggle('lit', st.mode === 'NIGHT');
    const [f, s] = fmtParts(), roll = C.R.cur && st.mode !== 'VIDEO';
    $('#cmFmt').innerHTML = roll ? `${ic('film', 14)}<b>ROLL</b><small>${Roll.left(C.R.cur)}</small>` : `<b>${f}</b><small>${s}</small>`;
    $('#cmFmt').classList.toggle('raw', !roll && f.startsWith('RAW')); $('#cmFmt').classList.toggle('roll', !!roll);
  }
  $('#cmFlash').onclick = () => { const opts = caps().flash ? ['off', 'auto', 'on'] : ['off', 'on']; st.flash = opts[(opts.indexOf(st.flash) + 1) % opts.length]; haptic('selection'); save(); paintTop(); chip('FLASH ' + st.flash.toUpperCase()); };
  $('#cmMoon').onclick = () => setMode(st.mode === 'NIGHT' ? 'PHOTO' : 'NIGHT');
  $('#cmFmt').onclick = () => openCard(C.R.cur && st.mode !== 'VIDEO' ? 'roll' : 'format');
  $('#cmClose').onclick = () => root.dispatchEvent(new CustomEvent('camera-close', { bubbles: true }));

  /* ---------- zoom inside the frame: ultra-wide · main (tap again: 28, 35, 50) · 2x ---------- */
  const lensList = () => E?.lenses?.(st.facing) || [{ mm: 26, kind: 'optical', zoom: 1 }];
  const MAIN = [26, 28, 35, 50];
  function paintZoom() {
    const L = lensList(), has = (m) => L.some((l) => l.mm === m);
    const z = $('#cmZoom');
    if (st.facing === 'front' || L.length < 2) { z.innerHTML = ''; z.hidden = true; return; }
    z.hidden = false;
    const fam = MAIN.filter(has), inFam = fam.includes(st.mm);
    const btn = (mm, label, on) => `<button class="${on ? 'on' : ''}" data-mm="${mm}"><span>${on ? `${label}<small>mm</small>` : label}</span></button>`;
    z.innerHTML = (has(13) ? btn(13, '13', st.mm === 13) : '') + btn(inFam ? st.mm : 26, inFam ? String(st.mm) : '26', inFam) + (has(52) ? btn(52, '52', st.mm === 52) : '');
    $$('#cmZoom button').forEach((b) => (b.onclick = () => {
      let mm = +b.dataset.mm;
      if (b.classList.contains('on') && fam.includes(mm)) mm = fam[(fam.indexOf(mm) + 1) % fam.length];   // tap the main again: the next crop
      else if (b.classList.contains('on')) return;
      setLens(mm);
    }));
  }
  async function setLens(mm) {
    if (mm === st.mm) return;
    st.mm = mm; save(); haptic('selection'); paintZoom(); paintTop();
    const l = lensList().find((x) => x.mm === mm);
    chip(`${mm} MM${l?.kind === 'crop' ? ' · CROP' : ''}`);
    await E.setLens?.(mm); E.setLook?.(view());
  }

  /* ---------- pro: one panel in the card; swipe the names, the dial below follows (sage = automatic) ---------- */
  const PRO = ['ev', 'iso', 'ss', 'wb', 'mf'];
  const proKeys = () => PRO.filter((k) => !DIALS[k].cap || caps()[DIALS[k].cap]);
  const manual = () => !!(st.iso || st.ss || st.k || st.mf >= 0);
  async function toAuto(k) {
    const D = DIALS[k];
    D.set(st, D.list[k === 'ev' ? EVS.indexOf(0) : 0]); if (k === 'wb') st.tint = 0;
    save(); C.pd?.paint(); await applyDial(k); chip(k === 'ev' ? 'EXPOSURE 0' : k === 'ap' ? 'DEPTH OFF' : 'AUTOMATIC'); haptic('light');
  }
  async function applyDial(k) {
    if (k === 'ev' || k === 'iso' || k === 'ss') await E.setExposure?.({ iso: st.iso, ss: st.ss, ev: st.ev });
    else if (k === 'wb') await E.setWB?.({ k: st.k, tint: st.tint });
    else if (k === 'mf') await E.setFocus?.({ pos: st.mf });
    else if (k === 'ap') { E.setDepth?.({ on: st.depth, ap: st.ap }); paintRow(); }
    E.setLook?.(view());
  }

  // a dial: a ruler that slides under a fixed needle; drag sideways. host gets the value and the ruler.
  const STEP = 16;
  function dial(host, k, after) {
    const D = DIALS[k], idx = () => Math.max(0, D.list.indexOf(D.get(st)));
    host.innerHTML = `<div class="cm-val" id="dv"></div><div class="cm-ruler"><div class="tk">${D.list.map((v, i) => `<i class="${i % 3 === 0 ? 'M' : ''}${D.auto(v) ? ' A' : ''}"></i>`).join('')}</div><b class="nd"></b></div>`;
    const tk = host.querySelector('.tk'), val = host.querySelector('.cm-val');
    const paint = () => { tk.style.transform = `translateX(${-idx() * STEP - STEP / 2}px)`; const v = D.get(st); val.textContent = D.auto(v) && D.live?.(C.meter) ? D.live(C.meter) : D.fmt(v); val.classList.toggle('auto', D.auto(v)); };
    paint();
    const ru = host.querySelector('.cm-ruler'); let x0 = null, i0 = 0, last = -1, busy = false;
    ru.onpointerdown = (e) => { x0 = e.clientX; i0 = idx(); ru.setPointerCapture(e.pointerId); };
    ru.onpointermove = async (e) => {
      if (x0 == null) return;
      const i = clamp(i0 - Math.round((e.clientX - x0) / STEP), 0, D.list.length - 1);
      if (i === last) return; last = i; D.set(st, D.list[i]); haptic('selection'); paint(); after?.();
      if (k === 'ev') paintSun();
      if (!busy) { busy = true; await applyDial(k).catch(() => {}); busy = false; }
    };
    ru.onpointerup = ru.onpointercancel = () => { if (x0 == null) return; x0 = null; last = -1; save(); applyDial(k); };
    val.ondblclick = () => toAuto(k).then(paint);
    return { paint };
  }

  /* ---------- tap: focus; then drag up or down for brightness; hold: lock; swipe sideways: the next look ---------- */
  const fb = $('#cmFbox');
  const paintSun = () => { fb.style.setProperty('--sy', -st.ev * 14 + 'px'); $('#cmFev').textContent = st.ev ? fmtEV(st.ev) : ''; };
  (() => {
    const t = $('#cmTouch'); let hideT = 0, holdT = 0, ev0 = 0, y0 = null, x0 = 0, how = '', locked = false, active = false, held = false;
    const pts = new Map(); let pinch = null;
    const lensSteps = () => lensList().map((l) => l.mm).sort((a, b) => a - b);
    t.addEventListener('pointerdown', (e) => {
      pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pts.size === 2) {
        clearTimeout(holdT); how = 'pinch'; const [a, b] = [...pts.values()];
        const L = lensSteps(); pinch = { d0: Math.hypot(a[0] - b[0], a[1] - b[1]) || 1, i0: Math.max(0, L.indexOf(st.mm)), L };
      }
    });
    t.addEventListener('pointermove', (e) => {
      if (!pts.has(e.pointerId)) return; pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (!pinch || pts.size < 2) return;
      const [a, b] = [...pts.values()], r = Math.hypot(a[0] - b[0], a[1] - b[1]) / pinch.d0;
      const i = clamp(pinch.i0 + Math.round(Math.log(r) / Math.log(1.3)), 0, pinch.L.length - 1);
      if (pinch.L[i] !== st.mm) setLens(pinch.L[i]);
    });
    const lift = (e) => { pts.delete(e.pointerId); if (pts.size < 2 && pinch) { pinch = null; how = 'pinch'; } };
    t.addEventListener('pointerup', lift); t.addEventListener('pointercancel', lift);
    const show = () => { fb.classList.add('in'); clearTimeout(hideT); hideT = setTimeout(() => { if (!locked) { fb.classList.remove('in'); active = false; } }, 3200); };
    const place = (x, y) => {
      fb.style.left = x + 'px'; fb.style.top = y + 'px'; fb.classList.remove('in'); void fb.offsetWidth;
      const f = C.frame; E.focusAt?.({ x: x / f.W, y: y / f.H }); haptic('light'); active = true; paintSun(); show();
    };
    const at = (e) => { const r = cm.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    t.addEventListener('pointerdown', (e) => {
      if (!E?.running?.()) return;
      y0 = e.clientY; x0 = e.clientX; ev0 = st.ev; how = ''; held = false; t.setPointerCapture(e.pointerId);
      const [x, y] = at(e);
      holdT = setTimeout(() => {
        held = true; place(x, y); locked = true; $('#cmLock').classList.add('on'); clearTimeout(hideT); E.lock?.(true); haptic('medium');
      }, 600);
    });
    t.addEventListener('pointermove', (e) => {
      if (y0 == null) return;
      const dx = e.clientX - x0, dy = e.clientY - y0;
      if (how === 'pinch') return;
      if (!how && Math.hypot(dx, dy) > 9) { clearTimeout(holdT); how = Math.abs(dx) > Math.abs(dy) ? 'look' : active ? 'ev' : 'none'; }
      if (how !== 'ev') return;
      const v = Math.round(clamp(ev0 - dy / 40, -3, 3) * 10) / 10;
      if (v !== st.ev) { st.ev = v; paintSun(); C.pd?.paint(); E.setExposure?.({ iso: st.iso, ss: st.ss, ev: st.ev }); E.setLook?.(view()); }
      show();
    });
    const end = (e) => {
      clearTimeout(holdT); if (y0 == null) return;
      const dx = e.clientX - x0;
      if (how === 'pinch') { if (!pts.size) y0 = null; return; }
      if (!how && !held) {
        if (locked) { locked = false; $('#cmLock').classList.remove('on'); E.lock?.(false); }
        const [x, y] = at(e); place(x, y);
      } else if (how === 'look' && Math.abs(dx) > 40) nextLook(dx < 0 ? 1 : -1);
      else if (how === 'ev') save();
      y0 = null;
    };
    t.addEventListener('pointerup', end); t.addEventListener('pointercancel', () => { clearTimeout(holdT); y0 = null; });
  })();
  function nextLook(d) { const i = LOOKS.findIndex((l) => l.id === st.look); setLook(LOOKS[(i + d + LOOKS.length) % LOOKS.length].id); }
  // the Camera Control button (iPhone 16 and later) offers the looks and depth; it tells us what was picked
  // Only when what it offers changes (the list of looks, depth on or off): moving the button's own picker from here
  // crashed some builds, and the button keeps its own place anyway.
  let sentControls = '';
  function syncControls() {
    const o = { looks: LOOKS.map((l) => l.name), look: Math.max(0, LOOKS.findIndex((l) => l.id === st.look)), depth: canDepth() && st.depth, ap: st.ap };
    const key = o.looks.join('|') + '#' + o.depth;
    if (key === sentControls || !caps().controls2) return;   // controls2: builds where the button's picker is changed safely
    sentControls = key; E?.setControls?.(o);
  }
  function controlled(c) {
    if (typeof c?.look === 'number' && LOOKS[c.look]) setLook(LOOKS[c.look].id, true);
    if (typeof c?.ap === 'number') { st.ap = Math.round(c.ap * 10) / 10; st.depth = true; save(); E.setDepth?.({ on: true, ap: st.ap }); paintRow(); if (C.panel === 'depth') paintCard(); }
  }
  function setLook(id, fromButton) {
    if (C.R.cur && id !== C.R.cur.look) { chip('LOOK SET FOR THIS ROLL'); return; }
    if (st.look !== id) { haptic('selection'); chip(lookById(id).name.toUpperCase()); }
    st.look = id; save(); E?.setLook?.(view()); E?.setTools?.(toolsFor()); if (!fromButton) syncControls();
    if (C.panel === 'looks') paintCard();
  }

  /* ---------- modes: a glass pill, the chosen one in the middle; swipe it or tap one ---------- */
  function paintModes() {
    const M = modes(), el = $('#cmModes'), tr = $('#cmModesTr');
    el.hidden = M.length < 2;
    tr.innerHTML = M.map((m) => `<button data-m="${m}" class="${m === st.mode ? 'on' : ''}">${m}</button>`).join('');
    $$('#cmModesTr button').forEach((b) => (b.onclick = () => { if (Date.now() - (C.swiped || 0) > 400) setMode(b.dataset.m); }));
    requestAnimationFrame(() => {
      const on = tr.querySelector('.on'); if (!on) return;
      tr.style.transform = `translateX(${el.clientWidth / 2 - (on.offsetLeft + on.offsetWidth / 2)}px)`;
    });
  }
  (() => {   // the lower area: swipe up for the card
    const low = [$('#cmLow'), $('#cmRow')]; let p0 = null;
    low.forEach((el) => {
      el.addEventListener('pointerdown', (e) => { p0 = [e.clientX, e.clientY]; });
      el.addEventListener('pointerup', (e) => {
        if (!p0) return; const dx = e.clientX - p0[0], dy = e.clientY - p0[1]; p0 = null;
        if (dy < -40 && Math.abs(dy) > Math.abs(dx) * 1.3 && !C.card && !C.rec) { C.swiped = Date.now(); openCard(''); }
      });
    });
  })();
  (() => {
    const el = $('#cmModes'); let x0 = null, y0 = 0;
    el.addEventListener('pointerdown', (e) => { x0 = e.clientX; y0 = e.clientY; });
    el.addEventListener('pointerup', (e) => {
      if (x0 == null) return; const dx = e.clientX - x0, dy = e.clientY - y0; x0 = null;
      if (Math.abs(dx) < 30 || Math.abs(dy) > Math.abs(dx)) return;
      const M = modes(), i = M.indexOf(st.mode); setMode(M[clamp(i + (dx < 0 ? 1 : -1), 0, M.length - 1)]);
    });
  })();
  async function setMode(m) {
    if (m === st.mode || C.rec || C.busy) return;
    const was = st.mode; st.mode = m; save(); haptic('selection');
    chip({ VIDEO: 'VIDEO', PHOTO: 'PHOTO', STACK: 'STACK · FRAMES MERGED', NIGHT: 'NIGHT · HOLD STILL' }[m]);
    if (m === 'VIDEO' || was === 'VIDEO') await E.setMode?.({ mode: m, k4: st.k4 });
    if (caps().depth) E.setDepth?.({ on: st.depth && m === 'PHOTO', ap: st.ap });
    closeCard(); paintAll(); layout(); syncControls();
  }

  /* ---------- the shutter row and the lower row ---------- */
  function paintRow() {
    const d = $('#cmDepth'), ok = canDepth();
    d.hidden = !ok; d.classList.toggle('lit', ok && st.depth);
    d.innerHTML = V6 ? `${ic('ap', 22)}${ok && st.depth ? `<small>ƒ${st.ap}</small>` : ''}` : ok && st.depth ? `<span>ƒ</span><small>${st.ap}</small>` : '<span>ƒ</span>';
    d.classList.toggle('num', ok && st.depth);
    const s = $('#cmShot');
    s.classList.toggle('vid', st.mode === 'VIDEO'); s.classList.toggle('stack', st.mode === 'STACK' || st.mode === 'NIGHT');
    s.classList.toggle('raw', st.mode === 'PHOTO' && fmtParts()[0].startsWith('RAW'));
    s.setAttribute('aria-label', st.mode === 'VIDEO' ? (C.rec ? 'Stop recording' : 'Record video') : 'Take photo');
    $('#cmMore').classList.toggle('on', C.card);
  }
  $('#cmDepth').onclick = () => {
    st.depth = !st.depth; if (st.depth && !st.ap) st.ap = 2.8; save(); haptic('selection');
    E.setDepth?.({ on: st.depth, ap: st.ap }); chip(st.depth ? 'DEPTH ƒ' + st.ap : 'DEPTH OFF'); paintRow(); syncControls();
    if (C.panel === 'depth') paintCard();
  };
  $('#cmMore').onclick = () => (C.card ? closeCard() : openCard(''));

  /* ---------- the card: everything else, in one glass sheet ---------- */
  function items() {
    const c = caps(), M = st.mode, photo = M === 'PHOTO';
    const [f, s] = fmtParts();
    return [
      photo && { k: 'flash', n: 'FLASH', i: flashIcon(), on: st.flash !== 'off' },
      M !== 'VIDEO' && { k: 'timer', n: 'TIMER', i: st.timer ? `<b class="tx">${st.timer}s</b>` : ic('timer', 22), on: !!st.timer },
      M !== 'VIDEO' && { k: 'aspect', n: 'ASPECT', i: `<span class="asp">${ic('aspect', 30)}<b>${st.aspect === 'FULL' ? 'FULL' : st.aspect}</b></span>` },
      { k: 'ev', n: 'EXPOSURE', i: Math.abs(st.ev) > 0.05 ? `<b class="tx">${fmtEV(st.ev)}</b>` : ic('ev', 22), on: Math.abs(st.ev) > 0.05 },
      { k: 'looks', n: 'LOOKS', i: ic('looks', 24), on: st.look !== 'natural' },
      canRoll() && st.roll !== false && M !== 'VIDEO' && { k: 'roll', n: 'FILM ROLL', i: C.R.cur ? `<b class="tx">${Roll.left(C.R.cur)}</b>` : ic('film', 22), on: !!C.R.cur },
      canDepth() && { k: 'depth', n: 'DEPTH', i: V6 ? (st.depth ? `<b class="tx">ƒ${st.ap}</b>` : ic('ap', 22)) : `<b class="tx f">ƒ${st.depth ? st.ap : ''}</b>`, on: st.depth },
      { k: 'format', n: M === 'VIDEO' ? 'QUALITY' : 'FORMAT', i: `<b class="tx two">${f}<small>${s}</small></b>` },
      proKeys().length > 1 && { k: 'pro', n: 'PRO', i: ic('pro', 22), on: manual() },
      { k: 'tools', n: 'TOOLS', i: ic('tools', 22) },
    ].filter(Boolean).slice(0, 12);
  }
  const TITLE = { flash: 'FLASH', timer: 'TIMER', aspect: 'ASPECT', ev: 'EXPOSURE', looks: 'LOOKS', depth: 'DEPTH', format: 'FORMAT', tools: 'TOOLS', pro: 'PRO', roll: 'FILM ROLL', studio: 'LOOK STUDIO' };
  function paintCard() {
    const inEl = $('#cmCardIn'), p = C.panel;
    if (!p) {
      const tile = (x) => `<button data-k="${x.k}" class="${x.on ? 'on' : ''}"><span class="o">${x.i}</span><b>${x.n}</b></button>`;
      if (V6) {
        const [f, s2] = fmtParts();
        inEl.innerHTML = `<div class="cm-hd"><button class="cm-hdb" data-k="format"><b>${f}</b><small>${s2}</small></button><span class="cm-hdt">${{ VIDEO: 'VIDEO', STACK: 'STACK', NIGHT: 'NIGHT' }[st.mode] || 'PHOTO'}</span><button class="cm-hdb ic" data-k="tools" aria-label="Tools">${ic('gear', 19)}</button></div>
          <div class="cm-grid9 v6">${items().filter((x) => x.k !== 'format' && x.k !== 'tools').map(tile).join('')}</div>`;
      } else inEl.innerHTML = `<div class="cm-grid9">${items().map(tile).join('')}</div>`;
      $$('#cmCardIn .cm-grid9 button, #cmCardIn .cm-hdb').forEach((b) => (b.onclick = () => {
        haptic('selection');
        C.panel = b.dataset.k; paintCard();
      }));
      return sizeCard();
    }
    const side = p === 'ev' || p === 'pro' ? '<button class="cm-auto" id="cmAuto">AUTO</button>' : '<span></span>';
    const head = `<div class="cm-ph"><button class="cm-back" id="cmBack" aria-label="Back">${ic('chev', 20)}</button><h4>${p === 'format' && st.mode === 'VIDEO' ? 'QUALITY' : TITLE[p]}</h4>${side}</div>`;
    let body = '';
    const opts = (list, cur, key) => `<div class="cm-opts" data-k="${key}">${list.map(([v, label, icon]) => `<button data-v="${v}" class="${String(cur) === String(v) ? 'on' : ''}"><span class="o">${icon || `<b class="tx">${label}</b>`}</span><b>${label.toUpperCase()}</b></button>`).join('')}</div>`;
    if (p === 'flash') body = opts([['off', 'Off', ic('flashOff', 22)], ...(caps().flash ? [['auto', 'Auto', ic('flashAuto', 22)]] : []), ['on', 'On', ic('flashOn', 22)]], st.flash, 'flash');
    else if (p === 'timer') body = opts([['0', 'Off', ic('timer', 22)], ['3', '3 s'], ['10', '10 s']], st.timer, 'timer');
    else if (p === 'aspect') body = `<div class="cm-chips" data-k="aspect">${ASPECTS.map(([a]) => `<button data-v="${a}" class="${st.aspect === a ? 'on' : ''}">${a}</button>`).join('')}</div>`;
    else if (p === 'ev') body = `<div class="cm-pd" id="cmPD"></div>`;
    else if (p === 'depth') body = `<div class="cm-pd" id="cmPD"></div><p class="cm-note">The subject stays sharp, the rest softens. Lower ƒ, more blur.</p>`;
    else if (p === 'pro') { if (!proKeys().includes(st.pro)) st.pro = proKeys()[0]; body = `<div class="cm-sel" id="cmSel"><div class="tr">${proKeys().map((k) => `<button data-d="${k}" class="${k === st.pro ? 'on' : ''}">${DIALS[k].name}</button>`).join('')}</div></div><div class="cm-pd" id="cmPD"></div>`; }
    else if (p === 'roll') body = rollBody();
    else if (p === 'studio') body = studioBody();
    else if (p === 'looks') body = `<div class="cm-sws" id="cmSws">${LOOKS.map((l) => `<button data-look="${l.id}" class="${l.id === st.look ? 'on' : ''}"><span class="sw" style="background:linear-gradient(135deg,${l.sw[0]} 0 50%,${l.sw[1]} 50%)"></span><b>${esc(l.name.split(' ')[0])}</b></button>`).join('')}</div>
      <div class="cm-slider"><span>STRENGTH</span><input type="range" min="0" max="100" value="${Math.round(st.amount * 100)}" id="cmAmt"><b>${Math.round(st.amount * 100)}</b></div>
      <div class="cm-slider"><span>GRAIN</span><input type="range" min="0" max="200" value="${Math.round(st.grain * 100)}" id="cmGr"><b>${Math.round(st.grain * 100)}</b></div>
      <div class="cm-acts"><button class="cm-act" id="cmNewLook">${ic('plus', 16)}NEW LOOK</button>${lookById(st.look).mine ? `<button class="cm-act" id="cmEditLook">${ic('pen', 16)}EDIT</button>` : ''}</div>`;
    else if (p === 'format') body = formatBody();
    else if (p === 'tools') body = toolsBody();
    inEl.innerHTML = head + `<div class="cm-pb">${body}</div>`;
    C.pd = null;
    $('#cmBack').onclick = () => { const was = C.panel; C.panel = was === 'studio' ? 'looks' : ''; C.pd = null; if (was === 'studio') endStudio(); paintCard(); };
    const au = $('#cmAuto'); if (au) au.onclick = () => toAuto(p === 'ev' ? 'ev' : st.pro);
    wirePanel(p);
    sizeCard();
  }
  function formatBody() {
    const c = caps();
    if (st.mode === 'VIDEO') return `<div class="cm-chips" data-k="k4"><button data-v="0" class="${st.k4 && c.k4 ? '' : 'on'}">HD 1080p</button><button data-v="1" class="${st.k4 && c.k4 ? 'on' : ''}${c.k4 ? '' : ' off'}">4K</button></div><p class="cm-note">16:9, 30 frames a second, with your look and sound.</p>`;
    if (st.mode !== 'PHOTO') return `<div class="cm-chips" data-k="fmt">${['HEIF', 'JPEG'].filter((f) => (c.formats || ['JPEG']).includes(f)).map((f) => `<button data-v="${f}" class="${(st.fmt === 'JPEG' ? 'JPEG' : 'HEIF') === f ? 'on' : ''}">${f}</button>`).join('')}</div><p class="cm-note">${st.mode === 'NIGHT' ? 'Night' : 'Stack'} merges several 12 MP frames into one clean photo.</p>`;
    const F = ['RAW+', 'RAW', 'HEIF', 'JPEG'].filter((f) => (f.startsWith('RAW') ? c.raw : (c.formats || ['JPEG']).includes(f)));
    const M = [12, 24, 48].filter((m) => (c.mp || [12]).includes(m)), raw = st.fmt.startsWith('RAW') && c.raw, [f, sz] = fmtParts();
    const say = raw ? `RAW files from this iPhone are ${rawMP()} MP (48 MP RAW is ProRAW, on Pro iPhones only).` : st.fmt === 'JPEG' ? 'With your look; opens everywhere.' : 'With your look; small files.';
    return `<div class="cm-big">${f === 'RAW+' ? 'RAW+HEIF' : f}<small>${sz} MP</small></div>
      <div class="cm-chips" data-k="fmt">${F.map((x) => `<button data-v="${x}" class="${st.fmt === x ? 'on' : ''}">${x}</button>`).join('')}</div>
      ${M.length > 1 ? `<div class="cm-chips" data-k="mp">${M.map((m) => `<button data-v="${m}" class="${(raw ? rawMP() : +st.mp) === m ? 'on' : ''}${raw && m !== rawMP() ? ' off' : ''}">${m} MP</button>`).join('')}</div>` : ''}
      <p class="cm-note">${say}</p>`;
  }
  const TOOLS = [['framed', 'Framed'], ['rev', 'Reversible'], ['roll', 'Film roll'], ['grid', 'Grid'], ['level', 'Level'], ['hist', 'Histogram'], ['peak', 'Peaking'], ['zebra', 'Zebra'], ['fc', 'False colour'],
    ['mirror', 'Mirror selfie'], ['loc', 'Location'], ['sound', 'Shutter sound'], ['stab', 'Stabilise video'], ['reset', 'Reset']];
  const GROUPS = [['GUIDES', ['grid', 'level', 'hist']], ['FOCUS AND EXPOSURE', ['peak', 'zebra', 'fc']], ['CAPTURE', ['framed', 'rev', 'roll', 'loc', 'sound', 'stab', 'mirror']]];
  function toolsBody() {
    const T = tools(), ok = (k) => (k === 'rev' ? !!caps().reversible : k === 'roll' ? canRoll() : !['loc', 'sound', 'stab'].includes(k) || T.includes(k));
    if (V6) {
      const name = Object.fromEntries(TOOLS);
      return `<div class="cm-list">${GROUPS.map(([g, ks]) => { const rows = ks.filter(ok); return rows.length ? `<h5>${g}</h5><div class="cm-grp">${rows.map((k) => `<button class="cm-li${st[k] ? ' on' : ''}" data-k="${k}"><span class="i">${ic(k, 18)}</span><b>${name[k]}</b><i class="tg"></i></button>`).join('')}</div>` : ''; }).join('')}
        <button class="cm-reset" data-k="reset">${ic('reset', 16)}RESET THE CAMERA</button></div>`;
    }
    return `<div class="cm-grid9 cm-tools">${TOOLS.filter(([k]) => ok(k)).map(([k, n]) => `<button class="${k !== 'reset' && st[k] ? 'on' : ''}" data-k="${k}"><span class="o">${ic(k, 22)}</span><b>${n.toUpperCase()}</b></button>`).join('')}</div>`;
  }
  function wirePanel(p) {
    $$('#cmCardIn .cm-opts, #cmCardIn .cm-chips').forEach((g) => g.querySelectorAll('button').forEach((b) => (b.onclick = async () => {
      const k = g.dataset.k, v = b.dataset.v;
      if (b.classList.contains('off')) { if (k === 'mp') line(`RAW is ${rawMP()} MP on this iPhone. Choose HEIF or JPEG for ${v} MP.`); return; }
      haptic('selection');
      if (k === 'flash') st.flash = v;
      else if (k === 'timer') st.timer = +v;
      else if (k === 'aspect') { st.aspect = v; cm.classList.toggle('full', !aspectNow()); layout(); }
      else if (k === 'fmt') st.fmt = v;
      else if (k === 'mp') { st.mp = +v; E.setResolution?.(+v); }
      else if (k === 'k4') { st.k4 = v === '1'; await E.setMode?.({ mode: 'VIDEO', k4: st.k4 }); }
      else if (k === 'rsize') st.rollSize = +v;
      else if (k === 'rdelay') st.rollDelay = v;
      save(); paintAll(); paintCard();
    })));
    if (p === 'ev') C.pd = dial($('#cmPD'), 'ev');
    if (p === 'depth') C.pd = dial($('#cmPD'), 'ap', () => paintRow());
    if (p === 'pro') {
      C.pd = dial($('#cmPD'), st.pro);
      const sel = $('#cmSel'), tr = sel.querySelector('.tr'), keys = proKeys();
      const centre = () => { const on = tr.querySelector('.on'); if (on) tr.style.transform = `translateX(${sel.clientWidth / 2 - (on.offsetLeft + on.offsetWidth / 2)}px)`; };
      const pick = (k) => { if (!k || k === st.pro) return; st.pro = k; save(); haptic('selection'); tr.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x.dataset.d === k)); centre(); C.pd = dial($('#cmPD'), k); };
      requestAnimationFrame(centre);
      tr.querySelectorAll('button').forEach((x) => (x.onclick = () => pick(x.dataset.d)));
      let x0 = null;
      sel.onpointerdown = (e) => { x0 = e.clientX; };
      sel.onpointerup = (e) => { if (x0 == null) return; const dx = e.clientX - x0; x0 = null; if (Math.abs(dx) < 24) return; pick(keys[clamp(keys.indexOf(st.pro) + (dx < 0 ? 1 : -1), 0, keys.length - 1)]); };
    }
    if (p === 'roll') wireRoll();
    if (p === 'studio') wireStudio();
    if (p === 'looks') {
      const nl = $('#cmNewLook'); if (nl) nl.onclick = () => openStudio(null);
      const el = $('#cmEditLook'); if (el) el.onclick = () => openStudio(lookById(st.look));
      const sws = $('#cmSws');
      sws.querySelectorAll('button').forEach((b) => (b.onclick = () => { setLook(b.dataset.look); }));
      const on = sws.querySelector('.on'); if (on) sws.scrollLeft = on.offsetLeft + on.offsetWidth / 2 - sws.clientWidth / 2;
      const amt = $('#cmAmt'), gr = $('#cmGr');
      amt.oninput = () => { st.amount = amt.value / 100; amt.nextElementSibling.textContent = amt.value; E.setLook?.(view()); };
      gr.oninput = () => { st.grain = gr.value / 100; gr.nextElementSibling.textContent = gr.value; E.setLook?.(view()); };
      amt.onchange = gr.onchange = save;
    }
    if (p === 'tools') $$('#cmCardIn .cm-tools button, #cmCardIn .cm-list [data-k]').forEach((b) => (b.onclick = async () => {
      const k = b.dataset.k; haptic('selection');
      if (k === 'reset') { const keep = { facing: st.facing, look: st.look, mode: st.mode }; st = { ...DEF, ...keep }; await applyAll(); chip('BACK TO THE START'); }
      else if (k === 'level' && !st.level) { if (!(await askMotion())) return; st.level = true; }
      else if (k === 'loc' && !st.loc) { if (!(await askLocation())) return; st.loc = true; }
      else st[k] = !st[k];
      if (k === 'roll' && !st.roll && C.R.cur) { C.R.cur.delay = 'now'; finishRoll(); }
      if (k === 'rev') chip(st.rev ? 'REVERSIBLE · PHOTOS CAN TAKE THE LOOK OFF' : 'LOOK BAKED IN');
      save(); paintAll(); paintCard(); E.setTools?.(toolsFor()); E.setLook?.(view());
    }));
  }
  /* ---------- Film Roll ---------- */
  function rollBody() {
    const r = C.R.cur, ready = C.R.list.slice(0, 6);
    const list = ready.length ? `<div class="cm-rolls">${ready.map((x, i) => `<button data-roll="${i}" class="${x.state === 'ready' ? '' : 'dev'}"><span class="rt">${ic('film', 18)}</span><span class="rn"><b>${x.shots.length} · ${esc(x.lookName)}</b><small>${x.state === 'ready' ? 'Developed ' + new Date(x.readyAt || x.devAt).toLocaleDateString([], { day: 'numeric', month: 'short' }) : 'Ready ' + Roll.when(x.devAt)}</small></span>${x.state === 'ready' ? ic('chev', 16) : ''}</button>`).join('')}</div>` : '';
    if (r) return `<div class="cm-big">${Roll.left(r)}<small>of ${r.size} left</small></div>
      <p class="cm-note">${esc(r.lookName)} · develops ${(Roll.DELAYS.find((d) => d[0] === r.delay) || Roll.DELAYS[0])[1].toLowerCase()} after the last shot</p>
      <div class="cm-acts"><button class="cm-act" id="cmRollStop">STOP ROLL</button><button class="cm-act pri" id="cmRollEnd">DEVELOP NOW</button></div>
      <p class="cm-note">Stop: the shots so far go to Photos now and the camera is back to normal.</p>${list}`;
    return `<div class="cm-chips" data-k="rsize">${Roll.SIZES.map((n) => `<button data-v="${n}" class="${+st.rollSize === n ? 'on' : ''}">${n}</button>`).join('')}</div>
      <div class="cm-chips small" data-k="rdelay">${Roll.DELAYS.map(([v, l]) => `<button data-v="${v}" class="${st.rollDelay === v ? 'on' : ''}">${l}</button>`).join('')}</div>
      <p class="cm-note">One look for the whole roll (${esc(lookById(st.look).name)}). The photos stay hidden until the roll develops, then go to Photos together.</p>
      <div class="cm-acts"><button class="cm-act pri" id="cmRollGo">${ic('film', 16)}LOAD ${st.rollSize} SHOTS</button></div>${list}`;
  }
  function wireRoll() {
    const go = $('#cmRollGo'); if (go) go.onclick = () => {
      const L = lookById(st.look);
      C.R.cur = { id: Date.now(), look: L.id, lookName: L.name, size: +st.rollSize || 24, delay: st.rollDelay || 'hour', shots: [], at: Date.now() };
      Roll.store(C.R); haptic('medium'); closeCard(); paintAll(); paintThumb(); chip(`ROLL LOADED · ${C.R.cur.size} SHOTS`);
    };
    const end = $('#cmRollEnd'); if (end) end.onclick = () => { closeCard(); finishRoll(); };
    const stopR = $('#cmRollStop'); if (stopR) stopR.onclick = () => { if (C.R.cur) C.R.cur.delay = 'now'; closeCard(); finishRoll(); };
    $$('#cmCardIn .cm-rolls button').forEach((b) => (b.onclick = () => { const r = C.R.list[+b.dataset.roll]; if (r?.state === 'ready') openRoll(r); else if (r) chip('READY ' + Roll.when(r.devAt).toUpperCase()); }));
  }
  function rollShot(shot) {
    const r = C.R.cur; if (!r) return;
    r.shots.push({ name: String(shot.uri || '').split('/').pop(), w: shot.w, h: shot.h, at: Date.now(), meta: shot.meta });
    Roll.store(C.R); paintTop(); paintThumb();
    const n = Roll.left(r); if (n > 0 && n <= 3) chip(`${n} LEFT ON THIS ROLL`);
    if (n <= 0) finishRoll();
  }
  async function finishRoll() {
    const r = C.R.cur; if (!r) return;
    C.R.cur = null;
    if (!r.shots.length) { Roll.store(C.R); paintAll(); paintThumb(); return chip('ROLL UNLOADED'); }
    r.state = 'developing'; r.devAt = Roll.readyAt(r.delay); C.R.list.unshift(r); Roll.store(C.R);
    paintAll(); paintThumb(); E?.setTools?.(toolsFor());
    if (r.devAt - Date.now() < 5000) return developDue();
    chip('ROLL DEVELOPING · READY ' + Roll.when(r.devAt).toUpperCase()); haptic('medium');
    liveShow('roll', { title: 'Roll developing', subtitle: `${r.shots.length} photos · ${r.lookName}`, icon: 'film', timerEnd: r.devAt, progress: -1 });
    const LN = plugin('LocalNotifications');
    try {
      const p = await LN?.requestPermissions?.();
      if (p?.display === 'granted') await LN.schedule({ notifications: [{ id: r.id % 2000000000, title: 'Your roll is ready', body: `${r.shots.length} photos · ${r.lookName}. Tap to see them.`, schedule: { at: new Date(r.devAt) }, extra: { open: 'camera' } }] });
    } catch {}
  }
  // rolls whose time has come: their photos go to Photos together, then they open
  async function developDue() {
    if (C.developing) return;
    const due = C.R.list.filter((r) => r.state === 'developing' && r.devAt <= Date.now());
    if (!due.length) return;
    C.developing = true;
    const N = plugin('ShivoNative');
    try {
      for (const r of due) {
        for (const sh of r.shots) {
          const uri = await Roll.fileOf(plugin, sh.name);
          if (uri && N?.saveFromURL) await N.saveFromURL({ url: uri, name: sh.name, kind: 'media' }).catch(() => {});
        }
        r.state = 'ready'; r.readyAt = Date.now(); Roll.store(C.R);
        liveDone('roll', { title: 'Roll ready', subtitle: `${r.shots.length} photos · ${r.lookName}` });
      }
      haptic('success'); chip('ROLL READY · IN PHOTOS');
      if (C.on) openRoll(due[0]);
    } finally { C.developing = false; }
  }
  async function openRoll(r) {
    const list = [];
    for (const sh of r.shots) {
      const uri = await Roll.fileOf(plugin, sh.name);
      if (uri) list.push({ url: Roll.shown(uri), uri, w: sh.w, h: sh.h, look: r.lookName, saved: true, meta: sh.meta });
    }
    if (list.length) openViewer(list); else toast?.("This roll's photos aren't on this phone any more (they're in Photos)");
  }

  /* ---------- Look Studio: your own looks, built with a few sliders, live in the viewfinder ---------- */
  const STUDIO = [['sat', 'COLOUR', 0, 160, 100], ['con', 'CONTRAST', 70, 140, 100], ['warm', 'WARMTH', -100, 100, 0], ['fade', 'FADE', 0, 100, 0],
    ['grain', 'GRAIN', 0, 40, 0], ['hal', 'GLOW', 0, 30, 0], ['vig', 'VIGNETTE', 0, 40, 0]];
  function studioLook(v, id, name) {
    const w = v.warm / 100, f = v.fade / 100, mono = !!v.mono;
    return { id, name, sub: 'Your look', mine: true, sat: v.sat / 100, con: v.con / 100, lift: f * 0.06, fade: f * 0.05,
      cm: [[1, 0, 0], [0, 1, 0], [0, 0, 1]], mono: mono ? [0.3, 0.59, 0.11] : undefined,
      hl: [0.045 * w, 0.02 * w, -0.035 * w], sh: [0.012 * w, 0.004 * w, -0.02 * w],
      grain: v.grain / 100, hal: v.hal / 100, vig: v.vig / 100, v: { ...v },
      sw: mono ? ['#d9d8d4', '#2a2a2b'] : [w > 0.2 ? '#d99a5b' : w < -0.2 ? '#8fa7b8' : '#b9b4a9', v.sat > 120 ? '#1f5fa8' : '#4b6670'] };
  }
  function openStudio(edit) {
    const base = edit?.v || { sat: 100, con: 100, warm: 0, fade: 0, grain: 0, hal: 0, vig: 0, mono: false };
    C.edit = { id: edit?.id || 'mine-' + Date.now(), name: edit?.name || `My look ${mine().length + 1}`, v: { ...base }, old: !!edit, n: 0 };
    C.studio = studioLook(C.edit.v, 'studio-0', C.edit.name); E?.setLook?.(view());
    C.panel = 'studio'; paintCard();
  }
  function endStudio() { C.studio = null; C.edit = null; E?.setLook?.(view()); }
  function studioBody() {
    const e = C.edit;
    return `<button class="cm-name" id="cmLookName">${esc(e.name)}${ic('pen', 14)}</button>
      ${STUDIO.map(([k, n, a, b]) => `<div class="cm-slider"><span>${n}</span><input type="range" min="${a}" max="${b}" value="${e.v[k]}" data-k="${k}"><b>${e.v[k]}</b></div>`).join('')}
      <div class="cm-acts"><button class="cm-act${e.v.mono ? ' on' : ''}" id="cmMono">BLACK & WHITE</button>${e.old ? '<button class="cm-act" id="cmDelLook">DELETE</button>' : ''}<button class="cm-act pri" id="cmSaveLook">SAVE LOOK</button></div>`;
  }
  function wireStudio() {
    const e = C.edit; let raf = 0;
    const live = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => { e.n++; C.studio = studioLook(e.v, 'studio-' + e.n, e.name); E?.setLook?.(view()); }); };
    $$('#cmCardIn .cm-slider input').forEach((i) => (i.oninput = () => { e.v[i.dataset.k] = +i.value; i.nextElementSibling.textContent = i.value; live(); }));
    $('#cmMono').onclick = () => { e.v.mono = !e.v.mono; $('#cmMono').classList.toggle('on', e.v.mono); haptic('selection'); live(); };
    $('#cmLookName').onclick = () => { const n = prompt('Name this look', e.name); if (n && n.trim()) { e.name = n.trim().slice(0, 24); paintCard(); } };
    $('#cmSaveLook').onclick = () => {
      const list = mine().filter((l) => l.id !== e.id); list.push(studioLook(e.v, e.id, e.name));
      localStorage.setItem(MINE, JSON.stringify(list)); mergeMine(); sentControls = '';
      C.studio = null; st.look = e.id; save(); E?.setLook?.(view()); syncControls(); haptic('success');
      chip(e.name.toUpperCase() + ' SAVED'); C.edit = null; C.panel = 'looks'; paintCard();
    };
    const del = $('#cmDelLook'); if (del) del.onclick = () => {
      localStorage.setItem(MINE, JSON.stringify(mine().filter((l) => l.id !== e.id))); mergeMine(); sentControls = '';
      C.studio = null; if (st.look === e.id) st.look = 'natural'; save(); E?.setLook?.(view()); syncControls();
      chip('LOOK DELETED'); C.edit = null; C.panel = 'looks'; paintCard();
    };
  }

  /* ---------- first time: three short tips ---------- */
  function tips() {
    if (localStorage.getItem('sl.cam.tips') || E?.kind !== 'native') return;
    try { localStorage.setItem('sl.cam.tips', '1'); } catch {}
    const T = ['Swipe the picture sideways for another look', 'Swipe up from the bottom for all controls', caps().buttons ? 'The volume and side buttons take the photo too' : 'Pinch to change the lens'];
    T.forEach((t, i) => setTimeout(() => { if (C.on && !C.card) line(t); }, 900 + i * 2200));
  }

  function sizeCard() {
    requestAnimationFrame(() => {
      const h = $('#cmCard').offsetHeight;
      cm.style.setProperty('--cardH', h + 'px'); glassFollow();
    });
  }
  function openCard(panel) {
    C.card = true; C.panel = panel || ''; paintCard();
    cm.classList.add('card'); haptic('light'); paintRow(); glassFollow();
  }
  function closeCard() { if (!C.card) return; C.card = false; C.panel = ''; C.pd = null; cm.classList.remove('card'); paintRow(); glassFollow(); }
  $('#cmScrim').onclick = closeCard;
  (() => {   // swipe the card down to close it
    const c = $('#cmCard'); let y0 = null;
    c.addEventListener('pointerdown', (e) => { if (!e.target.closest('input,.cm-ruler,.cm-sws')) y0 = e.clientY; });
    c.addEventListener('pointerup', (e) => { if (y0 != null && e.clientY - y0 > 50) closeCard(); y0 = null; });
  })();

  /* ---------- the level, and turning photos when the phone is held sideways ---------- */
  function onMotion(e) {
    const g = e.accelerationIncludingGravity; if (!g || g.x == null) return;
    const ax = g.x, ay = g.y, flat = Math.abs(g.z) > 8.6;
    const turn = flat ? C.turn : Math.abs(ax) > Math.abs(ay) * 1.2 ? (ax > 0 ? -90 : 90) : Math.abs(ay) > Math.abs(ax) * 1.2 ? 0 : C.turn;
    if (turn !== C.turn && !C.rec) { C.turn = turn; cm.style.setProperty('--turn', turn + 'deg'); }
    let a = Math.atan2(ax, -ay) * 180 / Math.PI; if (C.turn === 90) a -= 90; else if (C.turn === -90) a += 90;
    C.tilt = a; if (!st.level) return;
    const lv = $('#cmLevel'), ok = Math.abs(a) < 1;
    lv.style.setProperty('--tilt', (ok ? 0 : -a) + 'deg');
    if (ok && !lv.classList.contains('ok')) haptic('selection');
    lv.classList.toggle('ok', ok);
  }
  async function askMotion() {
    try {
      const D = window.DeviceMotionEvent;
      if (D?.requestPermission && (await D.requestPermission()) !== 'granted') throw new Error('no');
      if (!C.motion) { addEventListener('devicemotion', onMotion); C.motion = true; }
      localStorage.setItem('sl.cam.motion', '1'); return true;
    } catch { toast?.('Allow Motion for the level and turning photos'); return false; }
  }
  // which way up the phone is held (the icons turn, photos come out the right way): iOS asks once, on the first touch
  if (localStorage.getItem('sl.cam.motion') || !localStorage.getItem('sl.cam.motionAsked')) cm.addEventListener('pointerdown', () => {
    if (C.motion) return; try { localStorage.setItem('sl.cam.motionAsked', '1'); } catch {}
    const D = window.DeviceMotionEvent; if (!D?.requestPermission) return askMotion();
    D.requestPermission().then((r) => { if (r === 'granted') askMotion(); }).catch(() => {});
  }, { once: true });
  if (window.DeviceMotionEvent && !window.DeviceMotionEvent.requestPermission) { addEventListener('devicemotion', onMotion); C.motion = true; }

  /* ---------- location for photos and videos (when turned on) ---------- */
  async function askLocation() {
    const G = plugin('Geolocation');
    try {
      if (!G) throw new Error('none');
      const p = await G.requestPermissions?.().catch(() => null);
      if (p && p.location === 'denied') throw new Error('denied');
      await where(true); if (!C.loc) throw new Error('no fix');
      return true;
    } catch { toast?.('Allow Location for Shivo Labs to add where photos were taken'); return false; }
  }
  async function where(fresh) {
    if (!st.loc && !fresh) return null;
    if (!fresh && C.loc && Date.now() - C.locAt < 120000) return C.loc;
    const G = plugin('Geolocation'); if (!G) return null;
    try {
      const p = await G.getCurrentPosition({ enableHighAccuracy: false, timeout: 4000, maximumAge: 120000 });
      C.loc = { lat: p.coords.latitude, lon: p.coords.longitude }; C.locAt = Date.now();
    } catch {}
    return C.loc;
  }

  /* ---------- the shutter: photo, stack, night, or video ---------- */
  $('#cmShot').onclick = () => (st.mode === 'VIDEO' ? (C.rec ? recStop() : recStart()) : shoot());
  async function shoot() {
    if (!E?.running?.() || C.busy) return;
    C.busy = true; $('#cmShot').classList.add('busy'); closeCard();
    const stack = st.mode === 'STACK' || st.mode === 'NIGHT';
    let freed = false;
    const free = () => { if (freed) return; freed = true; C.busy = false; $('#cmShot').classList.remove('busy'); count(''); $('#cmFF').classList.remove('on'); };
    try {
      if (st.timer) for (let s = st.timer; s > 0; s--) { count(s); haptic('light'); await sleep(1000); }
      count('');
      if (stack) { progress(0); line(st.mode === 'NIGHT' ? 'Hold still…' : 'Hold steady…'); }
      const loc = st.loc ? await where() : null;
      const a = aspectNow() || C.frame.H / C.frame.W;
      const roll = !!C.R.cur && canRoll();
      const meta = { mm: st.mm, iso: Math.round(st.iso || C.meter.iso || 0), ss: st.ss || C.meter.ss || 0, ap: canDepth() && st.depth ? st.ap : 0 };
      const pending = E.shoot({ ...st, keep: roll, fmt: roll && st.fmt.startsWith('RAW') ? 'HEIF' : st.fmt, aspect: a, turn: C.turn, view: view(), loc,
        onCapture: () => { if (!stack) { blink(); haptic('medium'); free(); } },
        flashFront: async (on) => { $('#cmFF').classList.toggle('on', on); if (on) await sleep(320); } });
      const shot = await pending;
      if (stack) { blink(); haptic('medium'); line(shot?.saved ? 'Saved' : ''); progress(0); }
      if (!shot) return;
      shot.look = lookById(st.look).name; shot.meta = meta;
      if (shot.error) toast?.(shot.error);
      if (roll && shot.kept) return rollShot(shot);
      C.shots.unshift(shot); paintThumb();
    } catch (e) { console.error(e); toast?.('Photo not taken: ' + (e.message || e)); }
    finally { free(); }
  }
  async function recStart() {
    if (!E?.running?.() || C.busy || !E.record) return;
    C.busy = true; closeCard();
    try {
      await E.record({ on: true, turn: C.turn });
      C.rec = true; C.recT = Date.now(); cm.classList.add('rec'); haptic('medium'); paintRow(); tick();
    } catch (e) { toast?.('Video not started: ' + (e.message || e)); }
    finally { C.busy = false; }
  }
  function tick() {
    if (!C.rec) return;
    const s = Math.floor((Date.now() - C.recT) / 1000);
    $('#cmRecT').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
    setTimeout(tick, 250);
  }
  async function recStop() {
    if (!C.rec) return;
    C.rec = false; cm.classList.remove('rec'); haptic('medium'); paintRow(); $('#cmRecT').textContent = '00:00';
    C.busy = true;
    try {
      const loc = st.loc ? await where() : null;
      const shot = await E.record({ on: false, loc });
      if (shot) { shot.look = lookById(st.look).name; C.shots.unshift(shot); paintThumb(); if (shot.error) toast?.(shot.error); }
    } catch (e) { toast?.('Video not saved: ' + (e.message || e)); }
    finally { C.busy = false; }
  }
  function count(n) { const c = $('#cmCount'); c.textContent = n; c.classList.toggle('on', n !== ''); }
  function blink() { const b = $('#cmBlink'); b.classList.remove('on'); void b.offsetWidth; b.classList.add('on'); }

  /* ---------- photos taken: the corner thumbnail and the viewer ---------- */
  function paintThumb() {
    const t = $('#cmThumb'), s = C.shots[0], r = C.R.cur;
    t.classList.toggle('roll', !!r);
    t.innerHTML = r ? `${ic('film', 20)}<b>${r.shots.length}</b>` : s?.url ? `<img src="${s.url}" alt="">` : '';
    if (s || r) { t.classList.remove('pop'); void t.offsetWidth; t.classList.add('pop'); }
  }
  $('#cmThumb').onclick = () => { if (C.R.cur) openCard('roll'); else if (C.shots.length) openViewer(); else (openURL ? openURL('photos-redirect://') : null)?.catch?.(() => {}); };
  function openViewer(list = C.shots) {
    const v = $('#cmViewer'), framesOk = !!E?.frameImage && caps().frames;
    v.innerHTML = (V6 ? `<div class="cv-top"><button class="cm-rb" id="cvClose" aria-label="Close">${ic('x', 20)}</button><span class="cv-t"><b id="cvL"></b><small id="cvD"></small></span><span class="cv-n" id="cvN"></span></div>
      <div class="cv-strip" id="cvStrip">${list.map((s) => `<figure>${s.video ? `<video src="${s.src}" poster="${s.url}" controls playsinline></video>` : `<img src="${s.url}" alt="">`}</figure>`).join('')}</div>
      <div class="cv-info" id="cvI"></div>`
      : `<div class="cv-top"><button class="cm-rb" id="cvClose" aria-label="Close">${ic('x', 20)}</button><span class="cv-t"><span id="cvN"></span><small id="cvD"></small></span><span class="cv-sp"></span></div>
      <div class="cv-strip" id="cvStrip">${list.map((s) => `<figure>${s.video ? `<video src="${s.src}" poster="${s.url}" controls playsinline></video>` : `<img src="${s.url}" alt="">`}<figcaption>${esc(s.look || '')} · ${s.video ? 'Video' : (s.w * s.h / 1e6).toFixed(1) + ' MP'}${s.raw ? ' · RAW' : ''}</figcaption></figure>`).join('')}</div>`) + `
      ${V6 && list.length > 1 ? `<div class="cv-film" id="cvFilm">${list.slice(0, 60).map((s, i) => `<button data-i="${i}">${s.url ? `<img src="${s.url}" alt="">` : ''}</button>`).join('')}</div>` : ''}
      <div class="cv-bar"><button class="cv-btn" id="cvShare">${ic('share', 22)}<span>Share</span></button>${framesOk ? `<button class="cv-btn" id="cvFrame">${ic('frame', 22)}<span>Frame</span></button>` : ''}<button class="cv-btn" id="cvPhotos">${ic('photos', 22)}<span>Photos</span></button></div>
      <div class="cv-fr" id="cvFr" hidden><div class="cvf-pic"><img id="cvfImg" alt=""><span id="cvfWait">Printing…</span></div>
        <div class="cm-chips" id="cvfStyles">${[['white', 'White'], ['black', 'Black'], ['film', 'Film']].map(([k, n], i) => `<button data-v="${k}" class="${i === 0 ? 'on' : ''}">${V6 ? `<i class="fs fs-${k}"></i>` : ''}${n}</button>`).join('')}</div>
        <div class="cm-acts"><button class="cm-act" id="cvfDone">DONE</button><button class="cm-act" id="cvfSave">SAVE</button><button class="cm-act pri" id="cvfShare">SHARE</button></div></div>`;
    v.hidden = false; requestAnimationFrame(() => v.classList.add('in'));
    const strip = $('#cvStrip'), at = () => Math.round(strip.scrollLeft / strip.clientWidth);
    const paint = () => {
      const i = at(), sh = list[i]; $('#cvN').textContent = V6 ? `${i + 1} / ${list.length}` : `${i + 1} of ${list.length}`; const f = $('#cvFrame'); if (f) f.hidden = !!sh?.video;
      const L = $('#cvL'); if (L) L.textContent = sh?.look || 'Shivo Labs';
      const I = $('#cvI'); if (I && sh) { const m = sh.meta || {}; I.innerHTML = [m.mm && `${m.mm} mm`, m.ap && `ƒ${m.ap}`, m.ss && fmtSS(m.ss), m.iso && `ISO ${m.iso}`, sh.video ? 'VIDEO' : sh.w && `${(sh.w * sh.h / 1e6).toFixed(1)} MP`, sh.raw && 'RAW'].filter(Boolean).map((t) => `<span>${t}</span>`).join(''); }
      const d = new Date(sh?.at || Date.now()); $('#cvD').textContent = `${d.toLocaleDateString([], { day: 'numeric', month: 'short' })} · ${d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
      $$('#cvFilm button').forEach((b) => b.classList.toggle('on', +b.dataset.i === i));
    };
    $$('#cvFilm button').forEach((b) => (b.onclick = () => strip.scrollTo({ left: +b.dataset.i * strip.clientWidth, behavior: 'smooth' })));
    strip.addEventListener('scroll', paint, { passive: true }); paint();
    $('#cvClose').onclick = () => { v.querySelectorAll('video').forEach((x) => x.pause()); v.classList.remove('in'); setTimeout(() => (v.hidden = true), 300); };
    $('#cvPhotos').onclick = () => (openURL ? openURL('photos-redirect://') : null)?.catch?.(() => {});
    const share = async (uri) => { try { const SH = plugin('Share'); if (SH && uri) await SH.share({ files: [uri] }); else toast?.('Sharing isn\'t available here'); } catch {} };
    $('#cvShare').onclick = () => share(list[at()]?.uri);
    // Frames: a printed border with the look and the shot's details, made on the phone; the photo itself stays as it is
    let framed = null, style = 'white';
    const fr = $('#cvFr');
    const make = async () => {
      const s = list[at()]; if (!s?.uri) return;
      $('#cvfWait').hidden = false; $('#cvfImg').style.opacity = '.35';
      const m = s.meta || {}, d = new Date(s.at || Date.now());
      const detail = [m.mm && `${m.mm} mm`, m.ap && `ƒ${m.ap}`, m.ss && fmtSS(m.ss), m.iso && `ISO ${m.iso}`, d.toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' })].filter(Boolean).join('  ·  ');
      try { framed = await E.frameImage({ file: s.uri, style, title: s.look || 'Shivo Labs', detail, mark: 'SHIVO LABS' }); $('#cvfImg').src = framed.url; }
      catch (e) { toast?.('The frame wasn\'t made: ' + (e.message || e)); }
      $('#cvfWait').hidden = true; $('#cvfImg').style.opacity = '1';
    };
    const fb = $('#cvFrame'); if (fb) fb.onclick = () => { fr.hidden = false; haptic('light'); make(); };
    $$('#cvfStyles button').forEach((b) => (b.onclick = () => { style = b.dataset.v; $$('#cvfStyles button').forEach((x) => x.classList.toggle('on', x === b)); haptic('selection'); make(); }));
    $('#cvfDone').onclick = () => { fr.hidden = true; };
    $('#cvfShare').onclick = () => framed && share(framed.file);
    $('#cvfSave').onclick = async () => {
      const N = plugin('ShivoNative'); if (!framed || !N?.saveFromURL) return;
      try { await N.saveFromURL({ url: framed.file, name: 'SL_frame_' + Date.now() + '.jpg', kind: 'media' }); chip('FRAMED COPY SAVED'); haptic('success'); } catch (e) { toast?.(e.message || 'Not saved'); }
    };
  }

  /* ---------- flip between back and front ---------- */
  $('#cmFlip').onclick = async () => {
    if (C.rec || C.busy) return;
    st.facing = st.facing === 'front' ? 'back' : 'front'; st.mm = 26; save(); haptic('light');
    const f = $('#cmFlip'); f.classList.toggle('spin'); cm.classList.add('swap'); setTimeout(() => cm.classList.remove('swap'), 420);
    await E?.stop(); start();
  };

  /* ---------- asking for the camera, and when it is off ---------- */
  function gate(kind, detail) {
    const g = $('#cmGate'); g.hidden = false;
    const T = {
      ask: ['Shivo Labs Camera', 'Film looks, live in the viewfinder. Photos go straight to your Photos.', 'Allow camera', 'iPhone will ask you once.'],
      denied: ['Camera is off', 'Shivo Labs isn\'t allowed to use the camera. Turn on Camera for Shivo Labs in Settings, then come back.', 'Open Settings', ''],
      none: ['No camera here', 'This device has no camera Shivo Labs can use.', '', ''],
      error: ['The camera didn\'t start', detail || 'Something else may be using it. Close other camera apps and try again.', 'Try again', ''],
    }[kind];
    g.innerHTML = `<button class="cm-rb cg-x" id="cgX" aria-label="Close">${ic('x', 20)}</button><div class="cg-in"><span class="cg-ic">${ic('cam', 44)}</span><h2>${T[0]}</h2><p>${esc(T[1])}</p>
      ${T[2] ? `<button class="cg-go" id="cgGo">${T[2]}</button>` : ''}${kind === 'denied' ? '<button class="cg-alt" id="cgAgain">Try again</button>' : ''}<small>${T[3]}</small></div>`;
    const go = $('#cgGo');
    if (go) go.onclick = () => { if (kind === 'denied') return (openURL ? openURL('app-settings:') : Promise.reject()).catch(() => toast?.('Open Settings, then Shivo Labs, then Camera')); localStorage.setItem('sl.cam.asked', '1'); start(); };
    $('#cgX').onclick = () => $('#cmClose').click();
    const again = $('#cgAgain'); if (again) again.onclick = start;
  }

  function paintAll() {
    cm.dataset.grid = st.grid ? '1' : ''; cm.classList.toggle('framed', !!st.framed);
    cm.classList.toggle('full', !aspectNow()); $('#cmLevel').hidden = !st.level; $('#cmHist').hidden = !st.hist;
    cm.dataset.mode = st.mode;
    paintTop(); paintZoom(); paintModes(); paintRow(); E?.setTools?.(toolsFor()); E?.setLook?.(view()); glassFollow();
  }
  paintAll(); paintThumb();

  // the camera stops when the app goes to the background and comes back with it
  document.addEventListener('visibilitychange', () => { if (!C.on) return; if (document.hidden) { if (C.rec) recStop(); E?.stop(); } else start(); });
  setInterval(() => { if (C.on) developDue(); }, 30000);

  return { start, stop, get on() { return C.on; } };
}
