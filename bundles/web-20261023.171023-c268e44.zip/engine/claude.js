// Claude from the phone: the Messages API, called straight from the app with the user's own key.
// (Anthropic allows browser-side calls with the "dangerous-direct-browser-access" header; here the
// "browser" is the app, and the key is the user's own, kept on their phone.)
export const API = 'https://api.anthropic.com';
export const MODELS = {
  haiku:  { id: 'claude-haiku-5-5',  name: 'Haiku 5.5',  inp: 0.1, out: 0.5,  note: 'Fastest and cheapest' },
  sonnet: { id: 'claude-sonnet-5-5', name: 'Sonnet 5.5', inp: 2,   out: 10,   note: 'Balanced, a good default' },
  opus:   { id: 'claude-opus-5-5',   name: 'Opus 5.5',   inp: 4,   out: 20,   note: 'Most capable' },
  fable:  { id: 'claude-fable-5-1',  name: 'Fable 5.1',  inp: 10,  out: 50,   note: 'Deepest thinking, costs more' },
};
export const byId = (id) => Object.values(MODELS).find((m) => m.id === id);

// $ for one reply. Cache writes cost 1.25x input, cache reads 0.1x.
export function costOf(modelId, u = {}) {
  const m = byId(modelId) || MODELS.sonnet;
  const cw = u.cache_creation_input_tokens ?? (u.cache_creation ? Object.values(u.cache_creation).reduce((a, b) => a + (b || 0), 0) : 0);
  return ((u.input_tokens || 0) * m.inp + (cw || 0) * m.inp * 1.25 + (u.cache_read_input_tokens || 0) * m.inp * 0.1 + (u.output_tokens || 0) * m.out) / 1e6;
}

export const headers = (key, beta) => ({
  'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01',
  'anthropic-dangerous-direct-browser-access': 'true', ...(beta ? { 'anthropic-beta': beta } : {}),
});

export async function apiError(r) {
  let msg = '', type = '';
  try { const j = await r.json(); msg = j?.error?.message || ''; type = j?.error?.type || ''; } catch {}
  let text;
  if (r.status === 401 || r.status === 403) text = 'Claude rejected the key. Check it in Settings.';
  else if (r.status === 429) text = 'Claude says too many requests right now. Wait a moment and try again.';
  else if (/credit balance/i.test(msg)) text = 'Your Claude credits are used up. Add credits in the Claude Console.';
  else if (r.status >= 500) text = "Claude's servers had a problem. Try again in a moment.";
  else text = msg || `Claude error ${r.status}`;
  const e = new Error(text); e.status = r.status; e.type = type; e.raw = msg; return e;
}

// Is this key real? Listing models is free.
export async function checkKey(key) {
  try {
    const r = await fetch(API + '/v1/models?limit=1', { headers: headers(key) });
    if (r.ok) return { ok: true };
    return { ok: false, error: (await apiError(r)).message };
  } catch { return { ok: false, error: "Couldn't reach Claude. Are you online?" }; }
}

// Server-sent events: yields { event, data } with data already parsed.
export async function* sseEvents(resp) {
  const reader = resp.body.getReader(); const dec = new TextDecoder(); let buf = '';
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let m;
    while ((m = /\r?\n\r?\n/.exec(buf))) {
      const block = buf.slice(0, m.index); buf = buf.slice(m.index + m[0].length);
      let ev = 'message'; const data = [];
      for (const line of block.split(/\r?\n/)) {
        if (!line || line.startsWith(':')) continue;
        if (line.startsWith('event:')) ev = line.slice(6).trim();
        else if (line.startsWith('data:')) data.push(line.slice(5).replace(/^ /, ''));
      }
      if (!data.length) continue;
      const s = data.join('\n'); if (s === '[DONE]') continue;
      try { yield { event: ev, data: JSON.parse(s) }; } catch {}
    }
  }
}

// One streamed Messages API call. Returns { content, stop_reason, usage } (content blocks kept
// exactly as received, so they can be sent back unchanged).
export async function messagesStream({ key, model, system, messages, tools = [], maxTokens = 16000, effort = 'medium', signal, onText, onThinking, onBlock }) {
  const body = { model, max_tokens: maxTokens, stream: true, system, messages, ...(tools.length ? { tools } : {}), ...(effort ? { output_config: { effort } } : {}) };
  const r = await fetch(API + '/v1/messages', { method: 'POST', headers: headers(key), body: JSON.stringify(body), signal });
  if (!r.ok) throw await apiError(r);
  const blocks = []; let stop = null, usage = {};
  for await (const { data } of sseEvents(r)) {
    switch (data.type) {
      case 'message_start': usage = { ...(data.message?.usage || {}) }; break;
      case 'content_block_start': {
        const b = { ...data.content_block };
        if (b.type === 'tool_use' || b.type === 'server_tool_use') b._json = '';
        blocks[data.index] = b; onBlock?.('start', b); break;
      }
      case 'content_block_delta': {
        const b = blocks[data.index], d = data.delta; if (!b) break;
        if (d.type === 'text_delta') { b.text = (b.text || '') + d.text; onText?.(d.text); }
        else if (d.type === 'input_json_delta') b._json += d.partial_json;
        else if (d.type === 'thinking_delta') { b.thinking = (b.thinking || '') + d.thinking; onThinking?.(d.thinking); }
        else if (d.type === 'signature_delta') b.signature = (b.signature || '') + d.signature;
        else if (d.type === 'citations_delta') (b.citations ||= []).push(d.citation);
        break;
      }
      case 'content_block_stop': {
        const b = blocks[data.index]; if (!b) break;
        if ('_json' in b) { try { b.input = b._json ? JSON.parse(b._json) : {}; } catch { b.input = {}; } delete b._json; }
        onBlock?.('stop', b); break;
      }
      case 'message_delta': stop = data.delta?.stop_reason ?? stop; usage = { ...usage, ...(data.usage || {}) }; break;
      case 'error': throw new Error(data.error?.message || 'The reply was cut off.');
    }
  }
  return { content: blocks.filter(Boolean), stop_reason: stop, usage };
}

// Claude's own web tools run on Anthropic's servers. The newer ones need a newer model.
const webTools = (modern) => modern
  ? [{ type: 'web_search_20260209', name: 'web_search', max_uses: 5 }, { type: 'web_fetch_20260209', name: 'web_fetch', max_uses: 5 }]
  : [{ type: 'web_search_20250305', name: 'web_search', max_uses: 5 }, { type: 'web_fetch_20250910', name: 'web_fetch', max_uses: 5 }];
const modernWeb = new Map(); // model id -> true/false once we know what it accepts

// A chat turn: streams the reply, runs the phone tools Claude asks for, loops until done.
// `history` is changed in place (Claude message format).
export async function runChat({ key, model, system, history, phoneTools = [], execTool, confirm, web = true, signal, onText, onStep, onStepDone, onThinking, onUsage, effort = 'medium', maxTurns = 8 }) {
  let useModern = modernWeb.get(model) ?? !/haiku/.test(model);
  let useWeb = web;
  for (let turn = 0; turn < maxTurns; turn++) {
    if (signal?.aborted) throw new DOMException('Stopped', 'AbortError');
    let res;
    for (let attempt = 0; ; attempt++) {
      try {
        res = await messagesStream({ key, model, system, effort, messages: history.map(({ raw, ...m }) => m), tools: [...phoneTools.map(({ name, description, input_schema }) => ({ name, description, input_schema })), ...(useWeb ? webTools(useModern) : [])],
          signal, onText, onThinking,
          onBlock: (ph, b) => { if (ph === 'start' && b.type === 'server_tool_use') onStep?.({ id: b.id, kind: 'web', label: b.name === 'web_fetch' ? 'Reading a page' : 'Searching the web', detail: '' }); } });
        modernWeb.set(model, useModern); break;
      } catch (e) {
        if (signal?.aborted || e.name === 'AbortError') throw e;
        // The web tools are optional: if this model refuses the newer ones, try the older ones, then none.
        if (e.status === 400 && useWeb && /tool|web_/i.test(e.raw || '') && attempt < 2) { if (useModern) useModern = false; else useWeb = false; continue; }
        throw e;
      }
    }
    onUsage?.(res.usage);
    history.push({ role: 'assistant', content: res.content });
    for (const b of res.content) if (b.type === 'server_tool_use') onStep?.({ id: b.id, kind: 'web', label: b.name === 'web_fetch' ? 'Read a page' : 'Searched the web', detail: b.input?.query || b.input?.url || '', done: true });
    if (res.stop_reason === 'pause_turn') continue;
    if (res.stop_reason === 'refusal') throw new Error('Claude declined this request. Try rephrasing it.');
    const uses = res.content.filter((b) => b.type === 'tool_use');
    if (!uses.length) return res;
    const results = [];
    for (const u of uses) {
      onStep?.({ id: u.id, kind: 'phone', label: u.name, input: u.input });
      let out;
      try { out = await execTool(u.name, u.input, confirm); } catch (e) { out = { error: String(e?.message || e) }; }
      onStepDone?.(u.id, out);
      results.push({ type: 'tool_result', tool_use_id: u.id, content: JSON.stringify(out), ...(out?.error ? { is_error: true } : {}) });
    }
    history.push({ role: 'user', content: results });
  }
  throw new Error('That took more steps than allowed. Try asking in smaller pieces.');
}
