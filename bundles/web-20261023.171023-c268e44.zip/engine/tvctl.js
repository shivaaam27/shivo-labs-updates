// The TV for Labs AI and Search (UNIFY-PLAN.md phase 2): the paired TV this phone used last (tv/tv.js keeps them in
// sl.tv), reached the way the TV screen does it: straight over the Wi-Fi at home, else through the relay
// (tv/relay). The TV still checks this phone's own key on every request (Remote.java).
const PORT = 8799, RELAY = 'https://shivo-tv.ishivamparmar.workers.dev';
const sha = async (s) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)))].map((b) => b.toString(16).padStart(2, '0')).join('');
const tvs = () => { try { return JSON.parse(localStorage.getItem('sl.tv') || '[]'); } catch { return []; } };
export const paired = () => tvs()[0] || null;

async function get(u, ms, body) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
  try { return await fetch(u, { method: body != null ? 'POST' : 'GET', signal: ctl.signal, cache: 'no-store', ...(body != null ? { body } : {}) }); }
  finally { clearTimeout(t); }
}
export async function call(path, q = {}, body) {
  const t = paired();
  if (!t?.key) throw new Error('No TV is paired with this phone. Pair one in the TV screen first.');
  const qq = new URLSearchParams({ ...q, k: t.key });
  let r = t.host ? await get(`http://${t.host}:${PORT}${path}?${qq}`, 2500, body).catch(() => null) : null;
  if (!r) r = await get(`${t.relay || `${RELAY}/k/${await sha(t.key)}`}${path}?${qq}`, 10000, body).catch(() => null);
  if (!r) throw new Error("Can't reach the TV. Check it is on and has internet.");
  if (r.status === 401) throw new Error('This phone is no longer paired with the TV.');
  if (r.status === 503) throw new Error('The TV is off or has no internet right now.');
  return r.json();
}

// ---- the tools ----
export const TV_TOOLS = [
  { name: 'tv_status', description: "What the user's Shivo Labs TV is showing or playing now, and its name. Use before controlling it when unsure.",
    input_schema: { type: 'object', properties: {} } },
  { name: 'tv_control', description: "Control the user's Shivo Labs TV: play, pause, next, previous (what is playing), volume_up, volume_down, mute, home (the home screen), open_app (needs app, its name, e.g. YouTube or Netflix). The user is asked to allow it first.",
    input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['play', 'pause', 'next', 'previous', 'volume_up', 'volume_down', 'mute', 'home', 'open_app'] }, app: { type: 'string', description: 'for open_app: the app name' }, times: { type: 'integer', description: 'for volume: how many steps (1-10)' } }, required: ['action'] } },
  { name: 'tv_message', description: 'Show a message on the TV screen (a title and a short text), e.g. "Dinner is ready". The user is asked to allow it first.',
    input_schema: { type: 'object', properties: { title: { type: 'string' }, text: { type: 'string' } }, required: ['text'] } },
];

export async function execTvTool(name, i = {}) {
  try {
    if (name === 'tv_status') {
      const [now, dev, apps] = await Promise.all([call('/now').catch(() => []), call('/device').catch(() => ({})), call('/apps').catch(() => [])]);
      const label = (pkg) => (Array.isArray(apps) ? apps : []).find((x) => x.pkg === pkg)?.label || pkg;
      return { tv: paired()?.name || dev.model || 'TV', playing: (Array.isArray(now) ? now : []).slice(0, 3).map((p) => ({ app: label(p.pkg), title: p.title, by: p.sub || undefined, state: p.playing ? 'playing' : 'paused' })) };
    }
    if (name === 'tv_message') return await call('/show', {}, JSON.stringify({ title: String(i.title || '').slice(0, 80), text: String(i.text || '').slice(0, 400) }));
    const a = i.action;
    if (a === 'volume_up' || a === 'volume_down') {
      const n = Math.max(1, Math.min(10, Number(i.times) || 1));
      let r; for (let k = 0; k < n; k++) r = await call('/volume', { a: a === 'volume_up' ? 1 : -1 }, '');
      return { ok: true, volume: r?.vol };
    }
    if (a === 'mute') return await call('/mute', {}, '');
    if (a === 'home') return await call('/home');
    if (a === 'open_app') {
      const want = String(i.app || '').toLowerCase().trim();
      if (!want) return { error: 'Which app?' };
      const list = await call('/apps');
      const apps = Array.isArray(list) ? list : list.apps || [];
      const hit = apps.find((x) => String(x.label || x.name || '').toLowerCase() === want) || apps.find((x) => String(x.label || x.name || '').toLowerCase().includes(want));
      if (!hit) return { error: `No app called "${i.app}" on the TV`, apps: apps.slice(0, 30).map((x) => x.label || x.name) };
      return { ...(await call('/open', { a: hit.pkg || hit.package })), opened: hit.label || hit.name };
    }
    // play, pause, next, previous: the app playing now
    const now = await call('/now');
    const p = (Array.isArray(now) ? now : [])[0];
    if (!p) return { error: 'Nothing is playing on the TV.' };
    return { ...(await call('/media', { a: p.pkg, b: a === 'previous' ? 'prev' : a })), app: p.pkg, title: p.title };
  } catch (e) { return { error: String(e.message || e) }; }
}
