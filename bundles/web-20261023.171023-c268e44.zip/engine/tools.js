// What the AI may do on the phone itself. The same tool list is given to Claude chats, to hosted
// tasks (as custom tools: the task pauses until the phone answers) and to Gemini.
import { TV_TOOLS, execTvTool, paired as tvPaired } from './tvctl.js';
import * as cloud from './cloud.js';
import { CHAT_TOOLS, execChatTool, signedIn as chatSignedIn } from './chatctl.js';
import { PC_TOOLS, execPcTool, hasPc } from './pcctl.js';
import { plugin } from './native.js';
export const PHONE_TOOLS = [
  { name: 'list_calendar_events', description: "List events in the user's phone calendar between two moments. Dates are ISO 8601 with the user's timezone offset. Defaults: from now, for 7 days.",
    input_schema: { type: 'object', properties: { from: { type: 'string', description: 'ISO date-time' }, to: { type: 'string', description: 'ISO date-time' } } } },
  { name: 'add_calendar_event', description: "Add an event to the user's phone calendar. The user is asked to allow it first.",
    input_schema: { type: 'object', properties: { title: { type: 'string' }, start: { type: 'string', description: 'ISO date-time with timezone offset' }, end: { type: 'string', description: 'ISO date-time; default one hour after start' }, location: { type: 'string' }, notes: { type: 'string' } }, required: ['title', 'start'] } },
  { name: 'add_reminder', description: "Add a reminder to the user's phone (iPhone Reminders). The user is asked to allow it first.",
    input_schema: { type: 'object', properties: { title: { type: 'string' }, due: { type: 'string', description: 'ISO date-time with timezone offset; optional' }, notes: { type: 'string' } }, required: ['title'] } },
  { name: 'run_shortcut', description: "Run one of the user's iPhone Shortcuts by its exact name (Shortcuts app). Shortcuts can do almost anything on the phone: smart home, Focus, messages, music, files. Optional text input is passed to it. The user is asked to allow it first. If you don't know the name, ask the user.",
    input_schema: { type: 'object', properties: { name: { type: 'string' }, input: { type: 'string', description: 'optional text passed to the shortcut' } }, required: ['name'] } },
  { name: 'open_app', description: "Open another app ready to act; the user finishes it there (e.g. presses Send or Call). kind: call (to = phone number), sms (to, text), whatsapp (to = number with country code, text), email (to, subject, text), maps (query), url (a web or app link in 'to').",
    input_schema: { type: 'object', properties: { kind: { type: 'string', enum: ['call', 'sms', 'whatsapp', 'email', 'maps', 'url'] }, to: { type: 'string' }, text: { type: 'string' }, subject: { type: 'string' }, query: { type: 'string' } }, required: ['kind'] } },
];
// Search and Labs AI (UNIFY-PLAN.md phase 2) also reach the user's TV and Cloud files, when this phone has them
const CLOUD_TOOLS = [
  { name: 'cloud_find', description: "Find files and folders in the user's Shivo Labs Cloud by name (their own encrypted cloud storage). Returns names, sizes and dates.",
    input_schema: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] } },
];
// the phone's own contacts and flashlight (plugins in the app; contacts ask iOS's permission the first time)
const DEVICE_TOOLS = [
  { name: 'find_contact', description: "Look up people in the phone's contacts by name: their phone numbers and email addresses (to call, text or WhatsApp them with open_app).",
    input_schema: { type: 'object', properties: { name: { type: 'string' } }, required: ['name'] } },
  { name: 'flashlight', description: "Turn the phone's flashlight on or off.",
    input_schema: { type: 'object', properties: { on: { type: 'boolean' } }, required: ['on'] } },
];
export const phoneTools = () => [...PHONE_TOOLS, ...(plugin('Contacts') || plugin('Torch') ? DEVICE_TOOLS.filter((t) => plugin(t.name === 'find_contact' ? 'Contacts' : 'Torch')) : []),
  ...(tvPaired() ? TV_TOOLS : []), ...(cloud.creds() ? CLOUD_TOOLS : []), ...(chatSignedIn() ? CHAT_TOOLS : []), ...(hasPc() ? PC_TOOLS : [])];
export const WRITE_TOOLS = new Set(['add_calendar_event', 'add_reminder', 'run_shortcut', 'open_app', 'tv_control', 'tv_message', 'chat_send', 'pc_renew_apps', 'pc_copy_to_cloud']);
export const toolLabel = { list_calendar_events: 'Checked your calendar', add_calendar_event: 'Added to your calendar', add_reminder: 'Added a reminder', run_shortcut: 'Ran a shortcut', open_app: 'Opened an app' };

const parse = (s, d) => { if (!s) return d; const t = Date.parse(s); return Number.isNaN(t) ? null : t; };
const fmt = (ms) => new Date(ms).toISOString();

// env: { calendar (the Capacitor plugin or a fake), abil: { cal, rem } }
// Links that open other apps (Apple's and WhatsApp's documented URL schemes).
export function appLink(i = {}) {
  const e = encodeURIComponent, num = String(i.to || '').replace(/[^\d+]/g, '');
  switch (i.kind) {
    case 'call': return num && `tel:${num}`;
    case 'sms': return num && `sms:${num}${i.text ? '&body=' + e(i.text) : ''}`;
    case 'whatsapp': return `https://wa.me/${num.replace('+', '')}${i.text ? '?text=' + e(i.text) : ''}`;
    case 'email': return `mailto:${i.to || ''}?subject=${e(i.subject || '')}&body=${e(i.text || '')}`;
    case 'maps': return `maps://?q=${e(i.query || i.to || '')}`;
    case 'url': return /^[a-z][\w+.-]*:/i.test(i.to || '') ? i.to : '';
  }
  return '';
}
export async function execPhoneTool(name, input = {}, env) {
  if (name.startsWith('tv_')) return execTvTool(name, input);
  if (name.startsWith('chat_')) return execChatTool(name, input);
  if (name.startsWith('pc_')) return execPcTool(name, input);
  if (name === 'flashlight') {
    const T = plugin('Torch'); if (!T) return { error: 'The flashlight needs the newest app.' };
    try { await (input.on ? T.enable() : T.disable()); return { ok: true, on: !!input.on }; } catch (e) { return { error: String(e.message || e) }; }
  }
  if (name === 'find_contact') {
    const C = plugin('Contacts'); if (!C) return { error: 'Contacts need the newest app.' };
    try {
      const p = await C.requestPermissions(); if (p?.contacts !== 'granted') return { error: 'Contacts access was not allowed on this phone.' };
      const want = String(input.name || '').toLowerCase().trim();
      const { contacts } = await C.getContacts({ projection: { name: true, phones: true, emails: true } });
      const hits = (contacts || []).filter((c) => (c.name?.display || [c.name?.given, c.name?.family].filter(Boolean).join(' ')).toLowerCase().includes(want)).slice(0, 8);
      return { count: hits.length, people: hits.map((c) => ({ name: c.name?.display || [c.name?.given, c.name?.family].filter(Boolean).join(' '), phones: (c.phones || []).map((x) => x.number).filter(Boolean), emails: (c.emails || []).map((x) => x.address).filter(Boolean) })) };
    } catch (e) { return { error: String(e.message || e) }; }
  }
  if (name === 'cloud_find') {
    try {
      const hits = (await cloud.search(String(input.query || ''))).slice(0, 15);
      return { count: hits.length, items: hits.map((f) => ({ name: f.name, kind: f.kind, size: f.kind === 'file' ? f.size : undefined, changed: f.mtime ? new Date(f.mtime).toISOString().slice(0, 10) : undefined })) };
    } catch (e) { return { error: String(e.message || e) }; }
  }
  if (name === 'run_shortcut' && /Android/i.test(globalThis.navigator?.userAgent || '')) return { error: 'Shortcuts are an iPhone app; this is an Android phone.' };
  if (name === 'run_shortcut' || name === 'open_app') {
    if (!env.openURL) return { error: 'This only works inside the installed phone app.' };
    const url = name === 'run_shortcut'
      ? `shortcuts://run-shortcut?name=${encodeURIComponent(input.name || '')}${input.input ? '&input=text&text=' + encodeURIComponent(input.input) : ''}`
      : appLink(input);
    if (!url) return { error: 'Missing details (a number, address or link).' };
    try { const ok = await env.openURL(url); return ok === false ? { error: 'iPhone could not open that.' } : { ok: true, opened: name === 'run_shortcut' ? `Shortcut "${input.name}"` : input.kind }; }
    catch (e) { return { error: String(e.message || e) }; }
  }
  const cal = env.calendar;
  if (!cal) return { error: 'The calendar is only available inside the phone app.' };
  const which = name === 'add_reminder' ? 'rem' : 'cal';
  if (!env.abil?.[which]) return { error: `${which === 'rem' ? 'Reminders are' : 'The calendar is'} switched off in the Phone tab. Ask the user to turn it on.` };
  try {
    if (name === 'list_calendar_events') {
      const perm = await cal.requestFullCalendarAccess(); if (perm?.result !== 'granted') return { error: 'Calendar access was not allowed on this phone.' };
      const from = parse(input.from, Date.now()), to = parse(input.to, (from ?? Date.now()) + 7 * 864e5);
      if (from == null || to == null) return { error: 'Those dates were not valid ISO date-times.' };
      const { result } = await cal.listEventsInRange({ from, to });
      const events = (result || []).slice(0, 40).map((e) => ({ title: e.title, start: e.startDate != null ? fmt(e.startDate) : undefined, end: e.endDate != null ? fmt(e.endDate) : undefined, location: e.location || undefined, allDay: e.isAllDay || undefined }));
      return { count: events.length, events };
    }
    if (name === 'add_calendar_event') {
      const perm = await cal.requestFullCalendarAccess(); if (perm?.result !== 'granted') return { error: 'Calendar access was not allowed on this phone.' };
      const start = parse(input.start); if (start == null) return { error: 'The start time was not a valid ISO date-time.' };
      const end = parse(input.end, start + 36e5); if (end == null) return { error: 'The end time was not a valid ISO date-time.' };
      await cal.createEvent({ title: String(input.title || 'Event'), startDate: start, endDate: end, ...(input.location ? { location: String(input.location) } : {}), ...(input.notes ? { description: String(input.notes) } : {}) });
      return { ok: true, added: input.title, start: fmt(start), end: fmt(end) };
    }
    if (name === 'add_reminder') {
      const perm = await cal.requestFullRemindersAccess(); if (perm?.result !== 'granted') return { error: 'Reminders access was not allowed on this phone.' };
      const due = input.due ? parse(input.due) : undefined; if (input.due && due == null) return { error: 'The due time was not a valid ISO date-time.' };
      await cal.createReminder({ title: String(input.title || 'Reminder'), ...(due != null ? { dueDate: due } : {}), ...(input.notes ? { notes: String(input.notes) } : {}) });
      return { ok: true, added: input.title, due: due != null ? fmt(due) : undefined };
    }
    return { error: `Unknown tool ${name}.` };
  } catch (e) { return { error: String(e?.message || e) }; }
}

// The phone's own facts, so the model can resolve "tomorrow at 9".
export function contextLine(now = new Date()) {
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const off = -now.getTimezoneOffset(), sign = off >= 0 ? '+' : '-', pad = (n) => String(Math.floor(Math.abs(n))).padStart(2, '0');
  return `It is ${now.toString().slice(0, 24)} (${tz}, UTC${sign}${pad(off / 60)}:${pad(off % 60)}).`;
}
