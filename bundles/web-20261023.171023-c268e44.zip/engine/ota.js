// Over-the-air updates for the app's screens and logic (everything in www/).
// phone/install/Publish-OTA.ps1 (on Shivam's PC) puts each new version in R2 through shivo-id (ota/phone/; the GitHub
// repo shivo-labs-updates until 22 Oct 2026), never any keys. latest.json must carry the laptop update key's signature
// (latest.sig; public half hub/update-key.xml): a changed or foreign list is refused before anything is downloaded.
// On opening, and when coming back to the app, we check latest.json; a newer
// version is downloaded in the background by the Capgo updater plugin and switched to straight
// away when nothing is running, or the next time the app is closed otherwise.
// If a new version fails to start, the plugin rolls back to the last one that worked.
import { plugin } from './native.js';

const FEED = 'https://shivo-id.ishivamparmar.workers.dev/ota/phone/latest.json';
const KEY = { kty: 'RSA', n: '0iNyWMVcYB7L9rbnWEi7sze4jubq1ooPR3fzwrXWq-RM2Aecz0I6CysiUjJ759aZKuQo5Epql9e0-nFzcDuINHPgG-JRWX57NFH5g6GhGhpyRsuxbEWEEgWKImr2jZeR7ySHDckKW263mLe0kZs6H9cGxDTkMasgRR2frzCd9VhMu1rl3wM4wY_SfCciWIw3zPLyMs88AO8zzHnnS1zfuzv_qdl2jbc-gfAkN3CmKchKgLWoh5N-s3oZsrwpMaP6bGwZtLIuK6IrGcYeW3jmbVZKNe1iq15t9uNt9aVXoLDiyQy0P1kPEK8anGVchZQv4Xxs1LvcdySzW9iI_070DAVKz-aK7pjqIPFR75-okwr3l8FEyEh5yGnqYsA3xigv9L_s9VRs-88MoWQgOVlB81tvbALGyOXVwMxOaPOQmIwVg9ruR_i647H1Pjg9Ys6Sr98pnsufdMStEbCRpspTav14Csdvq-o1j8CzdJFYMl65B9dFfHs4NJ6IcsAvd2__', e: 'AQAB' };
async function signed(text, sig) {
  try {
    const k = await crypto.subtle.importKey('jwk', KEY, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
    const s = Uint8Array.from(atob(sig.trim()), (c) => c.charCodeAt(0));
    return await crypto.subtle.verify('RSASSA-PKCS1-v1_5', k, s, new TextEncoder().encode(text));
  } catch { return false; }
}
let busy = false, last = 0;

export async function myVersion() {
  try { const r = await fetch('version.json', { cache: 'no-store' }); if (r.ok) return (await r.json()).version || 'built-in'; } catch {}
  return 'built-in';
}

// Call once at startup: tells the plugin this version started fine (otherwise it rolls back).
export async function appReady() {
  const U = plugin('CapacitorUpdater'); if (!U) return;
  try { await U.notifyAppReady(); } catch {}
}

// isIdle(): true when switching now won't interrupt anything. onApplied(v): shown before a switch.
// Returns what happened, in plain words, so Settings can show it. force skips the 1-minute pause.
// the last check's result, for the check-ins (engine/id.js): the Owner pages show an update that keeps failing
export const lastCheck = { ok: true, msg: '', at: 0 };
export async function checkForUpdate(opts = {}) {
  const msg = await check(opts);
  if (msg !== 'Already checking…' && msg !== 'Checked a moment ago.') Object.assign(lastCheck, { ok: !/fail|couldn't|isn't signed|nothing usable/i.test(msg), msg, at: Date.now() });
  return msg;
}
async function check({ isIdle, onApplied, onAbort, force, onStep } = {}) {
  const U = plugin('CapacitorUpdater');
  if (!U) return "This copy of the app can't update itself. Reinstall it once from the PC.";
  if (busy) return 'Already checking…';
  if (!force && Date.now() - last < 60000) return 'Checked a moment ago.';
  busy = true; last = Date.now();
  try {
    onStep?.('Checking…');
    const t = Date.now();
    const [r, rs] = await Promise.all([fetch(FEED + '?t=' + t, { cache: 'no-store' }), fetch(FEED.replace('.json', '.sig') + '?t=' + t, { cache: 'no-store' })]);
    if (!r.ok) return "Couldn't reach the update server (" + r.status + ').';
    const text = await r.text();
    if (!rs.ok || !(await signed(text, await rs.text()))) return "An update was found but it isn't signed by Shivo Labs, so it was ignored.";
    const { version, url, checksum } = JSON.parse(text);
    if (!version || !url) return 'The update server sent nothing usable.';
    // only ever forward: versions start with their date and time (yyyymmdd.hhmmss), so a newer one sorts after. A copy
    // built on the PC (phone/local-build) is often newer than the last published update and must not be taken back
    const mine = await myVersion();
    if (version === mine || (mine !== 'built-in' && version.slice(0, 15) < mine.slice(0, 15))) return "You're up to date.";
    onStep?.('Downloading the new version…');
    const list = (await U.list().catch(() => ({ bundles: [] }))).bundles || [];
    const b = list.find((x) => x.version === version && x.status !== 'error') || await U.download({ url, version, checksum });
    if (isIdle?.()) {
      onApplied?.(version); await new Promise((s) => setTimeout(s, 900));
      try { await U.set({ id: b.id }); } catch (e) { onAbort?.(); throw e; }   // the page restarts; if it can't, give the screen back
      return 'Restarting into the new version…';
    }
    await U.next({ id: b.id }); return 'Downloaded. It switches over next time you open the app.';
  } catch (e) { return 'Update failed: ' + (e?.message || e); } finally { busy = false; }
}
