// Team Chat for Labs AI and Search (UNIFY-PLAN.md phase 2): the same account as the Chat screen (shivoChat: its
// server and this phone's sign-in), through the Chat server's own API (chat/worker): what's new, reading a chat,
// searching messages, sending (the user is asked first).
const DEFAULT_SERVER = 'https://shivo-labs-chat.ishivamparmar.workers.dev';
const cfg = () => { try { return JSON.parse(localStorage.getItem('shivoChat')) || {}; } catch { return {}; } };
export const signedIn = () => !!cfg().token && !cfg().demo;

async function api(path, body) {
  const c = cfg();
  if (!c.token) throw new Error('Sign in to Chat first (the Chat tab).');
  const r = await fetch((c.server || DEFAULT_SERVER).replace(/\/$/, '') + '/api/' + path, {
    method: body ? 'POST' : 'GET', cache: 'no-store',
    headers: { authorization: 'Bearer ' + c.token, ...(body ? { 'content-type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined,
  }).catch(() => { throw new Error("Can't reach Chat. Check the internet."); });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `Chat answered ${r.status}`);
  return j;
}
// the chats with readable names: a group's own name, a direct chat by the other person's name
async function chats() {
  const s = await api('sync');
  const name = (id) => s.users.find((u) => u.id === id)?.name || 'Someone';
  const other = (c) => (c.members || []).find((m) => m.user !== s.me)?.user;
  return {
    name, people: s.users.filter((u) => u.id !== s.me && !u.removed),
    list: s.chats.map((c) => ({ id: c.id, kind: c.kind, unread: c.unread || 0, last: c.last,
      title: c.kind !== 'dm' ? c.name || 'Chat' : other(c) ? name(other(c)) : 'Notes to self' })),
  };
}
const pick = (list, want) => {
  const w = String(want || '').toLowerCase().trim();
  return list.find((c) => c.title.toLowerCase() === w) || list.find((c) => c.title.toLowerCase().includes(w));
};
const when = (t) => new Date(t).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' });
const said = (name, m) => ({ from: name(m.user), at: when(m.ts), text: m.text || (m.file ? `[${m.file.voice ? 'voice note' : 'file: ' + m.file.name}]` : '') });

export const CHAT_TOOLS = [
  { name: 'chat_overview', description: "The user's team Chat (Shivo Labs Chat): their chats and groups, newest first, with unread counts and the last message.",
    input_schema: { type: 'object', properties: {} } },
  { name: 'chat_read', description: 'Read the latest messages of one team Chat conversation, by the group name or the person (for a direct chat).',
    input_schema: { type: 'object', properties: { chat: { type: 'string', description: 'group name or person name' }, count: { type: 'integer', description: 'how many messages, up to 40 (default 15)' } }, required: ['chat'] } },
  { name: 'chat_search', description: 'Search all the team Chat messages the user can see for words.',
    input_schema: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] } },
  { name: 'chat_send', description: 'Send a message in team Chat to a group or a person (by name). The user is asked to allow it first.',
    input_schema: { type: 'object', properties: { to: { type: 'string', description: 'group name or person name' }, text: { type: 'string' } }, required: ['to', 'text'] } },
];

export async function execChatTool(n, i = {}) {
  try {
    const { list, name, people } = await chats();
    if (n === 'chat_overview') {
      return { chats: list.sort((a, b) => (b.last?.ts || 0) - (a.last?.ts || 0)).slice(0, 15).map((c) => ({ chat: c.title, group: c.kind !== 'dm', unread: c.unread, last: c.last ? said(name, c.last) : null })) };
    }
    if (n === 'chat_search') {
      const r = await api('search?q=' + encodeURIComponent(String(i.query || '')));
      return { messages: (r.messages || []).slice(0, 20).map((m) => ({ chat: list.find((c) => c.id === m.chat)?.title || '', ...said(name, m) })) };
    }
    let c = pick(list, n === 'chat_send' ? i.to : i.chat);
    // a person in the team with no direct chat yet: start one (the same as tapping their name in Chat)
    const w = String(n === 'chat_send' ? i.to : i.chat || '').toLowerCase().trim();
    const p = !c && w && (people.find((u) => u.name.toLowerCase() === w) || people.find((u) => u.name.toLowerCase().includes(w)));
    if (p && n === 'chat_send') c = { id: (await api('act', { type: 'chat.dm', user: p.id })).chat, title: p.name };
    if (p && n === 'chat_read') return { chat: p.name, messages: [] };
    if (!c) return { error: `No chat called "${n === 'chat_send' ? i.to : i.chat}"`, chats: list.map((x) => x.title).slice(0, 30) };
    if (n === 'chat_read') {
      const r = await api(`messages?chat=${encodeURIComponent(c.id)}&limit=${Math.max(1, Math.min(40, Number(i.count) || 15))}`);
      return { chat: c.title, messages: (r.messages || []).filter((m) => !m.deleted && m.kind !== 'system').map((m) => said(name, m)) };
    }
    if (n === 'chat_send') {
      const text = String(i.text || '').trim(); if (!text) return { error: 'Empty message' };
      await api('act', { type: 'send', chat: c.id, text, cid: 'ai' + Date.now() });
      return { ok: true, sent: text, to: c.title };
    }
    return { error: `Unknown tool ${n}` };
  } catch (e) { return { error: String(e.message || e) }; }
}
