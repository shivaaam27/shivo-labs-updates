// Tasks: Claude Managed Agents. A hosted agent with its own cloud workspace runs on Anthropic's
// servers, so it keeps going when the phone locks. The phone starts it, watches the live stream,
// and can come back later: listing the session's events replays everything it missed.
// (Tested live, 11 Oct 2026: dropped the connection 4 s in; the task finished by itself and a
// re-attach recovered all of it.)
import { API, headers, apiError, sseEvents, byId } from './claude.js';

const BETA = 'managed-agents-2026-04-01,files-api-2025-04-14';   // files: so the task's outputs can be listed and downloaded
const H = (key) => headers(key, BETA);
async function call(key, method, path, body, signal) {
  const r = await fetch(API + path, { method, headers: H(key), body: body ? JSON.stringify(body) : undefined, signal });
  if (!r.ok) throw await apiError(r);
  return r.json();
}

const SYSTEM = `You are Shivo Labs AI. The user is on their phone, away from any computer, and has handed you a task to do in your own cloud workspace.
- Work on your own. Ask a question only if something truly blocks you.
- Put anything the user should receive (web pages, documents, data, images) in /mnt/session/outputs. Prefer one self-contained file: a web page as a single .html with its CSS and JavaScript inline.
- Check your work before you say you are done (open files, run them, look for errors).
- Finish with a short plain-language summary: what you made, the choices you made, and the file names.
- Phone tools (calendar, reminders) ask the user first and may be unavailable.`;

export async function ensureEnvironment(key, store) {
  const cached = store.get('sl.env'); if (cached) return cached;
  const e = await call(key, 'POST', '/v1/environments', { name: 'shivo-labs-phone', config: { type: 'cloud', networking: { type: 'limited', allow_package_managers: true, allow_mcp_servers: false } } });
  store.set('sl.env', e.id); return e.id;
}

// One agent per model and permission style, made once and reused (agents are saved, versioned objects).
export async function ensureAgent(key, modelKey, ask, store, phoneTools = []) {
  const ck = `sl.agent.${modelKey}.${ask ? 'ask' : 'auto'}.v1`;
  const cached = store.get(ck); if (cached) return cached;
  const m = byId(modelKey) || { id: modelKey };
  const a = await call(key, 'POST', '/v1/agents', {
    name: `Shivo Labs (${ask ? 'asks first' : 'auto'})`, model: m.id, system: SYSTEM,
    tools: [
      { type: 'agent_toolset_20260401', default_config: { enabled: true, permission_policy: { type: 'always_allow' } },
        configs: [...(ask ? ['bash', 'write', 'edit'].map((name) => ({ name, permission_policy: { type: 'always_ask' } })) : []),
          { name: 'web_search', enabled: true }, { name: 'web_fetch', enabled: true }] },
      ...phoneTools.map((t) => ({ type: 'custom', name: t.name, description: t.description, input_schema: t.input_schema })),
    ],
  });
  const v = { id: a.id, version: a.version }; store.set(ck, v); return v;
}

export async function createSession(key, { agent, environmentId, title, capDollars }) {
  const s = await call(key, 'POST', '/v1/sessions', {
    agent: { type: 'agent', id: agent.id, version: agent.version }, environment_id: environmentId, title: (title || 'Shivo Labs task').slice(0, 80),
    ...(capDollars ? { budget: { type: 'limit', max_list_cost: { amount: String(Math.max(1, Math.round(capDollars * 100))), currency: 'USD' } } } : {}),
  });
  return s.id;
}

const textOf = (c) => (Array.isArray(c) ? c.map((x) => x.text || '').join('') : String(c || ''));
const sendEvents = (key, id, events) => call(key, 'POST', `/v1/sessions/${id}/events`, { events });

// $ for a hosted session: model tokens at list price plus $0.08 per active hour (usage is cumulative).
export function sessionCost(modelId, u = {}) {
  const m = byId(modelId); if (!m) return 0;
  const cw = u.cache_creation ? Object.values(u.cache_creation).reduce((a, b) => a + (b || 0), 0) : (u.cache_creation_input_tokens || 0);
  return ((u.input_tokens || 0) * m.inp + cw * m.inp * 1.25 + (u.cache_read_input_tokens || 0) * m.inp * 0.1 + (u.output_tokens || 0) * m.out) / 1e6 + (u.active_seconds || 0) * 0.08 / 3600;
}

// Follow a session. If `message` is given it is sent as a new user turn; otherwise this re-attaches
// to whatever is happening. `seen` (a Set of event ids) is kept by the caller, so nothing is shown twice.
// handlers: onText(full agent message), onStep({id,name,input}), onStepResult(id,{ok,text}),
//           confirm(name,input)->bool, execCustom(name,input)->object, onUsage(cumulative), onStatus(s).
// Returns { status: 'done' | 'budget' | 'stopped' | 'error', error? }.
export async function followSession({ key, sessionId, message, seen, handlers: h, signal }) {
  const ctl = new AbortController();
  signal?.addEventListener('abort', () => ctl.abort(), { once: true });
  // 1. open the live stream first, so nothing slips between the replay and the stream
  const stream = await fetch(`${API}/v1/sessions/${sessionId}/events/stream`, { headers: { ...H(key), accept: 'text/event-stream' }, signal: ctl.signal });
  if (!stream.ok) throw await apiError(stream);

  let final = null, last = null; const answered = new Set();
  const handle = async (e, replay) => {
    // Events we showed before still tell us where the session is (running, idle, finished), but
    // nothing is shown or answered twice.
    const dup = !!(e.id && seen.has(e.id));
    if (e.id) seen.add(e.id);
    if (dup && e.type !== 'agent.tool_use' && e.type !== 'agent.custom_tool_use') {
      if (e.type === 'user.tool_confirmation') answered.add(e.tool_use_id);
      else if (e.type === 'user.custom_tool_result') answered.add(e.custom_tool_use_id);
      else if (e.type === 'session.status_running') { last = 'running'; final = null; }
      else if (e.type === 'session.status_idle') {
        const t = e.stop_reason?.type;
        if (t === 'requires_action') last = 'waiting'; else { last = 'idle'; final = { status: t === 'budget_reached' ? 'budget' : 'done' }; }
      } else if (e.type === 'session.error') final = { status: 'error', error: e.error?.message || e.message || 'The task hit an error.' };
      return replay;
    }
    switch (e.type) {
      case 'user.tool_confirmation': answered.add(e.tool_use_id); break;
      case 'user.custom_tool_result': answered.add(e.custom_tool_use_id); break;
      case 'agent.message': h.onText?.(textOf(e.content)); break;
      case 'agent.tool_use': {
        if (!dup) h.onStep?.({ id: e.id, name: e.name, input: e.input });
        if (e.evaluated_permission === 'ask' && !answered.has(e.id)) {
          const ok = await h.confirm?.(e.name, e.input);
          answered.add(e.id);
          await sendEvents(key, sessionId, [{ type: 'user.tool_confirmation', tool_use_id: e.id, result: ok ? 'allow' : 'deny' }]);
        }
        break;
      }
      case 'agent.tool_result': h.onStepResult?.(e.tool_use_id, { ok: !e.is_error, text: textOf(e.content) }); break;
      case 'agent.custom_tool_use': {
        if (!dup) h.onStep?.({ id: e.id, name: e.name, input: e.input, phone: true });
        if (answered.has(e.id)) break;
        answered.add(e.id);
        let out; try { out = await h.execCustom(e.name, e.input); } catch (err) { out = { error: String(err?.message || err) }; }
        h.onStepResult?.(e.id, { ok: !out?.error, text: out?.error || '' });
        await sendEvents(key, sessionId, [{ type: 'user.custom_tool_result', custom_tool_use_id: e.id, content: [{ type: 'text', text: JSON.stringify(out) }], ...(out?.error ? { is_error: true } : {}) }]);
        break;
      }
      case 'session.usage': h.onUsage?.(e.usage); break;
      case 'session.status_running': last = 'running'; final = null; h.onStatus?.('running'); break;
      case 'session.status_idle': {
        const t = e.stop_reason?.type;
        if (t === 'requires_action') { last = 'waiting'; h.onStatus?.('waiting'); }
        else { last = 'idle'; final = t === 'budget_reached' ? { status: 'budget' } : { status: 'done' }; h.onStatus?.('idle'); }
        break;
      }
      case 'session.error': final = { status: 'error', error: e.error?.message || e.message || 'The task hit an error.' }; break;
      case 'session.status_terminated': final = { status: 'error', error: 'The task ended unexpectedly.' }; break;
      default: break;
    }
    return replay;
  };

  try {
    // 2. replay anything we haven't seen (a task that finished while the phone was locked)
    let page = null, all = [];
    do {
      const j = await call(key, 'GET', `/v1/sessions/${sessionId}/events${page ? `?page=${encodeURIComponent(page)}` : ''}`, null, signal);
      all.push(...(j.data || j.events || [])); page = j.next_page || null;
    } while (page);
    for (const e of all) { if (e.type === 'user.tool_confirmation') answered.add(e.tool_use_id); if (e.type === 'user.custom_tool_result') answered.add(e.custom_tool_use_id); }
    const before = new Set(seen);
    for (const e of all) if (e && typeof e === 'object') await handle(e, true);
    // when re-attaching: if it already finished, we're done
    if (!message && final && all.length && last !== 'running') { ctl.abort(); return final; }
    if (message) { final = null; }
    // 3. a new turn
    if (message) await sendEvents(key, sessionId, [{ type: 'user.message', content: [{ type: 'text', text: message }] }]);
    // 4. the live stream, until the turn ends
    for await (const { data } of sseEvents(stream)) {
      if (!data || typeof data !== 'object') continue;   // keepalives and anything we don't understand
      await handle(data, false);
      if (final) break;
    }
  } catch (err) {
    if (signal?.aborted || err.name === 'AbortError') return { status: 'stopped' };
    throw err;
  } finally { ctl.abort(); }
  return final || { status: 'stopped' };
}

export const interrupt = (key, sessionId) => sendEvents(key, sessionId, [{ type: 'user.interrupt' }]);

// Files the agent wrote to /mnt/session/outputs.
export async function listOutputs(key, sessionId) {
  let data = [];   // outputs can take a moment to be listed after the task goes idle
  for (let i = 0; i < 4 && !data.length; i++) { if (i) await new Promise((r) => setTimeout(r, 2000)); data = (await call(key, 'GET', `/v1/files?scope_id=${encodeURIComponent(sessionId)}`)).data || []; }
  return data.map((f) => ({ id: f.id, name: f.filename || f.name || f.id, size: f.size_bytes ?? f.size ?? 0, type: f.mime_type || f.content_type || '' }));
}
export async function downloadOutput(key, fileId) {
  const r = await fetch(`${API}/v1/files/${fileId}/content`, { headers: H(key) });
  if (!r.ok) throw await apiError(r);
  return r;
}
