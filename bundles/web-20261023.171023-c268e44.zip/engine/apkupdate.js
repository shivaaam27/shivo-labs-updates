// The Android app's own updates (the screens update separately, ota.js). A newer app on the download page
// (shivo-id downloads/android.json) is downloaded, checked (fingerprint, our signing key) and handed to Android, which
// asks "Update?" (one tap). The first time, Android also asks to allow Shivo Labs to install apps. Native side:
// ShivoUpdate (phone/local-build/android/ShivoUpdatePlugin.java). On iPhone there is no such plugin: nothing happens.
import { plugin } from './native.js';

const BASE = 'https://shivo-id.ishivamparmar.workers.dev/dl/';

// what is published, if it is newer than this app: {version, code, sha256} or null
export async function newerApp() {
  const U = plugin('ShivoUpdate'); if (!U) return null;
  const r = await fetch(BASE + 'android.json?t=' + Date.now(), { cache: 'no-store' });
  if (!r.ok) throw new Error("Couldn't reach Shivo Labs (" + r.status + ').');
  const f = await r.json(), me = await U.info();
  return f?.code > me.code && f.sha256 ? f : null;
}

// Check and install. ask(version) -> true to go ahead (omit to go straight on). Returns what happened, in plain words.
export async function updateApp({ ask, say } = {}) {
  const U = plugin('ShivoUpdate'); if (!U) return null;
  let f; try { f = await newerApp(); } catch (e) { return e.message; }
  if (!f) return null;
  if (ask && !(await ask(f.version))) return `Version ${f.version} is ready.`;
  if (!(await U.info()).canInstall) {
    try { localStorage.setItem('sl.apkWant', f.version); } catch {}
    await U.allowInstalls().catch(() => {});
    return 'Switch on "Allow from this source" for Shivo Labs, then come back.';
  }
  try { localStorage.removeItem('sl.apkWant'); } catch {}
  say?.(`Downloading version ${f.version}…`);
  const h = await U.addListener?.('progress', (p) => say?.(`Downloading version ${f.version}… ${Math.round((p.done / p.total) * 100)}%`));
  try { await U.install({ url: BASE + 'ShivoLabs.apk', sha256: f.sha256 }); return `Installing version ${f.version}…`; }
  catch (e) { return e?.message || 'The update failed. It will try again later.'; }
  finally { h?.remove?.(); }
}

// after "Allow from this source" the person comes back to the app: carry on with the update they wanted
export const wantsApp = () => { try { return !!localStorage.getItem('sl.apkWant'); } catch { return false; } };
