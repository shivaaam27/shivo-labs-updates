// The PC for Labs AI and Search (UNIFY-PLAN.md phase 2): whether it is on (the Cloudflare shelf, hub/api/pclink.mjs),
// renewing this iPhone's apps over Wi-Fi (the same request as Settings › Your PC), finding files in the folders the
// PC shares with this phone (Beam's /fs/, beam/app/beam/beamfs.py; at home or through the relay) and copying one into
// Shivo Labs Cloud (encrypted on the phone), so it can be opened, shared or sent on.
import * as beam from './beam.js';
import * as cloud from './cloud.js';
import * as store from './store.js';

// (these two are in the app's own storage, engine/store.js: native on the phone)
const shelf = () => store.get('sl.shelf', '');
const myPhone = () => store.get('sl.myPhone', '');
export const hasPc = () => !!shelf() || !!localStorage.getItem('sl.beamRelay');

async function pcs() {
  if (!shelf()) throw new Error("This phone doesn't know your PC yet. Open Settings › Your PC once.");
  const j = await (await fetch(shelf() + '/pcs', { cache: 'no-store' })).json();
  return { now: j.now, list: (j.pcs || []).map((p) => ({ ...p, live: p.on && j.now - p.at < 20 * 60000 })).sort((a, b) => b.at - a.at) };
}

export const PC_TOOLS = [
  { name: 'pc_status', description: "Whether the user's PC (with Shivo Labs) is on and near this iPhone, and when it was last seen.",
    input_schema: { type: 'object', properties: {} } },
  { name: 'pc_renew_apps', description: "Ask the user's PC to renew this iPhone's apps (their 7-day signatures) over Wi-Fi. Shivo Labs closes for a moment while it renews. The user is asked to allow it first.",
    input_schema: { type: 'object', properties: {} } },
  { name: 'pc_find_files', description: 'Find files by name in the folders the PC shares with this phone (Downloads › Beam and the folders the user added). The PC must be on.',
    input_schema: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] } },
  { name: 'pc_copy_to_cloud', description: "Copy one file from the PC (an id from pc_find_files) into the user's Shivo Labs Cloud, folder \"From PC\", so it is on the phone and can be shared. The user is asked to allow it first.",
    input_schema: { type: 'object', properties: { id: { type: 'string' }, name: { type: 'string' } }, required: ['id'] } },
];

export async function execPcTool(n, i = {}) {
  try {
    if (n === 'pc_status') {
      const { now, list } = await pcs();
      return { pcs: list.slice(0, 3).map((p) => ({ name: p.name, on: p.live, seen: Math.round((now - p.at) / 60000) + ' min ago', nearThisPhone: !!p.phones?.find((x) => x.udid === myPhone())?.nearby })) };
    }
    if (n === 'pc_renew_apps') {
      const { list } = await pcs(), me = myPhone();
      const pc = list.find((p) => p.phones?.some((x) => x.udid === me)) || list[0];
      if (!pc) return { error: 'No PC yet. Open Shivo Labs on your PC.' };
      if (!me) return { error: 'Open Settings › Your PC once and pick this iPhone, then ask again.' };
      const r = await fetch(shelf() + '/ask', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ pc: pc.id, udid: me, action: 'renew' }) });
      if (!r.ok) return { error: 'Could not reach your PC.' };
      const j = await r.json();
      store.set('sl.pcAsk', { id: j.ask.id, at: Date.now() });
      return { ok: true, asked: pc.name, note: pc.live ? 'It renews now; Shivo Labs closes for a moment.' : 'The PC is off: it renews when it is on and this iPhone is near.' };
    }
    if (n === 'pc_find_files') {
      const want = String(i.query || '').toLowerCase().trim(); if (!want) return { error: 'What name?' };
      // the shared folders, three levels deep, at most 400 folders looked at
      const hits = [], todo = [{ id: '', depth: 0 }];
      let seen = 0;
      while (todo.length && seen < 400 && hits.length < 25) {
        const f = todo.shift(); seen++;
        for (const it of await beam.fsList(f.id)) {
          if (it.name.toLowerCase().includes(want)) hits.push({ id: it.id, name: it.name, folder: it.dir || undefined, size: it.dir ? undefined : it.size, changed: it.mtime ? new Date(it.mtime * (it.mtime < 1e11 ? 1000 : 1)).toISOString().slice(0, 10) : undefined, where: it.id.split('/').slice(0, -1).join('/') });
          if (it.dir && f.depth < 3) todo.push({ id: it.id, depth: f.depth + 1 });
        }
      }
      return { count: hits.length, files: hits };
    }
    if (n === 'pc_copy_to_cloud') {
      if (!cloud.creds()) return { error: 'Connect Shivo Labs Cloud first (the Cloud tab).' };
      const blob = await beam.fsFile(String(i.id || ''));
      const name = String(i.name || String(i.id).split('/').pop() || 'File');
      await cloud.add(await cloud.folder('From PC'), new File([blob], name, { type: blob.type || 'application/octet-stream' }));
      return { ok: true, copied: name, to: 'Cloud › From PC' };
    }
    return { error: `Unknown tool ${n}` };
  } catch (e) { return { error: String(e.message || e) }; }
}
