// Looks for Shivo Labs Camera (second set, 15 Oct 2026: all earlier looks replaced). Our own looks, after classic film
// stocks, cinema film and early digital cameras (no maker's names). They live in the app's screens, so new looks and
// changes reach phones over the air. The colour maths is lut.js; each field is optional:
//   cm: colour mix (rows: out r, g, b) · hue: each colour on its own, { band: [hue shift°, colour ×, brightness ±] }
//     (bands: red orange yellow green aqua blue purple magenta) · mono: black-and-white mix (r, g, b)
//   sat: colour amount · dens: film density (strong colours darker and richer) · con: contrast (studio looks)
//   curve: tone curve, points [[in, out], ...] (soft toe and shoulder; out at 0 = the blacks, at 1 = the whites)
//   rgb: { r, g, b } each channel's own curve (warm blacks, cream whites, cool shadows)
//   roll / clip: highlights roll off like film, or end clean like a digicam · sh / hl: shadow and highlight tint
//   hiSat / loSat: colour kept in the brightest / darkest parts (film: cream whites, deep blacks) · lift / fade
//   grain (gsize: its size, 1 = 35 mm 400; gcol: colour in it) · hal: halation, red glow round bright lights
//   mist: soft glow over highlights · crisp: digicam sharpness · vig: darker corners · stamp: offers the orange date
//   g: its group · sw: the two colours of its swatch
export const GROUPS = [['clean', 'CLEAN'], ['film', 'FILM'], ['cine', 'CINEMA'], ['digi', 'DIGICAM'], ['mono', 'BLACK & WHITE']];
export const LOOKS = [
  { id: 'natural', g: 'clean', name: 'Natural', sub: 'True colour, as the camera saw it', con: 1.06, sw: ['#b9b4a9', '#5d7a8c'] },

  // ---- clean
  { id: 'soft', g: 'clean', name: 'Soft', sub: 'Gentle and true: soft contrast, quiet highlights, real skin',
    curve: [[0, 0.035], [0.15, 0.15], [0.5, 0.5], [0.85, 0.83], [1, 0.95]], sat: 0.92,
    hue: { green: [-4, 0.8, 0.02], aqua: [0, 0.85, 0], blue: [0, 0.85, 0.04], orange: [0, 1, 0.03], red: [0, 0.92, 0] },
    rgb: { r: [[0, 0.005], [0.8, 0.805], [1, 0.99]], b: [[0, 0.01], [0.8, 0.785], [1, 0.97]] }, hiSat: 0.7, loSat: 0.8,
    grain: 0.1, gsize: 0.8, gcol: 0.2, mist: 0.12, sw: ['#e6dccd', '#7d8b8a'] },
  { id: 'clear', g: 'clean', name: 'Clear Day', sub: 'Bright and clean: deep blue skies, fresh greens, crisp',
    curve: [[0, 0], [0.2, 0.15], [0.5, 0.53], [0.8, 0.86], [1, 1]], sat: 1.18, dens: 0.3,
    hue: { blue: [-4, 1.3, -0.12], aqua: [-4, 1.2, -0.05], green: [-2, 1.15, -0.03], yellow: [0, 1.08, 0], orange: [0, 0.98, 0.02] }, hiSat: 0.95,
    rgb: { b: [[0, 0], [0.5, 0.505], [1, 1]] }, crisp: 0.15, sw: ['#f4f1ea', '#2f78c4'] },

  // ---- film
  { id: 'neg', g: 'film', name: 'Classic Neg', sub: 'Hard tones, cyan shadows, pink-warm whites, quiet colour',
    curve: [[0, 0.01], [0.2, 0.13], [0.5, 0.5], [0.8, 0.88], [1, 0.97]], sat: 0.8, dens: 0.55,
    hue: { red: [-6, 1.08, -0.1], orange: [-3, 0.92, 0], yellow: [10, 0.7, -0.02], green: [18, 0.65, -0.08], aqua: [6, 0.85, -0.02], blue: [-8, 0.8, -0.05] },
    rgb: { r: [[0, 0], [0.25, 0.2], [0.6, 0.61], [1, 1]], g: [[0, 0.012], [0.5, 0.49], [1, 0.95]], b: [[0, 0.05], [0.3, 0.32], [0.75, 0.73], [1, 0.95]] },
    hiSat: 0.8, loSat: 0.7, grain: 0.3, gsize: 1, gcol: 0.25, hal: 0.06, vig: 0.1, sw: ['#e8c6bd', '#2b5559'] },
  { id: 'gold', g: 'film', name: 'Gold 200', sub: 'Everyday film: golden light, warm skin, punchy reds',
    curve: [[0, 0.02], [0.25, 0.24], [0.5, 0.52], [0.8, 0.84], [1, 0.97]], sat: 1.08, dens: 0.35,
    hue: { red: [2, 1.1, -0.04], orange: [2, 1.05, 0.02], yellow: [-4, 1.15, 0.02], green: [-14, 0.85, 0], blue: [-4, 0.9, 0] },
    rgb: { r: [[0, 0.01], [0.5, 0.53], [1, 1]], g: [[0, 0], [0.5, 0.505], [1, 0.99]], b: [[0, 0.02], [0.5, 0.46], [1, 0.9]] }, hiSat: 0.85,
    grain: 0.32, gsize: 1.1, gcol: 0.35, hal: 0.12, vig: 0.12, sw: ['#f0c76a', '#9a4a2e'] },
  { id: 'portrait', g: 'film', name: 'Portrait 400', sub: 'Soft pastel film: peachy skin, powder blues, warm cream light',
    curve: [[0, 0.045], [0.2, 0.21], [0.5, 0.52], [0.8, 0.81], [1, 0.95]], sat: 0.88,
    hue: { orange: [2, 0.95, 0.05], red: [4, 0.88, 0.02], yellow: [-4, 0.85, 0.02], green: [-10, 0.6, 0.03], aqua: [-4, 0.75, 0.03], blue: [-10, 0.7, 0.06], magenta: [0, 0.85, 0] },
    rgb: { r: [[0, 0.02], [0.5, 0.53], [1, 1]], g: [[0, 0.01], [0.5, 0.505], [1, 0.98]], b: [[0, 0.04], [0.5, 0.48], [1, 0.92]] }, hiSat: 0.75, loSat: 0.85,
    grain: 0.22, gsize: 0.9, gcol: 0.3, mist: 0.1, hal: 0.05, sw: ['#f1d2be', '#8eaab0'] },
  { id: 'green', g: 'film', name: 'Green 400', sub: 'Cool consumer film: a green cast, rich foliage, cyan skies',
    curve: [[0, 0.02], [0.25, 0.23], [0.5, 0.51], [0.8, 0.83], [1, 0.97]], sat: 1.04, dens: 0.3,
    hue: { green: [8, 1.2, -0.05], yellow: [10, 0.9, 0], aqua: [0, 1.12, 0], blue: [8, 0.95, 0], red: [-4, 0.92, 0], orange: [2, 0.9, 0] },
    rgb: { r: [[0, 0], [0.3, 0.27], [0.7, 0.69], [1, 0.98]], g: [[0, 0.025], [0.5, 0.53], [1, 1]], b: [[0, 0.03], [0.5, 0.5], [1, 0.97]] },
    grain: 0.34, gsize: 1.05, gcol: 0.4, hal: 0.06, vig: 0.08, sw: ['#dde8d8', '#2f6b4f'] },
  { id: 'expired', g: 'film', name: 'Expired 98', sub: 'Old film found in a drawer: warm, washed, a little pink',
    curve: [[0, 0.08], [0.3, 0.32], [0.6, 0.62], [1, 0.92]], sat: 0.8,
    hue: { blue: [10, 0.7, 0.05], green: [-10, 0.65, 0], red: [0, 0.95, 0] },
    rgb: { r: [[0, 0.06], [1, 1]], g: [[0, 0], [0.5, 0.48], [1, 0.96]], b: [[0, 0.07], [0.5, 0.46], [1, 0.86]] }, hiSat: 0.75,
    grain: 0.42, gsize: 1.2, gcol: 0.45, hal: 0.15, vig: 0.18, sw: ['#efc9b0', '#8a6b78'] },
  { id: 'slide', g: 'film', name: 'Vivid Slide', sub: 'Slide film: deep blues, rich colour, true blacks',
    curve: [[0, 0], [0.2, 0.13], [0.5, 0.5], [0.8, 0.88], [1, 1]], sat: 1.2, dens: 0.7,
    hue: { blue: [-6, 1.2, -0.1], aqua: [-6, 1.1, -0.05], green: [-4, 1.12, -0.04], red: [-2, 1.1, -0.06], yellow: [0, 1.05, 0] },
    hiSat: 0.92, loSat: 0.95, grain: 0.16, gsize: 0.8, gcol: 0.2, sw: ['#f2d06b', '#123f8c'] },

  // ---- cinema
  { id: 'cinema', g: 'cine', name: 'Cinema 250', sub: 'Warm brown film look: olive greens, slate blues, cream whites',
    curve: [[0, 0.025], [0.18, 0.15], [0.5, 0.5], [0.82, 0.84], [1, 0.95]], sat: 0.82, dens: 0.5,
    hue: { green: [-28, 0.6, -0.08], yellow: [-10, 0.85, -0.02], aqua: [10, 0.55, -0.04], blue: [8, 0.6, -0.05], red: [6, 0.9, -0.04], magenta: [-20, 0.6, 0], purple: [-15, 0.6, 0] },
    rgb: { r: [[0, 0.035], [0.5, 0.53], [1, 0.99]], g: [[0, 0.02], [0.5, 0.5], [1, 0.96]], b: [[0, 0], [0.5, 0.45], [1, 0.86]] }, hiSat: 0.8, loSat: 0.75,
    grain: 0.25, gsize: 1, gcol: 0.3, hal: 0.12, mist: 0.06, vig: 0.16, sw: ['#d9b58c', '#4a3a2c'] },
  { id: 'teal', g: 'cine', name: 'Cine Teal', sub: 'Modern cinema: teal shadows and skies, warm glowing skin',
    curve: [[0, 0.01], [0.2, 0.15], [0.5, 0.5], [0.8, 0.86], [1, 0.97]], sat: 1, dens: 0.4,
    hue: { orange: [-4, 1.18, 0.03], red: [8, 0.9, 0], yellow: [-10, 0.8, 0], green: [40, 0.55, -0.08], aqua: [0, 1.1, -0.04], blue: [-22, 1, -0.05], purple: [-30, 0.7, 0] },
    rgb: { r: [[0, 0], [0.3, 0.24], [0.7, 0.73], [1, 1]], g: [[0, 0.02], [0.5, 0.505], [1, 0.98]], b: [[0, 0.08], [0.3, 0.34], [0.7, 0.67], [1, 0.92]] }, hiSat: 0.85,
    grain: 0.2, gsize: 0.9, gcol: 0.25, hal: 0.08, vig: 0.12, sw: ['#eba06a', '#155a64'] },
  { id: 'tungsten', g: 'cine', name: 'Tungsten 500', sub: 'Night cinema film: cool light, red glow round the lamps',
    curve: [[0, 0.02], [0.2, 0.16], [0.5, 0.5], [0.85, 0.88], [1, 0.98]], sat: 0.92,
    hue: { red: [0, 1.15, 0], orange: [-6, 1.05, 0], green: [20, 0.7, -0.05], blue: [-4, 1.05, 0] },
    rgb: { r: [[0, 0], [0.5, 0.47], [1, 0.96]], b: [[0, 0.04], [0.5, 0.55], [1, 1]] }, hiSat: 0.85,
    grain: 0.4, gsize: 1.15, gcol: 0.35, hal: 0.35, mist: 0.05, vig: 0.15, sw: ['#7fb0d6', '#c2412e'] },

  // ---- digicam
  { id: 'ccd', g: 'digi', name: 'CCD 05', sub: 'Early digital camera: cool, crisp, bright whites',
    curve: [[0, 0], [0.25, 0.24], [0.5, 0.53], [0.8, 0.86], [1, 1]], clip: 0.7, sat: 1.1,
    hue: { blue: [-6, 1.15, 0], green: [8, 1.05, 0], red: [0, 1.05, 0], orange: [0, 0.95, 0.02] },
    rgb: { r: [[0, 0], [0.5, 0.49], [1, 0.98]], b: [[0, 0.02], [0.5, 0.53], [1, 1]] },
    crisp: 0.4, grain: 0.12, gsize: 0.6, gcol: 0.6, vig: 0.05, stamp: true, sw: ['#e9f1f6', '#2b5f9e'] },

  // ---- black and white
  { id: 'silver', g: 'mono', name: 'Silver 400', sub: 'Gritty black and white, darker skies',
    mono: [0.4, 0.5, 0.1], curve: [[0, 0.01], [0.2, 0.12], [0.5, 0.5], [0.8, 0.88], [1, 0.99]],
    grain: 0.5, gsize: 1.15, gcol: 0, vig: 0.18, sw: ['#e6e6e3', '#1d1d1e'] },
  { id: 'print', g: 'mono', name: 'Warm Print', sub: 'Soft toned print: warm greys, gentle blacks',
    mono: [0.3, 0.59, 0.11], curve: [[0, 0.04], [0.25, 0.24], [0.5, 0.5], [0.8, 0.82], [1, 0.95]],
    rgb: { r: [[0, 0.06], [0.5, 0.53], [1, 0.98]], g: [[0, 0.04], [0.5, 0.5], [1, 0.95]], b: [[0, 0.02], [0.5, 0.44], [1, 0.86]] },
    grain: 0.3, gsize: 1, gcol: 0, vig: 0.2, sw: ['#e3d3bb', '#3b2c20'] },
];
// the looks before 15 Oct, each to the nearest new one (settings, setups and rolls saved with an old look)
const MOVED = { coast: 'gold', harbour: 'portrait', chrome50: 'slide', faded: 'expired', haze: 'soft', reel500: 'cinema', coldslide: 'slide',
  softchrome: 'neg', amber: 'gold', dargold: 'gold', cine: 'cinema', pocket: 'ccd', nightcam: 'ccd', pastel: 'soft', mono: 'silver', monosoft: 'print', sepia: 'print' };
export const lookById = (id) => LOOKS.find((l) => l.id === id) || LOOKS.find((l) => l.id === MOVED[id]) || LOOKS[0];
