// Film Roll: load a roll (12, 24 or 36 shots) with one look; the photos stay hidden in the app until the roll
// "develops" (at once, in an hour, or tomorrow morning), then go to Photos together, with a live card counting down
// and a notification when they're ready. The shots are kept by the camera add-on in Documents/ShivoRoll (by name,
// so they survive app updates, which move the app's folder).
const KEY = 'sl.rolls';
export const SIZES = [12, 24, 36];
export const DELAYS = [['now', 'At once'], ['hour', 'In an hour'], ['morning', 'Tomorrow 8:00']];

export function load() {
  try { const r = JSON.parse(localStorage.getItem(KEY) || 'null'); if (r && Array.isArray(r.list)) return r; } catch {}
  return { cur: null, list: [] };
}
export function store(r) { try { localStorage.setItem(KEY, JSON.stringify(r)); } catch {} }

export function readyAt(delay, now = Date.now()) {
  if (delay === 'hour') return now + 3600e3;
  if (delay === 'morning') { const d = new Date(now); d.setDate(d.getDate() + 1); d.setHours(8, 0, 0, 0); return +d; }
  return now;
}
export const left = (roll) => (roll ? roll.size - roll.shots.length : 0);
export const when = (t) => {
  const d = new Date(t), today = new Date().toDateString() === d.toDateString();
  return (today ? '' : 'tomorrow ') + d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
};

// a kept shot's file, wherever the app's folder is now
export async function fileOf(plugin, name) {
  const FS = plugin('Filesystem');
  if (!FS) return null;
  try { return (await FS.getUri({ path: 'ShivoRoll/' + name, directory: 'DOCUMENTS' })).uri; } catch { return null; }
}
export const shown = (uri) => (uri && globalThis.Capacitor?.convertFileSrc ? globalThis.Capacitor.convertFileSrc(uri) : uri);
