// A look as a colour table (3D LUT). The native camera engine applies it live and to the photo with Core Image
// (CIColorCube); the web engine (develop.js) reads the same table from a texture, so a look is exactly the same in
// both, and new looks arrive over the air. Spatial parts (grain, halation, mist, crispness, vignette) are separate
// settings, not in the table. False colour is a table too. Returns RGBA bytes, red changing fastest.
//
// The colour engine (Oct 2026, second version). What makes film and cinema looks differ is not one saturation and
// one contrast for the whole picture but:
//   - each colour moving on its own (greens to olive, blues to slate, skin kept warm): hue bands
//   - a tone curve with a soft toe and shoulder, and its own curve for red, green and blue (warm blacks, cream whites)
//   - film's density (strong colours darker and richer) and its quieter colour in the brightest and darkest parts
// A look's fields (all optional; see looks.js): cm · hue · mono · sat · dens · con · curve · roll · clip · rgb ·
// sh / hl · hiSat · loSat · lift · fade.

const luma = (r, g, b) => 0.2126 * r + 0.7152 * g + 0.0722 * b;
const sat01 = (x) => Math.max(0, Math.min(1, x));
const smooth = (a, b, x) => { const t = sat01((x - a) / (b - a)); return t * t * (3 - 2 * t); };

// a smooth curve through points [[x, y], ...] (monotone: it never wiggles between them), as a table of 1024 steps
const CURVES = new WeakMap();   // (by the points array itself: a look's arrays don't change)
function curveTable(pts) {
  if (CURVES.has(pts)) return CURVES.get(pts);
  const key = pts;
  const P = [...pts].sort((a, b) => a[0] - b[0]); if (P[0][0] > 0) P.unshift([0, P[0][1] - P[0][0] * ((P[1]?.[1] ?? 1) - P[0][1]) / Math.max(1e-6, (P[1]?.[0] ?? 1) - P[0][0])]);
  if (P[P.length - 1][0] < 1) P.push([1, P[P.length - 1][1] + (1 - P[P.length - 1][0])]);
  const n = P.length, d = [], m = [];
  for (let i = 0; i < n - 1; i++) d.push((P[i + 1][1] - P[i][1]) / Math.max(1e-6, P[i + 1][0] - P[i][0]));
  m[0] = d[0]; m[n - 1] = d[n - 2];
  for (let i = 1; i < n - 1; i++) m[i] = d[i - 1] * d[i] <= 0 ? 0 : (d[i - 1] + d[i]) / 2;
  for (let i = 0; i < n - 1; i++) {   // Fritsch–Carlson: keep it monotone
    if (d[i] === 0) { m[i] = m[i + 1] = 0; continue; }
    const a = m[i] / d[i], b = m[i + 1] / d[i], s = a * a + b * b;
    if (s > 9) { const t = 3 / Math.sqrt(s); m[i] = t * a * d[i]; m[i + 1] = t * b * d[i]; }
  }
  const T = new Float32Array(1024);
  for (let j = 0, i = 0; j < 1024; j++) {
    const x = j / 1023; while (i < n - 2 && x > P[i + 1][0]) i++;
    const h = Math.max(1e-6, P[i + 1][0] - P[i][0]), t = sat01((x - P[i][0]) / h), t2 = t * t, t3 = t2 * t;
    T[j] = (2 * t3 - 3 * t2 + 1) * P[i][1] + (t3 - 2 * t2 + t) * h * m[i] + (-2 * t3 + 3 * t2) * P[i + 1][1] + (t3 - t2) * h * m[i + 1];
  }
  CURVES.set(key, T); return T;
}
const at = (T, x) => { const f = sat01(x) * 1023, i = Math.min(1022, Math.floor(f)); return T[i] + (T[i + 1] - T[i]) * (f - i); };

// hue bands: the centre of each colour (degrees) and how far it reaches
const BANDS = { red: 0, orange: 30, yellow: 58, green: 115, aqua: 180, blue: 220, purple: 275, magenta: 320 };
const REACH = 38;
function rgb2hsv(r, g, b) {
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), c = mx - mn;
  let h = 0;
  if (c > 1e-6) h = mx === r ? ((g - b) / c) % 6 : mx === g ? (b - r) / c + 2 : (r - g) / c + 4;
  return [(h * 60 + 360) % 360, mx > 1e-6 ? c / mx : 0, mx];
}
function hsv2rgb(h, s, v) {
  const c = v * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = v - c, k = Math.floor(((h % 360) + 360) % 360 / 60);
  const [r, g, b] = [[c, x, 0], [x, c, 0], [0, c, x], [0, x, c], [x, 0, c], [c, 0, x]][k];
  return [r + m, g + m, b + m];
}
// each band: [hue shift in degrees, colour amount (1 = as is), brightness (+/-)]
function hueBands(hue, r, g, b) {
  let [h, s, v] = rgb2hsv(r, g, b);
  if (s < 0.02) return [r, g, b];
  let dh = 0, ds = 0, dv = 0, wsum = 0;
  for (const k in hue) {
    const c = BANDS[k]; if (c == null) continue;
    let d = Math.abs(h - c); if (d > 180) d = 360 - d;
    const w = d >= REACH ? 0 : 0.5 + 0.5 * Math.cos(Math.PI * d / REACH);
    if (!w) continue;
    const [sh = 0, sa = 1, lu = 0] = hue[k];
    dh += sh * w; ds += (sa - 1) * w; dv += lu * w; wsum += w;
  }
  if (!wsum) return [r, g, b];
  const grip = smooth(0.02, 0.25, s);   // greys stay grey: the bands act on real colour only
  h += dh * grip; s = sat01(s * (1 + ds * grip)); v = Math.max(0, v * (1 + dv * grip * s));
  return hsv2rgb(h, s, v);
}

function lookColour(L, amount, r0, g0, b0) {
  const cm = L.cm;
  let r = r0, g = g0, b = b0;
  if (cm) { r = cm[0][0] * r0 + cm[0][1] * g0 + cm[0][2] * b0; g = cm[1][0] * r0 + cm[1][1] * g0 + cm[1][2] * b0; b = cm[2][0] * r0 + cm[2][1] * g0 + cm[2][2] * b0; }
  r = sat01(r); g = sat01(g); b = sat01(b);
  if (L.hue && !L.mono) [r, g, b] = hueBands(L.hue, r, g, b);
  if (L.mono) { const m = L.mono[0] * r + L.mono[1] * g + L.mono[2] * b; r = g = b = m; }
  let l = luma(r, g, b);
  const sat = L.sat ?? 1;
  r = l + (r - l) * sat; g = l + (g - l) * sat; b = l + (b - l) * sat;
  // density: a strong colour comes out darker and richer, as in film (light colours stay light)
  if (L.dens) { const mx = Math.max(r, g, b), mn = Math.min(r, g, b), c = mx > 1e-6 ? (mx - mn) / mx : 0, k = 1 - L.dens * 0.45 * c * c * smooth(0.05, 0.6, mx); r *= k; g *= k; b *= k; }
  // contrast as before (looks made in the studio use it), then the look's own tone curve
  const k = (L.con ?? 1) - 1;
  if (k) { const curve = (x) => { x = sat01(x); if (k > 0) { const s = x * x * (3 - 2 * x); return x + (s - x) * sat01(k * 2.2); } return 0.5 + (x - 0.5) * (1 + k); }; r = curve(r); g = curve(g); b = curve(b); }
  if (L.curve) { const T = curveTable(L.curve); r = at(T, r); g = at(T, g); b = at(T, b); }
  // film: highlights roll off softly; digicam: they clip clean and bright
  const ro = L.roll || 0, cl = L.clip || 0;
  if (ro || cl) { const shape = (x) => { if (ro) x -= ro * 0.22 * Math.max(0, x - 0.55) ** 2 / 0.45; if (cl) x = sat01(x * (1 + cl * 0.14)); return x; }; r = shape(r); g = shape(g); b = shape(b); }
  // each channel's own curve: the colour of the blacks, the middle and the whites
  if (L.rgb) { if (L.rgb.r) r = at(curveTable(L.rgb.r), r); if (L.rgb.g) g = at(curveTable(L.rgb.g), g); if (L.rgb.b) b = at(curveTable(L.rgb.b), b); }
  l = luma(sat01(r), sat01(g), sat01(b));
  if (L.sh || L.hl) {
    const sh = L.sh || [0, 0, 0], hl = L.hl || [0, 0, 0], ws = 1 - smooth(0, 0.55, l), wh = smooth(0.45, 1, l);
    r += sh[0] * ws + hl[0] * wh; g += sh[1] * ws + hl[1] * wh; b += sh[2] * ws + hl[2] * wh;
  }
  // quieter colour in the brightest and the darkest parts (film), so whites are cream and blacks deep, never neon
  if (L.hiSat != null || L.loSat != null) {
    l = luma(sat01(r), sat01(g), sat01(b));
    const q = 1 - (1 - (L.hiSat ?? 1)) * smooth(0.6, 1, l) - (1 - (L.loSat ?? 1)) * (1 - smooth(0, 0.3, l));
    r = l + (r - l) * q; g = l + (g - l) * q; b = l + (b - l) * q;
  }
  const lift = L.lift || 0, fade = L.fade || 0;
  if (lift || fade) { const out = (x) => lift + sat01(x) * (1 - lift - fade); r = out(r); g = out(g); b = out(b); }
  return [sat01(r0 + (sat01(r) - r0) * amount), sat01(g0 + (sat01(g) - g0) * amount), sat01(b0 + (sat01(b) - b0) * amount)];
}
function falseColour(r, g, b) {
  const l = luma(r, g, b);
  if (l < 0.03) return [0.45, 0.1, 0.6]; if (l < 0.12) return [0.1, 0.3, 0.9];
  if (l > 0.42 && l < 0.52) return [0.35, 0.8, 0.4]; if (l > 0.97) return [0.95, 0.15, 0.1];
  if (l > 0.88) return [0.98, 0.6, 0.1]; if (l > 0.76) return [0.95, 0.88, 0.3];
  return [l, l, l];
}
export { lookColour };

// { look, amount, false } -> RGBA bytes of an n x n x n table (red fastest, then green, then blue). The look at full
// strength is worked out once and kept; a weaker strength is a straight blend of it with no change (cheap, so the
// STRENGTH ruler stays smooth)
const TABLES = new Map();
function fullTable(look, fc, n) {
  const key = fc ? 'false|' + n : look.mine || String(look.id).startsWith('studio') ? null : look.id + '|' + n;
  if (key && TABLES.has(key)) return TABLES.get(key);
  const px = new Uint8Array(n * n * n * 4);
  let i = 0;
  for (let bi = 0; bi < n; bi++) for (let gi = 0; gi < n; gi++) for (let ri = 0; ri < n; ri++) {
    const r = ri / (n - 1), g = gi / (n - 1), b = bi / (n - 1);
    const c = fc ? falseColour(r, g, b) : lookColour(look, 1, r, g, b);
    px[i++] = Math.round(c[0] * 255); px[i++] = Math.round(c[1] * 255); px[i++] = Math.round(c[2] * 255); px[i++] = 255;
  }
  if (key) { if (TABLES.size > 24) TABLES.delete(TABLES.keys().next().value); TABLES.set(key, px); }
  return px;
}
export function lutBytes({ look, amount = 1, false: fc = false }, size = 33) {
  const n = size, full = fullTable(look, fc, n);
  if (fc || amount >= 0.999) return full;
  const a = Math.max(0, amount), px = new Uint8Array(full.length);
  let i = 0;
  for (let bi = 0; bi < n; bi++) for (let gi = 0; gi < n; gi++) for (let ri = 0; ri < n; ri++) {
    const id = [ri, gi, bi];
    for (let c = 0; c < 3; c++) { const o = id[c] * 255 / (n - 1); px[i + c] = Math.round(o + (full[i + c] - o) * a); }
    px[i + 3] = 255; i += 4;
  }
  return px;
}
// the same as base64 (what the native engine takes)
export function lutFor(v, size = 33) {
  const px = lutBytes(v, size);
  let s = ''; for (let j = 0; j < px.length; j += 0x8000) s += String.fromCharCode.apply(null, px.subarray(j, j + 0x8000));
  return { size, data: btoa(s) };
}
