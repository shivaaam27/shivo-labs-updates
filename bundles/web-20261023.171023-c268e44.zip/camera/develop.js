// Develops a camera frame on the phone's graphics chip (WebGL): crop and zoom, exposure, white balance,
// a gentle highlight roll-off, then the look: its colour from the same colour table the native engine uses (lut.js,
// read here from a texture), then halation, vignette and grain. The same code draws the live view and the saved photo,
// so what you see is what you get. Zebra, false colour and focus peaking are drawn on the live view only.

import { lutBytes } from './lut.js';

const VS = `attribute vec2 p; varying vec2 v; void main(){ v = vec2((p.x + 1.0) * 0.5, (1.0 - p.y) * 0.5); gl_Position = vec4(p, 0.0, 1.0); }`;
const FS = `precision highp float;
varying vec2 v;
uniform sampler2D u_tex; uniform vec2 u_off, u_scale, u_texel; uniform float u_mirror, u_aspect;
uniform float u_ev; uniform vec3 u_wb;
uniform sampler2D u_lut; uniform float u_n;
uniform float u_hal, u_vig, u_grain, u_gcells, u_amount, u_seed;
uniform float u_zebra, u_false, u_peak;
float luma(vec3 c){ return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float h(vec2 q){ return fract(sin(dot(q, vec2(12.9898, 78.233))) * 43758.5453); }
vec3 soft(vec3 x){ vec3 k = 0.8 + 0.2 * (1.0 - exp(-(x - 0.8) / 0.2)); return mix(x, k, step(0.8, x)); }
// the colour table: n x n x n, laid out as n wide (red) and n x n high (blue blocks of green rows)
vec3 lut3(vec3 c){
  vec3 q = clamp(c, 0.0, 1.0) * (u_n - 1.0);
  float b0 = floor(q.b), b1 = min(b0 + 1.0, u_n - 1.0), x = (q.r + 0.5) / u_n;
  vec3 lo = texture2D(u_lut, vec2(x, (b0 * u_n + q.g + 0.5) / (u_n * u_n))).rgb;
  vec3 hi = texture2D(u_lut, vec2(x, (b1 * u_n + q.g + 0.5) / (u_n * u_n))).rgb;
  return mix(lo, hi, q.b - b0);
}
vec3 base(vec2 s){
  vec3 c = texture2D(u_tex, s).rgb;
  vec3 lin = pow(max(c, 0.0), vec3(2.2)) * exp2(u_ev) * u_wb;
  return pow(clamp(soft(lin), 0.0, 1.0), vec3(1.0 / 2.2));
}
void main(){
  vec2 uv = v; if (u_mirror > 0.5) uv.x = 1.0 - uv.x;
  vec2 s = u_off + uv * u_scale;
  vec3 b = base(s);
  vec3 o = lut3(b);
  if (u_hal > 0.0) {
    float g = 0.0; float r = 0.006;
    for (int i = 0; i < 8; i++) {
      float a = float(i) * 0.785398;
      vec2 d = vec2(cos(a), sin(a)) * r * vec2(1.0, u_aspect);
      g += smoothstep(0.72, 1.0, luma(base(s + d * u_scale))) + smoothstep(0.72, 1.0, luma(base(s + d * 2.2 * u_scale)));
    }
    o += vec3(1.0, 0.34, 0.14) * (g / 16.0) * u_hal * 0.9;
  }
  vec2 cq = (v - 0.5) * vec2(u_aspect, 1.0);
  o *= 1.0 - u_vig * smoothstep(0.45, 1.0, length(cq) / length(vec2(0.5 * u_aspect, 0.5)));
  if (u_grain > 0.0) {
    vec2 gq = floor(v * vec2(u_aspect, 1.0) * u_gcells);
    float n = (h(gq + u_seed) + h(gq * 1.37 + u_seed + 3.1) - 1.0);
    float m = 1.0 - abs(luma(o) - 0.5) * 1.3;
    o += n * u_grain * 0.16 * max(m, 0.15);
  }
  o = clamp(mix(b, o, u_amount), 0.0, 1.0);
  float bl = luma(b);
  if (u_false > 0.5) {
    vec3 f = vec3(bl);
    if (bl < 0.03) f = vec3(0.45, 0.1, 0.6); else if (bl < 0.12) f = vec3(0.1, 0.3, 0.9);
    else if (bl > 0.42 && bl < 0.52) f = vec3(0.35, 0.8, 0.4); else if (bl > 0.97) f = vec3(0.95, 0.15, 0.1);
    else if (bl > 0.88) f = vec3(0.98, 0.6, 0.1); else if (bl > 0.76) f = vec3(0.95, 0.88, 0.3);
    o = f;
  }
  if (u_zebra > 0.5 && bl > 0.96 && mod(gl_FragCoord.x + gl_FragCoord.y, 14.0) < 7.0) o = mix(o, vec3(0.0), 0.75);
  if (u_peak > 0.5) {
    vec2 t = u_texel * 1.5;
    float gx = luma(texture2D(u_tex, s + vec2(t.x, 0.0)).rgb) - luma(texture2D(u_tex, s - vec2(t.x, 0.0)).rgb);
    float gy = luma(texture2D(u_tex, s + vec2(0.0, t.y)).rgb) - luma(texture2D(u_tex, s - vec2(0.0, t.y)).rgb);
    o = mix(o, vec3(0.56, 0.86, 0.6), smoothstep(0.14, 0.26, length(vec2(gx, gy))));
  }
  gl_FragColor = vec4(o, 1.0);
}`;

// colour of light at a temperature (K), for white balance
function kelvin(k) {
  const t = k / 100; let r, g, b;
  if (t <= 66) { r = 255; g = 99.47 * Math.log(t) - 161.12; b = t <= 19 ? 0 : 138.52 * Math.log(t - 10) - 305.04; }
  else { r = 329.7 * Math.pow(t - 60, -0.1332); g = 288.12 * Math.pow(t - 60, -0.0755); b = 255; }
  const c = (x) => Math.min(255, Math.max(1, x)) / 255;
  return [c(r), c(g), c(b)];
}
// As on a camera: setting a lower K makes the picture cooler. 5600 K and tint 0 change nothing.
export function wbGains(k, tint) {
  const ref = kelvin(5600), to = kelvin(k);
  const g = [ref[0] / to[0], ref[1] / to[1], ref[2] / to[2]];
  g[1] *= 1 - tint * 0.004;
  const y = 0.2126 * g[0] + 0.7152 * g[1] + 0.0722 * g[2];
  return g.map((x) => x / y);
}
const LUT_N = 33;

export function makeRenderer(canvas, preserve = false) {
  const gl = canvas.getContext('webgl', { preserveDrawingBuffer: preserve, alpha: false, antialias: false, premultipliedAlpha: false });
  if (!gl) return null;
  const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
  const pr = gl.createProgram();
  gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr);
  if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(pr));
  gl.useProgram(pr);
  const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  const ap = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(ap); gl.vertexAttribPointer(ap, 2, gl.FLOAT, false, 0, 0);
  const tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex);
  for (const [k, val] of [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, k, val);
  // the look's colour table, on texture unit 1 (made again only when the look changes)
  const lutTex = gl.createTexture(); let lutKey = '';
  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, lutTex);
  for (const [k, val] of [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, k, val);
  gl.activeTexture(gl.TEXTURE0);
  const U = {};
  for (const n of ['u_tex', 'u_off', 'u_scale', 'u_texel', 'u_mirror', 'u_aspect', 'u_ev', 'u_wb', 'u_lut', 'u_n', 'u_hal', 'u_vig', 'u_grain', 'u_gcells', 'u_amount', 'u_seed', 'u_zebra', 'u_false', 'u_peak']) U[n] = gl.getUniformLocation(pr, n);
  const maxSize = Math.min(gl.getParameter(gl.MAX_TEXTURE_SIZE), ...gl.getParameter(gl.MAX_VIEWPORT_DIMS));
  return {
    gl, canvas, maxSize,
    // src: a video or image; sw, sh: its size; o: { w, h, zoom, mirror, ev, k, tint, look, amount, grain, zebra, false, peak, seed }
    draw(src, sw, sh, o) {
      if (canvas.width !== o.w) canvas.width = o.w;
      if (canvas.height !== o.h) canvas.height = o.h;
      gl.viewport(0, 0, o.w, o.h);
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
      const A = o.w / o.h, S = sw / sh, z = o.zoom || 1;
      let sx = 1, sy = 1; if (S > A) sx = A / S; else sy = S / A;
      sx /= z; sy /= z;
      const L = o.look;
      gl.uniform1i(U.u_tex, 0);
      gl.uniform2f(U.u_off, (1 - sx) / 2, (1 - sy) / 2); gl.uniform2f(U.u_scale, sx, sy); gl.uniform2f(U.u_texel, 1 / sw, 1 / sh);
      gl.uniform1f(U.u_mirror, o.mirror ? 1 : 0); gl.uniform1f(U.u_aspect, A);
      gl.uniform1f(U.u_ev, o.ev || 0); gl.uniform3fv(U.u_wb, wbGains(o.k || 5600, o.tint || 0));
      const key = L.mine || String(L.id).startsWith('studio') ? L : L.id;   // (a studio look is a new object at each change)
      if (key !== lutKey) {
        lutKey = key;
        gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, lutTex);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, LUT_N, LUT_N * LUT_N, 0, gl.RGBA, gl.UNSIGNED_BYTE, lutBytes({ look: L, amount: 1 }, LUT_N));
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex);
      }
      gl.uniform1i(U.u_lut, 1); gl.uniform1f(U.u_n, LUT_N);
      gl.uniform1f(U.u_hal, L.hal || 0); gl.uniform1f(U.u_vig, L.vig || 0);
      gl.uniform1f(U.u_grain, (L.grain || 0) * (o.grain ?? 1)); gl.uniform1f(U.u_gcells, 1100);
      gl.uniform1f(U.u_amount, o.amount ?? 1); gl.uniform1f(U.u_seed, o.seed || 0);
      gl.uniform1f(U.u_zebra, o.zebra ? 1 : 0); gl.uniform1f(U.u_false, o.false ? 1 : 0); gl.uniform1f(U.u_peak, o.peak ? 1 : 0);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    },
    pixels() { const { width: w, height: h } = canvas, px = new Uint8Array(w * h * 4); gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px); return { w, h, px }; },
  };
}
