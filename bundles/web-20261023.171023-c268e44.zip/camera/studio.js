// Look Studio and shared looks (pure helpers, no screen). A look made in the studio is a handful of slider numbers (v);
// studioLook() turns them into a look the camera can use (the fields documented at the top of looks.js).
// valuesOf() goes the other way, so any look can be opened in the studio as a copy. A look can also travel as a link
// (shivolabs://look/<code>): decodeLook() treats the code as untrusted and keeps only the fields it knows, each held to a safe range.
const I = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

// the sliders, in three groups: key, name, least, most, as first opened
export const SECTIONS = [
  ['COLOUR', [['sat', 'COLOUR', 0, 160, 100], ['con', 'CONTRAST', 60, 150, 100], ['warm', 'WARMTH', -100, 100, 0]]],
  ['TONE', [['fade', 'FADE', 0, 100, 0], ['lift', 'FADED BLACKS', 0, 100, 0], ['roll', 'ROLL-OFF', 0, 100, 0], ['clip', 'DIGICAM CLIP', 0, 100, 0]]],
  ['FILM', [['grain', 'GRAIN', 0, 100, 0], ['gsize', 'GRAIN SIZE', 50, 200, 100], ['gcol', 'GRAIN COLOUR', 0, 100, 30], ['hal', 'HALATION', 0, 100, 0],
    ['mist', 'MIST', 0, 100, 0], ['crisp', 'CRISPNESS', 0, 100, 0], ['vig', 'VIGNETTE', 0, 50, 0]]],
];
const ROWS = SECTIONS.flatMap(([, r]) => r);
export const START = () => ({ ...Object.fromEntries(ROWS.map(([k, , , , d]) => [k, d])), mono: false, stamp: false });

// slider numbers of any saved look: missing ones start at their usual value (looks saved before the film controls only had a few)
export function norm(v = {}) {
  const o = START();
  for (const [k, , a, b, d] of ROWS) o[k] = typeof v[k] === 'number' && Number.isFinite(v[k]) ? clamp(Math.round(v[k]), a, b) : d;
  if (typeof v.lift !== 'number') o.lift = clamp(Math.round((v.fade || 0) * 0.6), 0, 100);   // (the old FADE also lifted the blacks)
  o.mono = !!v.mono; o.stamp = !!v.stamp;
  if (Array.isArray(v.mix) && v.mix.length === 3 && v.mix.every((x) => typeof x === 'number')) o.mix = v.mix.map((x) => clamp(x, 0, 1.2));
  if (v.b && typeof v.b === 'object') o.b = v.b;   // the colour character of the look it was copied from
  return o;
}
const add = (a, b) => (a || [0, 0, 0]).map((x, i) => x + b[i]);
const warmOf = (L) => clamp(((L.hl?.[0] || 0) - (L.hl?.[2] || 0)) / 0.08, -1, 1);

export function studioLook(v0, id, name) {
  const v = norm(v0), w = v.warm / 100, b = v.b || {};
  const L = { id, name, sub: 'Your look', mine: true, sat: v.sat / 100, con: v.con / 100, lift: v.lift / 1000, fade: v.fade / 2000, roll: v.roll / 100, clip: v.clip / 100,
    cm: b.cm || I, sh: add(b.sh, [0.012 * w, 0.004 * w, -0.02 * w]), hl: add(b.hl, [0.045 * w, 0.02 * w, -0.035 * w]),
    hue: b.hue, curve: b.curve, rgb: b.rgb, dens: b.dens, hiSat: b.hiSat, loSat: b.loSat,
    mono: v.mono ? (v.mix || [0.3, 0.59, 0.11]) : undefined, grain: v.grain / 100, gsize: v.gsize / 100, gcol: v.gcol / 100, hal: v.hal / 100, mist: v.mist / 100, crisp: v.crisp / 100,
    vig: v.vig / 100, stamp: v.stamp, v: { ...v } };
  const tone = warmOf(L);
  L.sw = v.mono ? ['#d9d8d4', '#2a2a2b'] : [tone > 0.2 ? '#d99a5b' : tone < -0.2 ? '#8fa7b8' : '#b9b4a9', v.sat > 120 ? '#1f5fa8' : '#4b6670'];
  if (v.mono && tone > 0.2) L.sw = ['#d8bf9c', '#3b2c20'];
  return L;
}

// any look's fields as slider numbers (warmth starts at 0: the look's own colour is kept as it is)
export function valuesOf(L) {
  const r = (x, k) => { const row = ROWS.find((q) => q[0] === k); return clamp(Math.round(x), row[2], row[3]); };
  return norm({ sat: r((L.sat ?? 1) * 100, 'sat'), con: r((L.con ?? 1) * 100, 'con'), warm: 0, fade: r((L.fade || 0) * 2000, 'fade'), lift: r((L.lift || 0) * 1000, 'lift'),
    roll: r((L.roll || 0) * 100, 'roll'), clip: r((L.clip || 0) * 100, 'clip'), grain: r((L.grain || 0) * 100, 'grain'), gsize: r((L.gsize ?? 1) * 100, 'gsize'),
    gcol: r((L.gcol ?? 0.3) * 100, 'gcol'), hal: r((L.hal || 0) * 100, 'hal'), mist: r((L.mist || 0) * 100, 'mist'), crisp: r((L.crisp || 0) * 100, 'crisp'),
    vig: r((L.vig || 0) * 100, 'vig'), mono: !!L.mono, mix: L.mono || undefined, stamp: !!L.stamp, b: { cm: L.cm || I, sh: L.sh || [0, 0, 0], hl: L.hl || [0, 0, 0], hue: L.hue, curve: L.curve, rgb: L.rgb, dens: L.dens, hiSat: L.hiSat, loSat: L.loSat } });
}

/* ---------- looks as links ---------- */
const NUM = { sat: [0, 2, 1], con: [0.5, 1.6, 1], lift: [0, 0.12, 0], fade: [0, 0.1, 0], roll: [0, 1, 0], clip: [0, 1, 0], grain: [0, 1.2, 0], gsize: [0.4, 2.5, 1],
  gcol: [0, 1, 0.3], hal: [0, 1, 0], mist: [0, 1, 0], crisp: [0, 1, 0], vig: [0, 0.5, 0], dens: [0, 1, 0], hiSat: [0, 1.2, 1], loSat: [0, 1.2, 1] };
const BANDS = ['red', 'orange', 'yellow', 'green', 'aqua', 'blue', 'purple', 'magenta'];
const pts = (a) => (Array.isArray(a) && a.length >= 2 && a.length <= 12 && a.every((p) => Array.isArray(p) && p.length === 2 && p.every((x) => typeof x === 'number' && Number.isFinite(x)))
  ? a.map(([x, y]) => [r3(clamp(x, 0, 1)), r3(clamp(y, -0.1, 1.1))]) : undefined);
const r3 = (x) => Math.round(x * 1000) / 1000;
// a name that is safe to show and keep: letters, numbers and a few quiet marks only (nothing that means something in a page)
export const cleanName = (s, d = '') => (typeof s === 'string' ? s.replace(/[^\p{L}\p{N}\p{M} .,:;!?+&\-_·\/#()%]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 24) : '') || d;
const mat = (m, rows, cols, lo, hi, d) => (Array.isArray(m) && m.length === rows && m.every((r) => Array.isArray(r) && r.length === cols && r.every((x) => typeof x === 'number' && Number.isFinite(x)))
  ? m.map((r) => r.map((x) => r3(clamp(x, lo, hi)))) : d);

// only the known fields, each in range; anything else is ignored
export function cleanLook(o) {
  const out = { name: cleanName(o.n ?? o.name, 'Shared look') };
  for (const k in NUM) { const [a, b, d] = NUM[k]; out[k] = typeof o[k] === 'number' && Number.isFinite(o[k]) ? r3(clamp(o[k], a, b)) : d; }
  out.cm = mat(o.cm, 3, 3, -0.5, 1.5, I);
  const one = (m, d) => { const x = mat(m && [m], 1, 3, -0.15, 0.15, null); return x ? x[0] : d; };
  out.sh = one(o.sh, [0, 0, 0]); out.hl = one(o.hl, [0, 0, 0]);
  const mono = mat(o.mono && [o.mono], 1, 3, 0, 1.2, null); out.mono = mono ? mono[0] : undefined;
  out.stamp = o.stamp === true;
  out.curve = pts(o.curve);
  if (o.rgb && typeof o.rgb === 'object') { const g = { r: pts(o.rgb.r), g: pts(o.rgb.g), b: pts(o.rgb.b) }; if (g.r || g.g || g.b) out.rgb = g; }
  if (o.hue && typeof o.hue === 'object') {
    const h = {};
    for (const k of BANDS) { const v = o.hue[k]; if (Array.isArray(v) && v.length === 3 && v.every((x) => typeof x === 'number' && Number.isFinite(x))) h[k] = [r3(clamp(v[0], -60, 60)), r3(clamp(v[1], 0, 2)), r3(clamp(v[2], -0.5, 0.5))]; }
    if (Object.keys(h).length) out.hue = h;
  }
  return out;
}
const b64 = (bytes) => { let s = ''; for (const c of bytes) s += String.fromCharCode(c); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
export function encodeLook(L) {
  const o = { n: cleanName(L.name, 'Look') };
  for (const k in NUM) if (typeof L[k] === 'number' && r3(L[k]) !== NUM[k][2]) o[k] = r3(L[k]);
  if (L.cm && L.cm.some((r, i) => r.some((x, j) => Math.abs(x - I[i][j]) > 0.0005))) o.cm = L.cm.map((r) => r.map(r3));
  if (L.sh?.some((x) => Math.abs(x) > 0.0005)) o.sh = L.sh.map(r3);
  if (L.hl?.some((x) => Math.abs(x) > 0.0005)) o.hl = L.hl.map(r3);
  if (L.mono) o.mono = L.mono.map(r3);
  if (L.stamp) o.stamp = true;
  if (L.curve) o.curve = L.curve; if (L.rgb) o.rgb = L.rgb; if (L.hue) o.hue = L.hue;
  return b64(new TextEncoder().encode(JSON.stringify(o)));
}
export const linkOf = (L) => 'shivolabs://look/' + encodeLook(L);
export function decodeLook(code) {
  try {
    if (typeof code !== 'string' || !/^[A-Za-z0-9_-]{8,6000}$/.test(code)) return null;
    let s = code.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
    const bin = atob(s), bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
    const o = JSON.parse(new TextDecoder().decode(bytes));
    return o && typeof o === 'object' && !Array.isArray(o) ? cleanLook(o) : null;
  } catch { return null; }
}
