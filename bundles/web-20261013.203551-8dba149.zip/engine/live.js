// Live cards on the Lock Screen and in the Dynamic Island (the LiveActivity add-on, kits/app-native/live-activity).
// One card per feature at a time: show() starts it or updates it, done() ends it with a final line.
// Does nothing on phones or builds without the add-on, so features can call it freely.
// Fields: title, subtitle, progress (0..1, or -1 for none), icon (SF Symbol), timerEnd (ms since 1970).
import { plugin } from './native.js';

const ACCENT = '#7FB08B';   // --glow, readable on the dark card
const cards = {};           // kind -> card id (or a promise while it starts)

export async function show(kind, fields) {
  const L = plugin('LiveActivity'); if (!L) return;
  try {
    const id = await cards[kind];
    if (id) return await L.update({ id, ...fields });
    cards[kind] = L.start({ kind, accent: ACCENT, ...fields }).then((r) => r.id).catch(() => null);
    await cards[kind];
  } catch { delete cards[kind]; }
}

export async function done(kind, fields = {}, dismissAfter = 4) {
  const L = plugin('LiveActivity'); if (!L) return;
  const id = await cards[kind]; delete cards[kind];
  if (id) try { await L.end({ id, done: true, progress: -1, ...fields, dismissAfter }); } catch {}
}
