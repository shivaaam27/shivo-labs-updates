// The native camera engine: the ShivoCamera add-on (phone/native/shivo-native, ShivoCamera.swift), in builds that
// have it. The real camera through AVFoundation: focus and exposure points, manual ISO, shutter, white balance and
// focus, lenses (13 mm ultra-wide, 26 mm main, and 28/35/50 mm taken from the 48 MP sensor; 52 mm is the sensor's
// own 2x), RAW (DNG) with a developed HEIF/JPEG, up to 48 MP. Its picture is drawn by the add-on behind the page:
// sharp inside the frame, blurred outside. Looks go to it as a colour table (lut.js) plus grain, glow and vignette.
// Returns null when this build has no camera add-on, so the screen uses the web engine.
import { lutFor } from './lut.js';

export async function nativeEngine({ plugin, onHist }) {
  const P = plugin('ShivoCamera'); if (!P) return null;
  let info; try { info = await P.info(); } catch { return null; }
  if (!info?.ok) return null;
  let on = false, lastLut = '', facing = 'back', histOn = false;
  P.addListener?.('hist', (h) => { if (histOn) onHist?.([h.r, h.g, h.b, h.l]); });
  const call = (fn, o) => P[fn](o).catch((e) => console.warn('camera', fn, e?.message || e));
  return {
    kind: 'native',
    available: () => true,
    running: () => on,
    caps: () => info.caps,   // { wb, iso, shutter, focus, raw, formats, mp, depth, modes, tools, flash }
    lenses: (f) => (f === 'front' ? info.front : info.back),   // [{ mm, kind: 'optical'|'crop'|'native2x', zoom }]
    digitalZoom: () => 1,
    mpFor: (st) => { const l = (st.facing === 'front' ? info.front : info.back).find((x) => x.mm === st.mm); return l?.mp ? Math.min(l.mp, +st.mp || 12) : st.mp; },
    async start(o) {
      facing = o.facing;
      const r = await P.start({ facing: o.facing, mm: o.mm, mp: o.mp });
      if (r?.info) info = r.info;
      on = true;
    },
    async stop() { on = false; await call('stop', {}); },
    layout(f) { call('setFrame', { top: f.top, height: f.h, width: f.W, screen: f.H }); },
    setLook(v) {
      const t = lutFor(v), key = v.look.id + '|' + v.amount + '|' + (v.false ? 1 : 0);
      call('setLook', { lut: key === lastLut ? undefined : t.data, size: t.size, grain: v.look.grain * (v.grain ?? 1) * v.amount,
        vignette: v.look.vig * v.amount, glow: v.look.hal * v.amount, mirror: !!v.mirror, zebra: !!v.zebra, peak: !!v.peak });
      lastLut = key;
    },
    setTools(st) { histOn = !!st.hist; call('setTools', { hist: !!st.hist, stabilise: !!st.stab, sound: !!st.sound, location: !!st.loc, live: !!st.live }); },
    setLens: (mm) => call('setLens', { mm }),
    setResolution: (mp) => call('setResolution', { mp }),
    setExposure: ({ iso, ss, ev }) => call('setExposure', { iso, ss, ev }),   // 0 = automatic
    setWB: ({ k, tint }) => call('setWhiteBalance', { k, tint }),
    setFocus: ({ pos }) => call('setFocus', { pos }),   // -1 = automatic, 0 near ... 1 far
    focusAt: ({ x, y }) => call('focusAt', { x, y }),   // share of the screen
    lock: (v) => call('lock', { on: !!v }),
    setDepth: (o) => call('setDepth', o),
    async shoot(st) {
      const r = await P.shoot({ format: st.fmt, mp: +st.mp, aspect: st.aspect, flash: st.flash, turn: st.turn || 0, mode: st.mode });
      st.onCapture?.();
      if (!r) return null;
      const url = globalThis.Capacitor?.convertFileSrc ? globalThis.Capacitor.convertFileSrc(r.preview) : r.preview;
      return { url, uri: r.file, w: r.width, h: r.height, raw: !!r.raw, saved: !!r.saved, error: r.error, at: Date.now() };
    },
  };
}
