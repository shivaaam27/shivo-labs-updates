// Film looks for Shivo Labs Camera. Our own looks, inspired by classic film stocks and early digital cameras (no
// maker's names). They live in the app's screens, so new looks and changes reach phones over the air.
//   sat: colour amount · con: contrast (above 1 an S-curve, below 1 flatter) · lift: blacks raised · fade: whites lowered
//   roll: highlights roll off softly, like film · clip: highlights end clean and bright, like a small digital camera
//   cm: colour mix (rows: out r, g, b) · sh / hl: shadow and highlight tint · mono: black-and-white mix (r, g, b)
//   grain: film grain (gsize: its size, 1 = 35 mm 400; gcol: how much colour is in it)
//   hal: halation (red-orange glow around bright lights) · mist: soft diffusion over highlights · crisp: digicam sharpness
//   vig: darker corners · stamp: offers the orange date in the corner · g: its group in the picker
//   sw: the colours of its swatch in the picker
// The colour parts become a colour table (lut.js); grain, halation, mist, crispness and vignette are drawn by the
// camera engine on the picture itself (sized to the picture, so a 12 MP and a 48 MP photo look the same).
const I = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
export const GROUPS = [['clean', 'CLEAN'], ['film', 'FILM'], ['digi', 'DIGICAM'], ['mono', 'BLACK & WHITE']];
export const LOOKS = [
  { id: 'natural', g: 'clean', name: 'Natural', sub: 'Clean, true colour', sat: 1, con: 1.06, lift: 0, fade: 0, cm: I, sh: [0, 0, 0], hl: [0, 0, 0], grain: 0, hal: 0, vig: 0, sw: ['#b9b4a9', '#5d7a8c'] },

  // film: the new set (drawn by the film engine: grain that lives in the mid-tones, halation, soft highlights)
  { id: 'coast', g: 'film', name: 'Coast 200', sub: 'Everyday film, golden light', sat: 1.06, con: 1.08, lift: 0.025, fade: 0.02, roll: 0.6,
    cm: [[1.03, 0.0, -0.03], [0.0, 1.0, 0.0], [-0.02, 0.03, 0.99]], sh: [-0.004, 0.006, 0.02], hl: [0.04, 0.022, -0.026],
    grain: 0.38, gsize: 1, gcol: 0.35, hal: 0.22, mist: 0, vig: 0.14, sw: ['#e3a75a', '#3f7186'] },
  { id: 'harbour', g: 'film', name: 'Harbour 400', sub: 'Soft pastel portraits', sat: 0.86, con: 0.9, lift: 0.035, fade: 0.03, roll: 0.8,
    cm: [[1.02, 0.0, -0.02], [0.0, 1.0, 0.0], [0.0, 0.04, 0.96]], sh: [-0.006, 0.01, 0.016], hl: [0.03, 0.018, 0.0],
    grain: 0.3, gsize: 1, gcol: 0.3, hal: 0.14, mist: 0.15, vig: 0.08, sw: ['#e6b9a1', '#8fb0a9'] },
  { id: 'tungsten', g: 'film', name: 'Tungsten 800', sub: 'Night film, red glow round lights', sat: 1.02, con: 1.1, lift: 0.02, fade: 0.01, roll: 0.7,
    cm: [[0.95, 0.05, 0.0], [0.0, 0.98, 0.02], [0.0, 0.06, 1.05]], sh: [-0.02, 0.012, 0.035], hl: [0.022, 0.006, -0.012],
    grain: 0.5, gsize: 1.25, gcol: 0.45, hal: 0.85, mist: 0.1, vig: 0.18, sw: ['#d8473a', '#1f4f63'] },
  { id: 'chrome50', g: 'film', name: 'Chrome 50', sub: 'Fine-grain slide, deep blues', sat: 1.24, con: 1.22, lift: 0, fade: 0, roll: 0.3,
    cm: [[1.07, -0.05, -0.02], [-0.03, 1.07, -0.04], [-0.02, -0.06, 1.08]], sh: [0, 0, 0.014], hl: [0.012, 0.006, -0.01],
    grain: 0.12, gsize: 0.8, gcol: 0.2, hal: 0.05, crisp: 0.1, vig: 0.24, sw: ['#c7432c', '#17519c'] },
  { id: 'faded', g: 'film', name: 'Faded 99', sub: 'Expired film, warm and washed', sat: 0.82, con: 0.88, lift: 0.07, fade: 0.05, roll: 0.9,
    cm: [[1.03, 0.02, -0.05], [0.02, 0.97, 0.01], [0.02, 0.05, 0.9]], sh: [0.02, -0.006, 0.012], hl: [0.05, 0.035, -0.04],
    grain: 0.6, gsize: 1.3, gcol: 0.6, hal: 0.3, mist: 0.25, vig: 0.2, sw: ['#e0a77c', '#8a7d8e'] },
  { id: 'haze', g: 'film', name: 'Haze', sub: 'Soft glow on the highlights', sat: 0.92, con: 0.92, lift: 0.03, fade: 0.01, roll: 0.7,
    cm: I, sh: [0, 0.004, 0.012], hl: [0.03, 0.02, 0.0], grain: 0.15, gsize: 0.9, gcol: 0.2, hal: 0.12, mist: 0.7, vig: 0.05, sw: ['#efd2b5', '#9db3c0'] },

  { id: 'reel500', g: 'film', name: 'Reel 500', sub: 'Cinema daylight, warm and rich', sat: 1.04, con: 1.14, lift: 0.03, fade: 0.02, roll: 0.75,
    cm: [[1.04, -0.01, -0.03], [0.0, 1.0, 0.0], [-0.02, 0.03, 0.99]], sh: [-0.014, 0.008, 0.028], hl: [0.034, 0.016, -0.02],
    grain: 0.42, gsize: 1.2, gcol: 0.4, hal: 0.35, mist: 0.12, vig: 0.16, sw: ['#e0a35e', '#2b5b6b'] },
  { id: 'coldslide', g: 'film', name: 'Cold Slide', sub: 'Expired slide, cool and cross-processed', sat: 1.1, con: 1.2, lift: 0.03, fade: 0.04, roll: 0.5,
    cm: [[0.97, 0.05, 0.0], [0.0, 1.02, 0.02], [0.0, 0.05, 1.02]], sh: [-0.01, 0.02, 0.04], hl: [-0.01, 0.012, 0.03],
    grain: 0.35, gsize: 1.15, gcol: 0.5, hal: 0.08, vig: 0.26, sw: ['#7fb2b8', '#274a8a'] },

  // film: the first set
  { id: 'softchrome', g: 'film', name: 'Soft Chrome', sub: 'Muted, deep, documentary', sat: 0.74, con: 1.2, lift: 0.015, fade: 0.02,
    cm: [[0.94, 0.06, 0], [0.03, 0.92, 0.05], [0, 0.1, 0.9]], sh: [-0.012, 0.004, 0.022], hl: [0.022, 0.012, -0.018], grain: 0.12, hal: 0, vig: 0.18, sw: ['#9a9486', '#3f5866'] },
  { id: 'slide', g: 'film', name: 'Vivid Slide', sub: 'Rich colour, bold skies', sat: 1.32, con: 1.24, lift: 0, fade: 0,
    cm: [[1.08, -0.06, -0.02], [-0.04, 1.08, -0.04], [-0.02, -0.07, 1.09]], sh: [0, 0, 0.012], hl: [0.012, 0.006, -0.01], grain: 0.05, hal: 0, vig: 0.22, sw: ['#d6542e', '#1f5fa8'] },
  { id: 'portrait', g: 'film', name: 'Portrait 400', sub: 'Warm skin, soft light', sat: 0.9, con: 0.9, lift: 0.03, fade: 0.02,
    cm: [[1.03, 0, -0.03], [0, 1, 0], [0, 0.03, 0.97]], sh: [0, 0.008, 0.02], hl: [0.03, 0.016, -0.012], grain: 0.15, hal: 0.1, vig: 0.1, sw: ['#e2b08f', '#7d9a92'] },
  { id: 'neg', g: 'film', name: 'Classic Neg', sub: 'Hard tones, cool shadows', sat: 0.9, con: 1.22, lift: 0.015, fade: 0.03,
    cm: [[1, 0.03, -0.03], [-0.04, 1.02, 0.02], [-0.02, 0.08, 0.94]], sh: [-0.01, 0.018, 0.028], hl: [0.018, 0, 0.008], grain: 0.2, hal: 0.05, vig: 0.2, sw: ['#c98f6c', '#2f6466'] },
  { id: 'cine', g: 'film', name: 'Cine Soft', sub: 'Flat, quiet, film-like', sat: 0.68, con: 0.84, lift: 0.04, fade: 0.05,
    cm: [[0.97, 0.03, 0], [0.01, 0.96, 0.03], [0, 0.05, 0.95]], sh: [-0.018, 0.008, 0.026], hl: [0.02, 0.01, -0.01], grain: 0.08, hal: 0.06, vig: 0.08, sw: ['#a7a296', '#4b6670'] },
  { id: 'amber', g: 'film', name: 'Amber Neg', sub: 'Golden, nostalgic', sat: 0.94, con: 1.05, lift: 0.025, fade: 0.03,
    cm: [[1.02, 0.01, -0.03], [0.01, 0.99, 0], [0, 0.04, 0.96]], sh: [0, 0, 0.018], hl: [0.05, 0.026, -0.03], grain: 0.18, hal: 0.15, vig: 0.16, sw: ['#d99a52', '#6e6a5a'] },
  { id: 'dargold', g: 'film', name: 'Dar Gold', sub: 'Warm coast light', sat: 1.1, con: 1.1, lift: 0.01, fade: 0.01,
    cm: [[1.04, 0, -0.04], [0, 1.01, -0.01], [-0.02, 0.02, 1]], sh: [0, -0.004, 0.02], hl: [0.042, 0.022, -0.03], grain: 0.1, hal: 0.12, vig: 0.14, sw: ['#e7a64a', '#2d6f8a'] },

  // digicam: small digital cameras of the 2000s (crisp, clean highlights that clip, a colour cast, a date in the corner)
  { id: 'ccd', g: 'digi', name: 'CCD 05', sub: 'Early digicam, cool and crisp', sat: 1.12, con: 1.15, lift: 0.0, fade: 0.0, clip: 0.8,
    cm: [[0.96, 0.04, 0.0], [0.0, 1.0, 0.0], [0.0, 0.04, 1.06]], sh: [-0.01, 0.008, 0.03], hl: [-0.008, 0.01, 0.03],
    grain: 0.1, gsize: 0.7, gcol: 0.8, crisp: 0.7, hal: 0, vig: 0.05, stamp: true, sw: ['#b8d3e3', '#2c4f7a'] },
  { id: 'pocket', g: 'digi', name: 'Pocket 08', sub: 'Warm, punchy point-and-shoot', sat: 1.22, con: 1.18, lift: 0.0, fade: 0.0, clip: 0.6,
    cm: [[1.04, -0.02, -0.02], [0.0, 1.02, -0.02], [-0.02, 0.0, 1.0]], sh: [0.0, 0.0, 0.012], hl: [0.03, 0.016, -0.02],
    grain: 0.08, gsize: 0.7, gcol: 0.8, crisp: 0.55, hal: 0, vig: 0.04, stamp: true, sw: ['#f0a03c', '#c0392b'] },
  { id: 'nightcam', g: 'digi', name: 'Night Cam', sub: 'Digicam after dark, noisy and blue', sat: 1.0, con: 1.25, lift: 0.0, fade: 0.0, clip: 0.9,
    cm: [[0.94, 0.04, 0.02], [0.0, 1.0, 0.0], [0.0, 0.06, 1.08]], sh: [-0.012, 0.01, 0.05], hl: [0.0, 0.006, 0.02],
    grain: 0.28, gsize: 0.8, gcol: 1, crisp: 0.6, hal: 0, vig: 0.08, stamp: true, sw: ['#3d5a99', '#0f1a2e'] },

  { id: 'pastel', g: 'digi', name: 'Pastel 07', sub: 'Soft, bright, sugary compact', sat: 0.92, con: 0.9, lift: 0.04, fade: 0.0, clip: 0.7,
    cm: [[1.02, 0.0, -0.02], [0.0, 1.0, 0.0], [0.02, 0.0, 0.98]], sh: [0.01, 0.004, 0.016], hl: [0.03, 0.01, 0.02],
    grain: 0.1, gsize: 0.7, gcol: 0.8, crisp: 0.35, hal: 0.05, mist: 0.22, vig: 0.02, stamp: true, sw: ['#f4c6d4', '#b9d8e8'] },

  // black and white
  { id: 'silver', g: 'mono', name: 'Silver 400', sub: 'Gritty, classic black and white', sat: 1, con: 1.18, lift: 0.02, fade: 0, roll: 0.5, mono: [0.3, 0.6, 0.1],
    cm: I, sh: [0, 0, 0], hl: [0, 0, 0], grain: 0.6, gsize: 1.2, gcol: 0, hal: 0, vig: 0.18, sw: ['#dcdcd8', '#262627'] },
  { id: 'mono', g: 'mono', name: 'Mono 100', sub: 'Deep black and white', sat: 1, con: 1.26, lift: 0.01, fade: 0, mono: [0.42, 0.46, 0.12],
    cm: I, sh: [0, 0, 0], hl: [0, 0, 0], grain: 0.3, hal: 0, vig: 0.16, sw: ['#e8e8e6', '#1b1b1c'] },
  { id: 'monosoft', g: 'mono', name: 'Mono Soft', sub: 'Gentle grey tones', sat: 1, con: 0.94, lift: 0.04, fade: 0.03, mono: [0.3, 0.59, 0.11],
    cm: I, sh: [0, 0, 0.004], hl: [0.008, 0.005, 0], grain: 0.2, hal: 0, vig: 0.1, sw: ['#c9c6bf', '#4a4947'] },
  { id: 'sepia', g: 'mono', name: 'Sepia Print', sub: 'Warm toned black and white', sat: 1, con: 1.04, lift: 0.035, fade: 0.04, roll: 0.6,
    cm: [[0.306, 0.612, 0.102], [0.288, 0.576, 0.096], [0.252, 0.504, 0.084]], sh: [0.01, 0.004, -0.01], hl: [0.02, 0.01, -0.02],
    grain: 0.3, gsize: 1.1, gcol: 0, hal: 0.1, vig: 0.22, sw: ['#d8bf9c', '#3b2c20'] },
];
export const lookById = (id) => LOOKS.find((l) => l.id === id) || LOOKS[0];
