// The web camera engine: what a web page can do with the camera (getUserMedia). Builds without the ShivoCamera
// add-on use it. Looks, exposure and white balance are applied to the picture (develop.js) - digital, not the
// sensor's. The frame shows exactly what the photo will hold (cmFG); outside it, a small soft copy (cmGL).
// Photos come from the video stream (about 12 MP), saved as JPEG to Photos.

const MAIN = 26;   // the main camera's focal length (35 mm equivalent) on recent iPhones

export function webEngine({ vid, makeRenderer, plugin, onHist }) {
  const fg = document.getElementById('cmFG'), bg = document.getElementById('cmGL');
  const R = { fg: null, bg: null, mini: null, cap: null };
  try { R.fg = makeRenderer(fg); R.bg = makeRenderer(bg); R.mini = makeRenderer(document.createElement('canvas'), true); } catch (e) { console.error(e); }
  let stream = null, track = null, devs = [], on = false, view = null, tools = {}, frame = { top: 0, h: 0, W: 0, H: 0 }, facing = 'back', mm = MAIN, lastHist = 0, n = 0;

  const classify = (list) => list.filter((d) => d.kind === 'videoinput').map((d) => {
    const l = (d.label || '').toLowerCase();
    return { id: d.deviceId, label: d.label, kind: /front|user|facetime/.test(l) ? 'front' : /ultra/.test(l) ? 'uw' : /tele/.test(l) ? 'tele' : /dual|triple/.test(l) ? 'virtual' : 'main' };
  });
  const hasUW = () => devs.some((d) => d.kind === 'uw');
  const devFor = () => (facing === 'front' ? 'front' : mm === 13 ? 'uw' : 'main');
  let current = '';

  const named = () => devs.length && devs.every((d) => d.label);
  async function open() {
    close();
    // before the first yes, iOS gives the cameras no names, so "back" can't be told from "front": use facingMode
    const want = devFor(), dev = named() ? devs.find((d) => d.kind === want) : null;
    const video = { width: { ideal: 4032 }, height: { ideal: 3024 }, frameRate: { ideal: 30 } };
    if (dev) video.deviceId = { exact: dev.id }; else video.facingMode = facing === 'front' ? 'user' : 'environment';
    stream = await navigator.mediaDevices.getUserMedia({ video, audio: false });
    track = stream.getVideoTracks()[0];
    vid.srcObject = stream; await vid.play().catch(() => {});
    if (!named()) { try { devs = classify(await navigator.mediaDevices.enumerateDevices()); } catch {} }
    // the wrong camera (e.g. front when back was asked): try again by its name now that names are known
    // opened by facingMode (names weren't known yet) and got another camera than asked: open again by name, once
    const got = devs.find((d) => d.id === track?.getSettings?.().deviceId)?.kind;
    if (!dev && named() && got && got !== want && !(want === 'main' && got === 'virtual')) return open();
    current = want;
  }
  function close() { if (stream) stream.getTracks().forEach((t) => t.stop()); stream = null; track = null; vid.srcObject = null; }

  function loop() {
    if (!on || !stream) return;
    const next = () => (vid.requestVideoFrameCallback ? vid.requestVideoFrameCallback(loop) : requestAnimationFrame(loop));
    if (vid.readyState >= 2 && vid.videoWidth && view && frame.W) {
      const d = Math.min(devicePixelRatio || 1, 2), sw = vid.videoWidth, sh = vid.videoHeight;
      R.fg?.draw(vid, sw, sh, { ...view, w: Math.round(frame.W * d), h: Math.round(frame.h * d), seed: (n % 97) });
      if (n % 3 === 0) R.bg?.draw(vid, sw, sh, { ...view, zebra: 0, false: 0, peak: 0, grain: 0, w: 96, h: Math.round(96 * frame.H / frame.W), seed: 0 });
      n++;
      const now = performance.now();
      if (tools.hist && now - lastHist > 280) { lastHist = now; onHist?.(histogram(sw, sh)); }
    }
    next();
  }
  function histogram(sw, sh) {
    if (!R.mini) return null;
    R.mini.draw(vid, sw, sh, { ...view, zebra: 0, false: 0, peak: 0, grain: 0, w: 96, h: Math.round(96 * frame.h / frame.W), seed: 0 });
    const { px } = R.mini.pixels(), B = 48, H = [new Float32Array(B), new Float32Array(B), new Float32Array(B), new Float32Array(B)];
    for (let i = 0; i < px.length; i += 4) { const r = px[i], g = px[i + 1], b = px[i + 2], l = 0.2126 * r + 0.7152 * g + 0.0722 * b; H[0][r * B >> 8]++; H[1][g * B >> 8]++; H[2][b * B >> 8]++; H[3][l * B >> 8]++; }
    return H;
  }

  // to Photos: written to the app's cache, then saved by our add-on, else the Media plugin
  async function toPhotos(blob, shot) {
    const FS = plugin('Filesystem'), N = plugin('ShivoNative'), M = plugin('Media');
    const d = new Date(), p = (x) => String(x).padStart(2, '0');
    const name = `SL_${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}.jpg`;
    shot.name = name;
    if (!FS) { const a = document.createElement('a'); a.href = shot.url; a.download = name; a.click(); return true; }
    const data = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1]); fr.onerror = rej; fr.readAsDataURL(blob); });
    await FS.writeFile({ path: 'camera/' + name, data, directory: 'CACHE', recursive: true });
    const { uri } = await FS.getUri({ path: 'camera/' + name, directory: 'CACHE' });
    shot.uri = uri;
    try { if (!N) throw new Error('no add-on'); await N.saveFromURL({ url: uri, name, kind: 'media' }); }
    catch (e) { if (/Allow Photos/.test(e.message || '')) throw new Error('Allow Photos for Shivo Labs to save your pictures'); if (!M) throw e; await M.savePhoto({ path: uri }); }
    return true;
  }
  const outSize = (aspect, zoom) => {   // aspect: height / width of the frame
    const sw = vid.videoWidth, sh = vid.videoHeight; if (!sw) return null;
    const A = 1 / aspect; let w, h; if (sw / sh > A) { h = sh; w = sh * A; } else { w = sw; h = sw / A; }
    return [Math.round(w / zoom), Math.round(h / zoom)];
  };

  return {
    kind: 'web',
    available: () => !!navigator.mediaDevices?.getUserMedia,
    running: () => on && !!stream,
    caps: () => ({ wb: true, iso: false, shutter: false, focus: false, raw: false, formats: ['JPEG'], mp: [12], depth: false, modes: ['PHOTO'], tools: [], flash: false }),
    lenses: (f) => (f === 'front' ? [{ mm: MAIN, kind: 'optical' }] : [
      ...(hasUW() ? [{ mm: 13, kind: 'optical', zoom: 0.5 }] : []),
      { mm: MAIN, kind: 'optical', zoom: 1 }, { mm: 28, kind: 'crop', zoom: 1.1 }, { mm: 35, kind: 'crop', zoom: 1.3 },
      { mm: 50, kind: 'crop', zoom: 1.9 }, { mm: 52, kind: 'crop', zoom: 2 }]),
    digitalZoom: (m) => (facing === 'back' && m > MAIN ? m / MAIN : 1),
    mpFor: (st) => { const a = st.aspect === 'FULL' ? frame.H / frame.W : ({ '3:2': 1.5, '4:3': 4 / 3, '1:1': 1, '16:9': 16 / 9 })[st.aspect] || 4 / 3; const o = outSize(a, facing === 'back' && mm > MAIN ? mm / MAIN : 1); if (!o) return 12; const v = o[0] * o[1] / 1e6; return v >= 10 ? Math.round(v) : v.toFixed(1); },
    async start(o) {
      facing = o.facing; mm = o.facing === 'front' ? MAIN : o.mm;
      await open(); on = true; loop();
    },
    async stop() { on = false; close(); },
    layout(f) { frame = f; fg.style.top = '0'; },
    setLook(v) { view = v; },
    setTools(st) { tools = st; },
    async setLens(m) { mm = m; if (on && devFor() !== current) { await open(); loop(); } },
    async setExposure() {}, async setWB() {}, async setFocus() {}, focusAt() {}, lock() {},
    async shoot(st) {
      if (!stream) return null;
      const torch = st.flash === 'on' && facing === 'back' && track?.getCapabilities?.().torch;
      if (torch) { await track.applyConstraints({ advanced: [{ torch: true }] }).catch(() => {}); await new Promise((r) => setTimeout(r, 450)); }
      if (st.flash === 'on' && facing === 'front') await st.flashFront(true);
      await new Promise((r) => (vid.requestVideoFrameCallback ? vid.requestVideoFrameCallback(() => r()) : requestAnimationFrame(() => r())));
      const zoom = facing === 'back' && mm > MAIN ? mm / MAIN : 1, o = outSize(st.aspect, zoom);
      let [w, h] = o;
      if (!R.cap) R.cap = makeRenderer(document.createElement('canvas'), true);
      const k = Math.min(1, R.cap.maxSize / Math.max(w, h)); w = Math.round(w * k); h = Math.round(h * k);
      R.cap.draw(vid, vid.videoWidth, vid.videoHeight, { ...st.view, zebra: 0, false: 0, peak: 0, w, h, seed: Math.random() * 50 });
      st.onCapture();
      if (torch) track.applyConstraints({ advanced: [{ torch: false }] }).catch(() => {});
      if (st.flash === 'on' && facing === 'front') await st.flashFront(false);
      let out = R.cap.canvas;
      if (st.turn) { const r = document.createElement('canvas'); r.width = h; r.height = w; const x = r.getContext('2d'); x.translate(h / 2, w / 2); x.rotate(st.turn * Math.PI / 180); x.drawImage(out, -w / 2, -h / 2); out = r; }
      const blob = await new Promise((res) => out.toBlob(res, 'image/jpeg', 0.95));
      if (!blob) throw new Error('The photo could not be made');
      const shot = { url: URL.createObjectURL(blob), blob, w: out.width, h: out.height, at: Date.now() };
      shot.saved = await toPhotos(blob, shot).catch((e) => { shot.error = String(e.message || e); return false; });
      return shot;
    },
  };
}
