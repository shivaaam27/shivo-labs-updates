// Saved data (keys, chats, settings). On the phone it lives in native storage (UserDefaults through
// Capacitor Preferences) so iOS can't quietly clear it; in a browser it falls back to localStorage.
// Reads are instant (kept in memory); writes go through to storage.
import { plugin } from './native.js';
const mem = new Map();
const native = () => plugin('Preferences');

export async function initStore() {
  const p = native();
  if (p) {
    const { keys } = await p.keys();
    await Promise.all(keys.map(async (k) => { const { value } = await p.get({ key: k }); if (value != null) mem.set(k, value); }));
  } else {
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); mem.set(k, localStorage.getItem(k)); } } catch {}
  }
}
export function get(k, d = null) {
  if (!mem.has(k)) return d;
  try { return JSON.parse(mem.get(k)); } catch { return d; }
}
export function set(k, v) {
  const s = JSON.stringify(v); mem.set(k, s);
  const p = native();
  if (p) p.set({ key: k, value: s }).catch(() => {});
  else { try { localStorage.setItem(k, s); } catch {} }
}
export function del(k) {
  mem.delete(k);
  const p = native();
  if (p) p.remove({ key: k }).catch(() => {});
  else { try { localStorage.removeItem(k); } catch {} }
}
