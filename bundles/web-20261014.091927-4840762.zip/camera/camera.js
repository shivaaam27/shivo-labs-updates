// Shivo Labs Camera: photography with our own film looks, developed live on the phone.
// The camera's picture is developed by develop.js (exposure, white balance, the look) for the live view and,
// at full size, for the saved photo, so what you see is what you get. Saved to Photos as a high-quality JPEG.
// RAW (DNG) straight from the sensor needs the native part of a later iPhone build; this screen is made for it.
import { LOOKS, lookById } from './looks.js';
import { makeRenderer } from './develop.js';

const ASPECTS = [['3:4', 3 / 4, '4:3'], ['1:1', 1, '1:1'], ['9:16', 9 / 16, '16:9'], ['2:3', 2 / 3, '3:2']];
const DEF = { look: 'softchrome', amount: 1, grain: 1, ev: 0, k: 5600, tint: 0, aspect: '3:4', flash: 'off', timer: 0, grid: true, level: false,
  hist: false, peak: false, zebra: false, fc: false, q: 'max', mirror: true, facing: 'back', lens: 'main' };
const SVG = {
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  flash: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/>',
  flashOff: '<path d="M13 3 5 13.5h6L10 21l8-10.5h-6z"/><path d="M4 4l16 16"/>',
  timer: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9.5V13l2.5 1.5M9.5 2.5h5"/>',
  grid: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M9.3 4v16M14.7 4v16M4 9.3h16M4 14.7h16"/>',
  level: '<path d="M3 12h4M17 12h4M8.5 12.4l7-.8"/>',
  hist: '<path d="M4 19h16"/><path d="M5 19c2-1 2.5-9 4.5-9s2 6 3.5 6 1.8-11 3.5-11 1.5 10 3.5 14"/>',
  peak: '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>',
  zebra: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 12 12 4M4 18 18 4M9 20l11-11M15 20l5-5"/>',
  fc: '<circle cx="8" cy="9" r="2.4"/><circle cx="15.5" cy="8" r="2.4"/><circle cx="16" cy="15.5" r="2.4"/><circle cx="8.5" cy="16" r="2.4"/>',
  mirror: '<path d="M12 3v18"/><path d="M8 7 4 12l4 5zM16 7l4 5-4 5z"/>',
  ev: '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17"/><path d="M7 10h3M8.5 8.5v3M14 14.5h3"/>',
  reset: '<path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v4h4"/>',
  flip: '<path d="M20 11a8 8 0 0 0-14.2-4.6M4 13a8 8 0 0 0 14.2 4.6"/><path d="M20 4v7h-7M4 20v-7h7"/>',
  looks: '<circle cx="9" cy="10" r="5"/><circle cx="15" cy="10" r="5"/><circle cx="12" cy="15" r="5"/>',
  dots: '<circle cx="6" cy="9" r="1.3"/><circle cx="12" cy="9" r="1.3"/><circle cx="18" cy="9" r="1.3"/><circle cx="6" cy="15" r="1.3"/><circle cx="12" cy="15" r="1.3"/><circle cx="18" cy="15" r="1.3"/>',
  cam: '<path d="M4 8.5h3l1.8-2.5h6.4L17 8.5h3v10.5H4z"/><circle cx="12" cy="13.5" r="3.6"/>',
  share: '<path d="M12 3v12M7.5 7.5 12 3l4.5 4.5"/><path d="M5 12v8h14v-8"/>',
  photos: '<rect x="3.5" y="5" width="17" height="14" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="m20 16-4.5-4.5L7 19"/>',
  sun: '<circle cx="12" cy="12" r="3.6"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"/>',
};
const ic = (n) => `<svg viewBox="0 0 24 24">${SVG[n]}</svg>`;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// opts: { toast, haptic, plugin, openURL }
export function mountCamera(root, { toast, haptic = () => {}, plugin = () => null, openURL } = {}) {
  let st = { ...DEF }; try { Object.assign(st, JSON.parse(localStorage.getItem('sl.cam') || '{}')); } catch {}
  const save = () => { try { localStorage.setItem('sl.cam', JSON.stringify(st)); } catch {} };
  const C = { on: false, stream: null, track: null, devs: [], busy: false, shots: [], prev: null, mini: null, cap: null, panel: null,
    tilt: 0, turn: 0, motion: false, lastHist: 0, lastThumbs: 0, fps: 0 };

  root.innerHTML = `<div class="cm" id="cm">
    <video id="cmVid" playsinline muted autoplay></video>
    <header class="cm-top">
      <button class="cm-ib cm-rot" id="cmClose" aria-label="Close">${ic('x')}</button>
      <div class="cm-quick">
        <button class="cm-q cm-rot" id="cmQFlash" aria-label="Flash"></button>
        <button class="cm-q cm-rot" id="cmQTimer" aria-label="Timer"></button>
        <button class="cm-q cm-rot txt" id="cmQAspect" aria-label="Aspect"></button>
      </div>
      <button class="cm-badge cm-rot" id="cmQual" aria-label="Quality"></button>
    </header>
    <div class="cm-stage" id="cmStage">
      <div class="cm-vf" id="cmVf">
        <canvas id="cmGL"></canvas>
        <div class="cm-grid"><i></i><i></i><i></i><i></i></div>
        <div class="cm-level" id="cmLevel"><b></b><i></i><b></b></div>
        <div class="cm-focus" id="cmFocus"><span class="cm-sun">${ic('sun')}</span></div>
        <div class="cm-hist cm-rot" id="cmHist"><canvas width="240" height="104"></canvas><span>HISTOGRAM</span></div>
        <div class="cm-count" id="cmCount"></div>
        <div class="cm-lenses" id="cmLenses"></div>
        <div class="cm-blink" id="cmBlink"></div>
        <div class="cm-msg" id="cmMsg"></div>
      </div>
    </div>
    <div class="cm-chips" id="cmChips"></div>
    <div class="cm-row">
      <button class="cm-ib big cm-rot" id="cmLooksBtn" aria-label="Looks">${ic('looks')}</button>
      <button class="cm-shutter" id="cmShot" aria-label="Take photo"><i></i></button>
      <button class="cm-ib big cm-rot" id="cmCtlBtn" aria-label="Controls">${ic('dots')}</button>
    </div>
    <div class="cm-bottom">
      <button class="cm-thumb cm-rot" id="cmThumb" aria-label="Photos taken"></button>
      <div class="cm-names" id="cmNames"><div class="cm-names-in" id="cmNamesIn">${LOOKS.map((l) => `<button data-look="${l.id}">${esc(l.name)}</button>`).join('')}</div></div>
      <button class="cm-ib big cm-rot" id="cmFlip" aria-label="Switch camera">${ic('flip')}</button>
    </div>
    <div class="cm-scrim" id="cmScrim" hidden></div>
    <div class="cm-panel" id="cmPanel" hidden><div class="cm-grab"></div><div id="cmPanelBody"></div></div>
    <div class="cm-gate" id="cmGate" hidden></div>
    <div class="cm-viewer" id="cmViewer" hidden></div>
    <div class="cm-ff" id="cmFF"></div>
  </div>`;
  const $ = (s) => root.querySelector(s);
  const vid = $('#cmVid'), vf = $('#cmVf'), glc = $('#cmGL');

  try { C.prev = makeRenderer(glc); } catch (e) { console.error(e); }
  try { C.mini = makeRenderer(document.createElement('canvas'), true); } catch {}

  /* ---------- the viewfinder's size: the chosen aspect, as large as the space allows ---------- */
  const aspect = () => (ASPECTS.find((a) => a[0] === st.aspect) || ASPECTS[0])[1];
  function layout() {
    const s = $('#cmStage').getBoundingClientRect(); if (!s.width) return;
    const A = aspect(); let w = s.width - 16, h = w / A;
    if (h > s.height - 8) { h = s.height - 8; w = h * A; }
    vf.style.width = Math.round(w) + 'px'; vf.style.height = Math.round(h) + 'px';
    const d = Math.min(devicePixelRatio || 1, 2);
    C.vw = Math.round(w * d); C.vh = Math.round(h * d);
  }
  new ResizeObserver(layout).observe($('#cmStage'));

  /* ---------- lenses: what this phone has, from the camera names iOS gives ---------- */
  const lensList = () => {
    if (st.facing === 'front') return [{ id: 'front', label: '1×' }];
    const has = (k) => C.devs.some((d) => d.kind === k);
    return [has('uw') && { id: 'uw', label: '.5' }, { id: 'main', label: '1×' }, { id: 'main2', label: '2' }, has('tele') && { id: 'tele', label: 'Tele' }].filter(Boolean);
  };
  function classify(list) {
    return list.filter((d) => d.kind === 'videoinput').map((d) => {
      const l = (d.label || '').toLowerCase();
      const kind = /front|user|facetime/.test(l) ? 'front' : /ultra/.test(l) ? 'uw' : /tele/.test(l) ? 'tele' : /dual|triple/.test(l) ? 'virtual' : 'main';
      return { id: d.deviceId, kind, label: d.label };
    });
  }
  const zoom = () => (st.facing === 'back' && st.lens === 'main2' ? 2 : 1);

  /* ---------- start and stop the camera ---------- */
  async function start() {
    C.on = true; layout();
    if (!navigator.mediaDevices?.getUserMedia) return gate('none');
    if (!localStorage.getItem('sl.cam.asked')) return gate('ask');
    msg('');
    try {
      stopStream();
      const want = st.facing === 'front' ? 'front' : st.lens === 'main2' ? 'main' : st.lens;
      const dev = C.devs.find((d) => d.kind === want);
      const video = { width: { ideal: 4032 }, height: { ideal: 3024 }, frameRate: { ideal: 30 } };
      if (dev) video.deviceId = { exact: dev.id }; else video.facingMode = st.facing === 'front' ? 'user' : 'environment';
      const s = await navigator.mediaDevices.getUserMedia({ video, audio: false });
      if (!C.on) { s.getTracks().forEach((t) => t.stop()); return; }
      C.stream = s; C.track = s.getVideoTracks()[0];
      vid.srcObject = s; await vid.play().catch(() => {});
      if (!C.devs.length) { C.devs = classify(await navigator.mediaDevices.enumerateDevices()); paintLenses(); }
      $('#cmGate').hidden = true;
      paintAll(); loop();
    } catch (e) {
      console.error(e);
      if (e.name === 'NotAllowedError' || e.name === 'SecurityError') gate('denied');
      else if (e.name === 'NotFoundError' || e.name === 'OverconstrainedError') { if (st.lens !== 'main' && st.facing === 'back') { st.lens = 'main'; save(); return start(); } gate('none'); }
      else gate('error', e.message);
    }
  }
  function stopStream() { if (C.stream) C.stream.getTracks().forEach((t) => t.stop()); C.stream = null; C.track = null; vid.srcObject = null; }
  function stop() { C.on = false; stopStream(); closePanel(); }

  /* ---------- the live view ---------- */
  let seed = 0, frames = 0, fpsT = performance.now();
  function loop() {
    if (!C.on || !C.stream) return;
    const next = () => (vid.requestVideoFrameCallback ? vid.requestVideoFrameCallback(loop) : requestAnimationFrame(loop));
    if (vid.readyState >= 2 && vid.videoWidth && C.prev && C.vw) {
      seed = (seed + 1) % 97;
      C.prev.draw(vid, vid.videoWidth, vid.videoHeight, { ...view(), w: C.vw, h: C.vh, seed, zebra: st.zebra, false: st.fc, peak: st.peak });
      const now = performance.now();
      if (st.hist && now - C.lastHist > 280) { C.lastHist = now; histogram(); }
      if (C.panel === 'looks' && now - C.lastThumbs > 700) { C.lastThumbs = now; thumbs(); }
      frames++; if (now - fpsT > 1000) { C.fps = frames; frames = 0; fpsT = now; }
    }
    next();
  }
  const view = () => ({ zoom: zoom(), mirror: st.facing === 'front' && st.mirror, ev: st.ev, k: st.k, tint: st.tint, look: lookById(st.look), amount: st.amount, grain: st.grain });

  /* ---------- histogram (red, green, blue and brightness) of what you see ---------- */
  function histogram() {
    if (!C.mini) return;
    C.mini.draw(vid, vid.videoWidth, vid.videoHeight, { ...view(), w: 96, h: Math.round(96 / aspect()), seed: 0 });
    const { px } = C.mini.pixels(), B = 48, H = [new Float32Array(B), new Float32Array(B), new Float32Array(B), new Float32Array(B)];
    for (let i = 0; i < px.length; i += 4) {
      const r = px[i], g = px[i + 1], b = px[i + 2], l = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      H[0][r * B >> 8]++; H[1][g * B >> 8]++; H[2][b * B >> 8]++; H[3][l * B >> 8]++;
    }
    const cv = $('#cmHist canvas'), x = cv.getContext('2d'), W = cv.width, Ht = cv.height;
    const max = Math.max(...H.map((a) => Math.max(...a.slice(1, B - 1)))) || 1;
    x.clearRect(0, 0, W, Ht); x.globalCompositeOperation = 'lighter';
    [['rgba(232,84,70,.55)', 0], ['rgba(110,200,120,.55)', 1], ['rgba(80,130,235,.6)', 2]].forEach(([col, c]) => {
      x.beginPath(); x.moveTo(0, Ht);
      for (let i = 0; i < B; i++) x.lineTo(i / (B - 1) * W, Ht - Math.min(1, H[c][i] / max) * (Ht - 6));
      x.lineTo(W, Ht); x.closePath(); x.fillStyle = col; x.fill();
    });
    x.globalCompositeOperation = 'source-over'; x.beginPath();
    for (let i = 0; i < B; i++) x.lineTo(i / (B - 1) * W, Ht - Math.min(1, H[3][i] / max) * (Ht - 6));
    x.strokeStyle = 'rgba(255,255,255,.85)'; x.lineWidth = 2; x.stroke();
  }

  /* ---------- tap the picture: set the exposure for that spot, then slide up or down to adjust ---------- */
  let fT = null;
  vf.addEventListener('pointerdown', (e) => {
    if (!C.stream || e.target.closest('.cm-lenses,.cm-hist')) return;
    const r = vf.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
    const y0 = e.clientY, ev0 = st.ev; let moved = false;
    const mv = (m) => { const dy = y0 - m.clientY; if (Math.abs(dy) > 6) moved = true; if (!moved) return; st.ev = Math.round(clamp(ev0 + dy / 60, -3, 3) * 10) / 10; showFocus(x, y, true); paintChips(); };
    const up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); if (!moved) meter(x, y); save(); };
    addEventListener('pointermove', mv); addEventListener('pointerup', up);
  });
  function meter(x, y) {
    if (!C.mini) return;
    const W = 96, H = Math.round(96 / aspect());
    C.mini.draw(vid, vid.videoWidth, vid.videoHeight, { ...view(), ev: 0, amount: 0, grain: 0, w: W, h: H });
    const { px } = C.mini.pixels(); let sum = 0, n = 0;
    const cx = Math.round(x * W), cy = Math.round((1 - y) * H);   // the read starts at the bottom row
    for (let j = cy - 4; j <= cy + 4; j++) for (let i = cx - 4; i <= cx + 4; i++) {
      if (i < 0 || j < 0 || i >= W || j >= H) continue;
      const k = (j * W + i) * 4, l = (0.2126 * px[k] + 0.7152 * px[k + 1] + 0.0722 * px[k + 2]) / 255;
      sum += Math.pow(l, 2.2); n++;
    }
    const m = n ? sum / n : 0.18;
    st.ev = Math.round(clamp(Math.log2(0.18 / Math.max(m, 0.002)), -3, 3) * 10) / 10;
    haptic('light'); showFocus(x, y, false); paintChips(); save();
  }
  function showFocus(x, y, adjusting) {
    const f = $('#cmFocus'); f.style.left = x * 100 + '%'; f.style.top = y * 100 + '%';
    f.style.setProperty('--sun', -st.ev * 10 + 'px');
    f.classList.remove('in'); void f.offsetWidth; f.classList.add('in'); f.classList.toggle('adj', adjusting);
    clearTimeout(fT); fT = setTimeout(() => f.classList.remove('in'), 2600);
  }

  /* ---------- the level, and turning saved photos when the phone is held sideways ---------- */
  function onMotion(e) {
    const g = e.accelerationIncludingGravity; if (!g || g.x == null) return;
    const ax = g.x, ay = g.y, flat = Math.abs(g.z) > 8.6;
    const turn = flat ? C.turn : Math.abs(ax) > Math.abs(ay) * 1.2 ? (ax > 0 ? -90 : 90) : Math.abs(ay) > Math.abs(ax) * 1.2 ? 0 : C.turn;
    if (turn !== C.turn) { C.turn = turn; root.style.setProperty('--turn', turn + 'deg'); }
    let a = Math.atan2(ax, -ay) * 180 / Math.PI;   // 0 when upright
    if (turn === 90) a -= 90; else if (turn === -90) a += 90;
    C.tilt = a;
    const lv = $('#cmLevel'); if (!st.level) return;
    const ok = Math.abs(a) < 1;
    lv.style.setProperty('--tilt', (ok ? 0 : -a) + 'deg');
    if (ok && !lv.classList.contains('ok')) haptic('selection');
    lv.classList.toggle('ok', ok);
  }
  async function askMotion() {
    try {
      const D = window.DeviceMotionEvent;
      if (D?.requestPermission && (await D.requestPermission()) !== 'granted') throw new Error('no');
      if (!C.motion) { addEventListener('devicemotion', onMotion); C.motion = true; }
      localStorage.setItem('sl.cam.motion', '1'); return true;
    } catch { toast?.('Allow Motion for the level and turning photos'); return false; }
  }
  // once allowed, ask again quietly on the first tap (iOS needs a tap for it each time the app starts)
  if (localStorage.getItem('sl.cam.motion')) root.addEventListener('pointerdown', () => { if (!C.motion) askMotion(); }, { once: true });
  if (window.DeviceMotionEvent && !window.DeviceMotionEvent.requestPermission) { addEventListener('devicemotion', onMotion); C.motion = true; }

  /* ---------- take the photo ---------- */
  $('#cmShot').onclick = shoot;
  async function shoot() {
    if (!C.stream || C.busy) return;
    C.busy = true; $('#cmShot').classList.add('busy');
    try {
      if (st.timer) for (let s = st.timer; s > 0; s--) { count(s); haptic('light'); await sleep(1000); }
      count('');
      const torch = st.flash === 'on' && st.facing === 'back' && C.track?.getCapabilities?.().torch;
      if (torch) { await C.track.applyConstraints({ advanced: [{ torch: true }] }).catch(() => {}); await sleep(450); }
      if (st.flash === 'on' && st.facing === 'front') { $('#cmFF').classList.add('on'); await sleep(320); }
      await fresh();
      const A = aspect(), sw = vid.videoWidth, sh = vid.videoHeight, z = zoom();
      let w, h; if (sw / sh > A) { h = sh; w = sh * A; } else { w = sw; h = sw / A; }
      w = Math.round(w / z); h = Math.round(h / z);
      if (!C.cap) C.cap = makeRenderer(document.createElement('canvas'), true);
      const k = Math.min(1, C.cap.maxSize / Math.max(w, h)); w = Math.round(w * k); h = Math.round(h * k);
      C.cap.draw(vid, sw, sh, { ...view(), w, h, seed: Math.random() * 50 });
      blink(); haptic('medium');
      if (torch) C.track.applyConstraints({ advanced: [{ torch: false }] }).catch(() => {});
      $('#cmFF').classList.remove('on');
      let out = C.cap.canvas;
      if (C.turn) {   // held sideways: save it the way it was held
        const r = document.createElement('canvas'); r.width = h; r.height = w;
        const x = r.getContext('2d'); x.translate(h / 2, w / 2); x.rotate(C.turn * Math.PI / 180); x.drawImage(out, -w / 2, -h / 2); out = r;
      }
      const blob = await new Promise((res) => out.toBlob(res, 'image/jpeg', st.q === 'max' ? 0.97 : 0.9));
      if (!blob) throw new Error('The photo could not be made');
      const url = URL.createObjectURL(blob), shot = { url, blob, w: out.width, h: out.height, look: lookById(st.look).name, at: Date.now() };
      C.shots.unshift(shot); paintThumb();
      shot.saved = await toPhotos(blob, shot).catch((e) => { toast?.(String(e.message || e)); return false; });
    } catch (e) { console.error(e); toast?.('Photo not taken: ' + (e.message || e)); }
    finally { C.busy = false; $('#cmShot').classList.remove('busy'); count(''); }
  }
  const fresh = () => new Promise((r) => (vid.requestVideoFrameCallback ? vid.requestVideoFrameCallback(() => r()) : requestAnimationFrame(() => r())));
  function count(n) { const c = $('#cmCount'); c.textContent = n; c.classList.toggle('on', n !== ''); }
  function blink() { const b = $('#cmBlink'); b.classList.remove('on'); void b.offsetWidth; b.classList.add('on'); }

  // to Photos: written to the app's cache, then saved by our add-on (asks for "add only" access), else the Media plugin
  async function toPhotos(blob, shot) {
    const FS = plugin('Filesystem'), N = plugin('ShivoNative'), M = plugin('Media');
    const d = new Date(), p = (n) => String(n).padStart(2, '0');
    const name = `SL_${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}.jpg`;
    shot.name = name;
    if (!FS) { const a = document.createElement('a'); a.href = shot.url; a.download = name; a.click(); return true; }
    const data = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1]); fr.onerror = rej; fr.readAsDataURL(blob); });
    await FS.writeFile({ path: 'camera/' + name, data, directory: 'CACHE', recursive: true });
    const { uri } = await FS.getUri({ path: 'camera/' + name, directory: 'CACHE' });
    shot.uri = uri;
    try { if (!N) throw new Error('no add-on'); await N.saveFromURL({ url: uri, name, kind: 'media' }); }
    catch (e) {
      if (/Allow Photos/.test(e.message || '')) throw new Error('Allow Photos for Shivo Labs to save your pictures');
      if (!M) throw e; await M.savePhoto({ path: uri });
    }
    return true;
  }

  /* ---------- photos taken: the corner thumbnail and the viewer ---------- */
  function paintThumb() {
    const t = $('#cmThumb'), s = C.shots[0];
    t.innerHTML = s ? `<img src="${s.url}" alt="">` : '';
    if (s) { t.classList.remove('pop'); void t.offsetWidth; t.classList.add('pop'); }
  }
  $('#cmThumb').onclick = () => { if (C.shots.length) openViewer(); };
  function openViewer() {
    const v = $('#cmViewer');
    v.innerHTML = `<div class="cv-top"><button class="cm-ib" id="cvClose" aria-label="Close">${ic('x')}</button><span id="cvN"></span><span class="cv-sp"></span></div>
      <div class="cv-strip" id="cvStrip">${C.shots.map((s) => `<figure><img src="${s.url}" alt=""><figcaption>${esc(s.look)} · ${(s.w * s.h / 1e6).toFixed(1)} MP · ${s.w}×${s.h}</figcaption></figure>`).join('')}</div>
      <div class="cv-bar"><button class="cv-btn" id="cvShare">${ic('share')}<span>Share</span></button><span class="cv-saved" id="cvSaved"></span><button class="cv-btn" id="cvPhotos">${ic('photos')}<span>Photos</span></button></div>`;
    v.hidden = false; requestAnimationFrame(() => v.classList.add('in'));
    const strip = $('#cvStrip'), at = () => Math.round(strip.scrollLeft / strip.clientWidth);
    const paint = () => { const s = C.shots[at()]; $('#cvN').textContent = `${at() + 1} of ${C.shots.length}`; $('#cvSaved').textContent = s?.saved ? 'Saved to Photos' : 'Not saved'; };
    strip.addEventListener('scroll', paint, { passive: true }); paint();
    $('#cvClose').onclick = () => { v.classList.remove('in'); setTimeout(() => (v.hidden = true), 300); };
    $('#cvPhotos').onclick = () => (openURL ? openURL('photos-redirect://') : null)?.catch?.(() => {});
    $('#cvShare').onclick = async () => {
      const s = C.shots[at()]; if (!s) return;
      try {
        const SH = plugin('Share');
        if (SH && s.uri) await SH.share({ files: [s.uri] });
        else if (navigator.canShare?.({ files: [new File([s.blob], s.name || 'photo.jpg', { type: 'image/jpeg' })] })) await navigator.share({ files: [new File([s.blob], s.name || 'photo.jpg', { type: 'image/jpeg' })] });
        else toast?.('Sharing isn\'t available here');
      } catch {}
    };
  }

  /* ---------- the top bar, lenses, chips and look names ---------- */
  const flashIcon = () => ic(st.flash === 'on' ? 'flash' : 'flashOff');
  function paintTop() {
    $('#cmQFlash').innerHTML = flashIcon(); $('#cmQFlash').classList.toggle('hot', st.flash === 'on');
    $('#cmQTimer').innerHTML = ic('timer') + (st.timer ? `<b>${st.timer}s</b>` : ''); $('#cmQTimer').classList.toggle('hot', !!st.timer);
    $('#cmQAspect').textContent = (ASPECTS.find((a) => a[0] === st.aspect) || ASPECTS[0])[2];
    $('#cmQual').innerHTML = `<b>${st.q === 'max' ? 'JPEG' : 'JPEG'}</b><small>${st.q === 'max' ? 'MAX' : 'HIGH'}</small>`;
  }
  $('#cmQFlash').onclick = () => { st.flash = st.flash === 'on' ? 'off' : 'on'; haptic('selection'); save(); paintTop(); paintPanel(); };
  $('#cmQTimer').onclick = () => { st.timer = st.timer === 0 ? 3 : st.timer === 3 ? 10 : 0; haptic('selection'); save(); paintTop(); paintPanel(); };
  $('#cmQAspect').onclick = () => { const i = ASPECTS.findIndex((a) => a[0] === st.aspect); st.aspect = ASPECTS[(i + 1) % ASPECTS.length][0]; haptic('selection'); save(); layout(); paintAll(); };
  $('#cmQual').onclick = () => { st.q = st.q === 'max' ? 'high' : 'max'; haptic('selection'); save(); paintTop(); paintChips(); paintPanel(); };
  $('#cmClose').onclick = () => root.dispatchEvent(new CustomEvent('camera-close', { bubbles: true }));

  function paintLenses() {
    const L = lensList(); if (!L.some((l) => l.id === st.lens) && st.facing === 'back') st.lens = 'main';
    $('#cmLenses').innerHTML = L.length > 1 ? L.map((l) => `<button data-lens="${l.id}" class="${(st.facing === 'front' || l.id === st.lens) ? 'on' : ''}">${l.label}${(st.facing === 'front' || l.id === st.lens) && l.label !== 'Tele' ? (l.label.endsWith('×') ? '' : '×') : ''}</button>`).join('') : '';
    $('#cmLenses').querySelectorAll('button').forEach((b) => (b.onclick = (e) => {
      e.stopPropagation(); const id = b.dataset.lens; if (id === st.lens) return;
      const was = st.lens; st.lens = id; save(); haptic('selection'); paintLenses(); paintChips();
      if (!((was === 'main' && id === 'main2') || (was === 'main2' && id === 'main'))) start();   // 1× and 2 are the same camera
    }));
  }
  function outSize() {
    const sw = vid.videoWidth, sh = vid.videoHeight; if (!sw) return null;
    const A = aspect(), z = zoom(); let w, h; if (sw / sh > A) { h = sh; w = sh * A; } else { w = sw; h = sw / A; }
    return [Math.round(w / z), Math.round(h / z)];
  }
  function paintChips() {
    const o = outSize(), mp = o ? (o[0] * o[1] / 1e6) : 0;
    const wb = st.k === 5600 && st.tint === 0 ? 'AWB' : st.k + 'K';
    $('#cmChips').innerHTML = [
      ['ev', `<i>${ic('ev')}</i>${st.ev > 0 ? '+' : st.ev < 0 ? '−' : '±'}${Math.abs(st.ev).toFixed(1)}`, st.ev !== 0],
      ['wb', `<i>${ic('sun')}</i>${wb}`, wb !== 'AWB'],
      ['tint', `<i class="dot"></i>${st.tint > 0 ? '+' : ''}${st.tint}`, st.tint !== 0],
      ['look', `<i>${ic('looks')}</i>${Math.round(st.amount * 100)}%`, st.amount !== 1],
      ['mp', o ? `${mp >= 10 ? Math.round(mp) : mp.toFixed(1)} MP` : '— MP', false],
    ].map(([k, t, hot]) => `<button class="cm-chip cm-rot${hot ? ' hot' : ''}" data-chip="${k}">${t}</button>`).join('');
    $('#cmChips').querySelectorAll('button').forEach((b) => (b.onclick = () => {
      const k = b.dataset.chip; haptic('selection');
      if (k === 'ev') openPanel('manual', 'ex'); else if (k === 'wb' || k === 'tint') openPanel('manual', 'wb'); else if (k === 'look') openPanel('looks'); else $('#cmQual').click();
    }));
  }
  // the look names under the shutter: slide them like the iPhone's camera modes, or tap one
  const names = $('#cmNames');
  function centerName(smooth) {
    const b = names.querySelector(`[data-look="${st.look}"]`); if (!b) return;
    names.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
    names.scrollTo({ left: b.offsetLeft + b.offsetWidth / 2 - names.clientWidth / 2, behavior: smooth ? 'smooth' : 'auto' });
  }
  names.querySelectorAll('button').forEach((b) => (b.onclick = () => setLook(b.dataset.look)));
  let nT = null;
  names.addEventListener('scroll', () => {
    clearTimeout(nT); nT = setTimeout(() => {
      const mid = names.scrollLeft + names.clientWidth / 2; let best = null, bd = 1e9;
      names.querySelectorAll('button').forEach((b) => { const d = Math.abs(b.offsetLeft + b.offsetWidth / 2 - mid); if (d < bd) { bd = d; best = b; } });
      if (best && best.dataset.look !== st.look) setLook(best.dataset.look); else centerName(true);
    }, 120);
  }, { passive: true });
  function setLook(id) { if (st.look !== id) haptic('selection'); st.look = id; save(); centerName(true); paintChips(); paintPanel(); }

  /* ---------- floating panels: looks, controls, manual exposure and balance ---------- */
  $('#cmLooksBtn').onclick = () => (C.panel === 'looks' ? closePanel() : openPanel('looks'));
  $('#cmCtlBtn').onclick = () => (C.panel === 'controls' ? closePanel() : openPanel('controls'));
  $('#cmScrim').onclick = closePanel;
  let tab = 'ex';
  function openPanel(which, t) { C.panel = which; if (t) tab = t; paintPanel(); const p = $('#cmPanel'); $('#cmScrim').hidden = false; p.hidden = false; void p.offsetHeight; p.classList.add('up'); haptic('light'); }
  function closePanel() { if (!C.panel) return; C.panel = null; const p = $('#cmPanel'); p.classList.remove('up'); $('#cmScrim').hidden = true; setTimeout(() => { if (!C.panel) p.hidden = true; }, 380); }
  // drag the panel down to close
  (() => { const p = $('#cmPanel'); let y0 = null, dy = 0;
    p.addEventListener('touchstart', (e) => { if (e.target.closest('.cm-ruler,.cl-grid')) return; y0 = e.touches[0].clientY; dy = 0; p.style.transition = 'none'; }, { passive: true });
    p.addEventListener('touchmove', (e) => { if (y0 == null) return; dy = Math.max(0, e.touches[0].clientY - y0); p.style.transform = `translateY(${dy}px)`; }, { passive: true });
    p.addEventListener('touchend', () => { if (y0 == null) return; y0 = null; p.style.transition = ''; p.style.transform = ''; if (dy > 80) closePanel(); });
  })();

  const TOG = [
    ['flash', 'Flash', () => (st.flash === 'on' ? 'On' : 'Off'), () => { st.flash = st.flash === 'on' ? 'off' : 'on'; }, () => st.flash === 'on', () => flashIcon()],
    ['timer', 'Timer', () => (st.timer ? st.timer + 's' : 'Off'), () => { st.timer = st.timer === 0 ? 3 : st.timer === 3 ? 10 : 0; }, () => !!st.timer, () => ic('timer')],
    ['aspect', 'Aspect', () => (ASPECTS.find((a) => a[0] === st.aspect) || ASPECTS[0])[2], () => { const i = ASPECTS.findIndex((a) => a[0] === st.aspect); st.aspect = ASPECTS[(i + 1) % ASPECTS.length][0]; layout(); }, () => st.aspect !== '3:4', () => `<b class="t">${(ASPECTS.find((a) => a[0] === st.aspect) || ASPECTS[0])[2]}</b>`],
    ['manual', 'Manual', () => 'EV · WB', null, () => st.ev !== 0 || st.k !== 5600 || st.tint !== 0, () => ic('ev')],
    ['grid', 'Grid', () => (st.grid ? 'On' : 'Off'), () => { st.grid = !st.grid; }, () => st.grid, () => ic('grid')],
    ['level', 'Level', () => (st.level ? 'On' : 'Off'), async () => { if (!st.level && !C.motion && !(await askMotion())) return; st.level = !st.level; }, () => st.level, () => ic('level')],
    ['hist', 'Histogram', () => (st.hist ? 'On' : 'Off'), () => { st.hist = !st.hist; }, () => st.hist, () => ic('hist')],
    ['peak', 'Peaking', () => (st.peak ? 'On' : 'Off'), () => { st.peak = !st.peak; }, () => st.peak, () => ic('peak')],
    ['zebra', 'Zebra', () => (st.zebra ? 'On' : 'Off'), () => { st.zebra = !st.zebra; }, () => st.zebra, () => ic('zebra')],
    ['fc', 'False colour', () => (st.fc ? 'On' : 'Off'), () => { st.fc = !st.fc; }, () => st.fc, () => ic('fc')],
    ['mirror', 'Mirror selfie', () => (st.mirror ? 'On' : 'Off'), () => { st.mirror = !st.mirror; }, () => st.mirror, () => ic('mirror')],
    ['reset', 'Reset', () => 'All', () => { const keep = { facing: st.facing, lens: st.lens }; st = { ...DEF, ...keep }; layout(); }, () => false, () => ic('reset')],
  ];
  function paintPanel() {
    const b = $('#cmPanelBody'); if (!C.panel) return;
    if (C.panel === 'controls') {
      b.innerHTML = `<h4 class="cm-ph">PHOTO CONTROLS</h4><div class="cl-grid">${TOG.map(([id, label, val, , on, icon]) =>
        `<button class="cl-b${on() ? ' on' : ''}" data-t="${id}"><span class="cl-ic">${icon()}</span><b>${label}</b><small>${val()}</small></button>`).join('')}</div>
        <p class="cm-note">${C.stream ? `${vid.videoWidth}×${vid.videoHeight} from the camera · ${C.fps || '–'} fps live` : ''}</p>`;
      b.querySelectorAll('[data-t]').forEach((x) => (x.onclick = async () => {
        const t = TOG.find((r) => r[0] === x.dataset.t); haptic('selection');
        if (t[0] === 'manual') return openPanel('manual', 'ex');
        await t[3](); save(); paintAll();
      }));
    } else if (C.panel === 'looks') {
      b.innerHTML = `<h4 class="cm-ph">LOOKS</h4><div class="lk-grid">${LOOKS.map((l) => `<button class="lk${l.id === st.look ? ' on' : ''}" data-look="${l.id}"><canvas width="96" height="${Math.round(96 / aspect())}" style="--a:${l.sw[0]};--b:${l.sw[1]};aspect-ratio:${aspect()}"></canvas><b>${esc(l.name)}</b><small>${esc(l.sub)}</small></button>`).join('')}</div>
        ${ruler('amount', 'Strength', 0, 1, 0.05, (v) => Math.round(v * 100) + '%', 1)}${ruler('grain', 'Grain', 0, 2, 0.1, (v) => Math.round(v * 100) + '%', 1)}`;
      b.querySelectorAll('.lk').forEach((x) => (x.onclick = () => { setLook(x.dataset.look); }));
      wireRulers(b); C.lastThumbs = 0;
    } else {
      b.innerHTML = `<div class="cm-tabs"><button data-tab="ex" class="${tab === 'ex' ? 'on' : ''}">Exposure</button><button data-tab="wb" class="${tab === 'wb' ? 'on' : ''}">Balance</button></div>
        ${tab === 'ex' ? ruler('ev', 'Exposure', -3, 3, 0.1, (v) => (v > 0 ? '+' : v < 0 ? '−' : '±') + Math.abs(v).toFixed(1) + ' EV', 0)
          : ruler('k', 'Temperature', 2500, 10000, 100, (v) => (v === 5600 ? 'Auto · ' : '') + v + ' K', 5600) + ruler('tint', 'Tint', -50, 50, 1, (v) => (v > 0 ? '+' : '') + v + (v > 0 ? ' magenta' : v < 0 ? ' green' : ''), 0)}
        <p class="cm-note">${tab === 'ex' ? 'Tap the picture to set exposure for that spot. Slide up or down there to adjust.' : 'Lower is cooler, higher is warmer. Double-tap a ruler to go back to Auto.'}</p>`;
      b.querySelectorAll('[data-tab]').forEach((x) => (x.onclick = () => { tab = x.dataset.tab; haptic('selection'); paintPanel(); }));
      wireRulers(b);
    }
  }
  // a ruler like a camera dial: drag it sideways; the value sits in the middle
  const PX = 7;
  function ruler(k, label, min, max, step, fmt, def) {
    const n = Math.round((max - min) / step);
    return `<div class="cm-ruler" data-k="${k}" data-min="${min}" data-max="${max}" data-step="${step}" data-def="${def}">
      <div class="cr-head"><span>${label}</span><b class="cr-v">${fmt(st[k])}</b></div>
      <div class="cr-track"><div class="cr-ticks" style="width:${n * PX}px"></div><i class="cr-mark"></i></div></div>`;
  }
  function wireRulers(b) {
    b.querySelectorAll('.cm-ruler').forEach((r) => {
      const k = r.dataset.k, min = +r.dataset.min, max = +r.dataset.max, step = +r.dataset.step, def = +r.dataset.def;
      const tk = r.querySelector('.cr-ticks'), tr = r.querySelector('.cr-track');
      const fmtOf = { amount: (v) => Math.round(v * 100) + '%', grain: (v) => Math.round(v * 100) + '%', ev: (v) => (v > 0 ? '+' : v < 0 ? '−' : '±') + Math.abs(v).toFixed(1) + ' EV',
        k: (v) => (v === 5600 ? 'Auto · ' : '') + v + ' K', tint: (v) => (v > 0 ? '+' : '') + v + (v > 0 ? ' magenta' : v < 0 ? ' green' : '') }[k];
      const place = () => { tk.style.transform = `translateX(${tr.clientWidth / 2 - ((st[k] - min) / step) * PX}px)`; r.querySelector('.cr-v').textContent = fmtOf(st[k]); };
      requestAnimationFrame(place);
      let x0 = null, v0 = 0, last = 0;
      const set = (v) => { v = clamp(Math.round(v / step) * step, min, max); v = +v.toFixed(3); if (v !== st[k]) { st[k] = v; if (Date.now() - last > 40) { haptic('selection'); last = Date.now(); } place(); paintChips(); } };
      tr.addEventListener('pointerdown', (e) => { x0 = e.clientX; v0 = st[k]; tr.setPointerCapture(e.pointerId); });
      tr.addEventListener('pointermove', (e) => { if (x0 != null) set(v0 - ((e.clientX - x0) / PX) * step); });
      const end = () => { if (x0 != null) { x0 = null; save(); } };
      tr.addEventListener('pointerup', end); tr.addEventListener('pointercancel', end);
      let tap = 0; tr.addEventListener('click', () => { const n = Date.now(); if (n - tap < 320) { st[k] = def; place(); paintChips(); save(); haptic('light'); } tap = n; });
    });
  }
  // live previews of every look, small, while the looks panel is open
  function thumbs() {
    if (!C.mini || !vid.videoWidth) return;
    $('#cmPanelBody').querySelectorAll('.lk canvas').forEach((cv) => {
      const l = lookById(cv.parentElement.dataset.look);
      const H = Math.round(160 / aspect());
      C.mini.draw(vid, vid.videoWidth, vid.videoHeight, { ...view(), look: l, amount: 1, w: 160, h: H, seed: 0 });
      const { w, h, px } = C.mini.pixels(), img = new ImageData(w, h);
      for (let y = 0; y < h; y++) img.data.set(px.subarray((h - 1 - y) * w * 4, (h - y) * w * 4), y * w * 4);   // the read is bottom-up
      if (cv.width !== w) cv.width = w; if (cv.height !== h) cv.height = h;
      cv.getContext('2d').putImageData(img, 0, 0);
    });
  }

  /* ---------- flip between back and front ---------- */
  $('#cmFlip').onclick = () => { st.facing = st.facing === 'front' ? 'back' : 'front'; save(); haptic('light'); const f = $('#cmFlip'); f.classList.remove('spin'); void f.offsetWidth; f.classList.add('spin'); vf.classList.add('swap'); setTimeout(() => vf.classList.remove('swap'), 420); paintLenses(); start(); };

  /* ---------- asking for the camera, and when it is off ---------- */
  function gate(kind, detail) {
    const g = $('#cmGate'); g.hidden = false;
    const T = {
      ask: ['Shivo Labs Camera', 'Film looks, live in the viewfinder. Full-size photos go straight to your Photos.', 'Allow camera', 'iPhone will ask you once.'],
      denied: ['Camera is off', 'Shivo Labs isn\'t allowed to use the camera. Turn on Camera for Shivo Labs in Settings, then come back.', 'Open Settings', ''],
      none: ['No camera here', 'This device has no camera Shivo Labs can use.', '', ''],
      error: ['The camera didn\'t start', detail || 'Something else may be using it. Close other camera apps and try again.', 'Try again', ''],
    }[kind];
    g.innerHTML = `<button class="cm-ib cg-x" id="cgX" aria-label="Close">${ic('x')}</button><div class="cg-in"><span class="cg-ic">${ic('cam')}</span><h2>${T[0]}</h2><p>${esc(T[1])}</p>
      ${T[2] ? `<button class="cg-go" id="cgGo">${T[2]}</button>` : ''}${kind === 'denied' ? '<button class="cg-alt" id="cgAgain">Try again</button>' : ''}<small>${T[3]}</small></div>`;
    const go = $('#cgGo');
    if (go) go.onclick = () => {
      if (kind === 'denied') return (openURL ? openURL('app-settings:') : Promise.reject()).catch(() => toast?.('Open Settings, then Shivo Labs, then Camera'));
      localStorage.setItem('sl.cam.asked', '1'); start();
    };
    $('#cgX').onclick = () => $('#cmClose').click();
    const again = $('#cgAgain'); if (again) again.onclick = start;
  }
  function msg(t) { const m = $('#cmMsg'); m.textContent = t; m.classList.toggle('on', !!t); }

  function paintAll() { paintTop(); paintChips(); paintLenses(); centerName(false); paintPanel(); root.querySelector('.cm').dataset.grid = st.grid ? '1' : ''; $('#cmLevel').hidden = !st.level; $('#cmHist').hidden = !st.hist; }
  paintAll(); paintThumb();

  // the camera stops when the app goes to the background (no green dot, no battery use) and comes back with it
  document.addEventListener('visibilitychange', () => { if (!C.on) return; if (document.hidden) stopStream(); else start(); });

  return { start, stop, get on() { return C.on; } };
}
