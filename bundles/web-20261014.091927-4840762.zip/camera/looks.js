// Film looks for Shivo Labs Camera. Our own looks, inspired by classic film stocks (no maker's names).
// They live in the app's screens, so new looks and changes reach phones over the air.
//   sat: colour amount · con: contrast (above 1 an S-curve, below 1 flatter) · lift: blacks raised · fade: whites lowered
//   cm: colour mix (rows: out r, g, b) · sh / hl: shadow and highlight tint · mono: black-and-white mix (r, g, b)
//   grain, hal (glow around bright lights), vig (darker corners): 0 = none
//   sw: the colours of its swatch in the picker
const I = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
export const LOOKS = [
  { id: 'natural', name: 'Natural', sub: 'Clean, true colour', sat: 1, con: 1.06, lift: 0, fade: 0, cm: I, sh: [0, 0, 0], hl: [0, 0, 0], grain: 0, hal: 0, vig: 0, sw: ['#b9b4a9', '#5d7a8c'] },
  { id: 'softchrome', name: 'Soft Chrome', sub: 'Muted, deep, documentary', sat: 0.74, con: 1.2, lift: 0.015, fade: 0.02,
    cm: [[0.94, 0.06, 0], [0.03, 0.92, 0.05], [0, 0.1, 0.9]], sh: [-0.012, 0.004, 0.022], hl: [0.022, 0.012, -0.018], grain: 0.12, hal: 0, vig: 0.18, sw: ['#9a9486', '#3f5866'] },
  { id: 'slide', name: 'Vivid Slide', sub: 'Rich colour, bold skies', sat: 1.32, con: 1.24, lift: 0, fade: 0,
    cm: [[1.08, -0.06, -0.02], [-0.04, 1.08, -0.04], [-0.02, -0.07, 1.09]], sh: [0, 0, 0.012], hl: [0.012, 0.006, -0.01], grain: 0.05, hal: 0, vig: 0.22, sw: ['#d6542e', '#1f5fa8'] },
  { id: 'portrait', name: 'Portrait 400', sub: 'Warm skin, soft light', sat: 0.9, con: 0.9, lift: 0.03, fade: 0.02,
    cm: [[1.03, 0, -0.03], [0, 1, 0], [0, 0.03, 0.97]], sh: [0, 0.008, 0.02], hl: [0.03, 0.016, -0.012], grain: 0.15, hal: 0.1, vig: 0.1, sw: ['#e2b08f', '#7d9a92'] },
  { id: 'neg', name: 'Classic Neg', sub: 'Hard tones, cool shadows', sat: 0.9, con: 1.22, lift: 0.015, fade: 0.03,
    cm: [[1, 0.03, -0.03], [-0.04, 1.02, 0.02], [-0.02, 0.08, 0.94]], sh: [-0.01, 0.018, 0.028], hl: [0.018, 0, 0.008], grain: 0.2, hal: 0.05, vig: 0.2, sw: ['#c98f6c', '#2f6466'] },
  { id: 'cine', name: 'Cine Soft', sub: 'Flat, quiet, film-like', sat: 0.68, con: 0.84, lift: 0.04, fade: 0.05,
    cm: [[0.97, 0.03, 0], [0.01, 0.96, 0.03], [0, 0.05, 0.95]], sh: [-0.018, 0.008, 0.026], hl: [0.02, 0.01, -0.01], grain: 0.08, hal: 0.06, vig: 0.08, sw: ['#a7a296', '#4b6670'] },
  { id: 'amber', name: 'Amber Neg', sub: 'Golden, nostalgic', sat: 0.94, con: 1.05, lift: 0.025, fade: 0.03,
    cm: [[1.02, 0.01, -0.03], [0.01, 0.99, 0], [0, 0.04, 0.96]], sh: [0, 0, 0.018], hl: [0.05, 0.026, -0.03], grain: 0.18, hal: 0.15, vig: 0.16, sw: ['#d99a52', '#6e6a5a'] },
  { id: 'dargold', name: 'Dar Gold', sub: 'Warm coast light', sat: 1.1, con: 1.1, lift: 0.01, fade: 0.01,
    cm: [[1.04, 0, -0.04], [0, 1.01, -0.01], [-0.02, 0.02, 1]], sh: [0, -0.004, 0.02], hl: [0.042, 0.022, -0.03], grain: 0.1, hal: 0.12, vig: 0.14, sw: ['#e7a64a', '#2d6f8a'] },
  { id: 'mono', name: 'Mono 100', sub: 'Deep black and white', sat: 1, con: 1.26, lift: 0.01, fade: 0, mono: [0.42, 0.46, 0.12],
    cm: I, sh: [0, 0, 0], hl: [0, 0, 0], grain: 0.3, hal: 0, vig: 0.16, sw: ['#e8e8e6', '#1b1b1c'] },
  { id: 'monosoft', name: 'Mono Soft', sub: 'Gentle grey tones', sat: 1, con: 0.94, lift: 0.04, fade: 0.03, mono: [0.3, 0.59, 0.11],
    cm: I, sh: [0, 0, 0.004], hl: [0.008, 0.005, 0], grain: 0.2, hal: 0, vig: 0.1, sw: ['#c9c6bf', '#4a4947'] },
];
export const lookById = (id) => LOOKS.find((l) => l.id === id) || LOOKS[0];
