// Shivo Cloud on the phone (files/PLAN.md): joining the PC's account, and a quick look at what's there. Files
// themselves are opened and saved in the iPhone's Files app (Shivo Cloud location, ShivoFiles extension), which
// encrypts and decrypts on the phone. Joining happens on the home Wi-Fi only, through Beam on the PC, with a key
// exchange nobody in between can read (files/FORMAT.md, "Joining a phone").
import { plugin } from './native.js';
import * as beam from './beam.js';

const KEY = 'sl.cloud';
const enc = new TextEncoder(), dec = new TextDecoder();
const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = (s) => { const t = String(s).replace(/-/g, '+').replace(/_/g, '/'); return Uint8Array.from(atob(t + '='.repeat((4 - (t.length % 4)) % 4)), (c) => c.charCodeAt(0)); };

export const creds = () => { try { return JSON.parse(localStorage.getItem(KEY)) || null; } catch { return null; } };
const store = (c) => { try { localStorage.setItem(KEY, JSON.stringify(c)); } catch {} };

// hand the details to the Files app's Shivo Cloud location (once per app start, and after joining)
let shared = false;
export async function share(force = false) {
  const c = creds(), N = plugin('ShivoNative');
  if (!c || !N?.cloudShare || (shared && !force)) return null;
  try { const i = await N.info(); if (!i.cloudFiles) return null; } catch { return null; }
  shared = true;
  return N.cloudShare({ api: c.api, token: c.token, master: c.master, account: c.account });
}

// join the PC's Shivo Cloud: ECDH P-256 with the hub, through Beam on the home Wi-Fi
export async function join() {
  const lan = await beam.lanForJoin();   // throws when the PC isn't on this Wi-Fi
  const pair = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveBits']);
  const pub = b64u(await crypto.subtle.exportKey('raw', pair.publicKey));
  const r = await fetch(`${lan.base}/files/join?k=${encodeURIComponent(lan.key)}&bid=${encodeURIComponent(lan.bid)}`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, cache: 'no-store',
    body: JSON.stringify({ pub, name: lan.name || 'iPhone', kind: beam.deviceKind() }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `The PC answered ${r.status}`);
  const hub = await crypto.subtle.importKey('raw', unb64u(j.pub), { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const secret = await crypto.subtle.deriveBits({ name: 'ECDH', public: hub }, pair.privateKey, 256);
  const hk = await crypto.subtle.importKey('raw', secret, 'HKDF', false, ['deriveKey']);
  const key = await crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: enc.encode('shivo-files-join'), info: enc.encode('v1') },
    hk, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
  const box = unb64u(j.box);
  const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: box.slice(0, 12), additionalData: enc.encode('shivo-join') }, key, box.slice(12));
  const c = JSON.parse(dec.decode(plain));
  if (!c.token || !c.master || !c.api) throw new Error("The PC's answer was incomplete");
  store(c);
  const s = await share(true);
  return { ...c, files: s };
}

export function forget() { try { localStorage.removeItem(KEY); } catch {} shared = false; }

async function api(path) {
  const c = creds(); if (!c) throw new Error('Not connected');
  const r = await fetch(c.api + path, { headers: { authorization: 'Bearer ' + c.token }, cache: 'no-store' });
  if (r.status === 401) { forget(); throw new Error('This phone was removed from Shivo Cloud. Connect again on the PC\'s Wi-Fi.'); }
  if (!r.ok) throw new Error(`Shivo Cloud answered ${r.status}`);
  return r.json();
}
// names are encrypted on the server: read them with the master key
async function names(items) {
  const k = await crypto.subtle.importKey('raw', unb64u(creds().master), 'AES-GCM', false, ['decrypt']);
  return Promise.all(items.map(async (it) => {
    let name = '?';
    try {
      const box = unb64u(String(it.name).slice(3));
      name = dec.decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: box.slice(0, 12), additionalData: enc.encode('shivo-name') }, k, box.slice(12)));
    } catch {}
    return { ...it, name };
  }));
}
export const status = () => api('/v1/me');
export async function top() {
  const j = await api('/v1/items?parent=');
  return (await names(j.items)).sort((a, b) => (a.kind === b.kind ? a.name.localeCompare(b.name) : a.kind === 'folder' ? -1 : 1));
}
