// A look as a colour table (3D LUT) for the native camera engine, which applies it live and to the photo with
// Core Image (CIColorCube). Same colour maths as develop.js's shader (colour mix, black and white, saturation,
// contrast curve, highlight roll-off and clip, shadow and highlight tint, lift and fade), so a look is the same in both engines and new
// looks still arrive over the air. Spatial parts (grain, glow, vignette) are separate settings, not in the table.
// False colour is a table too. Returns RGBA bytes, red changing fastest, as base64.

const luma = (r, g, b) => 0.2126 * r + 0.7152 * g + 0.0722 * b;
const sat01 = (x) => Math.max(0, Math.min(1, x));
const smooth = (a, b, x) => { const t = sat01((x - a) / (b - a)); return t * t * (3 - 2 * t); };

function lookColour(L, amount, r0, g0, b0) {
  const cm = L.cm;
  let r = cm[0][0] * r0 + cm[0][1] * g0 + cm[0][2] * b0;
  let g = cm[1][0] * r0 + cm[1][1] * g0 + cm[1][2] * b0;
  let b = cm[2][0] * r0 + cm[2][1] * g0 + cm[2][2] * b0;
  if (L.mono) { const m = L.mono[0] * r + L.mono[1] * g + L.mono[2] * b; r = g = b = m; }
  let l = luma(r, g, b);
  r = l + (r - l) * L.sat; g = l + (g - l) * L.sat; b = l + (b - l) * L.sat;
  const k = L.con - 1;
  const curve = (x) => { if (k > 0) { const s = x * x * (3 - 2 * x); return x + (s - x) * sat01(k * 2.2); } return 0.5 + (x - 0.5) * L.con; };
  r = curve(r); g = curve(g); b = curve(b);
  // film: highlights roll off softly; digicam: they clip clean and bright
  const ro = L.roll || 0, cl = L.clip || 0;
  const shape = (x) => { if (ro) x -= ro * 0.22 * Math.max(0, x - 0.55) ** 2 / 0.45; if (cl) x = sat01(x * (1 + cl * 0.14)); return x; };
  r = shape(r); g = shape(g); b = shape(b);
  l = luma(sat01(r), sat01(g), sat01(b));
  const ws = 1 - smooth(0, 0.55, l), wh = smooth(0.45, 1, l);
  r += L.sh[0] * ws + L.hl[0] * wh; g += L.sh[1] * ws + L.hl[1] * wh; b += L.sh[2] * ws + L.hl[2] * wh;
  const out = (x) => L.lift + sat01(x) * (1 - L.lift - L.fade);
  r = out(r); g = out(g); b = out(b);
  return [sat01(r0 + (r - r0) * amount), sat01(g0 + (g - g0) * amount), sat01(b0 + (b - b0) * amount)];
}
function falseColour(r, g, b) {
  const l = luma(r, g, b);
  if (l < 0.03) return [0.45, 0.1, 0.6]; if (l < 0.12) return [0.1, 0.3, 0.9];
  if (l > 0.42 && l < 0.52) return [0.35, 0.8, 0.4]; if (l > 0.97) return [0.95, 0.15, 0.1];
  if (l > 0.88) return [0.98, 0.6, 0.1]; if (l > 0.76) return [0.95, 0.88, 0.3];
  return [l, l, l];
}

// { look, amount, false } -> { size, data (base64 RGBA bytes) }
// Character: our looks were too timid next to each other (most looked alike). Each look's own colour, contrast and
// tints are taken this many times further from neutral, and its lifted blacks halved (they made photos milky).
// Natural and your own looks stay exactly as set; black and white looks get only the stronger contrast.
export const CHARACTER = 1.8;
function bold(L, k = CHARACTER) {
  if (L.mine || L.id === 'natural' || k === 1) return L;
  const con = 1 + ((L.con ?? 1) - 1) * k;
  if (L.mono) return { ...L, con, lift: (L.lift || 0) * 0.5 };
  const I = [[1, 0, 0], [0, 1, 0], [0, 0, 1]], cm = L.cm || I;
  return { ...L, con, sat: 1 + ((L.sat ?? 1) - 1) * k, cm: cm.map((row, r) => row.map((x, c) => I[r][c] + (x - I[r][c]) * k)),
    sh: (L.sh || [0, 0, 0]).map((x) => x * k * 1.1), hl: (L.hl || [0, 0, 0]).map((x) => x * k * 1.1), lift: (L.lift || 0) * 0.5, fade: (L.fade || 0) * 0.6 };
}

export function lutFor({ look: look0, amount = 1, false: fc = false }, size = 25) {
  const look = bold(look0);
  const n = size, px = new Uint8Array(n * n * n * 4);
  let i = 0;
  for (let bi = 0; bi < n; bi++) for (let gi = 0; gi < n; gi++) for (let ri = 0; ri < n; ri++) {
    const r = ri / (n - 1), g = gi / (n - 1), b = bi / (n - 1);
    const c = fc ? falseColour(r, g, b) : lookColour(look, amount, r, g, b);
    px[i++] = Math.round(c[0] * 255); px[i++] = Math.round(c[1] * 255); px[i++] = Math.round(c[2] * 255); px[i++] = 255;
  }
  let s = ''; for (let j = 0; j < px.length; j += 0x8000) s += String.fromCharCode.apply(null, px.subarray(j, j + 0x8000));
  return { size: n, data: btoa(s) };
}
