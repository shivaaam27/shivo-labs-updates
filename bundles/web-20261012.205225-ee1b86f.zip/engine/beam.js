// Beam inside the phone app: send photos and files to the PC, and receive what the PC sends.
// Talks straight to Beam on the PC over the shared Wi-Fi (beam.local:8765). Nothing goes online.
// The first time, Beam on the PC asks its owner to accept this phone (like AirDrop).
// Received photos and videos go into Photos; other files go into the Files app
// (On My iPhone > Shivo Labs > Beam).
import { plugin } from './native.js';

export const SHARE_URL = 'https://shivamparmar.vercel.app/beam';
let host = 'beam.local';
export const setHost = (h) => { host = String(h || 'beam.local').trim().replace(/^https?:\/\//, '').replace(/[:/].*$/, '') || 'beam.local'; };
const base = () => `http://${host}:8765`;

async function call(path, opts = {}, ms = 8000) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await fetch(base() + path, { ...opts, signal: ctl.signal, cache: 'no-store' });
    if (r.status === 403) throw new Error('Not accepted on the PC yet. Click Accept on the PC, then try again.');
    if (r.status === 401) throw new Error('The PC did not accept this phone. Try again and click Accept on the PC.');
    return r;
  } catch (e) {
    if (e.name === 'AbortError' || e instanceof TypeError) throw new Error("Can't reach Beam. Check Beam is open on the PC and both are on the same Wi-Fi.");
    throw e;
  } finally { clearTimeout(t); }
}

// Is Beam there? Returns the PC's name. The first call may wait while the owner clicks Accept,
// so the default wait is long; background checks pass a short one.
export async function ping(ms = 75000) {
  const r = await call('/ping', {}, ms);
  if (!r.ok) throw new Error('Beam answered ' + r.status);
  return (await r.json()).pc || 'PC';
}

export async function waiting(ms = 75000) {
  const r = await call('/outbox', {}, ms);
  const list = r.ok ? await r.json() : [];
  return list.filter((it) => it.size > 0);   // an empty entry is a file an older Beam was still copying
}

// Send files (from an <input type=file>) one by one; onStep(done, total, name) for progress.
export async function send(files, onStep) {
  let n = 0;
  for (const f of files) {
    onStep?.(n, files.length, f.name);
    const fd = new FormData(); fd.append('file', f, f.name);
    const r = await call('/upload', { method: 'POST', body: fd }, 10 * 60000);
    if (!r.ok) throw new Error((await r.text()) || 'Upload failed');
    n++;
  }
  return n;
}

// Save everything waiting on the PC: photos and videos to Photos, the rest to Files.
// Each file gets a time budget that grows with its size; one that fails is left on the PC and the rest carry on.
// What this phone just saved (name + size, kept 10 minutes), so a file the PC failed to drop
// from its list is never saved twice.
const SEEN_KEY = 'sl.beamSaved';
const seenList = () => { try { const now = Date.now(); return (JSON.parse(localStorage.getItem(SEEN_KEY)) || []).filter((x) => now - x.t < 10 * 60000); } catch { return []; } };
const sig = (it) => `${it.name}|${it.size}`;
const markSaved = (it) => { try { const l = seenList(); l.push({ k: sig(it), t: Date.now() }); localStorage.setItem(SEEN_KEY, JSON.stringify(l.slice(-500))); } catch {} };
const limit = (p, ms) => Promise.race([p, new Promise((_, no) => setTimeout(() => no(new Error('took too long')), ms))]);
// How long one file may take before we stop waiting: 2 minutes plus a second per MB, so a big video on
// slow Wi-Fi isn't given up on (it would still finish in the background, then be fetched a second time).
export const saveBudget = (size = 0) => 120000 + Math.ceil(size / 1e6) * 1000;
// items: the list the caller just fetched (saves asking the PC twice); fetched here when left out.
export async function receiveAll(onStep, items) {
  const N = plugin('ShivoNative'), FS = plugin('Filesystem'), M = plugin('Media');
  if (!N && !FS) throw new Error('Saving files only works in the installed app.');
  items = items || await waiting(); let done = 0, photos = 0; const failed = [];
  const already = new Set(seenList().map((x) => x.k));
  for (const it of items) {
    if (already.has(sig(it))) { await call('/done?name=' + encodeURIComponent(it.name), { method: 'POST' }).catch(() => {}); continue; }
    onStep?.(done + failed.length, items.length, it.name, it.size);
    const budget = saveBudget(it.size);
    const url = base() + '/file/' + encodeURIComponent(it.name);
    try {
      if (N) {   // our own add-on: plain download, then Photos or Files
        const r = await limit(N.saveFromURL({ url, name: it.name, kind: it.kind }), budget);
        if (r.saved === 'photos') photos++;
      } else if (it.kind === 'media' && M) {
        const rel = 'beam-tmp/' + it.name;
        await limit(FS.downloadFile({ url, path: rel, directory: 'CACHE', recursive: true }), budget);
        const { uri } = await FS.getUri({ path: rel, directory: 'CACHE' });
        await limit(/\.(mov|mp4|m4v|avi|mkv|webm|3gp)$/i.test(it.name) ? M.saveVideo({ path: uri }) : M.savePhoto({ path: uri }), 60000);
        FS.deleteFile({ path: rel, directory: 'CACHE' }).catch(() => {});
        photos++;
      } else await limit(FS.downloadFile({ url, path: 'Beam/' + it.name, directory: 'DOCUMENTS', recursive: true }), budget);
      markSaved(it);
      await call('/done?name=' + encodeURIComponent(it.name), { method: 'POST' }).catch(() => {});
      done++;
    } catch (e) { failed.push(`${it.name}: ${e.message || e}`); }
  }
  return { done, photos, failed };
}
