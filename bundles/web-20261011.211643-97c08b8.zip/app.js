/* Shivo Labs: your AI on your phone. Standalone: your own Claude and Gemini keys live on this phone,
   chats call the models directly, and long tasks run as hosted agents on Anthropic's servers. */
import * as store from './engine/store.js';
import { MODELS, checkKey, runChat, costOf } from './engine/claude.js';
import { PHONE_TOOLS, WRITE_TOOLS, execPhoneTool, contextLine } from './engine/tools.js';
import { listGeminiModels, defaultGeminiChain, makeGeminiLimits, runGeminiChat, freeLimits, prettyGemini } from './engine/gemini.js';
import * as ag from './engine/agents.js';
import { plugin } from './engine/native.js';
import { appReady, checkForUpdate, myVersion } from './engine/ota.js';
import * as beam from './engine/beam.js';
import qrcode from './kit/qrcode.mjs';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));
const qs = new URLSearchParams(location.search);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const FAST = qs.has('fast');

/* ---------- icons, mark, markdown ---------- */
const IC = {
  chev: 'm9 6 6 6-6 6', check: 'm5 12.5 4.5 4.5L19 7.5', x: 'M6 6l12 12M18 6 6 18',
  spark: 'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z', doc: 'M7 3h7l5 5v13H7zM14 3v5h5',
  img: 'M4 5h16v14H4zM4 15l5-5 4 4 3-3 4 4',
};
const ic = (n, cls = '') => `<svg class="${cls}" viewBox="0 0 24 24"><path d="${IC[n]}"/></svg>`;
const TILES = [[18, 64, 't'], [64, 18, 't'], [18, 41, 't'], [41, 18, 't'], [41, 41, 't'], [18, 18, 'lit']];
const mark = (cls = '') => `<svg class="mk ${cls}" viewBox="0 0 100 100"><g transform="rotate(15 50 50)">${TILES.map(([x, y, c], i) => `<rect class="${c}" style="--i:${i}" x="${x}" y="${y}" width="18" height="18" rx="4.5"/>`).join('')}</g></svg>`;
const light = () => document.documentElement.dataset.theme === 'light';
const loader = (k, n = 18) => fabraLoader(k, n, light());

function md(src) {
  let s = String(src || '');
  const blocks = [];
  s = s.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, l, c) => { blocks.push(`<pre><code>${esc(c.replace(/\n$/, ''))}</code></pre>`); return `\u0000${blocks.length - 1}\u0000`; });
  const inline = (t) => esc(t)
    .replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<i>$2</i>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  const out = [];
  for (const para of s.split(/\n{2,}/)) {
    const p = para.trim(); if (!p) continue;
    if (/^\u0000\d+\u0000$/.test(p)) { out.push(p); continue; }
    const lines = p.split('\n');
    if (lines.every((l) => /^\s*[-*] /.test(l))) { out.push('<ul>' + lines.map((l) => '<li>' + inline(l.replace(/^\s*[-*] /, '')) + '</li>').join('') + '</ul>'); continue; }
    if (lines.every((l) => /^\s*\d+[.)] /.test(l))) { out.push('<ol>' + lines.map((l) => '<li>' + inline(l.replace(/^\s*\d+[.)] /, '')) + '</li>').join('') + '</ol>'); continue; }
    const h = /^(#{1,4}) (.+)$/.exec(p);
    if (h && lines.length === 1) { out.push(`<h4>${inline(h[2])}</h4>`); continue; }
    out.push('<p>' + lines.map(inline).join('<br>') + '</p>');
  }
  return out.join('').replace(/\u0000(\d+)\u0000/g, (_, i) => blocks[+i]);
}

/* ---------- state ---------- */
const DEF = { theme: 'auto', cap: 2, askPhone: true, mode: 'auto', model: 'sonnet', workspace: 'chat', abil: { cal: true, rem: true } };
const S = { keys: {}, st: { ...DEF }, chats: [], cur: null, run: null, gm: { models: [], chain: [] }, online: navigator.onLine !== false, app: 'ai', log: [], limits: null };
const saveSettings = () => store.set('sl.settings', S.st);
const saveKeys = () => store.set('sl.keys', S.keys);
const saveChat = (c) => { if (!c) return; store.set('chat.' + c.id, c); store.set('sl.index', S.chats.map((x) => x.id)); };
let saveT = 0; const saveSoon = (c) => { clearTimeout(saveT); saveT = setTimeout(() => saveChat(c), 400); };
const hasClaude = () => !!S.keys.claude, hasGemini = () => !!S.keys.gemini;
const isG = (m = S.st.model) => String(m).startsWith('g:');
const canUse = () => S.online && (isG() ? hasGemini() : hasClaude());
const monthKey = () => new Date().toISOString().slice(0, 7);
const monthSpend = () => store.get('sl.spend', {})[monthKey()] || 0;
function addSpend(d) { if (!d) return; const sp = store.get('sl.spend', {}); sp[monthKey()] = (sp[monthKey()] || 0) + d; store.set('sl.spend', sp); paintPill(); }
const money = (n) => '$' + (n < 0.01 && n > 0 ? '0.01' : n.toFixed(2));
function paintPill() { $('#pcName').textContent = !S.online ? 'Offline' : monthSpend() > 0 ? money(monthSpend()) + ' this month' : 'Settings'; $('#pcPill').classList.toggle('off', !S.online); }
const modelName = (m) => (isG(m) ? prettyGemini(m.slice(2)) : MODELS[m]?.name || m);

/* ---------- theme ---------- */
const mq = matchMedia('(prefers-color-scheme: dark)');
function applyTheme() {
  const t = S.st.theme === 'auto' ? (mq.matches ? 'dark' : 'light') : S.st.theme;
  document.documentElement.dataset.theme = t;
  $('meta[name=theme-color]').content = t === 'dark' ? '#141517' : '#F5F5F2';
  plugin('StatusBar')?.setStyle?.({ style: t === 'dark' ? 'DARK' : 'LIGHT' })?.catch?.(() => {});
}
mq.addEventListener?.('change', applyTheme);

/* ---------- sheets and toasts ---------- */
function openSheet(title, html, after) {
  $('#shTitle').textContent = title; $('#shBody').innerHTML = html;
  $('#scrim').classList.remove('out'); $('#scrim').hidden = false; $('#sheet').hidden = false; void $('#sheet').offsetHeight; $('#sheet').classList.add('up');
  after && after($('#shBody'));
}
function closeSheet() {
  $('#sheet').classList.remove('up'); $('#scrim').classList.add('out');
  setTimeout(() => { if (!$('#sheet').classList.contains('up')) { $('#sheet').hidden = true; $('#scrim').hidden = true; } }, 420);
}
const swapSheet = (fn) => { closeSheet(); setTimeout(fn, 440); };
$('#scrim').onclick = closeSheet;
function toast(t) {
  let el = $('#toast'); if (!el) { el = document.createElement('div'); el.id = 'toast'; $('#device').append(el); }
  el.textContent = t; el.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('on'), 2800);
}
function pickSheet(title, items, current, onPick) {
  openSheet(title, items.map(([id, name, sub, off]) => `<button class="row ${id === current ? 'sel' : ''} ${off ? 'dis' : ''}" data-id="${id}"><span class="t"><b>${esc(name)}</b><small>${esc(sub || '')}</small></span>${ic('check', 'tick')}</button>`).join(''),
    (b) => $$('.row', b).forEach((r) => (r.onclick = () => { onPick(r.dataset.id); closeSheet(); })));
}

/* ---------- boot ---------- */
async function boot() {
  await store.initStore();
  S.st = { ...DEF, ...store.get('sl.settings', {}) }; S.st.abil = { ...DEF.abil, ...(S.st.abil || {}) };
  S.keys = store.get('sl.keys', {});
  S.gm = store.get('sl.gm', { models: [], chain: [] });
  S.log = store.get('sl.log', []);
  S.chats = store.get('sl.index', []).map((id) => store.get('chat.' + id)).filter(Boolean);
  S.limits = makeGeminiLimits(store);
  if (qs.has('reset')) { S.keys = {}; saveKeys(); }
  applyTheme();
  $('#splashMark').innerHTML = mark('play'); $('#loginMark').innerHTML = mark('play'); $('#topMark').innerHTML = mark('play');
  if (!hasClaude() && !hasGemini() && !store.get('sl.imported', false)) {
    try {   // a build made on the owner's PC carries the keys in keys.json; they move into phone storage once
      const r = await fetch('keys.json', { cache: 'no-store' });
      if (r.ok) { const j = await r.json(); if (j.claude || j.gemini) { S.keys = { claude: j.claude || '', gemini: j.gemini || '' }; saveKeys(); store.set('sl.imported', true); if (j.gemini) refreshGemini(); } }
    } catch {}
  }
  if (!S.keys.claude && !S.keys.gemini) S.keys = {};
  normalizeModel();
  await sleepMs(FAST ? 250 : 1700);
  $('#splash').classList.add('out');
  if (hasClaude() || hasGemini() || store.get('sl.explore', false)) enterApp(); else { $('#login').hidden = false; }
  if (hasGemini() && !S.gm.chain.length) refreshGemini();
  appReady(); otaCheck();
}
// Over-the-air updates: check on opening and whenever the app comes back to the front.
const otaCheck = () => checkForUpdate({ isIdle: () => !S.run, onApplied: () => toast('Updating Shivo Labs…') });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') otaCheck(); });

/* ---------- first-run setup ---------- */
const kc = $('#claudeKey'), kg = $('#geminiKey');
const syncGo = () => { $('#goBtn').disabled = kc.value.trim().length < 12 && kg.value.trim().length < 12; };
kc.oninput = kg.oninput = () => { $('#codeHint').className = 'hint'; syncGo(); };
$('#goBtn').onclick = async () => {
  const c = kc.value.trim(), g = kg.value.trim(), hint = $('#codeHint'), btn = $('#goBtn');
  btn.disabled = true; hint.className = 'hint'; hint.textContent = 'Checking your keys…';
  if (c) { const r = await checkKey(c); if (!r.ok) { hint.className = 'hint err'; hint.textContent = r.error; syncGo(); return; } }
  let models = [];
  if (g) { try { models = await listGeminiModels(g); } catch (e) { hint.className = 'hint err'; hint.textContent = e.message; syncGo(); return; } }
  S.keys = { claude: c, gemini: g }; saveKeys();
  if (g) { S.gm = { models, chain: defaultGeminiChain(models) }; store.set('sl.gm', S.gm); }
  normalizeModel(); hint.textContent = 'You are in.';
  await sleepMs(500); enterApp();
};
// Look around without keys; keys can be added later in Settings.
$('#exploreBtn').onclick = () => { store.set('sl.explore', true); enterApp(); };

/* ---------- shell ---------- */
function enterApp() {
  $('#login').hidden = true; $('#shell').hidden = false;
  requestAnimationFrame(() => $('#shell').classList.add('on'));
  $('#offLoader').innerHTML = loader('wait', 18);
  paintPill(); paintChips(); renderMsgs(); updateSend(); renderTasks(); renderPhone();
  $('#offline').hidden = S.online;
  const last = S.chats.find((c) => c.session?.status === 'running'); if (last) resumeTask(last);
}
const ORDER = ['ai', 'beam', 'phone'];
const taskBadgeEl = () => $('#taskBadge') || { hidden: true };
function switchApp(to) {
  if (to === S.app) return;
  const from = S.app; S.app = to; document.body.dataset.app = to;
  $$('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.go === to)); window.__syncLens?.();
  const vf = $('#v-' + from), vt = $('#v-' + to);
  vf.classList.remove('on'); vf.classList.toggle('left', ORDER.indexOf(to) > ORDER.indexOf(from)); vt.classList.remove('left'); vt.classList.add('on');
  const tag = $('#tag'); tag.classList.add('swap');
  setTimeout(() => { tag.textContent = { ai: 'AI', tasks: 'TASKS', beam: 'BEAM', phone: 'PHONE' }[to]; tag.classList.remove('swap'); }, 160);
  const m = $('#topMark .mk'); m.classList.remove('play', 'sweep'); void m.getBoundingClientRect(); m.classList.add('sweep');
  if (to === 'tasks') renderTasks(); if (to === 'phone') renderPhone(); if (to === 'beam') renderBeam(true);
  markScrolled();
}
$$('#tabs button').forEach((b) => (b.onclick = () => switchApp(b.dataset.go)));
const scroller = () => ({ ai: $('#msgs'), tasks: $('#tasksBody'), beam: $('#beamBody'), phone: $('#phoneBody') }[S.app]);
const markScrolled = () => $('.top').classList.toggle('scrolled', (scroller()?.scrollTop || 0) > 4);
['#msgs', '#tasksBody', '#beamBody', '#phoneBody'].forEach((s) => $(s).addEventListener('scroll', markScrolled, { passive: true }));

function setOnline(v) {
  S.online = v; $('#offline').hidden = v; paintPill(); syncPlaceholder(); updateSend();
  if (v) { const c = S.chats.find((x) => x.session?.status === 'running'); if (c && !S.run) resumeTask(c); }
}
addEventListener('online', () => setOnline(true)); addEventListener('offline', () => setOnline(false));
document.addEventListener('visibilitychange', async () => {
  if (document.visibilityState !== 'visible' || $('#shell').hidden) return;
  const live = S.run?.chat?.session?.status === 'running' ? S.run : null;
  if (live) {   // iOS may have cut the live stream while we were away: drop it and re-attach
    live.detached = true; live.ctl.abort();
    for (let i = 0; i < 40 && S.run; i++) await sleepMs(50);
    S.run = null;
    resumeTask(live.chat, true); return;
  }
  const c = S.chats.find((x) => x.session?.status === 'running');
  if (c) resumeTask(c, true);
});

/* ---------- models ---------- */
function normalizeModel() {
  if (isG() && !hasGemini()) S.st.model = hasClaude() ? 'sonnet' : S.st.model;
  else if (!isG() && !hasClaude() && hasGemini()) S.st.model = 'g:' + (S.gm.chain[0] || 'gemini-3.5-flash-lite');
  if (S.st.workspace === 'cloud' && !hasClaude()) S.st.workspace = 'chat';
  saveSettings();
}
async function refreshGemini() {
  try { const models = await listGeminiModels(S.keys.gemini); S.gm = { models, chain: defaultGeminiChain(models) }; store.set('sl.gm', S.gm); normalizeModel(); paintChips(); } catch {}
}
function chainFor(m) { const start = String(m).slice(2); return [start, ...S.gm.chain.filter((x) => x !== start)]; }

function paintChips() {
  $('#chatTitle').textContent = modelName(S.st.model).replace('Gemini ', '');
  $('#modelTxt').textContent = S.fell ? modelName('g:' + S.fell).replace('Gemini ', '') : modelName(S.st.model).replace('Gemini ', '');
  $('#modelChip').classList.toggle('fell', !!S.fell);
  $('#folderTxt').textContent = S.st.workspace === 'cloud' ? 'Cloud task' : 'Chat';
  $('#modeTxt').textContent = { ask: 'Ask', auto: 'Auto', plan: 'Plan' }[S.st.mode];
  $('#modeChip').hidden = S.st.workspace !== 'cloud';
  syncPlaceholder();
}
function syncPlaceholder() { $('#box').placeholder = !S.online ? "You're offline" : !canUse() ? 'Add a key in Settings to start' : S.st.workspace === 'cloud' ? 'Describe a task…' : 'Ask Labs AI…'; }

$('#modelChip').onclick = () => {
  const row = (id, n, sub, off) => `<button class="row ${id === S.st.model ? 'sel' : ''} ${off ? 'dis' : ''}" data-id="${id}"><span class="t"><b>${esc(n)}</b><small>${esc(sub)}</small></span>${ic('check', 'tick')}</button>`;
  const claude = hasClaude() ? Object.entries(MODELS).map(([k, m]) => row(k, m.name, m.note)).join('')
    : `<button class="row" id="addClaude"><span class="t"><b>Add your Claude key</b><small>From the Claude Console. Kept on this phone only.</small></span>${ic('chev')}</button>`;
  const gem = hasGemini() ? (S.gm.chain.length ? S.gm.chain.map((m) => {
    const L = freeLimits(m), used = S.limits.usedToday(m), out = S.limits.isOut(m);
    return row('g:' + m, prettyGemini(m), out ? (S.limits.whyOut(m) === 'gone' ? 'Not available to your key' : S.limits.whyOut(m) === 'busy' ? 'Overloaded at Google, retrying soon' : 'Used up today') : `Free: ${used} of ${L.rpd} used today`);
  }).join('') : '<p class="sh-p">Loading your Gemini models…</p>')
    : `<button class="row" id="addGem"><span class="t"><b>Add a Gemini key</b><small>Free from Google. Works anywhere.</small></span>${ic('chev')}</button>`;
  openSheet('Model', `<div class="sh-sub" style="margin-top:0">CLAUDE · YOUR KEY</div>${claude}
    <div class="sh-sub">GEMINI · YOUR FREE KEY</div>${gem}
    <p class="sh-p" style="margin-top:10px">If a Gemini model runs out of free requests, the next one takes over by itself and you get a notice.</p>`, (b) => {
    $$('.row[data-id]', b).forEach((r) => (r.onclick = () => { S.st.model = r.dataset.id; S.fell = null; if (isG() && S.st.workspace === 'cloud') { S.st.workspace = 'chat'; toast('Gemini works in Chat. Cloud tasks use Claude.'); } saveSettings(); paintChips(); updateSend(); closeSheet(); }));
    $('#addClaude', b) && ($('#addClaude', b).onclick = () => swapSheet(() => keySheet('claude')));
    $('#addGem', b) && ($('#addGem', b).onclick = () => swapSheet(() => keySheet('gemini')));
  });
};
$('#folderChip').onclick = () => pickSheet('How should it work?', [
  ['chat', 'Chat', 'Quick answers. Can search the web and use your calendar.'],
  ['cloud', 'Cloud task', hasClaude() ? 'A cloud workspace that builds, fixes and writes things. Keeps going when you lock your phone.' : 'Needs your Claude key', !hasClaude()],
], S.st.workspace, (id) => { S.st.workspace = id; if (id === 'cloud' && isG()) S.st.model = 'sonnet'; saveSettings(); paintChips(); updateSend(); });
$('#modeChip').onclick = () => pickSheet('How much can it do on its own?', [
  ['auto', 'Auto', 'Does the work without stopping to ask'], ['ask', 'Ask', 'Asks before it runs commands or changes files'], ['plan', 'Plan', 'Only looks and proposes a plan'],
], S.st.mode, (id) => { S.st.mode = id; saveSettings(); paintChips(); });

/* ---------- chats ---------- */
const msgsEl = $('#msgs'), box = $('#box');
const scrollDown = () => { msgsEl.scrollTop = msgsEl.scrollHeight; };
const newChat = () => ({ id: 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), title: 'New chat', at: Date.now(), history: [], ui: [], session: null, kind: 'chat' });
function renderChats() { $('#chatTitle').textContent = modelName(S.st.model).replace('Gemini ', ''); document.body.classList.toggle('fresh', !S.cur || !S.cur.ui.length); }
function assistantEl(a) {
  const el = document.createElement('div'); el.className = 'm a';
  for (const n of a.notes || []) addNote(el, n);
  if (a.steps?.length) el.insertAdjacentHTML('beforeend', `<div class="steps collapsed"><button class="sg"><span class="ico">${ic('check')}</span><span class="lbl">${esc(a.sum || a.steps.length + ' steps')}</span>${ic('chev', 'chev')}</button><div class="sl"><div>${a.steps.map((s) => `<div class="st done"><i class="s"></i><span>${s.html}</span></div>`).join('')}</div></div></div>`);
  if (a.t) el.insertAdjacentHTML('beforeend', `<div class="txt">${md(a.t)}</div>`);
  if (a.files?.length) addFiles(el, a.files, S.cur);
  $$('.steps .sg', el).forEach((b) => (b.onclick = () => b.parentElement.classList.toggle('collapsed')));
  return el;
}
function renderMsgs() {
  renderChats();
  const c = S.cur;
  if (!c || !c.ui.length) {
    const sugg = S.st.workspace === 'cloud'
      ? ['Build me a one-page website for a coffee stall', 'Turn my notes into a clean one-page summary', 'Make a simple budget tracker page']
      : ['What is on my calendar this week?', 'Remind me to call the electrician tomorrow at 9', 'Explain how mortgages work in simple terms'];
    const hr = new Date().getHours(), hi = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
    msgsEl.innerHTML = `<div class="empty"><div class="mkw hero">${mark('play')}</div>
      <h1>${hi}. <span>${S.st.workspace === 'cloud' ? 'What should I build in the cloud?' : 'What are we doing today?'}</span></h1>
      <div class="sugg">${sugg.map((t) => `<button>${ic('spark')}<span>${esc(t)}</span></button>`).join('')}</div></div>`;
    $$('.sugg button', msgsEl).forEach((b) => (b.onclick = () => send(b.textContent.trim())));
    return;
  }
  msgsEl.innerHTML = '';
  for (const m of c.ui) {
    if (m.r === 'u') { const el = document.createElement('div'); el.className = 'm u'; el.innerHTML = `<div>${esc(m.t)}</div>`; msgsEl.append(el); }
    else msgsEl.append(assistantEl(m));
  }
  scrollDown();
}
$('#modelTitle').onclick = () => $('#modelChip').click();
$('#setBtn').onclick = () => $('#pcPill').click();
$('#menuBtn').onclick = () => openDrawer();
/* ---------- drawer: chat history and Cloud tasks (like Gemini's side menu) ---------- */
const LAB = { running: ['Running', 'run'], done: ['Done', ''], stopped: ['Stopped', ''], budget: ['Paused at cap', 'bad'], error: ['Error', 'bad'] };
function openDrawer() {
  const dr = $('#drawer'), sc = $('#scrim');
  const paint = (q = '') => {
    const f = (c) => !q || (c.title + ' ' + (c.ui.at(-1)?.t || '')).toLowerCase().includes(q);
    const all = [...S.chats].filter(f).sort((a, b) => (b.pin ? 1 : 0) - (a.pin ? 1 : 0) || b.at - a.at);
    const cloud = all.filter((c) => c.session), chats = all.filter((c) => !c.session);
    const row = (c) => `<button class="dr-row ${S.cur === c ? 'sel' : ''}" data-id="${c.id}"><span>${esc(c.title)}</span>${c.session ? `<i class="st-pill ${LAB[c.session.status]?.[1] || ''}">${LAB[c.session.status]?.[0] || 'Done'}</i>` : ''}</button>`;
    $('#drawerBody').innerHTML = `
      <div class="dr-top"><b>Shivo Labs</b><button class="gbtn" id="drClose" aria-label="Close"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
      <button class="dr-act" id="drNew"><svg viewBox="0 0 24 24"><path d="M12 20h8M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg><span>New chat</span></button>
      <button class="dr-act" id="drCloud"><svg viewBox="0 0 24 24"><path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9.5 4.3 4.3 0 0 0 7 18z"/></svg><span>New cloud task<small>Keeps working when your phone is locked</small></span></button>
      <label class="dr-search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6"/><path d="m20 20-4-4"/></svg><input id="drQ" placeholder="Search chats" value="${esc(q)}" autocapitalize="off"></label>
      ${cloud.length ? `<h4>Cloud</h4>${cloud.map(row).join('')}` : ''}
      <h4>Recent</h4>${chats.map(row).join('') || '<p class="emptyt">No chats yet.</p>'}
      ${S.chats.length ? '<button class="dr-row danger" id="drDel"><span>Delete all chats on this phone</span></button>' : ''}`;
    const b = $('#drawerBody');
    $('#drClose', b).onclick = closeDrawer;
    $('#drNew', b).onclick = () => { closeDrawer(); if (S.run) return; S.st.workspace = 'chat'; saveSettings(); S.cur = null; S.fell = null; paintChips(); renderMsgs(); switchApp('ai'); };
    $('#drCloud', b).onclick = () => { closeDrawer(); if (S.run) return; if (!hasClaude()) return toast('Cloud tasks need your Claude key. Add it in Settings.'); S.st.workspace = 'cloud'; if (isG()) S.st.model = 'sonnet'; saveSettings(); S.cur = null; paintChips(); renderMsgs(); updateSend(); switchApp('ai'); box.focus(); };
    $('#drQ', b).oninput = (e) => { const v = e.target.value, pos = e.target.selectionStart; paint(v.toLowerCase()); const i = $('#drQ'); i.focus(); i.value = v; i.setSelectionRange(pos, pos); };
    $$('.dr-row[data-id]', b).forEach((r) => (r.onclick = () => { if (S.run) return toast('Wait for the current reply, or stop it first'); S.cur = S.chats.find((c) => c.id === r.dataset.id); S.fell = null; paintChips(); renderMsgs(); closeDrawer(); switchApp('ai'); }));
    $('#drDel', b) && ($('#drDel', b).onclick = () => { if (S.run) return toast('Stop the current reply first'); if (!confirm('Delete every chat on this phone? Files made by tasks stay in your Claude account.')) return; S.chats.forEach((c) => store.del('chat.' + c.id)); S.chats = []; S.cur = null; store.set('sl.index', []); renderMsgs(); renderTasks(); paint(); });
  };
  paint();
  sc.classList.remove('out'); sc.hidden = false; dr.hidden = false; void dr.offsetHeight; dr.classList.add('in');
  sc.onclick = closeDrawer;
}
function closeDrawer() {
  const dr = $('#drawer'); dr.classList.remove('in'); $('#scrim').classList.add('out'); $('#scrim').onclick = closeSheet;
  setTimeout(() => { if (!dr.classList.contains('in')) { dr.hidden = true; if ($('#sheet').hidden) $('#scrim').hidden = true; } }, 380);
}
// swipe the drawer closed to the left
(() => {
  let x0 = null; const dr = $('#drawer');
  dr.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true });
  dr.addEventListener('touchmove', (e) => { if (x0 == null) return; dr.style.transform = `translateX(${Math.min(0, e.touches[0].clientX - x0)}px)`; }, { passive: true });
  dr.addEventListener('touchend', (e) => { if (x0 == null) return; const dx = e.changedTouches[0].clientX - x0; x0 = null; dr.style.transform = ''; if (dx < -70) closeDrawer(); });
})();

/* ---------- sheets: drag the handle (or the top of the sheet) down to close ---------- */
(() => {
  const sh = $('#sheet'); let y0 = null, dy = 0;
  sh.addEventListener('touchstart', (e) => {
    if (sh.scrollTop > 0) return;
    if (e.target.closest('input,textarea,.seg')) return;
    y0 = e.touches[0].clientY; dy = 0; sh.style.transition = 'none';
  }, { passive: true });
  sh.addEventListener('touchmove', (e) => { if (y0 == null) return; dy = Math.max(0, e.touches[0].clientY - y0); sh.style.transform = `translateY(${dy}px)`; }, { passive: true });
  sh.addEventListener('touchend', () => { if (y0 == null) return; y0 = null; sh.style.transition = ''; sh.style.transform = ''; if (dy > 90) closeSheet(); });
})();

/* ---------- tab bar: press and slide along it; a glass lens follows your finger and stretches ---------- */
(() => {
  const bar = $('#tabs'); const lens = document.createElement('i'); lens.className = 'lens'; bar.prepend(lens);
  const btns = () => $$('button', bar);
  const place = (el, s = 1) => { const r = el.getBoundingClientRect(), b = bar.getBoundingClientRect(); lens.style.width = r.width + 'px'; lens.style.transform = `translateX(${r.left - b.left}px) scale(${s})`; };
  const sync = () => { const on = $('button.on', bar); if (on) place(on); };
  new ResizeObserver(sync).observe(bar); setTimeout(sync, 60);
  let drag = false, lastX = 0;
  const at = (x) => btns().find((b) => { const r = b.getBoundingClientRect(); return x >= r.left && x <= r.right; });
  bar.addEventListener('pointerdown', (e) => { drag = true; lastX = e.clientX; bar.classList.add('drag'); const b = at(e.clientX); if (b) place(b, 1.12); });
  bar.addEventListener('pointermove', (e) => {
    if (!drag) return; const v = e.clientX - lastX; lastX = e.clientX;
    const br = bar.getBoundingClientRect(), w = lens.offsetWidth, x = Math.max(4, Math.min(br.width - w - 4, e.clientX - br.left - w / 2));
    lens.style.transform = `translateX(${x}px) scale(${1.12 + Math.min(.18, Math.abs(v) / 50)}, ${1.12 - Math.min(.08, Math.abs(v) / 120)})`;
  });
  const end = (e) => { if (!drag) return; drag = false; bar.classList.remove('drag'); const b = at(e.clientX); if (b && b.dataset.go !== S.app) b.click(); setTimeout(sync, 0); };
  bar.addEventListener('pointerup', end);
  bar.addEventListener('pointercancel', () => { drag = false; bar.classList.remove('drag'); sync(); });
  window.__syncLens = sync;
})();
const oldChatsSheet = () => {
  const list = [...S.chats].sort((a, b) => (b.pin ? 1 : 0) - (a.pin ? 1 : 0) || b.at - a.at);
  const row = (c) => `<button class="row ${S.cur === c ? 'sel' : ''}" data-id="${c.id}"><span class="t"><b>${esc(c.title)}</b><small>${c.kind === 'task' ? 'Cloud task · ' : ''}${esc(c.ui.at(-1)?.t?.slice(0, 60) || 'No messages yet')}</small></span>${c.session?.status === 'running' ? '<i class="live-dot"></i>' : ''}</button>`;
  openSheet('Chats', (list.map(row).join('') || '<p class="sh-p">No chats yet.</p>') + (list.length ? '<button class="row danger" id="delAll"><span class="t"><b>Delete all chats on this phone</b></span></button>' : ''), (b) => {
    $$('.row[data-id]', b).forEach((r) => (r.onclick = () => { if (S.run) return toast('Wait for the current reply, or stop it first'); S.cur = S.chats.find((c) => c.id === r.dataset.id); S.fell = null; paintChips(); renderMsgs(); closeSheet(); switchApp('ai'); }));
    $('#delAll', b) && ($('#delAll', b).onclick = () => { if (S.run) return toast('Stop the current reply first'); if (!confirm('Delete every chat on this phone? Files made by tasks stay in your Claude account.')) return; S.chats.forEach((c) => store.del('chat.' + c.id)); S.chats = []; S.cur = null; store.set('sl.index', []); renderMsgs(); renderTasks(); closeSheet(); });
  });
};
$('#newBtn').onclick = () => { if (S.run) return; S.cur = null; S.fell = null; paintChips(); renderMsgs(); box.focus(); };

/* ---------- composer ---------- */
function grow() { box.style.height = 'auto'; box.style.height = Math.min(box.scrollHeight, 120) + 'px'; }
function updateSend() {
  syncPlaceholder();
  const b = $('#sendBtn'); b.classList.toggle('stop', !!S.run);
  b.innerHTML = S.run ? '<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="3"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M12 19V5m0 0-6 6m6-6 6 6"/></svg>';
  b.disabled = S.run ? false : !box.value.trim() || !canUse();
}
box.addEventListener('input', () => { grow(); updateSend(); });
box.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !('ontouchstart' in window)) { e.preventDefault(); $('#sendBtn').click(); } });
$('#sendBtn').onclick = () => (S.run ? stopRun() : send(box.value));
let rec = null;
// Voice: the iPhone's own speech recognition through the native plugin (the web view has none).
let nativeRec = null;
async function nativeMic(P) {
  const mic = $('#micBtn');
  if (nativeRec) { try { await P.stop(); } catch {} return; }
  try {
    const perm = await P.requestPermissions();
    if (perm.speechRecognition && perm.speechRecognition !== 'granted') return toast('Allow Speech Recognition and Microphone for Shivo Labs in iPhone Settings.');
    const base = box.value; mic.classList.add('rec');
    nativeRec = await P.addListener('partialResults', (d) => { const t = d.matches?.[0] || ''; box.value = (base ? base + ' ' : '') + t; grow(); updateSend(); });
    const stopL = await P.addListener('listeningState', (d) => { if (d.status === 'stopped') { mic.classList.remove('rec'); nativeRec?.remove(); stopL.remove(); nativeRec = null; } });
    await P.start({ language: navigator.language || 'en-US', partialResults: true, popup: false });
  } catch (e) { mic.classList.remove('rec'); nativeRec?.remove?.(); nativeRec = null; toast('Voice: ' + (e.message || e)); }
}
$('#micBtn').onclick = () => {
  const P = plugin('SpeechRecognition'); if (P) return nativeMic(P);
  const SR = globalThis.SpeechRecognition || globalThis.webkitSpeechRecognition;
  if (!SR) return toast('Voice needs the newest app version. For now, use the microphone key on your keyboard.');
  if (rec) { rec.stop(); return; }
  rec = new SR(); rec.interimResults = true; rec.lang = navigator.language || 'en-US';
  const base = box.value; $('#micBtn').classList.add('rec');
  rec.onresult = (e) => { box.value = (base ? base + ' ' : '') + [...e.results].map((r) => r[0].transcript).join(' '); grow(); updateSend(); };
  rec.onend = rec.onerror = () => { rec = null; $('#micBtn').classList.remove('rec'); };
  try { rec.start(); } catch { rec = null; $('#micBtn').classList.remove('rec'); }
};

/* ---------- live pieces of a reply ---------- */
function addNote(parent, text) {
  const n = document.createElement('div'); n.className = 'note';
  n.innerHTML = '<svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.6-5.9M20 4v5h-5"/></svg><span></span>'; $('span', n).textContent = text; parent.append(n); return n;
}
// a note sits above the steps of the reply it belongs to
function noteBefore(msg, sb, text) { const n = addNote(document.createDocumentFragment(), text); msg.insertBefore(n, sb.el); return n; }
function stepsBox() {
  const el = document.createElement('div'); el.className = 'steps working';
  el.innerHTML = `<button class="sg"><span class="ico"></span><span class="lbl"></span>${ic('chev', 'chev')}</button><div class="sl"><div></div></div>`;
  const o = { el, rows: $('.sl>div', el), byId: new Map(), list: [], n: 0,
    kind(k, label) { $('.ico', el).innerHTML = loader(k, 20); $('.lbl', el).textContent = label; },
    add(id, html) { $$('.st', el).forEach((x) => x.classList.add('done')); const r = document.createElement('div'); r.className = 'st'; r.innerHTML = `<i class="s"></i><span>${html}</span>`; o.rows.append(r); o.byId.set(id, r); o.list.push({ html }); o.n++; return r; },
    update(id, html) { const r = o.byId.get(id); if (r) { $('span', r).innerHTML = html; const i = [...o.rows.children].indexOf(r); if (o.list[i]) o.list[i].html = html; } },
    finish(stopped) {
      el.classList.remove('working'); $$('.st', el).forEach((r) => r.classList.add('done'));
      o.summary = o.n ? (stopped ? 'Stopped · ' : '') + o.n + (o.n === 1 ? ' step' : ' steps') : (stopped ? 'Stopped' : 'Thought about it');
      $('.ico', el).innerHTML = ic('check'); $('.lbl', el).textContent = o.summary; setTimeout(() => el.classList.add('collapsed'), 350);
    } };
  $('.sg', el).onclick = () => el.classList.toggle('collapsed');
  return o;
}
async function permCard(msg, title, detail, signal) {
  const p = document.createElement('div'); p.className = 'perm';
  p.innerHTML = `<div class="ph">${loader('wait', 18)}<span></span></div><pre></pre><div class="pb"><button class="btn" data-a="deny">Deny</button><button class="btn pri" data-a="allow">Allow</button></div>`;
  $('.ph span', p).textContent = title; $('pre', p).textContent = detail; msg.append(p); scrollDown();
  const ans = await new Promise((res) => { signal?.addEventListener('abort', () => res('stop'), { once: true }); $$('button', p).forEach((b) => (b.onclick = () => res(b.dataset.a))); });
  if (ans === 'stop') { p.remove(); return 'stop'; }
  p.classList.add('done'); $('.ph', p).innerHTML = '<span></span>'; $('.ph span', p).textContent = (ans === 'allow' ? 'Allowed: ' : 'Denied: ') + detail.split('\n').join(' · ');
  return ans;
}
function addFiles(el, files, chat) {
  const wrap = document.createElement('div'); wrap.className = 'files';
  for (const f of files) {
    const b = document.createElement('button'); b.className = 'art';
    const ext = (f.name.split('.').pop() || 'file').slice(0, 4).toUpperCase();
    b.innerHTML = `<span class="ext">${esc(ext)}</span><span><b>${esc(f.name)}</b><small>${f.size ? Math.max(1, Math.round(f.size / 1024)) + ' KB · ' : ''}Tap to open</small></span>`;
    b.onclick = () => openFile(f, chat);
    wrap.append(b);
  }
  el.append(wrap);
}
async function openFile(f, chat) {
  openSheet(f.name, `<div class="sh-p">Loading…</div>`);
  try {
    const r = await ag.downloadOutput(S.keys.claude, f.id); const blob = await r.blob(); const ext = (f.name.split('.').pop() || '').toLowerCase();
    const body = $('#shBody'); body.innerHTML = '';
    if (['html', 'htm'].includes(ext)) {
      const fr = document.createElement('iframe'); fr.className = 'preview'; fr.setAttribute('sandbox', 'allow-scripts'); fr.srcdoc = await blob.text(); body.append(fr);
    } else if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].includes(ext) || blob.type.startsWith('image/')) {
      const im = document.createElement('img'); im.className = 'preview-img'; im.src = URL.createObjectURL(blob); body.append(im);
    } else {
      const pre = document.createElement('pre'); pre.className = 'preview-txt'; pre.textContent = (await blob.text()).slice(0, 60000); body.append(pre);
    }
    const act = document.createElement('div'); act.className = 'sh-act';
    if (navigator.canShare?.({ files: [new File([blob], f.name)] })) {
      const s = document.createElement('button'); s.className = 'btn pri'; s.textContent = 'Share or save';
      s.onclick = () => navigator.share({ files: [new File([blob], f.name, { type: blob.type })] }).catch(() => {}); act.append(s);
    }
    const t = document.createElement('button'); t.className = 'btn'; t.textContent = 'Copy text';
    t.onclick = async () => { try { await navigator.clipboard.writeText(await blob.text()); toast('Copied'); } catch { toast("Couldn't copy"); } }; act.append(t);
    body.append(act);
  } catch (e) { $('#shBody').innerHTML = `<p class="sh-p">${esc(e.message || "Couldn't open this file.")}</p>`; }
}

/* ---------- phone tools ---------- */
const phoneEnv = () => ({ calendar: plugin('CapacitorCalendar'), abil: S.st.abil });
const toolTitle = { list_calendar_events: 'Check your calendar', add_calendar_event: 'Add to your calendar', add_reminder: 'Add a reminder' };
function toolDetail(name, i = {}) {
  const when = (s) => { const d = new Date(s); return Number.isNaN(+d) ? s : d.toLocaleString([], { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); };
  if (name === 'add_calendar_event') return `${i.title || 'Event'}\n${i.start ? when(i.start) : ''}${i.end ? ' to ' + new Date(i.end).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : ''}${i.location ? '\n' + i.location : ''}`.trim();
  if (name === 'add_reminder') return `${i.title || 'Reminder'}${i.due ? '\n' + when(i.due) : ''}`;
  return 'Look at the next few days';
}
// one place that asks first (when asked to), runs the tool, and writes the log
async function runPhoneTool(msg, name, input, signal) {
  if (WRITE_TOOLS.has(name) && S.st.askPhone) {
    const a = await permCard(msg, 'Allow this on your phone?', `${toolTitle[name]}\n${toolDetail(name, input)}`, signal);
    if (a === 'stop') throw new DOMException('Stopped', 'AbortError');
    if (a !== 'allow') return { error: 'The user declined this.' };
  }
  const out = await execPhoneTool(name, input, phoneEnv());
  if (!out.error && WRITE_TOOLS.has(name)) { S.log.unshift({ t: `${toolTitle[name]}: ${(input.title || '').slice(0, 60)}`, w: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) }); store.set('sl.log', S.log.slice(0, 30)); }
  return out;
}

/* ---------- one turn ---------- */
const chatSystem = (web) => `You are Shivo Labs AI, an assistant on the user's phone. They may be away from any computer, so answer directly and briefly, in plain language.${web ? ' You can search the web.' : ''} You can read and add to their calendar and reminders with tools; those ask the user first. Never say you did something unless a tool confirmed it. ${contextLine()}`;
const stepLabel = { bash: 'Ran a command', write: 'Wrote a file', edit: 'Edited a file', read: 'Read a file', glob: 'Looked for files', grep: 'Searched files', web_search: 'Searched the web', web_fetch: 'Read a page', list_calendar_events: 'Checked your calendar', add_calendar_event: 'Added to your calendar', add_reminder: 'Added a reminder' };
const stepKind = { bash: 'run', write: 'write', edit: 'edit', read: 'read', glob: 'search', grep: 'search', web_search: 'web', web_fetch: 'web' };
const stepDetail = (n, i = {}) => i.command ? String(i.command).split('\n')[0].slice(0, 70) : i.file_path || i.path || i.pattern || i.query || i.url || i.title || '';

function failText(e) { return e.message || 'Something went wrong. Try again.'; }
async function send(text) {
  text = String(text || '').trim();
  if (!text || S.run || !canUse()) return;
  box.value = ''; grow();
  let c = S.cur; if (!c) { c = newChat(); S.chats.unshift(c); S.cur = c; }
  if (!c.ui.length) { c.title = text.length > 34 ? text.slice(0, 32).trim() + '…' : text; msgsEl.innerHTML = ''; }
  renderChats();
  const u = document.createElement('div'); u.className = 'm u'; u.innerHTML = `<div>${esc(text)}</div>`; msgsEl.append(u);
  c.ui.push({ r: 'u', t: text }); c.at = Date.now();
  const a = { r: 'a', t: '', steps: [], notes: [], files: [] }; c.ui.push(a);
  const msg = document.createElement('div'); msg.className = 'm a'; msgsEl.append(msg);
  const run = (S.run = { ctl: new AbortController(), chat: c }); updateSend();
  const sb = stepsBox(); msg.append(sb.el); sb.kind('think', 'Thinking…'); scrollDown();
  let txt = null, acc = '', brk = false;
  const stream = (t, whole) => {
    if (!txt) { txt = document.createElement('div'); txt.className = 'txt caret'; msg.append(txt); }
    acc += ((whole || brk) && acc ? '\n\n' : '') + t; brk = false; a.t = acc; txt.innerHTML = md(acc); scrollDown(); saveSoon(c);
  };
  const step = (id, kind, label, detail) => {
    brk = true;
    const html = `${esc(label)}${detail ? ` <code>${esc(detail)}</code>` : ''}`;
    if (sb.byId.has(id)) sb.update(id, html); else sb.add(id, html);
    sb.kind(kind, label); scrollDown();
  };
  const task = S.st.workspace === 'cloud' && hasClaude();
  try {
    if (task) await runTaskTurn({ c, a, msg, sb, run, text, stream, step });
    else if (isG()) await runGeminiTurn({ c, a, msg, sb, run, text, stream, step });
    else await runClaudeTurn({ c, a, msg, sb, run, text, stream, step });
    finishTurn(c, a, sb, false);
  } catch (e) {
    if (run.detached) { sb.finish(false); a.steps = sb.list; a.sum = sb.summary; }
    else if (run.ctl.signal.aborted || e.name === 'AbortError') { finishTurn(c, a, sb, true); }
    else { sb.finish(false); const er = document.createElement('div'); er.className = 'note err'; er.innerHTML = '<span></span>'; $('span', er).textContent = failText(e); msg.append(er); a.t = (a.t ? a.t + '\n\n' : '') + '⚠️ ' + failText(e); a.steps = sb.list; a.sum = sb.summary; }
  } finally {
    if (txt) txt.classList.remove('caret');
    S.run = null; saveChat(c); updateSend(); renderTasks(); paintPill();
  }
}
function finishTurn(c, a, sb, stopped) { sb.finish(stopped); a.steps = sb.list; a.sum = sb.summary; if (!a.t && !stopped && !a.files?.length) a.t = '(No text came back.)'; }
function stopRun() {
  const r = S.run; if (!r) return;
  r.ctl.abort();
  const c = r.chat;
  if (c.session?.id && hasClaude()) ag.interrupt(S.keys.claude, c.session.id).catch(() => {});
}

async function runClaudeTurn({ c, a, msg, sb, run, text, stream, step }) {
  const model = MODELS[S.st.model]?.id || MODELS.sonnet.id;
  c.history.push({ role: 'user', content: text });
  const tn = new Map();
  await runChat({ key: S.keys.claude, model, system: chatSystem(true), history: c.history, phoneTools: PHONE_TOOLS, signal: run.ctl.signal,
    execTool: (n, i) => runPhoneTool(msg, n, i, run.ctl.signal),
    onText: (t) => stream(t), onThinking: () => sb.kind('think', 'Thinking…'),
    onStep: (s) => { if (s.kind === 'web') step(s.id, 'web', s.label, s.detail); else { tn.set(s.id, s.label); step(s.id, 'wait', toolTitle[s.label] || s.label, ''); } },
    onStepDone: (id, out) => { const n = tn.get(id); step(id, 'read', out?.error ? `Couldn't: ${(toolTitle[n] || n).toLowerCase()}` : (stepLabel[n] || n), ''); },
    onUsage: (u) => addSpend(costOf(model, u)) });
}
async function runGeminiTurn({ c, a, msg, sb, run, text, stream, step }) {
  c.history.push({ role: 'user', content: text });
  const tn = new Map();
  S.fell = null;
  const chain = chainFor(S.st.model);
  const res = await runGeminiChat({ key: S.keys.gemini, limits: S.limits, chain, system: chatSystem(false), history: c.history, phoneTools: PHONE_TOOLS, signal: run.ctl.signal,
    execTool: (n, i) => runPhoneTool(msg, n, i, run.ctl.signal),
    onText: (t) => stream(t), onThought: () => sb.kind('think', 'Thinking…'),
    onStep: (s) => { tn.set(s.id, s.label); step(s.id, 'wait', toolTitle[s.label] || s.label, ''); },
    onStepDone: (id, out) => { const n = tn.get(id); step(id, 'read', out?.error ? `Couldn't: ${(toolTitle[n] || n).toLowerCase()}` : (stepLabel[n] || n), ''); },
    onNotice: ({ from, to, why }) => {
      const t = `Switched to ${prettyGemini(to)}: ${prettyGemini(from)} ${({ busy: 'is overloaded at Google right now', gone: "isn't available to your key any more", big: "can't take a chat this big on the free tier" })[why] || 'has used its free requests for today'}`;
      a.notes.push(t); noteBefore(msg, sb, t); S.fell = to; paintChips(); toast(t);
    },
    onWait: (m, sec, kind) => sb.kind('wait', kind === 'check' ? `Gemini refused this; waiting ${sec}s to see why…` : `Pacing for Gemini's per-minute limit (${sec}s)…`) });
  if (res?.used && res.used !== chain[0]) { S.fell = res.used; paintChips(); }
}

/* ---------- cloud tasks ---------- */
const TASK_PREFIX = (mode) => (mode === 'plan' ? 'PLAN ONLY: look at what is needed and write a short step-by-step plan. Do not create or change anything.\n\n' : '');
async function runTaskTurn({ c, a, msg, sb, run, text, stream, step }) {
  const key = S.keys.claude, modelKey = isG() ? 'sonnet' : S.st.model, modelId = MODELS[modelKey].id;
  const ask = S.st.mode === 'ask';
  c.kind = 'task';
  const noteT = `Running in the cloud. You can lock your phone, it keeps working. Cap ${money(S.st.cap)}.`; if (!c.session) { a.notes.push(noteT); noteBefore(msg, sb, noteT); }
  sb.kind('think', 'Getting a cloud workspace ready…');
  if (!c.session) {
    const envId = await ag.ensureEnvironment(key, store);
    const agent = await ag.ensureAgent(key, modelId, ask, store, PHONE_TOOLS);
    const id = await ag.createSession(key, { agent, environmentId: envId, title: c.title, capDollars: S.st.cap });
    c.session = { id, seen: [], model: modelId, cost: 0, status: 'running' };
  }
  c.session.status = 'running'; saveChat(c); renderTasks();
  const seen = new Set(c.session.seen); run.seen = seen;
  await attach({ c, a, msg, sb, run, seen, stream, step, message: TASK_PREFIX(S.st.mode) + `[${contextLine()}]\n\n` + text });
}
// Follow the session; used for a new turn and for coming back after the phone was locked.
async function attach({ c, a, msg, sb, run, seen, stream, step, message }) {
  const key = S.keys.claude;
  const handlers = {
    onText: (t) => { stream(t, true); sb.kind('write', 'Writing…'); },
    onStep: (s) => { const k = stepKind[s.name] || (s.phone ? 'wait' : 'run'); step(s.id, k, stepLabel[s.name] || s.name, stepDetail(s.name, s.input)); },
    onStepResult: (id, r) => { if (!r.ok) { const row = sb.byId.get(id); if (row) row.classList.add('bad'); } },
    confirm: async (name, input) => { const ans = await permCard(msg, 'Allow this in the cloud?', `${stepLabel[name] || name}\n${stepDetail(name, input)}`, run.ctl.signal); return ans === 'allow'; },
    execCustom: (name, input) => runPhoneTool(msg, name, input, run.ctl.signal),
    onUsage: (u) => { const cost = ag.sessionCost(c.session.model, u); const d = cost - (c.session.cost || 0); if (d > 0) { c.session.cost = cost; addSpend(d); } },
    onStatus: (s) => { if (s === 'waiting') sb.kind('wait', 'Waiting for you…'); },
  };
  // keep the seen-set saved as events arrive, so a locked phone can pick up exactly where it left off
  const tick = setInterval(() => { c.session.seen = [...seen]; saveChat(c); }, 1500);
  let res;
  try { res = await ag.followSession({ key, sessionId: c.session.id, message, seen, handlers, signal: run.ctl.signal }); }
  finally { clearInterval(tick); c.session.seen = [...seen]; }
  c.session.status = res.status === 'stopped' ? (run.detached ? 'running' : 'stopped') : res.status === 'error' ? 'error' : res.status === 'budget' ? 'budget' : 'done';
  if (res.status === 'error') throw new Error(res.error || 'The task hit an error.');
  if (res.status === 'budget') { const t = `This task reached its ${money(S.st.cap)} cap and paused. Raise the cap in Settings to continue.`; a.notes.push(t); noteBefore(msg, sb, t); }
  if (res.status !== 'stopped') await loadOutputs(c, a, msg);
}
async function loadOutputs(c, a, msg) {
  let files = [];
  for (let i = 0; i < 6 && !files.length; i++) { try { files = await ag.listOutputs(S.keys.claude, c.session.id); } catch {} if (!files.length) await sleepMs(FAST ? 100 : 2000); }
  const known = new Set((c.files || []).map((f) => f.id)); const fresh = files.filter((f) => !known.has(f.id));
  c.files = [...(c.files || []), ...fresh];
  if (fresh.length) { a.files = fresh; addFiles(msg, fresh, c); scrollDown(); }
}
async function resumeTask(c, fromVisibility) {
  if (S.run || !c.session?.id || !hasClaude() || !S.online) return;
  // rebuild the screen from what we saved, then continue with whatever happened while away
  if (S.cur !== c) { S.cur = c; paintChips(); }
  renderMsgs();
  let a = c.ui.at(-1); if (!a || a.r !== 'a') { a = { r: 'a', t: '', steps: [], notes: [], files: [] }; c.ui.push(a); }
  const msg = document.createElement('div'); msg.className = 'm a'; msgsEl.append(msg);
  const run = (S.run = { ctl: new AbortController(), chat: c }); updateSend();
  const sb = stepsBox(); msg.append(sb.el); sb.kind('think', 'Catching up with your task…');
  let txt = null, acc = a.t || '';
  const stream = (t, whole) => { if (!txt) { txt = document.createElement('div'); txt.className = 'txt caret'; msg.append(txt); } acc += (whole && acc ? '\n\n' : '') + t; a.t = acc; txt.innerHTML = md(acc); scrollDown(); saveSoon(c); };
  const step = (id, kind, label, detail) => { const html = `${esc(label)}${detail ? ` <code>${esc(detail)}</code>` : ''}`; if (sb.byId.has(id)) sb.update(id, html); else sb.add(id, html); sb.kind(kind, label); };
  try {
    const seen = new Set(c.session.seen); run.seen = seen;
    await attach({ c, a, msg, sb, run, seen, stream, step });
    a.steps = [...(a.steps || []), ...sb.list]; sb.finish(false); a.sum = (a.steps.length) + ' steps';
  } catch (e) { if (!(run.ctl.signal.aborted || e.name === 'AbortError')) toast(failText(e)); sb.finish(true); }
  finally { if (txt) txt.classList.remove('caret'); S.run = null; saveChat(c); updateSend(); renderTasks(); }
}

/* ---------- tasks tab ---------- */
const ago = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'Just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' d ago'; };
function renderTasks() {
  const tasks = S.chats.filter((c) => c.session).sort((a, b) => b.at - a.at);
  const running = tasks.filter((c) => c.session.status === 'running').length;
  taskBadgeEl().hidden = !running; $('#menuBtn')?.classList.toggle('busy', !!running);
  const lab = { running: ['Running', 'run'], done: ['Done', ''], stopped: ['Stopped', ''], budget: ['Paused at cap', 'bad'], error: ['Error', 'bad'] };
  $('#tasksBody').innerHTML = tasks.length ? `<section class="card"><div class="head"><h2>Cloud <span>tasks</span></h2></div>${tasks.map((c) => {
    const [t, k] = lab[c.session.status] || ['Done', ''];
    return `<button class="trow" data-id="${c.id}"><span class="tt"><b>${esc(c.title)}</b><small>${ago(c.at)} · ${money(c.session.cost || 0)}${c.files?.length ? ' · ' + c.files.length + ' file' + (c.files.length > 1 ? 's' : '') : ''}</small></span><span class="st-pill ${k}">${t}</span></button>`;
  }).join('')}</section><p class="foot">Tasks run on Anthropic's servers, so they keep going when your phone is locked.</p>`
    : `<section class="card"><div class="head"><h2>Cloud <span>tasks</span></h2></div><p class="emptyt">Nothing yet. In Chat, choose <b>Cloud task</b> and describe what you want built, fixed or written.</p></section>`;
  $$('.trow', $('#tasksBody')).forEach((b) => (b.onclick = () => { if (S.run) return toast('Wait for the current reply, or stop it first'); S.cur = S.chats.find((c) => c.id === b.dataset.id); renderMsgs(); switchApp('ai'); }));
}

/* ---------- phone tab ---------- */
async function accessState() {
  const cal = plugin('CapacitorCalendar'); if (!cal) return null;
  try { const r = await cal.checkAllPermissions(); return r?.result || null; } catch { return null; }
}
async function renderPhone() {
  const native = !!plugin('CapacitorCalendar');
  const sw = (on) => `<i class="sw ${on ? 'on' : ''}"></i>`;
  $('#phoneBody').innerHTML = `
    <section class="card"><div class="head"><h2>What it can do <span>on this phone</span></h2></div>
      <button class="row" data-ab="cal"><span class="t"><b>Calendar</b><small>Read your events and add new ones</small></span>${sw(S.st.abil.cal)}</button>
      <button class="row" data-ab="rem"><span class="t"><b>Reminders</b><small>Add reminders to the Reminders app</small></span>${sw(S.st.abil.rem)}</button>
      <button class="row" id="askRow"><span class="t"><b>Ask me before each change</b><small>Recommended. You see what it will do and tap Allow.</small></span>${sw(S.st.askPhone)}</button>
    </section>
    <section class="card"><div class="head"><h2>Allow <span>access</span></h2></div>
      <p class="sh-p">${native ? 'iPhone asks once. You can change this any time in Settings, Shivo Labs.' : 'Calendar and reminders only work inside the installed phone app.'}</p>
      <button class="btn ${native ? '' : 'dis'}" id="askAccess" ${native ? '' : 'disabled'}>Allow calendar and reminders</button>
    </section>
    <section class="card"><div class="head"><h2>Recent <span>actions</span></h2></div>
      ${S.log.length ? S.log.slice(0, 12).map((l) => `<div class="row" style="pointer-events:none"><span class="t"><b>${esc(l.t)}</b><small>${esc(l.w)}</small></span></div>`).join('') : '<p class="emptyt">Nothing yet.</p>'}
    </section>
    <p class="foot">Everything it does on this phone is listed here. Only what you send to a model leaves the phone.</p>`;
  const root = $('#phoneBody');
  $$('[data-ab]', root).forEach((b) => (b.onclick = () => { const k = b.dataset.ab; S.st.abil[k] = !S.st.abil[k]; saveSettings(); $('.sw', b).classList.toggle('on', S.st.abil[k]); }));
  $('#askRow', root).onclick = (e) => { S.st.askPhone = !S.st.askPhone; saveSettings(); $('.sw', e.currentTarget).classList.toggle('on', S.st.askPhone); };
  $('#askAccess', root).onclick = async () => {
    const cal = plugin('CapacitorCalendar'); if (!cal) return;
    try { const a = await cal.requestFullCalendarAccess(); const r = await cal.requestFullRemindersAccess(); toast(a.result === 'granted' && r.result === 'granted' ? 'Calendar and reminders allowed' : a.result === 'granted' ? 'Calendar allowed. Reminders were not.' : 'Not allowed. You can change it in iPhone Settings.'); }
    catch (e) { toast(e.message || "Couldn't ask for access"); }
  };
}

/* ---------- beam: files between this phone and the PC ---------- */
const BM = { pc: '', items: [], busy: '', err: '' };
async function renderBeam(check) {
  beam.setHost(S.st.beamHost);
  const root = $('#beamBody'); if (!root) return;
  const n = BM.items.length, ph = BM.items.filter((x) => x.kind === 'media').length;
  root.innerHTML = `
    <section class="card"><div class="head"><h2>${BM.pc ? esc(BM.pc) : 'Your PC'} <span>${BM.pc ? 'connected' : BM.err ? 'not found' : 'looking…'}</span></h2></div>
      ${BM.err ? `<p class="sh-p">${esc(BM.err)}</p>` : ''}
      ${BM.busy ? `<p class="sh-p"><span class="bm-ld">${loader('wait', 16)}</span> ${esc(BM.busy)}</p>` : ''}
      <label class="btn pri bm-send ${BM.busy ? 'dis' : ''}">Send photos or files to the PC<input type="file" id="bmPick" multiple hidden ${BM.busy ? 'disabled' : ''}></label>
      <button class="btn" id="bmGet" style="margin-top:10px" ${BM.busy || !n ? 'disabled' : ''}>${n ? `Save ${n} from the PC` : 'Nothing waiting on the PC'}</button>
      ${n ? `<p class="hint">${ph ? `${ph} photo${ph > 1 ? 's' : ''} or video${ph > 1 ? 's' : ''} go to Photos. ` : ''}${n - ph ? 'Other files go to Files, On My iPhone, Shivo Labs, Beam.' : ''}</p>` : ''}
      <button class="btn" id="bmRetry" style="margin-top:10px">Check again</button>
    </section>
    <section class="card"><div class="head"><h2>Share <span>Beam</span></h2></div>
      <p class="sh-p">Let someone get Beam for their PC: they scan this, or you send them the link.</p>
      <div class="bm-qr" id="bmQr"></div>
      <button class="btn" id="bmShare">Send the link</button>
    </section>
    <section class="card"><div class="head"><h2>PC <span>address</span></h2></div>
      <p class="sh-p">Leave as beam.local. Only change it if Beam on the PC shows a different address.</p>
      <input class="field" id="bmHost" value="${esc(S.st.beamHost || 'beam.local')}" autocapitalize="off" autocorrect="off" spellcheck="false">
    </section>
    <p class="foot">Beam works on the same Wi-Fi (or your iPhone's hotspot). Files go straight to your PC, never online.</p>`;
  const q = qrcode(0, 'M'); q.addData(beam.SHARE_URL); q.make(); $('#bmQr', root).innerHTML = q.createSvgTag({ cellSize: 5, margin: 2, scalable: true });
  $('#bmShare', root).onclick = async () => {
    const S2 = plugin('Share');
    try { if (S2) await S2.share({ title: 'Beam', text: 'Send files between your iPhone and PC:', url: beam.SHARE_URL }); else if (navigator.share) await navigator.share({ url: beam.SHARE_URL }); else { await navigator.clipboard.writeText(beam.SHARE_URL); toast('Link copied'); } } catch {}
  };
  $('#bmHost', root).onchange = (e) => { S.st.beamHost = e.target.value.trim() || 'beam.local'; saveSettings(); BM.pc = ''; renderBeam(true); };
  $('#bmRetry', root).onclick = () => renderBeam(true);
  $('#bmPick', root).onchange = async (e) => {
    const files = [...e.target.files]; if (!files.length) return;
    try { await beam.send(files, (i, t, name) => { BM.busy = `Sending ${i + 1} of ${t}: ${name}`; renderBeam(); }); toast(`Sent ${files.length} to the PC`); }
    catch (err) { toast(err.message); }
    BM.busy = ''; renderBeam(true);
  };
  $('#bmGet', root).onclick = async () => {
    try { const r = await beam.receiveAll((i, t, name) => { BM.busy = `Saving ${i + 1} of ${t}: ${name}`; renderBeam(); }); toast(`Saved ${r.done}${r.photos ? `, ${r.photos} in Photos` : ''}`); }
    catch (err) { toast(err.message); }
    BM.busy = ''; renderBeam(true);
  };
  if (check && !BM.busy) {
    try { BM.pc = await beam.ping(); BM.items = await beam.waiting(); BM.err = ''; }
    catch (err) { BM.pc = ''; BM.items = []; BM.err = err.message; }
    if (S.app === 'beam') renderBeam();
  }
}

/* ---------- settings ---------- */
function keySheet(which) {
  const P = which === 'claude'
    ? { name: 'Claude', ph: 'sk-ant-…', intro: "Paste your API key from the Claude Console (platform.claude.com). It is checked with Anthropic, then kept on this phone. It never goes anywhere else.", tip: 'Tip: make a separate key for your phone in its own Console workspace with a spend limit, so a lost phone can never cost more than that.' }
    : { name: 'Gemini', ph: 'Paste your key', intro: 'Paste the free key from Google AI Studio. It is checked with Google, then kept on this phone. It never goes anywhere else.', tip: 'On the free tier Google may use what you send to improve its products, so keep private work on Claude.' };
  openSheet(`${S.keys[which] ? 'Replace' : 'Add'} your ${P.name} key`, `<p class="sh-p">${P.intro}</p>
    <input class="field" id="gkey" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="${P.ph}">
    <div class="hint" id="gmsg">${P.tip}</div><button class="btn pri" id="gsave" disabled>Check &amp; save</button>`, (b) => {
    const inp = $('#gkey', b), btn = $('#gsave', b), m = $('#gmsg', b);
    inp.oninput = () => { btn.disabled = inp.value.trim().length < 12; m.className = 'hint'; };
    btn.onclick = async () => {
      const k = inp.value.trim(); btn.disabled = true; m.className = 'hint'; m.textContent = `Checking with ${which === 'claude' ? 'Anthropic' : 'Google'}…`;
      try {
        if (which === 'claude') { const r = await checkKey(k); if (!r.ok) throw new Error(r.error); }
        else { const models = await listGeminiModels(k); S.gm = { models, chain: defaultGeminiChain(models) }; store.set('sl.gm', S.gm); }
      } catch (e) { m.className = 'hint err'; m.textContent = e.message; btn.disabled = false; return; }
      S.keys[which] = k; saveKeys(); normalizeModel(); m.textContent = 'Saved on this phone.';
      await sleepMs(500); closeSheet(); paintChips(); updateSend(); toast(`${P.name} added`);
    };
    setTimeout(() => inp.focus({ preventScroll: true }), 450);
  });
}
function providerSheet(which) {
  if (!S.keys[which]) return keySheet(which);
  const name = which === 'claude' ? 'Claude' : 'Gemini';
  openSheet(name, `<p class="sh-p">${which === 'claude' ? "Your Claude key is saved on this phone. Tasks run on Anthropic's servers, so they keep going when your phone locks." : 'A free Gemini key is saved on this phone, with automatic switching between models when one runs out.'}</p>
    <button class="row" id="pvChange"><span class="t"><b>Replace the key</b></span>${ic('chev')}</button>
    <button class="row danger" id="pvRemove"><span class="t"><b>Remove the key from this phone</b></span></button>`, (b) => {
    $('#pvChange', b).onclick = () => swapSheet(() => keySheet(which));
    $('#pvRemove', b).onclick = () => { S.keys[which] = ''; saveKeys(); normalizeModel(); paintChips(); updateSend(); closeSheet(); if (!hasClaude() && !hasGemini()) location.reload(); };
  });
}
$('#pcPill').onclick = () => {
  const capSeg = [0.5, 2, 5].map((v) => `<button data-c="${v}" class="${v === S.st.cap ? 'on' : ''}">$${v.toFixed(2).replace(/\.00$/, '')}</button>`).join('');
  openSheet('Settings', `
    <div class="sh-sub" style="margin-top:0">KEYS · STAY ON THIS PHONE</div>
    <button class="row" id="clRow"><span class="t"><b>Claude</b><small>${hasClaude() ? 'Key saved. Works anywhere.' : 'Not added yet'}</small></span>${ic('chev')}</button>
    <button class="row" id="gemRow"><span class="t"><b>Gemini</b><small>${hasGemini() ? 'Free key saved.' : 'Not added yet. Free from Google.'}</small></span>${ic('chev')}</button>
    <div class="sh-sub">SPENDING</div>
    <div class="row" style="pointer-events:none"><span class="t"><b>This month</b><small>An estimate from token use. Gemini free-tier use costs nothing.</small></span><b>${money(monthSpend())}</b></div>
    <div class="row"><span class="t"><b>Cap per task</b><small>A cloud task stops by itself at this amount.</small></span><div class="seg" id="capSeg">${capSeg}</div></div>
    <div class="sh-sub">LOOK</div>
    <div class="row"><span class="t"><b>Appearance</b></span><div class="seg" id="themeSeg">${['auto', 'light', 'dark'].map((t) => `<button data-t="${t}" class="${t === S.st.theme ? 'on' : ''}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div></div>
    <div class="sh-sub">ABOUT</div>
    <div class="row" style="pointer-events:none"><span class="t"><b>Shivo Labs</b><small>Version <span id="verTxt">…</span> · updates itself · your keys and chats stay on this phone</small></span></div>
    <button class="row" id="updRow"><span class="t"><b>Check for updates</b><small id="updTxt">Updates also arrive by themselves when you open the app.</small></span>${ic('chev')}</button>`, (b) => {
    myVersion().then((v) => { const e = $('#verTxt', b); if (e) e.textContent = v; });
    $('#updRow', b).onclick = async () => {
      const t = $('#updTxt', b), say = (m) => { t.textContent = m; };
      say(await checkForUpdate({ force: true, isIdle: () => !S.run, onStep: say, onApplied: () => toast('Updating Shivo Labs…') }));
    };
    $$('#themeSeg button', b).forEach((x) => (x.onclick = () => { S.st.theme = x.dataset.t; saveSettings(); applyTheme(); $$('#themeSeg button', b).forEach((y) => y.classList.toggle('on', y === x)); }));
    $$('#capSeg button', b).forEach((x) => (x.onclick = () => { S.st.cap = Number(x.dataset.c); saveSettings(); $$('#capSeg button', b).forEach((y) => y.classList.toggle('on', y === x)); }));
    $('#clRow', b).onclick = () => swapSheet(() => providerSheet('claude'));
    $('#gemRow', b).onclick = () => swapSheet(() => providerSheet('gemini'));
  });
};

boot().catch((e) => { console.error(e); $('#splash').classList.add('out'); document.body.insertAdjacentHTML('beforeend', `<pre style="position:fixed;inset:0;z-index:99;background:#fff;color:#900;padding:20px;white-space:pre-wrap">Shivo Labs could not start:\n${esc(e.stack || e.message || e)}</pre>`); });
globalThis.__shivo = { S, send };   // for tests
