// The native camera engine: the ShivoCamera add-on (phone/native/shivo-native, ShivoCamera.swift), in builds that
// have it. The real camera through AVFoundation: focus and exposure points, manual ISO, shutter, white balance and
// focus, lenses (13 mm ultra-wide, 26 mm main, and 28/35/50 mm taken from the 48 MP sensor; 52 mm is the sensor's
// own 2x), RAW (DNG) with a developed HEIF/JPEG, up to 48 MP; newer builds also video, stack, night and depth.
// Its picture is drawn by the add-on behind the page: sharp inside the frame, frosted outside. Looks go to it as
// a colour table (lut.js) plus grain, glow and vignette. Older builds simply don't list the newer things in caps,
// so the screen doesn't offer them.
// Returns null when this build has no camera add-on, so the screen uses the web engine.
import { lutFor } from './lut.js';

export async function nativeEngine({ plugin, onHist, onMeter, onProgress, onPress, onControl }) {
  const P = plugin('ShivoCamera'); if (!P) return null;
  let info; try { info = await P.info(); } catch { return null; }
  if (!info?.ok) return null;
  let on = false, lastLut = '', histOn = false;
  P.addListener?.('hist', (h) => { if (histOn) onHist?.([h.r, h.g, h.b, h.l]); });
  P.addListener?.('meter', (m) => onMeter?.(m));
  P.addListener?.('progress', (p) => onProgress?.(p.p));
  P.addListener?.('press', () => onPress?.());            // a side button (volume or Camera Control) pressed: the shutter
  P.addListener?.('control', (c) => onControl?.(c));      // Camera Control: a look or the depth picked on the button
  let onCaptured = null;   // newer builds say when the picture is taken, before it is developed and saved
  P.addListener?.('captured', () => { const f = onCaptured; onCaptured = null; f?.(); });
  const call = (fn, o) => P[fn](o).catch((e) => console.warn('camera', fn, e?.message || e));
  const src = (p) => (p && globalThis.Capacitor?.convertFileSrc ? globalThis.Capacitor.convertFileSrc(p) : p);
  const shot = (r) => (r ? { url: src(r.preview), src: src(r.file), uri: r.file, video: !!r.video, w: r.width, h: r.height, raw: !!r.raw, saved: !!r.saved, kept: !!r.kept, error: r.error, at: Date.now() } : null);
  const newer = !!info.caps?.style;   // builds with video, stack, night, depth and the frosted outside
  return {
    kind: 'native',
    available: () => true,
    running: () => on,
    caps: () => info.caps,   // { wb, iso, shutter, focus, raw, formats, mp, depth, modes, tools, flash, k4, meter, style }
    lenses: (f) => (f === 'front' ? info.front : info.back),   // [{ mm, kind: 'optical'|'crop'|'native2x', zoom }]
    digitalZoom: () => 1,
    mpFor: (st) => { const l = (st.facing === 'front' ? info.front : info.back).find((x) => x.mm === st.mm); return l?.mp ? Math.min(l.mp, +st.mp || 12) : st.mp; },
    async start(o) {
      const r = await P.start({ facing: o.facing, mm: o.mm, mp: o.mp, mode: o.mode, k4: !!o.k4 });
      if (r?.info) info = r.info;
      on = true; document.documentElement.classList.add('cam-native');   // the page turns see-through so the picture behind it shows
    },
    async stop() { on = false; document.documentElement.classList.remove('cam-native'); await call('stop', {}); },
    layout(f) { call('setFrame', { top: f.top, height: f.h, width: f.W, screen: f.H, inset: f.inset || 0, radius: f.radius || 0 }); },   // inset/radius: the framed viewfinder, drawn by the add-on
    setStyle(s) { if (newer) call('setStyle', s); },
    setControls(o) { if (info.caps?.controls) call('setControls', o); },   // what the Camera Control offers: looks, depth
    frameImage: async (o) => { if (!info.caps?.frames) return null; const r = await P.frameImage(o); return { file: r.file, url: src(r.file), w: r.width, h: r.height }; },
    setGlass(rects) { if (info.caps?.glass) call('setGlass', { rects }); },   // shapes the add-on blurs under (cards, buttons)
    setLook(v) {
      const t = lutFor(v), key = v.look.id + '|' + v.amount + '|' + (v.false ? 1 : 0);
      call('setLook', { lut: key === lastLut ? undefined : t.data, size: t.size, grain: v.look.grain * (v.grain ?? 1) * v.amount,
        vignette: v.look.vig * v.amount, glow: v.look.hal * v.amount, mirror: !!v.mirror, zebra: !!v.zebra, peak: !!v.peak });
      lastLut = key;
    },
    setTools(st) { histOn = !!st.hist; call('setTools', { hist: !!st.hist, stabilise: !!st.stab, sound: !!st.sound }); },
    setLens: (mm) => call('setLens', { mm }),
    setResolution: (mp) => call('setResolution', { mp }),
    setExposure: ({ iso, ss, ev }) => call('setExposure', { iso, ss, ev }),   // 0 = automatic
    setWB: ({ k, tint }) => call('setWhiteBalance', { k, tint }),
    setFocus: ({ pos }) => call('setFocus', { pos }),   // -1 = automatic, 0 near ... 1 far
    focusAt: ({ x, y }) => call('focusAt', { x, y }),   // share of the screen
    lock: (v) => call('lock', { on: !!v }),
    setDepth: (o) => call('setDepth', o),
    async setMode({ mode, k4 }) { if (!newer) return; const r = await P.setMode({ mode, k4: !!k4 }).catch(() => null); if (r?.info) info = r.info; },
    record: newer ? async ({ on: rec, turn, loc }) => {
      if (rec) { await P.record({ on: true, turn: turn || 0 }); return null; }
      return shot(await P.record({ on: false, ...(loc || {}) }));
    } : undefined,
    async shoot(st) {
      onCaptured = st.onCapture || null;
      const r = await P.shoot({ format: st.fmt, mp: +st.mp, aspect: st.aspect, flash: st.flash, turn: st.turn || 0, mode: st.mode, keep: !!st.keep, ...(st.loc || {}) });
      if (onCaptured) { onCaptured(); onCaptured = null; }
      return shot(r);
    },
  };
}
