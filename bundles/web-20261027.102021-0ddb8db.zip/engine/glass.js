// Real Liquid Glass on iPhone (iOS 26+): the bottom bar (tabs, search button, search box) and the round buttons are drawn by our
// native add-on (native/shivo-native) as floating glass views over the page, so they truly bend and reflect what's behind them.
// The bottom bar is placed by the add-on itself (ShivoDock.swift: fixed size, above the home indicator, riding on the keyboard);
// the page only says which tabs there are and hears taps and what is typed. The round buttons of each screen still sit where the
// page puts them (it measures its invisible web versions). Older iPhones and the preview keep the web versions.
import { plugin } from './native.js';

const N = () => plugin('ShivoNative');
let on = false, hidden = 0;

// Switched off on 23 Oct 2026 (the measured native pieces never matched the page and lagged it), back on the same day with the bottom
// bar placed by the add-on itself. Only an add-on that has the bar ("dock" in info) draws glass; an older one leaves the web bar.
const NATIVE_GLASS = false;   // off again (24 Oct 2026, Shivam's call): the native glass looked wrong on flat pages (white blob in light, black slab in dark); the page's own frosted bar, search button and round buttons show everywhere, as in the preview. The native bar code (ShivoDock.swift) stays in the add-on; true brings it back.
let dock = false;
export const glassDock = () => dock;

export async function startGlass({ tabs, buttons, onTab, onButton, onHold, onSearch }) {
  const P = N(); if (!P) return false;
  const clearNative = (P) => {   // take away any native glass an older version of the page left on screen (it survives an update)
    P.setTabs?.({ items: [], frame: null })?.catch?.(() => {});
    P.setButtons?.({ buttons: [] })?.catch?.(() => {});
    P.setDock?.({ items: [] })?.catch?.(() => {});
  };
  if (!NATIVE_GLASS) { clearNative(P); return false; }
  try { const i = await P.info(); if (!i.glass || !i.dock) { clearNative(P); return false; } } catch { return false; }
  on = true; dock = true;
  document.documentElement.classList.add('nglass');
  await P.addListener('tab', (e) => onTab(e.id));
  await P.addListener('button', (e) => onButton(e.id));
  if (onHold) await P.addListener('hold', onHold);
  if (onSearch) for (const k of ['Open', 'Query', 'Submit', 'Close']) await P.addListener('search' + k, (e) => onSearch[k.toLowerCase()]?.(e?.text ?? ''));
  const sync = () => syncGlass({ tabs, buttons });
  addEventListener('resize', () => setTimeout(sync, 60));
  sync();
  glassPark(false);   // the app is in: show what the start parked
  return true;
}

// The glass floats above the whole page, the logo screen included, and stays on the screen while the page restarts
// (an update). Park it at the start of every launch and while an update restarts; startGlass shows it once the app is in.
export function glassPark(park = true) {
  const P = N(); if (!P) return;
  P.setVisible({ tabs: !park && !hidden, buttons: !park && !hidden }).catch(() => {});
}

const box = (el) => { const r = el?.getBoundingClientRect(); return r && r.width ? { x: r.left, y: r.top, w: r.width, h: r.height } : null; };

// tabs(): { el, items, selected }; buttons(): [{ id, symbol }] for elements that are on screen now
// The glass is placed from the web elements' boxes, so it is only placed once nothing moves them: a bar still sliding or scaling
// (after the search box, when the bar comes back) gave the glass the wrong size and left it there. Fades (opacity, colours) don't
// move anything and are not waited for. Nothing is cleared meanwhile: the glass stays as it is until the new place is known.
const GEOMETRY = (a) => !/^(opacity|color|background|border|box-shadow|filter|visibility|outline)/.test(a.transitionProperty || '');
const moving = (el) => { const out = []; for (let e = el; e && e !== document.documentElement; e = e.parentElement) for (const a of e.getAnimations?.() || []) if (a.playState === 'running' && GEOMETRY(a)) out.push(a.finished); return out; };
export function syncGlass({ tabs, buttons }, tries = 0) {
  if (!on) return;
  const P = N(), t = tabs(), bs = buttons();
  const wait = bs.flatMap((x) => moving(document.getElementById(x.id)));
  if (wait.length && tries < 3) {   // asked again when it has settled (at most 0.9 s)
    Promise.race([Promise.allSettled(wait), new Promise((r) => setTimeout(r, 900))]).then(() => syncGlass({ tabs, buttons }, tries + 1));
    return;
  }
  P.setDock({ items: t.items, selected: t.selected }).catch(() => {});
  P.setButtons({ buttons: bs.filter((x) => x.id !== 'searchBtn').map((x) => ({ ...x, frame: box(document.getElementById(x.id)) })).filter((x) => x.frame) }).catch(() => {});
}

// the app's Light / Dark choice, for the glass and the system sheets (ShivoNative.setTheme; older builds don't have it)
export function glassTheme(theme) { try { N()?.setTheme?.({ theme })?.catch?.(() => {}); } catch {} }

export const selectGlassTab = (id) => on && N().selectTab({ id }).catch(() => {});
// open or close the search box in the native bar (it takes the keyboard itself)
export const glassSearch = (open) => { if (on) N().setSearch({ open }).catch(() => {}); };

// Sheets, the side panel and menus slide over the glass: hide it while any of them is open.
export function glassCover(cover) {
  if (!on) return;
  hidden = Math.max(0, hidden + (cover ? 1 : -1));
  N().setVisible({ tabs: !hidden, buttons: !hidden }).catch(() => {});
}

export const haptic = (style = 'light') => N()?.haptic({ style }).catch(() => {});
export const openURL = async (url) => { const P = N(); if (P) return (await P.openURL({ url })).opened; location.href = url; return true; };
