// The Shivo Browser's side panel (BROWSER-PLAN.md step 2, 23 Oct 2026): it slides in from the right edge over the page, with four
// tabs: Chat (send the page to a conversation), Notes (write, clip and read notes, which are files in Cloud's Notes folder),
// Cloud (save the page, see what is saved) and AI (ask about the page). This is its screen, drawn by the browser's own panel
// (ShivoBrowser.swift) as a small web page; it talks to the browser through one message channel, and the app answers (the data
// lives in the app: Cloud is locked there, and the AI key too). Colours follow the app's Light / Dark through the system.
// opts: { tabs: ['chat','notes','cloud','ai'] }, the ones this phone's pass includes.
export function panelHtml({ tabs = ['chat', 'notes', 'cloud', 'ai'] } = {}) {
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no"><style>
:root{--text:#141517;--muted:#6B6E73;--soft:rgba(20,21,23,.07);--line:rgba(20,21,23,.1);--sage:#4F7A5A;color-scheme:light dark}
@media(prefers-color-scheme:dark){:root{--text:#ECEDE9;--muted:#A0A2A7;--soft:rgba(255,255,255,.09);--line:rgba(255,255,255,.13);--sage:#7FB08B}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;height:100%;background:transparent;color:var(--text);font:16px -apple-system,system-ui,sans-serif;-webkit-text-size-adjust:100%}
body{display:flex;flex-direction:column;padding:max(14px,env(safe-area-inset-top)) 0 0}
header{display:flex;align-items:center;gap:6px;padding:0 12px 10px}
.tabs{flex:1;display:flex;gap:4px;padding:4px;border-radius:18px;background:var(--soft)}
.tabs button{flex:1;display:grid;justify-items:center;gap:2px;padding:7px 0 5px;border:0;border-radius:14px;background:none;color:var(--muted);font:600 10.5px -apple-system,sans-serif}
.tabs button svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.tabs button.on{background:var(--soft);color:var(--text);box-shadow:inset 0 0 0 .5px var(--line)}
.x{width:38px;height:38px;border:0;border-radius:50%;background:var(--soft);color:var(--text);display:grid;place-items:center}
.x svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round}
main{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:4px 14px max(18px,env(safe-area-inset-bottom))}
h4{margin:18px 2px 8px;font:600 13px -apple-system,sans-serif;color:var(--muted);letter-spacing:.02em}
.page{padding:12px 14px;border-radius:16px;background:var(--soft);font-size:14px;line-height:1.35}
.page b{display:block;font-size:15px;margin-bottom:2px;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.page span{color:var(--muted)}
.row{display:flex;align-items:center;gap:12px;width:100%;padding:13px 4px;border:0;border-top:1px solid var(--line);background:none;color:var(--text);text-align:left;font:16px -apple-system,sans-serif}
.row:first-of-type{border-top:0}
.row i{flex:none;width:36px;height:36px;border-radius:50%;background:var(--soft);display:grid;place-items:center;font:600 14px -apple-system,sans-serif;font-style:normal}
.row small{display:block;color:var(--muted);font-size:13px}
.row .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.row .ok{color:var(--sage);font-weight:600;font-size:13px}
.btns{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}
.btn{padding:11px 16px;border:0;border-radius:16px;background:var(--soft);color:var(--text);font:600 14.5px -apple-system,sans-serif}
.btn.pri{background:var(--text);color:var(--bg,#fff)}
@media(prefers-color-scheme:dark){.btn.pri{color:#141517}}
.btn:disabled{opacity:.4}
textarea{width:100%;min-height:92px;padding:12px 14px;border:0;border-radius:16px;background:var(--soft);color:var(--text);font:16px -apple-system,sans-serif;resize:none;outline:0;-webkit-appearance:none}
textarea::placeholder{color:var(--muted)}
.empty{padding:22px 6px;text-align:center;color:var(--muted);font-size:14.5px;line-height:1.45}
.ans{margin-top:12px;padding:14px;border-radius:16px;background:var(--soft);white-space:pre-wrap;font-size:15.5px;line-height:1.5;user-select:text;-webkit-user-select:text}
.ans.err{color:#c0392b}
.note{white-space:pre-wrap;font-size:15px;line-height:1.5;user-select:text;-webkit-user-select:text}
.back{display:inline-flex;align-items:center;gap:4px;border:0;background:none;color:var(--sage);font:600 15px -apple-system,sans-serif;padding:8px 0}
</style></head><body>
<header><nav class="tabs" id="tb"></nav><button class="x" id="cl" aria-label="Close"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg></button></header>
<main id="m"></main>
<script>
var TABS=${JSON.stringify(tabs)};
var META={chat:['Chat','<path d="M20 12a8 8 0 0 1-11.7 7L4 20l1-4.1A8 8 0 1 1 20 12z"/>'],notes:['Notes','<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 13h7M9 17h5"/>'],cloud:['Cloud','<path d="M7 18a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 18 10a4 4 0 0 1-.5 8z"/>'],ai:['Ask AI','<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z"/>']};
var post=function(m){try{webkit.messageHandlers.shivo.postMessage(m)}catch(e){}};
var seq=0,pend={},ctx={chats:[],url:'',title:'',host:'',start:true},tab=TABS[0],viewing=null;
function call(type,extra,cb){var id=++seq;pend[id]=cb||function(){};var m={id:id,type:type};for(var k in extra)m[k]=extra[k];post(m)}
window.shivoPanel={
  reply:function(id,d){var f=pend[id];if(!f)return;if(!d||!('delta' in d))delete pend[id];f(d||{})},
  open:function(c){ctx=c||ctx;viewing=null;go(tab)}
};
var $=function(s){return document.querySelector(s)},esc=function(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
function head(){$('#tb').innerHTML=TABS.map(function(t){return '<button data-t="'+t+'" class="'+(t===tab?'on':'')+'"><svg viewBox="0 0 24 24">'+META[t][1]+'</svg>'+META[t][0]+'</button>'}).join('')}
function pageCard(){return ctx.start?'<div class="page"><span>Open a page first, then use the panel on it.</span></div>':'<div class="page"><b>'+esc(ctx.title||ctx.host)+'</b><span>'+esc(ctx.host)+'</span></div>'}
function go(t){tab=t;viewing=null;head();var m=$('#m');m.scrollTop=0;({chat:chat,notes:notes,cloud:cloud,ai:ai})[t](m)}
function chat(m){
  var h=pageCard()+'<h4>Send it to</h4>';
  if(!ctx.chats||!ctx.chats.length)h+='<div class="empty">No conversations yet.<br>Set up Chat to send pages to people.</div><div class="btns"><button class="btn" id="dc">Open Chat</button></div>';
  else h+=ctx.chats.map(function(c){return '<button class="row" data-c="'+esc(c.id)+'" data-n="'+esc(c.name)+'"><i>'+esc((c.name||'?').trim().charAt(0).toUpperCase())+'</i><span class="t">'+esc(c.name)+'</span><span class="ok"></span></button>'}).join('');
  m.innerHTML=h;
  m.querySelectorAll('[data-c]').forEach(function(b){b.onclick=function(){if(ctx.start)return;post({type:'send',chat:b.dataset.c,name:b.dataset.n});b.querySelector('.ok').textContent='Sent'}});
  var d=$('#dc');if(d)d.onclick=function(){post({type:'door',id:'chat'})}
}
function notes(m){
  var h=pageCard()+'<h4>New note</h4><textarea id="nt" placeholder="Write a note about this page…"></textarea><div class="btns"><button class="btn pri" id="ns">Save note</button><button class="btn" id="nc">Clip this page</button></div><h4>Your notes</h4><div id="nl"><div class="empty">Loading…</div></div>';
  m.innerHTML=h;
  $('#ns').onclick=function(){var v=$('#nt').value.trim();if(!v)return;var b=$('#ns');b.disabled=true;call('newnote',{text:v},function(d){b.disabled=false;if(d.ok){$('#nt').value='';list()}else $('#nl').innerHTML='<div class="empty">'+esc(d.error||"Couldn't save")+'</div>'})};
  $('#nc').onclick=function(){if(!ctx.start)post({type:'clip'})};
  list();
  function list(){call('notes',{},function(d){var l=$('#nl');if(!l)return;
    if(d.error)return l.innerHTML='<div class="empty">'+esc(d.error)+'</div>';
    if(!d.items||!d.items.length)return l.innerHTML='<div class="empty">No notes yet. Write one above, or clip a page.</div>';
    l.innerHTML=d.items.map(function(n){return '<button class="row" data-i="'+esc(n.id)+'"><i>&#9998;</i><span class="t">'+esc(n.name.replace(/\\.md$/,''))+'<small>'+esc(n.when||'')+'</small></span></button>'}).join('');
    l.querySelectorAll('[data-i]').forEach(function(b){b.onclick=function(){read(b.dataset.i,b.querySelector('.t').firstChild.textContent)}})})}
  function read(id,name){m.innerHTML='<button class="back" id="bk">&#8249; Notes</button><h4>'+esc(name)+'</h4><div class="note" id="nb">Loading…</div>';$('#bk').onclick=function(){go('notes')};call('note',{item:id},function(d){var b=$('#nb');if(b)b.textContent=d.error||d.text||''})}
}
function cloud(m){
  m.innerHTML=pageCard()+'<h4>Save this page to Cloud</h4><div class="btns"><button class="btn pri" id="sp">Page as PDF</button><button class="btn" id="sl">Link</button></div><h4>Saved</h4><div id="sv"><div class="empty">Loading…</div></div>';
  $('#sp').onclick=function(){if(!ctx.start)post({type:'save',kind:'pdf'})};$('#sl').onclick=function(){if(!ctx.start)post({type:'save',kind:'link'})};
  call('saved',{},function(d){var l=$('#sv');if(!l)return;
    if(d.error)return l.innerHTML='<div class="empty">'+esc(d.error)+'</div>';
    if(!d.items||!d.items.length)return l.innerHTML='<div class="empty">Nothing saved yet.</div>';
    l.innerHTML=d.items.map(function(n){return '<div class="row"><i>'+(/\\.pdf$/i.test(n.name)?'PDF':/\\.md$/i.test(n.name)?'&#128279;':'&#9729;')+'</i><span class="t">'+esc(n.name.replace(/\\.(md|pdf|mht)$/i,''))+'<small>'+esc(n.when||'')+'</small></span></div>'}).join('')})
}
function ai(m){
  m.innerHTML=pageCard()+'<h4>Ask about this page</h4><div class="btns"><button class="btn" data-q="Summarize this page in a few short points.">Summarize</button><button class="btn" data-q="What are the key facts and numbers on this page?">Key facts</button><button class="btn" data-q="Explain this page in simple words.">Explain simply</button></div><textarea id="aq" placeholder="Ask anything about this page…"></textarea><div class="btns"><button class="btn pri" id="ag">Ask</button></div><div id="aa"></div>';
  m.querySelectorAll('[data-q]').forEach(function(b){b.onclick=function(){$('#aq').value=b.dataset.q;run()}});
  $('#ag').onclick=run;
  function run(){var q=$('#aq').value.trim();if(!q||ctx.start)return;var b=$('#ag'),a=$('#aa');b.disabled=true;a.innerHTML='<div class="ans" id="at">Reading the page…</div>';var got='';
    call('ask',{q:q},function(d){var t=$('#at');if(!t)return;
      if(d.error){t.className='ans err';t.textContent=d.error;b.disabled=false;return}
      if('delta' in d){got+=d.delta;t.textContent=got;return}
      b.disabled=false;if(!got)t.textContent='No answer.'})}
}
$('#tb').addEventListener('click',function(e){var b=e.target.closest('button');if(b)go(b.dataset.t)});
$('#cl').onclick=function(){post({type:'close'})};
head();go(tab);
</script></body></html>`;
}
