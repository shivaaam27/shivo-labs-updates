// Live cards on the Lock Screen and in the Dynamic Island (the LiveActivity add-on, kits/app-native/live-activity).
// One card per feature at a time: show() starts it or updates it, done() ends it with a final line.
// Does nothing on phones or builds without the add-on, so features can call it freely.
// Fields: title, subtitle, progress (0..1, or -1 for none), icon (SF Symbol), timerEnd (ms since 1970).
import { plugin } from './native.js';

const ACCENT = '#7FB08B';   // --glow, readable on the dark card
const cards = {};           // kind -> card id (or a promise while it starts)
export let lastError = '';  // why the last card didn't start (shown by the test button)

export async function show(kind, fields) {
  const L = plugin('LiveActivity'); if (!L) return;
  try {
    const id = await cards[kind];
    if (id) return await L.update({ id, ...fields });
    cards[kind] = L.start({ kind, accent: ACCENT, ...fields }).then((r) => { lastError = ''; return r.id; }).catch((e) => { lastError = e?.message || String(e); return null; });
    await cards[kind];
  } catch { delete cards[kind]; }
}

// Step by step, in plain words: is the add-on there, are cards allowed, does one start. Shows a 30-second
// countdown card when all is well. Returns the lines to show.
export async function test() {
  const out = [], L = plugin('LiveActivity');
  if (!L) return ["The live card add-on isn't reachable here (only in the installed iPhone app)."];
  try {
    const s = await L.supported();
    out.push(`Add-on found. iOS ${s.supported ? 'supports' : "doesn't support"} live cards; allowed for this app: ${s.enabled ? 'yes' : 'no'}.`);
    if (!s.supported || !s.enabled) return out;
  } catch (e) { out.push('Add-on missing in this install: ' + (e?.message || e) + '. Install the newest build with X Tools.'); return out; }
  try {
    const r = await L.start({ kind: 'test', accent: ACCENT, title: 'Shivo Labs', subtitle: 'Test card. Lock the phone to see it.', icon: 'bolt.fill', timerEnd: Date.now() + 30000 });
    out.push('Card started. Look at the notch, or lock the phone. It ends in 30 seconds.');
    setTimeout(() => L.end({ id: r.id, done: true, title: 'Test finished', subtitle: '', timerEnd: 0, dismissAfter: 3 }).catch(() => {}), 30000);
  } catch (e) { out.push("Card didn't start: " + (e?.message || e)); }
  return out;
}

export async function done(kind, fields = {}, dismissAfter = 4) {
  const L = plugin('LiveActivity'); if (!L) return;
  const id = await cards[kind]; delete cards[kind];
  if (id) try { await L.end({ id, done: true, progress: -1, ...fields, dismissAfter }); } catch {}
}
