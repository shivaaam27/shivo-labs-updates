// TV inside the phone app: use a TV that runs the Shivo Labs home screen, over the shared Wi-Fi.
// The TV app answers on port 8799 (tv/home/src/labs/shivo/tv/Remote.java). The first time, the phone asks the TV
// for a code, the TV shows 6 digits on screen and the person types them here; the phone then gets its own key
// (kept on this phone, sent as ?k=). Nothing goes online.
// What works: what is playing (pause, play, skip), volume and mute, Home, your apps (open them on the TV), the TV's
// rows (YouTube's picks...), inputs. The full remote (arrows, OK, Back, typing) needs the next app build.
// Layout: one column on a phone; on an iPad or any wide screen the controls sit on the left, the content on the right.
import { deviceName } from '../engine/beam.js';

const PORT = 8799;
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const svg = (d) => `<svg viewBox="0 0 24 24">${d}</svg>`;
const IC = {
  tv: svg('<rect x="3" y="5" width="18" height="12" rx="2.5"/><path d="M8 21h8M12 17v4"/>'),
  play: svg('<path d="M8 5.5v13l10.5-6.5z"/>'),
  pause: svg('<path d="M8 5.5v13M16 5.5v13"/>'),
  next: svg('<path d="M6 6l8 6-8 6zM18 6v12"/>'),
  prev: svg('<path d="M18 6l-8 6 8 6zM6 6v12"/>'),
  minus: svg('<path d="M6 12h12"/>'),
  plus: svg('<path d="M12 6v12M6 12h12"/>'),
  home: svg('<path d="M4 11.5 12 5l8 6.5V19a1 1 0 0 1-1 1h-4.5v-5h-5v5H5a1 1 0 0 1-1-1z"/>'),
  vol: svg('<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M16 9.5a3.5 3.5 0 0 1 0 5M18.5 7a7 7 0 0 1 0 10"/>'),
  mute: svg('<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>'),
  hdmi: svg('<path d="M4 8h16v5l-2 3H6l-2-3z"/><path d="M8 11h8"/>'),
  input: svg('<rect x="3" y="5" width="18" height="12" rx="2.5"/><path d="M8 21h8M12 17v4"/>'),
  phone: svg('<rect x="6.5" y="2.5" width="11" height="19" rx="2.5"/><path d="M10.5 18.5h3"/>'),
  remote: svg('<rect x="7" y="2.5" width="10" height="19" rx="5"/><circle cx="12" cy="8" r="2"/><path d="M10 14h4M10 17h4"/>'),
};
// the big services whose rows are worth showing (no rows from the apps the TV maker put on)
const BIG = [/youtube/, /netflix/, /amazonvideo/, /disneyplus/, /showmax/, /spotify/, /apple\.atve/, /hbo|\.max\b/, /google\.android\.videos/];
const HIDE = /tvlauncher|launcherx|setupwraith|com\.android\.vending|tcl\.settings|tclhome_passive|webview_shell|android\.tv\.settings/;

export function mountTv(root, { toast = () => {}, haptic = () => {} } = {}) {
  const buzz = (k = 'light') => { try { haptic(k); } catch {} };
  let tvs = []; try { tvs = JSON.parse(localStorage.getItem('sl.tv') || '[]'); } catch {}
  const save = () => { try { localStorage.setItem('sl.tv', JSON.stringify(tvs)); } catch {} };
  let cur = tvs[0] || null, apps = [], now = [], shelves = [], inputs = [], hist = [], dev = {}, timer = 0, alive = false, pairing = null;
  let tab = 'foryou';
  try { tab = localStorage.getItem('sl.tvTab') || 'foryou'; } catch {}
  const blobs = new Map();   // pictures fetched from the TV, kept while the app is open

  const url = (host, path, q = {}) => `http://${host}:${PORT}${path}?${new URLSearchParams({ ...q, ...(cur?.key ? { k: cur.key } : {}) })}`;
  async function call(path, q = {}, { host = cur?.host, ms = 6000, post = false } = {}) {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
    try {
      const r = await fetch(url(host, path, q), { method: post ? 'POST' : 'GET', signal: ctl.signal, cache: 'no-store' });
      if (r.status === 401) throw Object.assign(new Error('This phone is no longer paired with the TV. Pair it again.'), { unpaired: true });
      return await r.json();
    } catch (e) {
      if (e.unpaired) throw e;
      throw new Error("Can't reach the TV. Check it is on, showing Shivo Labs, and on the same Wi-Fi as this phone.");
    } finally { clearTimeout(t); }
  }
  // the TV's pictures, fetched with the key and shown from memory
  async function pic(img) {
    const path = img.dataset.tvpic;
    if (blobs.has(path)) { img.src = blobs.get(path); return; }
    try {
      const r = await fetch(url(cur.host, path), { cache: 'force-cache' });
      if (!r.ok) throw 0;
      const u = URL.createObjectURL(await r.blob()); blobs.set(path, u); img.src = u;
    } catch { img.dispatchEvent(new Event('error')); }
  }
  const pics = () => root.querySelectorAll('img[data-tvpic]:not([src])').forEach(pic);
  const web = (a) => /^https?:/.test(a || '') ? a : '';
  const label = (pkg) => apps.find((a) => a.pkg === pkg)?.label || '';
  // what was watched, newest first; a YouTube video has its own thumbnail and resumes at the same point
  const watched = () => hist.filter((h) => apps.some((a) => a.pkg === h.pkg)).slice(0, 10);
  const histPic = (h) => h.vid ? `<img src="https://i.ytimg.com/vi/${esc(h.vid)}/mqdefault.jpg" alt="" loading="lazy">`
    : `<img data-tvpic="/${h.art && h.art.startsWith('np/') ? esc(h.art) : `banner/${esc(h.pkg)}`}" alt="" onerror="this.remove()">`;
  const pct = (h) => h.len > 0 ? Math.min(100, Math.round(100 * h.pos / h.len)) : 0;
  function resume(h) {
    if (!h) return;
    const url = h.vid ? `https://www.youtube.com/watch?v=${h.vid}${h.pos > 30000 ? `&t=${Math.floor(h.pos / 1000)}s` : ''}` : '';
    (url ? act('/openIn', { a: h.pkg, b: url }, 'Continuing on the TV') : act('/open', { a: h.pkg }, 'Opening on the TV')).then(() => setTimeout(pollNow, 2500));
  }

  // ---- not paired yet ----
  function paintPair(err = '') {
    root.innerHTML = `<div class="tvp">
      <div class="tvp-art"><span class="tvp-tv">${IC.tv}</span><span class="tvp-ph">${IC.phone}</span></div>
      <h2 class="tvp-h">${pairing ? 'Type the code on your TV' : 'Connect your TV'}</h2>
      <p class="tvp-p">${pairing ? `${esc(pairing.name)} is showing a 6-digit code now.` : 'Use your Shivo Labs TV from this phone: what is playing, the volume, your apps.'}</p>
      ${pairing ? `
        <input class="tvp-code" id="tvCode" inputmode="numeric" maxlength="7" placeholder="000000" autocomplete="one-time-code">
        <button class="btn pri tvp-btn" id="tvFinish">Pair</button>
        <button class="tvp-link" id="tvBack">Get a new code</button>`
      : `
        <ol class="tvp-steps">
          <li><b>1</b><span>On the TV, open the Shivo Labs home screen.</span></li>
          <li><b>2</b><span>Find its address in <em>Settings › This TV</em>. It looks like 192.168.1.9.</span></li>
          <li><b>3</b><span>Type it here. The TV then shows a code.</span></li>
        </ol>
        <input class="field tvp-host" id="tvHost" inputmode="decimal" placeholder="192.168.1.9" value="${esc(cur?.host || '')}" autocapitalize="off" autocorrect="off" spellcheck="false">
        <button class="btn pri tvp-btn" id="tvStart">Show the code on the TV</button>`}
      <p class="tvp-err" id="tvErr" ${err ? '' : 'hidden'}>${esc(err)}</p>
      <p class="tvp-foot">Phone and TV talk only over your Wi-Fi. The code on the TV screen means only someone in the room can pair.</p>
    </div>`;
    const startBtn = root.querySelector('#tvStart');
    if (startBtn) {
      const go = async () => {
        const host = root.querySelector('#tvHost').value.trim().replace(/^https?:\/\//, '').replace(/[:/].*$/, '');
        if (!host) return toast("Type the TV's address first");
        startBtn.disabled = true; startBtn.textContent = 'Asking the TV…';
        try {
          const hi = await call('/hello', {}, { host, ms: 5000 });
          if (hi.app !== 'shivo-tv') throw new Error('That address is not a TV with Shivo Labs.');
          await call('/pair/start', { a: deviceName() || 'A phone' }, { host, post: true });
          pairing = { host, name: hi.name }; buzz(); paintPair();
          setTimeout(() => root.querySelector('#tvCode')?.focus(), 250);
        } catch (e) { paintPair(e.message); }
      };
      startBtn.onclick = go;
      root.querySelector('#tvHost').onkeydown = (e) => { if (e.key === 'Enter') go(); };
    }
    const fin = root.querySelector('#tvFinish');
    if (fin) {
      const go = async () => {
        const code = root.querySelector('#tvCode').value.replace(/\D/g, '');
        if (code.length !== 6) return toast('The code has 6 digits');
        fin.disabled = true; fin.textContent = 'Pairing…';
        try {
          const r = await call('/pair/finish', { a: code }, { host: pairing.host, post: true });
          if (!r.ok) throw new Error(r.error || 'Pairing failed');
          cur = { host: pairing.host, key: r.key, name: pairing.name };
          tvs = [cur, ...tvs.filter((t) => t.host !== cur.host)]; save();
          pairing = null; buzz('success'); toast('Paired with ' + cur.name); refresh(true);
        } catch (e) { paintPair(e.message); }
      };
      fin.onclick = go;
      const ci = root.querySelector('#tvCode');
      ci.oninput = () => { if (ci.value.replace(/\D/g, '').length === 6) go(); };
      ci.onkeydown = (e) => { if (e.key === 'Enter') go(); };
      root.querySelector('#tvBack').onclick = async () => { const h = pairing.host; pairing = null; paintPair(); root.querySelector('#tvHost').value = h; root.querySelector('#tvStart').click(); };
    }
  }

  // ---- paired ----
  const rowsOf = () => shelves.filter((r) => BIG.some((re) => re.test(r.pkg)))
    .map((r) => ({ ...r, items: r.items.filter((i) => i.title && i.title.trim()) })).filter((r) => r.items.length > 1)
    .sort((a, b) => (/youtube/.test(b.pkg) ? 1 : 0) - (/youtube/.test(a.pkg) ? 1 : 0));
  // the big services first (in the order of BIG), then TV apps, then the rest; A to Z within each
  const rank = (a) => { const i = BIG.findIndex((re) => re.test(a.pkg)); return i >= 0 ? i : a.tv ? 50 : 60; };
  const appList = () => apps.filter((a) => !HIDE.test(a.pkg)).sort((a, b) => (rank(a) - rank(b)) || a.label.localeCompare(b.label));
  const playing = () => now.filter((p) => apps.some((a) => a.pkg === p.pkg));

  function nowHtml() {
    const p = playing()[0];
    if (!p) {
      const h = watched()[0];
      if (!h) return `<section class="tvx-now empty"><span class="tvx-now-ic">${IC.remote}</span>
        <div><b>Nothing playing</b><small>Open an app or a video below and it plays on the TV.</small></div></section>`;
      return `<section class="tvx-now">
        <div class="tvx-now-art">${histPic(h).replace('mqdefault', 'hq720').replace('loading="lazy"', `onerror="if(this.src.includes('hq720'))this.src=this.src.replace('hq720','mqdefault')"`)}<i></i>
          <div class="tvx-now-t"><small>Continue watching · ${esc(label(h.pkg))}</small><b>${esc(h.title)}</b>${h.sub ? `<span>${esc(h.sub)}</span>` : ''}</div></div>
        ${pct(h) ? `<div class="tvx-track"><i style="width:${pct(h)}%"></i></div>` : ''}
        <div class="tvx-now-b"><button class="btn pri tvx-cont" data-resume="0">${IC.play}Continue on the TV</button></div>
      </section>`;
    }
    const pct = p.len > 0 ? Math.min(100, Math.round(100 * p.pos / p.len)) : 0;
    return `<section class="tvx-now">
      <div class="tvx-now-art">${p.art ? `<img data-tvpic="/${esc(p.art.split('?')[0])}" alt="">` : `<img class="ic" data-tvpic="/icon/${esc(p.pkg)}" alt="">`}<i></i>
        <div class="tvx-now-t"><small>${p.playing ? 'Playing' : 'Paused'} on the TV · ${esc(label(p.pkg))}</small><b>${esc(p.title)}</b>${p.sub ? `<span>${esc(p.sub)}</span>` : ''}</div></div>
      ${pct ? `<div class="tvx-track"><i style="width:${pct}%"></i></div>` : ''}
      <div class="tvx-now-b">
        <button class="tvx-btn" data-media="prev" aria-label="Previous">${IC.prev}</button>
        <button class="tvx-btn big" data-media="${p.playing ? 'pause' : 'play'}" aria-label="${p.playing ? 'Pause' : 'Play'}">${p.playing ? IC.pause : IC.play}</button>
        <button class="tvx-btn" data-media="next" aria-label="Next">${IC.next}</button></div>
    </section>`;
  }
  function contentHtml() {
    if (tab === 'apps') {
      return `<div class="tvx-apps">${appList().map((a) => `<button class="tvx-app${a.banner ? '' : ' ic'}" data-open="${esc(a.pkg)}">
        <span class="tvx-app-p">${a.banner ? `<img data-tvpic="/banner/${esc(a.pkg)}" alt="" onerror="this.closest('.tvx-app').classList.add('ic');this.remove()">` : ''}<img class="tvx-app-i" data-tvpic="/icon/${esc(a.pkg)}" alt="" onerror="this.remove()"></span>
        <span class="tvx-app-l">${esc(a.label)}</span></button>`).join('')}</div>`;
    }
    if (tab === 'inputs') {
      return inputs.length ? `<div class="tvx-inputs">${inputs.map((x) => `<button class="tvx-input" data-input="${esc(x.id)}"><span>${/hdmi/i.test(x.label) ? IC.hdmi : IC.input}</span><b>${esc(x.label)}</b><small>Switch the TV to this</small></button>`).join('')}</div>`
        : '<p class="tvx-none">This TV has no inputs to switch to.</p>';
    }
    const rows = rowsOf(), w = watched();
    const contHtml = w.length ? `<h3 class="tvx-h">Continue watching</h3>
      <div class="tvx-strip">${w.map((h, i) => `<button class="tvx-thumb" data-resume="${i}"><span class="tvx-thumb-p">${histPic(h)}${pct(h) ? `<i class="tvx-thumb-bar"><i style="width:${pct(h)}%"></i></i>` : ''}</span>
        <b>${esc(h.title)}</b><small class="tvx-thumb-s">${esc(label(h.pkg))}</small></button>`).join('')}</div>` : '';
    if (!rows.length && w.length) return contHtml;
    if (!rows.length) return '<p class="tvx-none">Nothing to suggest yet. Apps like YouTube fill this in once they have been opened on the TV.</p>';
    return contHtml + rows.map((r) => `<h3 class="tvx-h">${esc(label(r.pkg))}<span>${esc(r.name)}</span></h3>
      <div class="tvx-strip">${r.items.slice(0, 14).map((it) => `<button class="tvx-thumb" data-uri="${esc(it.uri || '')}" data-pkg="${esc(r.pkg)}">
        <span class="tvx-thumb-p">${web(it.art) ? `<img src="${esc(web(it.art))}" alt="" loading="lazy">` : ''}</span><b>${esc(it.title)}</b></button>`).join('')}</div>`).join('');
  }
  function paint() {
    const v = dev.volMax ? Math.round(100 * dev.vol / dev.volMax) : 0;
    root.innerHTML = `<div class="tvx">
      <aside class="tvx-side">
        <section class="tvx-tv"><span class="tvx-tv-ic">${IC.tv}</span>
          <div><b>${esc(cur.name || 'TV')}</b><small><i class="dot"></i>Connected · ${esc(cur.host)}</small></div></section>
        <div id="tvNow">${nowHtml()}</div>
        <section class="tvx-ctl">
          <div class="tvx-vol">
            <button class="tvx-btn" data-vol="-1" aria-label="Quieter">${IC.minus}</button>
            <div class="tvx-vol-m"><div class="tvx-vol-top"><span>${dev.muted ? IC.mute : IC.vol}</span><b id="tvVolN">${dev.vol ?? '–'}</b></div><div class="tvx-track"><i id="tvVolBar" style="width:${v}%"></i></div></div>
            <button class="tvx-btn" data-vol="1" aria-label="Louder">${IC.plus}</button>
          </div>
          <div class="tvx-quick">
            <button class="tvx-q" id="tvHome">${IC.home}<span>Home</span></button>
            <button class="tvx-q" id="tvMute">${IC.mute}<span>Mute</span></button>
            <button class="tvx-q" id="tvInputs">${IC.hdmi}<span>Inputs</span></button>
          </div>
        </section>
        <p class="tvx-later">${IC.remote}<span>Arrows, OK, Back and typing come with the next app update.</span></p>
      </aside>
      <main class="tvx-main">
        <div class="seg tvx-seg">${[['foryou', 'For you'], ['apps', 'Apps'], ['inputs', 'Inputs']].map(([id, n]) => `<button data-tab="${id}" class="${tab === id ? 'on' : ''}">${n}</button>`).join('')}</div>
        <div class="tvx-content" id="tvContent">${contentHtml()}</div>
        <button class="tvx-forget" id="tvForget">Forget this TV</button>
      </main>
    </div>`;
    wire();
    pics();
  }
  function wire() {
    root.querySelector('#tvHome').onclick = () => act('/home', {}, 'Home on the TV');
    root.querySelector('#tvMute').onclick = () => act('/mute', {}).then((r) => { if (r) { dev.muted = r.muted; toast(r.muted ? 'TV muted' : 'Sound on'); } });
    root.querySelector('#tvInputs').onclick = () => setTab('inputs');
    root.querySelectorAll('[data-vol]').forEach((b) => (b.onclick = async () => {
      buzz();
      try {
        const r = await call('/volume', { a: b.dataset.vol }, { post: true }); dev.vol = r.vol;
        root.querySelector('#tvVolN').textContent = r.vol;
        root.querySelector('#tvVolBar').style.width = `${dev.volMax ? Math.round(100 * r.vol / dev.volMax) : 0}%`;
      } catch (e) { toast(e.message); }
    }));
    wireNow();
    root.querySelectorAll('[data-tab]').forEach((b) => (b.onclick = () => setTab(b.dataset.tab)));
    wireContent();
    root.querySelector('#tvForget').onclick = () => {
      tvs = tvs.filter((t) => t.host !== cur.host); save(); cur = tvs[0] || null; apps = []; now = []; shelves = [];
      toast('This phone forgot the TV'); cur ? refresh(true) : paintPair();
    };
  }
  function wireNow() {
    root.querySelectorAll('#tvNow [data-resume]').forEach((b) => (b.onclick = () => resume(watched()[+b.dataset.resume])));
    root.querySelectorAll('[data-media]').forEach((b) => (b.onclick = () => {
      const p = playing()[0]; if (!p) return;
      act('/media', { a: p.pkg, b: b.dataset.media }).then(() => setTimeout(pollNow, 700));
    }));
  }
  function wireContent() {
    root.querySelectorAll('[data-open]').forEach((b) => (b.onclick = () => act('/open', { a: b.dataset.open }, `Opening ${label(b.dataset.open)} on the TV`)));
    root.querySelectorAll('[data-input]').forEach((b) => (b.onclick = () => act('/input', { a: b.dataset.input }, 'Switching the TV')));
    root.querySelectorAll('[data-resume]').forEach((b) => (b.onclick = () => resume(watched()[+b.dataset.resume])));
    root.querySelectorAll('.tvx-thumb:not([data-resume])').forEach((b) => (b.onclick = () => act(b.dataset.uri ? '/openUri' : '/open', { a: b.dataset.uri || b.dataset.pkg }, 'Playing on the TV').then(() => setTimeout(pollNow, 2500))));
  }
  function setTab(t) {
    tab = t; try { localStorage.setItem('sl.tvTab', t); } catch {}
    buzz();
    root.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
    const c = root.querySelector('#tvContent'); c.innerHTML = contentHtml(); c.classList.remove('in'); void c.offsetWidth; c.classList.add('in');
    wireContent(); pics();
  }
  async function act(path, q, msg) {
    buzz();
    try { const r = await call(path, q, { post: true }); if (r.ok === false) throw new Error("The TV couldn't do that"); if (msg) toast(msg); return r; }
    catch (e) { toast(e.message); }
  }
  async function pollNow() {
    try {
      const n = await call('/now', {}, { ms: 4000 });
      const h = await call('/history', {}, { ms: 4000 }).catch(() => hist);
      const hChanged = JSON.stringify(h.slice(0, 3).map((x) => [x.title, x.vid])) !== JSON.stringify(hist.slice(0, 3).map((x) => [x.title, x.vid]));
      hist = h;
      if (hChanged && tab === 'foryou') { const c = root.querySelector('#tvContent'); if (c) { c.innerHTML = contentHtml(); wireContent(); pics(); } }
      if (hChanged || JSON.stringify(n.map((p) => [p.title, p.playing])) !== JSON.stringify(now.map((p) => [p.title, p.playing]))) {
        now = n; const box = root.querySelector('#tvNow'); if (box) { box.innerHTML = nowHtml(); wireNow(); pics(); }
      }
    } catch {}
  }

  async function refresh(full = false) {
    if (!cur) return paintPair();
    try {
      if (full || !apps.length) {
        root.innerHTML = `<div class="tvx-wait"><span class="tvx-tv-ic">${IC.tv}</span><p>Connecting to ${esc(cur.name || 'the TV')}…</p></div>`;
        [apps, dev, shelves, inputs, hist] = await Promise.all([call('/apps'), call('/device'), call('/shelves'), call('/inputs'), call('/history').catch(() => [])]);
        inputs.sort((a, b) => a.label.localeCompare(b.label, undefined, { numeric: true }));
      }
      now = await call('/now');
      paint();
    } catch (e) {
      if (e.unpaired) { tvs = tvs.filter((t) => t.host !== cur.host); save(); cur = null; return paintPair(e.message); }
      root.innerHTML = `<div class="tvp"><div class="tvp-art off"><span class="tvp-tv">${IC.tv}</span></div>
        <h2 class="tvp-h">Can't reach ${esc(cur.name || 'the TV')}</h2><p class="tvp-p">${esc(e.message)}</p>
        <button class="btn pri tvp-btn" id="tvRetry">Try again</button><button class="tvp-link" id="tvOther">Use a different TV</button></div>`;
      root.querySelector('#tvRetry').onclick = () => refresh(true);
      root.querySelector('#tvOther').onclick = () => { cur = null; paintPair(); };
    }
  }

  return {
    // the screen is shown: fresh look, then what is playing every few seconds
    start() { alive = true; refresh(!apps.length); clearInterval(timer); timer = setInterval(() => { if (alive && cur && apps.length && !document.hidden) pollNow(); }, 5000); },
    stop() { alive = false; clearInterval(timer); },
  };
}
